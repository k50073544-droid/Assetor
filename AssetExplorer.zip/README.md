# Asset Explorer

An Android app that unpacks Brawl Stars game files from a .zip (APK, XAPK or a zip containing the `assets` folder) and lets you:

- sort files by **type** (3D, textures, 2D .sc, images, sounds, music, csv…) and **theme** (pins, icons, skins, brawlers, maps, effects…);
- compare **versions**: import several zips, and the "Updates" screen shows what was added, changed and removed;
- search by file name, including Russian words (пин, скин, 3д, текстура, звук…);
- view textures (SCTX / KTX / ZKTX / _tex.sc: ASTC, ETC1/2, RGBA…) with zoom, play sounds and read csv files;
- view **3D models** (.glb, including Supercell's flatbuffer + Odin glTF) with their textures: rotate, zoom, hide parts, pick another skin texture, save a PNG or export a plain `.glb` that Blender opens;
- models are drawn on the GPU (OpenGL ES 2.0, 4× antialiasing, mipmapped textures), with the CPU renderer as fallback and for PNG export;
- brawlers get their **face** (eyes, mouth: a 2D export from `characters.sc`, see `faces.csv`, painted over the body texture) and play their **animations** (skinning; animations listed per skin from `skin_confs.csv` + `animations.csv`, or by file name).
- **Brawlers · Cosmetics · Boxes** (button on the main screen), all read from the game tables of the imported version, so a newer game zip brings the newest brawlers:
  - every brawler with portrait, rarity, numbers, skins, all animations (open in 3D with the skin texture), voice lines, gadgets / star powers / hypercharge;
  - the brawler list and the brawler screen are laid out like the game's (landscape), with the game's font and icons;
  - **GIF** on the brawler screen: the chosen skin does its attack or super with the game's own effects (`fx/*._bin` clips and particle emitters from `particle_emitters.json.flex`, projectile clips, trails and range-end puffs from `projectiles_skin.csv`, explosions from `area_effects_skin.csv`), rendered frame by frame and saved as a .gif;
  - cosmetics: all skins (3D), pins (with sound), sprays and player icons;
  - boxes: Starr Drops (rarity drawn with the game's odds, upgrade animation, Starr's face, sounds), chaos drops and every container from `random_reward_containers.csv` with rewards rolled from `random_rewards.csv` (simulation only);
  - content switched off in the tables (transformed forms, event brawlers, hidden skins) is listed too, marked «скрыт».
- **Что нового**: patch notes between any two imported versions, written from the tables — new brawlers with their kit, balance changes (▲ buff / ▼ nerf: health, speed, damage, range, reload, super charge, gadget cooldowns, star power and gadget numbers inside their descriptions), new gadgets / star powers / hypercharges, new skins with prices, modes, maps, pins / sprays / icons, music and texts; share or copy as text.
- **Карты**: every map of every mode (`maps.csv` + `locations.csv`) drawn from above like the map maker, with search, mode filter and hidden maps; open one to see it in 3D and turn around it. Scenery follows `location_themes.csv`: ground and surroundings, every tile model (decorations and damageable walls included) turned by the theme's angle steps, water built from the theme's shore pieces (`*_water_geo.glb`, its texture is a 2D export such as `effects.sc#tex_water_tile`), the theme's background colour; **«Окружение»** puts any other theme on the map.
- **Играть за новых бойцов**: bots on any map, in any mode — Gem Grab, Showdown, Brawl Ball, Bounty, Knockout and this version's Hide and Seek (`HunterSurvivor`), Super Hockey (`SuperHockey`, charge the puck, goalkeepers on `g`) and Mega Boss Duo (`MegaBoss20P`, the boss comes back stronger after every defeat) — in any location theme. Playable: brawlers new compared with the previous imported version, and hidden ones. Cosmo and Vince have their own mechanics (`codec/Specials.java`): orbiting shots and the magnet super; caterpillars, moths, the levelled super and the mark; both gadgets and star powers, chosen before the battle. Numbers that live only in the game's code are set from the descriptions and listed in `Specials.ASSUMED`.
- **Музыка и звуки**: all of `music.csv` (menus, battles, seasons, wins and losses, which location themes use a track) with a player, and all of `sounds.csv` grouped into voice lines and sounds by brawler, interface and battle; long tap saves the .ogg.
- save single files or a whole filtered list, with textures converted to PNG.

The APK is built by GitHub Actions (`.github/workflows/build.yml`) and lands in Releases.

## Third-party notes
- SC2 matrix-bank and compressed frame decoding is a Java reimplementation of the logic in
  [SupercellFlash](https://github.com/sc-workshop/SupercellFlash) (MIT License, Copyright (c) 2025 SC Workshop).
- Supercell flat glTF (FlatBuffer schema, Odin vertex layout) follows
  [Supercell-Flat-Converter](https://github.com/Daniil-SV/Supercell-Flat-Converter) by Daniil-SV.
- LZMA via [XZ for Java](https://tukaani.org/xz/java.html) (public domain / 0BSD).
