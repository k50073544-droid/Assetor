# Asset Explorer

An Android app that unpacks Brawl Stars game files from a .zip (APK, XAPK or a zip containing the `assets` folder) and lets you:

- sort files by **type** (3D, textures, 2D .sc, images, sounds, music, csv…) and **theme** (pins, icons, skins, brawlers, maps, effects…);
- compare **versions**: import several zips, and the "Updates" screen shows what was added, changed and removed;
- search by file name, including Russian words (пин, скин, 3д, текстура, звук…);
- view textures (SCTX / KTX / ZKTX / _tex.sc: ASTC, ETC1/2, RGBA…) with zoom, play sounds and read csv files;
- save single files or a whole filtered list, with textures converted to PNG.

The APK is built by GitHub Actions (`.github/workflows/build.yml`) and lands in Releases.
