# Asset Explorer

An Android app that unpacks Brawl Stars game files from a .zip (APK, XAPK or a zip containing the `assets` folder) and lets you:

- sort files by **type** (3D, textures, 2D .sc, images, sounds, music, csv…) and **theme** (pins, icons, skins, brawlers, maps, effects…);
- compare **versions**: import several zips, and the "Updates" screen shows what was added, changed and removed;
- search by file name, including Russian words (пин, скин, 3д, текстура, звук…);
- view textures (SCTX / KTX / ZKTX / _tex.sc: ASTC, ETC1/2, RGBA…) with zoom, play sounds and read csv files;
- view **3D models** (.glb, including Supercell's flatbuffer + Odin glTF) with their textures: rotate, zoom, hide parts, pick another skin texture, save a PNG or export a plain `.glb` that Blender opens;
- models are drawn on the GPU (OpenGL ES 2.0, 4× antialiasing, mipmapped textures), with the CPU renderer as fallback and for PNG export;
- brawlers get their **face** (eyes, mouth: a 2D export from `characters.sc`, see `faces.csv`, painted over the body texture) and play their **animations** (skinning; animations listed per skin from `skin_confs.csv` + `animations.csv`, or by file name).
- save single files or a whole filtered list, with textures converted to PNG.

The APK is built by GitHub Actions (`.github/workflows/build.yml`) and lands in Releases.

## Third-party notes
- SC2 matrix-bank and compressed frame decoding is a Java reimplementation of the logic in
  [SupercellFlash](https://github.com/sc-workshop/SupercellFlash) (MIT License, Copyright (c) 2025 SC Workshop).
- Supercell flat glTF (FlatBuffer schema, Odin vertex layout) follows
  [Supercell-Flat-Converter](https://github.com/Daniil-SV/Supercell-Flat-Converter) by Daniil-SV.
- LZMA via [XZ for Java](https://tukaani.org/xz/java.html) (public domain / 0BSD).
