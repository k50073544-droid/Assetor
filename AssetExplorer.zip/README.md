# Asset Explorer

An Android app that unpacks Brawl Stars game files from a .zip (APK, XAPK or a zip containing the `assets` folder) and lets you:

- sort files by **type** (3D, textures, 2D .sc, images, sounds, music, csv…) and **theme** (pins, icons, skins, brawlers, maps, effects…);
- compare **versions**: import several zips, and the "Updates" screen shows what was added, changed and removed;
- search by file name, including Russian words (пин, скин, 3д, текстура, звук…);
- view textures (SCTX / KTX / ZKTX / _tex.sc: ASTC, ETC1/2, RGBA…) with zoom, play sounds and read csv files;
- save single files or a whole filtered list, with textures converted to PNG;
- **Бойцы**: every brawler's 2D effects grouped by ability (attack, super, gadgets, star powers, hypercharge, spawn, lobby) and skin, in blue or red team colours. **«Собрать вместе»** plays all pieces of an ability as one scene: start at the brawler, the projectile and trails flying, then each outcome (hit a brawler, hit a wall, max range) as its own shot. Pieces can be switched on/off; the scene saves as GIF or PNG.

### How abilities are found
- By export names in `sc/effects_brawler*.sc`: `<brawler>_<skin>_<ability>_<part>[_NN][_red]` — `atk`, `ulti`, `gadget1/2`, `sp`, `oc` (hypercharge), `buddy`/`buffy` (buffies).
- By the game tables when the zip has them (`csv_logic/characters.csv`, `skills.csv`, `cards.csv`, `accessories.csv`, `projectiles_skin.csv`, `area_effects_skin.csv`, `localization/ru.csv`): default-look projectiles with old names (e.g. `bullet_shotgun_def_blue_long`), Russian names of brawlers, gadgets, star powers and hypercharges.
- Particle effects from `fx/*._bin` are not drawn (separate particle format).

The APK is built by GitHub Actions (`.github/workflows/build.yml`) and lands in Releases.

## Third-party notes
- SC2 matrix-bank and compressed frame decoding is a Java reimplementation of the logic in
  [SupercellFlash](https://github.com/sc-workshop/SupercellFlash) (MIT License, Copyright (c) 2025 SC Workshop).
- LZMA via [XZ for Java](https://tukaani.org/xz/java.html) (public domain / 0BSD).
