package com.weker.assetexplorer.codec;

public class Battle {
    // Codec module
}
