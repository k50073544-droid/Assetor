package com.weker.assetexplorer.codec;

public class BoxSim {
    // Codec module
}
