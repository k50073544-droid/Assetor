package com.weker.assetexplorer.codec;

public class Glb {
    // Codec module
}
