package com.weker.assetexplorer;

public class GameUi {
    // Module component
}
