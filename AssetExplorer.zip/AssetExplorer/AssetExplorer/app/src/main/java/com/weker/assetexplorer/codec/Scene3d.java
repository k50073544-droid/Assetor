package com.weker.assetexplorer.codec;

public class Scene3d {
    // Codec module
}
