package com.weker.assetexplorer;

public class GameButton {
    // Module component
}
