package com.weker.assetexplorer;

public class SpritesActivity {
    // Module component
}
