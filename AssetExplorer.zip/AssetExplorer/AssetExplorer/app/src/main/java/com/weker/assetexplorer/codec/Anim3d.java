package com.weker.assetexplorer.codec;

public class Anim3d {
    // Codec module
}
