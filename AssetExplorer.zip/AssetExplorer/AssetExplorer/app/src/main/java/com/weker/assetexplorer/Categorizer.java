package com.weker.assetexplorer;

public class Categorizer {
    // Module component
}
