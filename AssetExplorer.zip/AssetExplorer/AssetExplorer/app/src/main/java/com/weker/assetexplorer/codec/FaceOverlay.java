package com.weker.assetexplorer.codec;

public class FaceOverlay {
    // Codec module
}
