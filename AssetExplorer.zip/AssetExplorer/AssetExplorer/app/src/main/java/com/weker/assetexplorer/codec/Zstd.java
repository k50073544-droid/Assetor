package com.weker.assetexplorer.codec;

public class Zstd {
    // Codec module
}
