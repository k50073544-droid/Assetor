package com.weker.assetexplorer.codec;

public class Render3d {
    // Codec module
}
