package com.weker.assetexplorer.codec;

public class PixelFormats {
    // Codec module
}
