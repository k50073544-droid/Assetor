package com.weker.assetexplorer.codec;

public class SupercellFiles {
    // Codec module
}
