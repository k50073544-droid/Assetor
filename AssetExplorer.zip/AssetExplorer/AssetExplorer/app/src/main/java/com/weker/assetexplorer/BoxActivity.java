package com.weker.assetexplorer;

public class BoxActivity {
    // Module component
}
