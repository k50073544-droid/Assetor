package com.weker.assetexplorer;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.List;

public class MainActivity extends Activity {
    private ListView packetListView;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        TextView title = new TextView(this);
        title.setText("AssetExplorer Pro - Live Packet Interceptor & Updates");
        title.setTextSize(16f);
        layout.addView(title);

        Button checkBtn = new Button(this);
        checkBtn.setText("Проверить обновления");
        checkBtn.setOnClickListener(v -> {
            UpdateChecker.checkForUpdates(this, "https://raw.githubusercontent.com/weker/assetexplorer/main/changelog.txt");
        });
        layout.addView(checkBtn);

        Button simulatePacketBtn = new Button(this);
        simulatePacketBtn.setText("Симулировать пакет сервера");
        simulatePacketBtn.setOnClickListener(v -> {
            PacketInspector.captureServerPacket("AssetDataSync: 120 items updated, assets verified.");
            refreshPacketList();
        });
        layout.addView(simulatePacketBtn);

        packetListView = new ListView(this);
        layout.addView(packetListView);

        setContentView(layout);
        refreshPacketList();
    }

    private void refreshPacketList() {
        List<String> packets = PacketInspector.getInterceptedPackets();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, packets);
        packetListView.setAdapter(adapter);
    }
}
