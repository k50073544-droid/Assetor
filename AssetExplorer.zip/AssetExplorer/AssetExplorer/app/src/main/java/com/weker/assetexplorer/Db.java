package com.weker.assetexplorer;

public class Db {
    // Module component
}
