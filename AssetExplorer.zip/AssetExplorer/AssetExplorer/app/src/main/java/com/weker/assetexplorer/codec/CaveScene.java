package com.weker.assetexplorer.codec;

public class CaveScene {
    // Codec module
}
