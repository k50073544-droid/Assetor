package com.weker.assetexplorer.codec;

public class Assets {
    // Codec module
}
