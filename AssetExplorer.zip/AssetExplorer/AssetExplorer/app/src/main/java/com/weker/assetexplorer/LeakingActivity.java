package com.weker.assetexplorer;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class LeakingActivity extends Activity {

    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> leakedItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Инициализируем список для предотвращения NullPointerException
        leakedItems = new ArrayList<>();

        // Безопасно получаем список файлов внешнего хранилища
        File filesDir = getExternalFilesDir(null);
        if (filesDir != null && filesDir.exists()) {
            File[] files = filesDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    leakedItems.add(file.getName());
                }
            }
        }

        // Явно указываем generic-тип <String>, чтобы избежать ошибки вывода типов (cannot infer type arguments)
        adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                leakedItems
        );

        listView = new ListView(this);
        listView.setAdapter(adapter);
        setContentView(listView);
    }
}
