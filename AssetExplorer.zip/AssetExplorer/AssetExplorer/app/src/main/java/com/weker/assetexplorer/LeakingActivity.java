package com.weker.assetexplorer;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.weker.assetexplorer.codec.LeakingCsvParser;
import java.io.File;
import java.util.ArrayList;
import java.util.Map;

/**
 * Экран датамайнера для сканирования распакованных ассетов.
 */
public class LeakingActivity extends AppCompatActivity {

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        listView = new ListView(this);
        setContentView(listView);

        loadLeaks();
    }

    private void loadLeaks() {
        ArrayList<String> leakedItems = new ArrayList<>();
        leakedItems.add("🔍 Поиск утечек и неанонсированного контента...");

        File assetsDir = getExternalFilesDir(null);
        if (assetsDir != null && assetsDir.exists()) {
            File[] files = assetsDir.listFiles();
            if (files != null && files.length > 0) {
                for (File file : files) {
                    if (file.getName().endsWith(".csv")) {
                        Map<String, String> entries = LeakingCsvParser.parseCsvChanges(file);
                        leakedItems.add("📄 Конфиг: " + file.getName() + " [" + entries.size() + " записей]");
                    }
                }
            } else {
                leakedItems.add("⚠️ В директории ассетов пока нет файлов.");
            }
        } else {
            leakedItems.add("⚠️ Директива ассетов не найдена.");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, leakedItems);
        listView.setAdapter(adapter);
    }
}
