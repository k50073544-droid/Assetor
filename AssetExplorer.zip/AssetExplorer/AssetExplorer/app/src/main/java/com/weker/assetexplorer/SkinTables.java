package com.weker.assetexplorer;

public class SkinTables {
    // Module component
}
