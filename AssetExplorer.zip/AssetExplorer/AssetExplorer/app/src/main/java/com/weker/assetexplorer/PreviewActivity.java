package com.weker.assetexplorer;

public class PreviewActivity {
    // Module component
}
