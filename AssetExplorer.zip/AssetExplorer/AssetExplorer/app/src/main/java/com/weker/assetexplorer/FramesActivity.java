package com.weker.assetexplorer;

public class FramesActivity {
    // Module component
}
