package com.weker.assetexplorer.codec;

public class BattleFx {
    // Codec module
}
