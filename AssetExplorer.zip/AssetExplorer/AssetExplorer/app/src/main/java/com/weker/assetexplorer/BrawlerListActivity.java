package com.weker.assetexplorer;

public class BrawlerListActivity {
    // Module component
}
