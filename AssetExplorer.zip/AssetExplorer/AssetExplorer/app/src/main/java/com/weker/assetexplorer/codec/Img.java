package com.weker.assetexplorer.codec;

public class Img {
    // Codec module
}
