package com.weker.assetexplorer.codec;

public class GifEncoder {
    // Codec module
}
