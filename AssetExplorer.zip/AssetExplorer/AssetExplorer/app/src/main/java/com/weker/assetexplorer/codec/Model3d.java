package com.weker.assetexplorer.codec;

public class Model3d {
    // Codec module
}
