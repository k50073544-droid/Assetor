package com.weker.assetexplorer;

public class Thumbs {
    // Module component
}
