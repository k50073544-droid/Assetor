package com.weker.assetexplorer.codec;

public class ScSprites {
    // Codec module
}
