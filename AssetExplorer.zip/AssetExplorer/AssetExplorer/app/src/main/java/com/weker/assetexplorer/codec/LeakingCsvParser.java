package com.weker.assetexplorer.codec;

public class LeakingCsvParser {
    // Codec module
}
