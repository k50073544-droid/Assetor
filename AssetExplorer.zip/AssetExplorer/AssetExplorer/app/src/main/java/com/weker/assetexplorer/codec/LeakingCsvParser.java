package com.weker.assetexplorer.codec;

import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Парсер CSV-конфигураций для датамайнинга и поиска скрытого контента.
 */
public class LeakingCsvParser {
    private static final String TAG = "LeakingCsvParser";

    public static Map<String, String> parseCsvChanges(File csvFile) {
        Map<String, String> dataMap = new HashMap<>();
        if (csvFile == null || !csvFile.exists()) return dataMap;

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Пропускаем комментарии Supercell и пустые строки
                if (line.startsWith("#") || line.trim().isEmpty()) continue;
                
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    dataMap.put(parts[0].trim(), parts[1].trim());
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "Ошибка чтения CSV: " + e.getMessage());
        }
        
        return dataMap;
    }
}
