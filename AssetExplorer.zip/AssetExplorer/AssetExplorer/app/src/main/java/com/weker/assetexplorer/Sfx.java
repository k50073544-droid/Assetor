package com.weker.assetexplorer;

public class Sfx {
    // Module component
}
