package com.weker.assetexplorer;

public class GameData {
    // Module component
}
