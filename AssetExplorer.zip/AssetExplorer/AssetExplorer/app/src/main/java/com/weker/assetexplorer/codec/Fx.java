package com.weker.assetexplorer.codec;

public class Fx {
    // Codec module
}
