package com.weker.assetexplorer.codec;

public class AxmlDecoder {
    // Codec module
}
