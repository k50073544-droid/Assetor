package com.weker.assetexplorer.codec;

public class Astc {
    // Codec module
}
