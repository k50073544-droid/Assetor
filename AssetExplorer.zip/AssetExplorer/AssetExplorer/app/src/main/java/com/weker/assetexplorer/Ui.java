package com.weker.assetexplorer;

public class Ui {
    // Module component
}
