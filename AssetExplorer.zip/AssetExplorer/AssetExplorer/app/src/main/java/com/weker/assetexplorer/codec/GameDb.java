package com.weker.assetexplorer.codec;

public class GameDb {
    // Codec module
}
