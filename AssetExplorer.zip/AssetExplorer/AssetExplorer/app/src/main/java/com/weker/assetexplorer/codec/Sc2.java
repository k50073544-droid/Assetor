package com.weker.assetexplorer.codec;

public class Sc2 {
    // Codec module
}
