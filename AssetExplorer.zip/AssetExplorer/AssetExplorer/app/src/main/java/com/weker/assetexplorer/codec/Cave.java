package com.weker.assetexplorer.codec;

public class Cave {
    // Codec module
}
