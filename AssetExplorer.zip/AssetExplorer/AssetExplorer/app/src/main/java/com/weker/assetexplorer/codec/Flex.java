package com.weker.assetexplorer.codec;

public class Flex {
    // Codec module
}
