package com.weker.assetexplorer.codec;

public class Etc {
    // Codec module
}
