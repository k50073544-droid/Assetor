package com.weker.assetexplorer.codec;

public class BattleScene {
    // Codec module
}
