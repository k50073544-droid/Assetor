package com.weker.assetexplorer;

public class SoftModelView {
    // Module component
}
