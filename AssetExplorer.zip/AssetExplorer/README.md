# AssetExplorer Pro
Fixed Gradle plugin resolution for Android build.
