package com.weker.assetexplorer;

import android.content.Context;

import java.io.File;

/** Content-addressed storage: identical files across versions are stored once. */
public final class Blobs {

    private Blobs() {}

    public static File dir(Context c) {
        File d = new File(c.getFilesDir(), "blobs");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    public static File file(File dir, String key) {
        String sub = key.length() >= 2 ? key.substring(0, 2) : "00";
        return new File(new File(dir, sub), key);
    }

    public static File file(Context c, String key) {
        return file(dir(c), key);
    }
}
