package com.weker.assetexplorer.codec;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The game's visual effects, played from its own files:
 * {@code fx/<name>._bin} lists what an effect is made of (2D clips from .sc files, particle emitters,
 * other effects, sounds); {@code particle_emitters.json.flex} describes each emitter (spawn rate, speeds,
 * gravity, lifetime, scale / alpha over life, which clips the particles show).
 * World units are tiles, y is up; effects face an angle (0 = +z).
 */
public final class Fx {

    /** pictures of .sc clips, supplied by the platform (cached) */
    public interface Sprites {
        /** frame of a clip, or null; bounds are in .sc units */
        Sprite get(String file, String export, int frame);

        int frames(String file, String export);

        int fps(String file, String export);
    }

    public static final class Sprite {
        public Img img;
        /** clip-space rectangle the picture covers (x right, y down) */
        public float x0, y0, x1, y1;
        Model3d quad;
    }

    /** .sc units per tile (a brawler's shadow, 32 units, is about 0.75 tile) */
    public static float UNITS_PER_TILE = 44f;
    /** emitter distances are in the game's range units: a third of a tile (CastingRange 23 = 7.7 tiles) */
    public static float EMITTER_UNIT = 1f / 3f;

    final GameDb.Source src;
    public Sprites sprites;
    byte[] emitterData;
    boolean emitterTried;
    final Map<String, List<String[]>> effects = new HashMap<>();
    final Map<String, Map<String, Object>> emitters = new HashMap<>();
    /** sound names the effects asked for since the last call to {@link #takeSounds} */
    final List<String> sounds = new ArrayList<>();
    final Random rnd = new Random();
    final List<Particle> particles = new ArrayList<>();
    final List<Emitter> running = new ArrayList<>();
    final List<Clip> clips = new ArrayList<>();
    public int maxParticles = 600;

    public Fx(GameDb.Source src, Sprites sprites) {
        this.src = src;
        this.sprites = sprites;
    }

    // ------------------------------------------------------------------ effect files
    /** {kind, a, b}: kind SWF (file, export), EMITTER (name), EFFECT (name), SOUND (name) */
    synchronized List<String[]> effect(String name) {
        if (effects.containsKey(name)) return effects.get(name);
        List<String[]> out = new ArrayList<>();
        byte[] d = src.read(name + "._bin");
        if (d != null) parse(d, out);
        effects.put(name, out);
        return out;
    }

    /** the strings of an effect file (each one: 4-byte big-endian length + text) in order */
    static void parse(byte[] d, List<String[]> out) {
        List<String> t = new ArrayList<>();
        for (int i = 0; i + 4 < d.length; ) {
            int len = ((d[i] & 255) << 24) | ((d[i + 1] & 255) << 16) | ((d[i + 2] & 255) << 8) | (d[i + 3] & 255);
            if (len > 0 && len < 300 && i + 4 + len <= d.length && printable(d, i + 4, len)) {
                t.add(new String(d, i + 4, len, StandardCharsets.UTF_8));
                i += 4 + len;
            } else {
                i++;
            }
        }
        String pendingFile = null;
        for (int k = 0; k < t.size(); k++) {
            String s = t.get(k);
            switch (s) {
                case "SWF": {
                    // file, then the clip
                    String f = k + 1 < t.size() ? strip(t.get(k + 1)) : null;
                    String e = k + 2 < t.size() ? strip(t.get(k + 2)) : null;
                    if (f != null && f.endsWith(".sc") && e != null) {
                        out.add(new String[]{"SWF", GameDb.fileName(f), e});
                        k += 2;
                        pendingFile = GameDb.fileName(f);
                    }
                    break;
                }
                case "Emitter":
                    if (k + 1 < t.size()) out.add(new String[]{"EMITTER", strip(t.get(++k))});
                    break;
                case "Effect":
                    if (k + 1 < t.size()) out.add(new String[]{"EFFECT", strip(t.get(++k))});
                    break;
                case "Sound":
                    if (k + 1 < t.size() && !t.get(k + 1).contains(" | ")) out.add(new String[]{"SOUND", t.get(++k)});
                    break;
                default:
                    // a second clip of the same file
                    if (pendingFile != null && s.contains(" | 49e9c85e")) out.add(new String[]{"SWF", pendingFile, strip(s)});
                    break;
            }
        }
    }

    static boolean printable(byte[] d, int o, int n) {
        for (int i = 0; i < n; i++) {
            int c = d[o + i] & 255;
            if (c < 32 || c > 126) return false;
        }
        return true;
    }

    /** "name | uuid" → "name" */
    static String strip(String s) {
        int i = s.indexOf(" | ");
        return i >= 0 ? s.substring(0, i) : s;
    }

    @SuppressWarnings("unchecked")
    synchronized Map<String, Object> emitter(String name) {
        if (emitters.containsKey(name)) return emitters.get(name);
        if (!emitterTried) {
            emitterTried = true;
            emitterData = src.read("particle_emitters.json.flex");
        }
        Map<String, Object> e = null;
        if (emitterData != null) {
            try {
                Object o = Flex.lookup(emitterData, 0, emitterData.length, name);
                if (o instanceof Map) e = (Map<String, Object>) o;
            } catch (Throwable ignored) {
                // broken entry
            }
        }
        emitters.put(name, e);
        return e;
    }

    /** sounds to play now */
    public synchronized List<String> takeSounds() {
        List<String> l = new ArrayList<>(sounds);
        sounds.clear();
        return l;
    }

    // ------------------------------------------------------------------ playing
    /**
     * Starts an effect at a point (h = height above the ground) facing an angle.
     * @param scale 1 = as the game draws it
     */
    public synchronized void play(String name, float x, float h, float z, float angle, float scale) {
        play(name, x, h, z, angle, scale, 0);
    }

    void play(String name, float x, float h, float z, float angle, float scale, int depth) {
        if (name == null || name.isEmpty() || depth > 4) return;
        for (String[] l : effect(name)) {
            switch (l[0]) {
                case "SWF": {
                    Clip c = new Clip();
                    c.file = l[1];
                    c.export = l[2];
                    c.x = x;
                    c.h = h;
                    c.z = z;
                    c.angle = angle;
                    c.scale = scale;
                    if (sprites != null) {
                        c.frames = Math.max(1, sprites.frames(c.file, c.export));
                        c.fps = Math.max(1, sprites.fps(c.file, c.export));
                    }
                    if (clips.size() < 80) clips.add(c);
                    break;
                }
                case "EMITTER": {
                    Map<String, Object> e = emitter(l[1]);
                    if (e != null && running.size() < 120) running.add(new Emitter(e, x, h, z, angle, scale));
                    break;
                }
                case "EFFECT":
                    play(l[1], x, h, z, angle, scale, depth + 1);
                    break;
                case "SOUND":
                    if (sounds.size() < 16) sounds.add(l[1]);
                    break;
                default:
                    break;
            }
        }
    }

    /** renders every picture an effect will need now, so the first shot doesn't stutter */
    @SuppressWarnings("unchecked")
    public void prewarm(String name, int depth) {
        if (name == null || name.isEmpty() || sprites == null || depth > 3) return;
        for (String[] l : effect(name)) {
            switch (l[0]) {
                case "SWF":
                    warmClip(l[1], l[2]);
                    break;
                case "EMITTER": {
                    Map<String, Object> e = emitter(l[1]);
                    if (e == null) break;
                    for (Object mc : list(e.get("movieclip"))) {
                        if (!(mc instanceof Map)) continue;
                        Map<String, Object> m = (Map<String, Object>) mc;
                        warmClip(GameDb.fileName(String.valueOf(m.get("swf"))), String.valueOf(m.get("name")));
                    }
                    break;
                }
                case "EFFECT":
                    prewarm(l[1], depth + 1);
                    break;
                default:
                    break;
            }
        }
    }

    public void warmClip(String file, String export) {
        int n = Math.max(1, sprites.frames(file, export));
        int step = Math.max(1, (n + 15) / 16);
        for (int f = 0; f < n; f += step) sprites.get(file, export, f);
    }

    public synchronized boolean busy() {
        return !particles.isEmpty() || !running.isEmpty() || !clips.isEmpty();
    }

    public synchronized void clear() {
        particles.clear();
        running.clear();
        clips.clear();
    }

    /** a 2D clip played once where the effect is */
    static final class Clip {
        String file, export;
        float x, h, z, angle, scale = 1, age;
        int frames = 1, fps = 30;
    }

    static final class Particle {
        String file, export;
        int frames = 1, fps = 30;
        boolean loop, orient, additive;
        float x, h, z, vx, vh, vz, ax, ah, az;
        float age, life, rot, rotSpeed, size, fade;
        float[] scale, alpha;
        float r = 1, g = 1, b = 1;
        float bounce = -1, friction;
        float decX, decZ;
    }

    /** one running emitter, spawning particles */
    final class Emitter {
        final Map<String, Object> e, em, render;
        final float x, h, z, angle, scale;
        float t, delay, duration = 0.001f, acc;
        boolean started;
        List<Object> spawnRate, minA, maxA, minXY, maxXY, minZ, maxZ, minSize, maxSize, decel;
        boolean randomAngle;
        float bounce = -1, friction;

        @SuppressWarnings("unchecked")
        Emitter(Map<String, Object> e, float x, float h, float z, float angle, float scale) {
            this.e = e;
            this.x = x;
            this.h = h;
            this.z = z;
            this.angle = angle;
            this.scale = scale;
            em = e.get("emitter") instanceof Map ? (Map<String, Object>) e.get("emitter") : new HashMap<>();
            render = e.get("render") instanceof Map ? (Map<String, Object>) e.get("render") : new HashMap<>();
            delay = num(em.get("emitterDelay"), 0);
            for (Object o : list(em.get("components"))) {
                if (!(o instanceof Map)) continue;
                Map<String, Object> c = (Map<String, Object>) o;
                String cls = String.valueOf(c.get("__class"));
                switch (cls) {
                    case "SpawnRate":
                        duration = Math.max(0.001f, num(c.get("duration"), 0.001f) + num(c.get("durationJitter"), 0) * (rnd.nextFloat() - 0.5f));
                        spawnRate = curveList(c.get("spawnRate"));
                        break;
                    case "SpawnPlanar": case "SpawnSphere": case "SpawnCone":
                        minA = curveList(c.get("minAngle"));
                        maxA = curveList(c.get("maxAngle"));
                        minXY = curveList(c.get("minSpeedXY"));
                        maxXY = curveList(c.get("maxSpeedXY"));
                        minZ = curveList(c.get("minSpeedZ"));
                        maxZ = curveList(c.get("maxSpeedZ"));
                        minSize = curveList(c.get("spawnMinSize"));
                        maxSize = curveList(c.get("spawnMaxSize"));
                        randomAngle = Boolean.TRUE.equals(c.get("randomAngle"));
                        break;
                    case "Deceleration":
                        decel = curveList(c.get("deceleration"));
                        break;
                    case "Ground":
                        bounce = curve(c.get("bounciness"), 0, 0.5f);
                        friction = curve(c.get("friction"), 0, 0.3f);
                        break;
                    default:
                        break;
                }
            }
        }

        /** spawns for dt; false when finished */
        boolean step(float dt) {
            t += dt;
            if (t < delay) return true;
            float et = t - delay;
            float p = Math.min(1, et / duration);
            float rate = curve(spawnRate, p, 10);
            if (!started) {
                started = true;
                spawn();
            }
            acc += rate * dt;
            int guard = 0;
            while (acc >= 1 && guard++ < 40) {
                acc -= 1;
                spawn();
            }
            return et < duration;
        }

        @SuppressWarnings("unchecked")
        void spawn() {
            if (particles.size() >= maxParticles) return;
            List<Object> mcs = list(e.get("movieclip"));
            if (mcs.isEmpty()) return;
            Object mc = mcs.get(rnd.nextInt(mcs.size()));
            if (!(mc instanceof Map)) return;
            Map<String, Object> m = (Map<String, Object>) mc;
            Particle q = new Particle();
            q.file = GameDb.fileName(String.valueOf(m.get("swf")));
            q.export = String.valueOf(m.get("name"));
            if (sprites != null) {
                q.frames = Math.max(1, sprites.frames(q.file, q.export));
                q.fps = Math.max(1, sprites.fps(q.file, q.export));
            }
            float fx = (float) Math.sin(angle), fz = (float) Math.cos(angle); // forward
            float sx = fz, sz = -fx;                                         // side
            float a = randomAngle ? rnd.nextFloat() * 360 : lerp(curve(minA, 0, 0), curve(maxA, 0, 0), rnd.nextFloat());
            double ar = Math.toRadians(a);
            float u = EMITTER_UNIT * scale;
            float sp = lerp(curve(minXY, 0, 0), curve(maxXY, 0, 0), rnd.nextFloat()) * u;
            float up = lerp(curve(minZ, 0, 0), curve(maxZ, 0, 0), rnd.nextFloat()) * u;
            float lx = (float) Math.cos(ar) * sp, ly = (float) Math.sin(ar) * sp;
            q.vx = fx * lx + sx * ly;
            q.vz = fz * lx + sz * ly;
            q.vh = up;
            Map<String, Object> off = em.get("spawnPointOffset") instanceof Map ? (Map<String, Object>) em.get("spawnPointOffset") : null;
            float ox = off == null ? 0 : num(off.get("x"), 0), oy = off == null ? 0 : num(off.get("y"), 0), oz = off == null ? 0 : num(off.get("z"), 0);
            q.x = x + (fx * ox + sx * oy) * u;
            q.z = z + (fz * ox + sz * oy) * u;
            q.h = h + oz * u;
            float[] g = vec(em.get("gravity"));
            q.ax = (fx * g[0] + sx * g[1]) * u;
            q.az = (fz * g[0] + sz * g[1]) * u;
            q.ah = g[2] * u;
            float[] dc = decel == null ? new float[3] : vec3(decel);
            q.decX = dc[0];
            q.decZ = dc[1];
            q.life = Math.max(0.02f, curve(em.get("lifetime"), 0, 0.5f) + curve(em.get("lifetimeJitter"), 0, 0) * (rnd.nextFloat() - 0.5f));
            q.size = lerp(curve(minSize, 0, 0), curve(maxSize, 0, 0), rnd.nextFloat());
            q.scale = startEnd(render.get("scale"), 1);
            q.alpha = startEnd(render.get("alpha"), 1);
            float gs = num(render.get("globalScale"), 1);
            q.scale = new float[]{q.scale[0] * gs * scale, q.scale[1] * gs * scale};
            q.fade = num(render.get("alphaFadeout"), 0);
            q.loop = !Boolean.FALSE.equals(render.get("loopMovieClip"));
            q.orient = Boolean.TRUE.equals(render.get("orientToDirection"));
            q.additive = num(render.get("blendMode"), 0) == 2;
            q.rot = curve(render.get("angle"), 0, 0) + curve(render.get("angleJitter"), 0, 0) * (rnd.nextFloat() - 0.5f) * 2;
            q.rotSpeed = curve(render.get("rotationSpeed"), 0, 0) + curve(render.get("rotationSpeedJitter"), 0, 0) * (rnd.nextFloat() - 0.5f) * 2;
            float[] col = vec(firstOf(render.get("color")));
            if (col[0] + col[1] + col[2] > 0) {
                q.r = col[0];
                q.g = col[1];
                q.b = col[2];
            }
            q.bounce = bounce;
            q.friction = friction;
            particles.add(q);
        }
    }

    public synchronized void step(float dt) {
        if (dt <= 0) return;
        for (int i = running.size() - 1; i >= 0; i--) if (!running.get(i).step(dt)) running.remove(i);
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.age += dt;
            if (p.age >= p.life) {
                particles.remove(i);
                continue;
            }
            p.vx += p.ax * dt;
            p.vz += p.az * dt;
            p.vh += p.ah * dt;
            if (p.decX > 0) {
                float k = Math.max(0, 1 - p.decX * dt);
                p.vx *= k;
                p.vz *= k;
            }
            p.x += p.vx * dt;
            p.z += p.vz * dt;
            p.h += p.vh * dt;
            if (p.bounce >= 0 && p.h < 0) {
                p.h = 0;
                p.vh = -p.vh * p.bounce;
                p.vx *= 1 - p.friction;
                p.vz *= 1 - p.friction;
            }
            p.rot += p.rotSpeed * dt;
        }
        for (int i = clips.size() - 1; i >= 0; i--) {
            Clip c = clips.get(i);
            c.age += dt;
            if (c.age * c.fps >= c.frames + 0.5f || c.age > 4) clips.remove(i);
        }
    }

    // ------------------------------------------------------------------ drawing
    /** adds every live sprite to the scene, facing the camera */
    public synchronized void addTo(Scene3d s) {
        if (sprites == null) return;
        for (Clip c : clips) {
            int f = Math.min(c.frames - 1, (int) (c.age * c.fps));
            Sprite sp = sprites.get(c.file, c.export, f);
            float rot = screenAngle(s, c.angle);
            billboard(s, sp, c.x, c.h, c.z, rot, c.scale, 1, 1, 1, 1, false);
        }
        for (Particle p : particles) {
            float t = p.age / p.life;
            int f = p.loop ? (int) (p.age * p.fps) % p.frames : Math.min(p.frames - 1, (int) (t * p.frames));
            Sprite sp = sprites.get(p.file, p.export, f);
            float sc = lerp(p.scale[0], p.scale[1], t) + p.size;
            if (sc <= 0.001f) continue;
            float al = lerp(p.alpha[0], p.alpha[1], t);
            if (p.fade > 0 && p.life - p.age < p.fade) al *= (p.life - p.age) / p.fade;
            float rot = p.orient ? screenAngle(s, (float) Math.atan2(p.vx, p.vz)) : (float) Math.toRadians(p.rot);
            billboard(s, sp, p.x, p.h, p.z, rot, sc, al, p.r, p.g, p.b, p.additive);
        }
    }

    /** where a world direction points on screen (radians, 0 = right, counter-clockwise) */
    public static float screenAngle(Scene3d s, float worldAngle) {
        float dx = (float) Math.sin(worldAngle), dz = (float) Math.cos(worldAngle);
        float[] v = s.view;
        float cx = v[0] * dx + v[8] * dz, cy = v[1] * dx + v[9] * dz;
        return (float) Math.atan2(cy, cx);
    }

    /** a flat picture facing the camera, turned by {@code rot} in the screen plane */
    public static void billboard(Scene3d s, Sprite sp, float x, float h, float z, float rot, float scale, float alpha,
                                 float r, float g, float b, boolean additive) {
        if (sp == null || sp.img == null || alpha <= 0.01f) return;
        if (sp.quad == null) sp.quad = quad(sp);
        float[] v = s.view;
        // camera axes in world space: right, up, back
        float k = scale / UNITS_PER_TILE;
        float c = (float) Math.cos(rot), sn = (float) Math.sin(rot);
        float rx = v[0], ry = v[4], rz = v[8], ux = v[1], uy = v[5], uz = v[9], bx = v[2], by = v[6], bz = v[10];
        // in-plane rotation, then scale
        float ax = (rx * c + ux * sn) * k, ay = (ry * c + uy * sn) * k, az = (rz * c + uz * sn) * k;
        float px = (-rx * sn + ux * c) * k, py = (-ry * sn + uy * c) * k, pz = (-rz * sn + uz * c) * k;
        float[] m = {ax, ay, az, 0, px, py, pz, 0, bx, by, bz, 0, x + bx * 0.05f, h + by * 0.05f, z + bz * 0.05f, 1};
        Scene3d.Item it = s.add(sp.quad, null, m);
        it.override = sp.img;
        it.sprite = true;
        it.additive = additive;
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255)));
        it.color = (a << 24) | (Math.min(255, Math.round(r * 255)) << 16) | (Math.min(255, Math.round(g * 255)) << 8) | Math.min(255, Math.round(b * 255));
        it.overlay = true;
    }

    /** the picture's rectangle in clip units (y flipped: clips grow downwards, the world upwards) */
    static Model3d quad(Sprite sp) {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "sprite";
        p.triangles = 2;
        float x0 = sp.x0, x1 = sp.x1, y0 = -sp.y1, y1 = -sp.y0;
        p.pos = new float[]{x0, y0, 0, x1, y0, 0, x1, y1, 0, x0, y0, 0, x1, y1, 0, x0, y1, 0};
        p.nrm = new float[18];
        for (int i = 0; i < 6; i++) p.nrm[i * 3 + 2] = 1;
        p.uv = new float[]{0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0};
        p.hasUv = true;
        p.hasNormals = true;
        m.parts.add(p);
        m.triangles = 2;
        m.bounds = new float[]{x0, y0, 0, x1, y1, 0};
        return m;
    }

    // ------------------------------------------------------------------ curves: [x1, y1, x2, y2, start, end]
    @SuppressWarnings("unchecked")
    static List<Object> list(Object o) {
        return o instanceof List ? (List<Object>) o : new ArrayList<>();
    }

    static List<Object> curveList(Object o) {
        return o instanceof List ? list(o) : o instanceof Number ? java.util.Arrays.asList(o) : null;
    }

    static float num(Object o, float def) {
        return o instanceof Number ? ((Number) o).floatValue() : def;
    }

    static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** value of a curve at t (0..1); plain numbers are constant */
    static float curve(Object o, float t, float def) {
        if (o instanceof Number) return ((Number) o).floatValue();
        List<Object> l = curveList(o);
        if (l == null || l.isEmpty()) return def;
        if (l.size() == 1) return num(l.get(0), def);
        if (l.size() < 6) return num(l.get(0), def);
        float y1 = num(l.get(1), 0.333f), y2 = num(l.get(3), 0.666f);
        float a = num(l.get(4), def), b = num(l.get(5), a);
        float u = 1 - t;
        float e = 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t;
        return a + (b - a) * e;
    }

    static float[] startEnd(Object o, float def) {
        if (o instanceof Number) return new float[]{((Number) o).floatValue(), ((Number) o).floatValue()};
        List<Object> l = curveList(o);
        if (l == null || l.size() < 6) return new float[]{curve(o, 0, def), curve(o, 0, def)};
        return new float[]{num(l.get(4), def), num(l.get(5), def)};
    }

    static Object firstOf(Object o) {
        List<Object> l = curveList(o);
        if (l != null && l.size() >= 6) return l.get(4);
        return o;
    }

    /** a vector curve's start value [x, y, z] */
    static float[] vec(Object o) {
        Object v = firstOf(o);
        float[] r = new float[3];
        if (v instanceof List) {
            List<Object> l = list(v);
            for (int i = 0; i < 3 && i < l.size(); i++) r[i] = num(l.get(i), 0);
        } else if (v instanceof Number) {
            r[0] = r[1] = r[2] = ((Number) v).floatValue();
        }
        return r;
    }

    static float[] vec3(List<Object> l) {
        return vec(l);
    }

    /** a small LRU of rendered frames for a {@link Sprites} implementation */
    public static final class FrameCache extends LinkedHashMap<String, Sprite> {
        final int max;

        public FrameCache(int max) {
            super(64, 0.75f, true);
            this.max = max;
        }

        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Sprite> e) {
            return size() > max;
        }
    }
}
