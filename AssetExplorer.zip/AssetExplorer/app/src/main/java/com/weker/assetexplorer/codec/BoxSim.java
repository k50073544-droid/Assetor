package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Opens boxes and Starr Drops with the game's own weights (random_reward_containers.csv, random_rewards.csv).
 * Only a simulation: nothing is sent anywhere.
 */
public final class BoxSim {

    /** one thing that came out of a box */
    public static final class Reward {
        public String type, title, subtitle = "";
        public int amount;
        public int color = 0xFFB9C2D6;
        /** 2D picture (sc file + export) when there is one */
        public String iconFile, iconExport;
        /** skin rewards: model + texture for a 3D picture */
        public GameDb.Skin skin;
        public GameDb.Brawler brawler;
        public String sound;
    }

    /** result of opening one Starr Drop: rarities it went through, then the reward */
    public static final class StarrResult {
        public final List<GameDb.Container> steps = new ArrayList<>();
        public GameDb.Container fin;
        public Reward reward;
    }

    private final GameDb db;
    private final Random rnd;

    public BoxSim(GameDb db, long seed) {
        this.db = db;
        this.rnd = new Random(seed);
    }

    /** Starr Drop of a family: the final rarity is drawn with the game's weights, shown as upgrades from the lowest */
    public StarrResult openStarr(String family) {
        StarrResult res = new StarrResult();
        List<GameDb.Container> rar = db.starrRarities(family);
        if (rar.isEmpty()) return res;
        int total = 0;
        for (GameDb.Container c : rar) total += db.drawTickets(c);
        int pick = rnd.nextInt(Math.max(1, total));
        GameDb.Container fin = rar.get(0);
        for (GameDb.Container c : rar) {
            pick -= db.drawTickets(c);
            if (pick < 0) {
                fin = c;
                break;
            }
        }
        for (GameDb.Container c : rar) {
            res.steps.add(c);
            if (c == fin) break;
        }
        res.fin = fin;
        res.reward = roll(fin);
        return res;
    }

    /** how many rewards a box gives (MultiDropCount), at least one */
    public int dropCount(GameDb.Container c) {
        GameDb.Table t = db.table("random_reward_containers.csv");
        return Math.max(1, Math.min(10, t.num(c.row, "MultiDropCount", 1)));
    }

    public List<Reward> open(GameDb.Container c) {
        List<Reward> out = new ArrayList<>();
        int n = dropCount(c);
        for (int i = 0; i < n; i++) out.add(roll(c));
        return out;
    }

    /** one reward from a container by its tickets */
    public Reward roll(GameDb.Container c) {
        List<GameDb.RewardType> types = new ArrayList<>();
        int total = 0;
        for (GameDb.RewardType t : db.rewardTypes()) {
            int k = t.tickets.getOrDefault(c.name, 0);
            if (k > 0) {
                types.add(t);
                total += k;
            }
        }
        if (types.isEmpty()) return amount("Coins", 0, c);
        int pick = rnd.nextInt(total);
        GameDb.RewardType t = types.get(0);
        for (GameDb.RewardType x : types) {
            pick -= x.tickets.get(c.name);
            if (pick < 0) {
                t = x;
                break;
            }
        }
        Reward r = resolve(t);
        if (r == null) r = amount(t.fallback.isEmpty() ? "Coins" : t.fallback, Math.max(1, t.fallbackAmount), c);
        return r;
    }

    private Reward resolve(GameDb.RewardType t) {
        String type = t.type;
        switch (type) {
            case "Coins": case "PowerPoints": case "Credits": case "Bling": case "Gems": case "TokenDoubler": case "ProXP":
            case "WasabiPower": case "NanoPower":
                return amount(type, t.min + (t.max > t.min ? rnd.nextInt(t.max - t.min + 1) : 0), null);
            case "Skin": case "CollabSkin": case "RankedStarSkin": {
                List<GameDb.Skin> pool = new ArrayList<>();
                for (GameDb.Skin s : db.allSkins()) if (s.priceGems >= t.priceMin && s.priceGems <= t.priceMax && s.model != null && !s.model.isEmpty()) pool.add(s);
                if (pool.isEmpty()) return null;
                GameDb.Skin s = pool.get(rnd.nextInt(pool.size()));
                Reward r = new Reward();
                r.type = "Skin";
                r.skin = s;
                r.brawler = db.brawler(s.brawler);
                r.title = s.title;
                r.subtitle = "Скин · " + (r.brawler != null ? r.brawler.name : "") + (s.priceGems > 0 ? " · " + s.priceGems + " гем." : "");
                r.color = GameDb.rarityColor(s.rarity.isEmpty() ? "epic" : s.rarity);
                return r;
            }
            case "Pin": case "CollabPin": case "Spray": case "CollabSpray": case "RankedStarSpray": case "ProfilePic":
            case "CollabProfilePic": case "RankedStarProfilePic": {
                String kind = type.contains("Pin") ? "pins" : type.contains("Spray") ? "sprays" : "icons";
                List<GameDb.Item2d> pool = new ArrayList<>();
                for (GameDb.Item2d it : db.items(kind)) {
                    if (t.priceMax < 99999 && (it.priceGems < t.priceMin || it.priceGems > t.priceMax)) continue;
                    if (!t.value.isEmpty() && !it.rarity.isEmpty() && kind.equals("pins") && !it.rarity.equalsIgnoreCase(t.value)) continue;
                    pool.add(it);
                }
                if (pool.isEmpty()) for (GameDb.Item2d it : db.items(kind)) if (it.priceGems > 0 || it.priceBling > 0) pool.add(it);
                if (pool.isEmpty()) return null;
                GameDb.Item2d it = pool.get(rnd.nextInt(pool.size()));
                Reward r = new Reward();
                r.type = kind;
                r.title = kind.equals("pins") ? "Пин" : kind.equals("sprays") ? "Спрей" : "Иконка игрока";
                r.subtitle = it.name;
                r.iconFile = it.file;
                r.iconExport = it.export;
                r.sound = it.sound;
                r.color = GameDb.rarityColor(it.rarity);
                return r;
            }
            case "Brawler": {
                List<GameDb.Brawler> pool = new ArrayList<>();
                for (GameDb.Brawler b : db.brawlers()) if (t.value.isEmpty() || b.rarity.equalsIgnoreCase(t.value)) pool.add(b);
                if (pool.isEmpty()) pool.addAll(db.brawlers());
                if (pool.isEmpty()) return null;
                GameDb.Brawler b = pool.get(rnd.nextInt(pool.size()));
                Reward r = new Reward();
                r.type = "Brawler";
                r.brawler = b;
                r.title = "Новый боец: " + b.name;
                r.subtitle = b.rarityName;
                r.color = GameDb.rarityColor(b.rarity);
                return r;
            }
            case "Gadget": case "StarPower": case "Overcharge": {
                List<String[]> pool = new ArrayList<>();
                for (GameDb.Brawler b : db.brawlers()) {
                    List<String> l = new ArrayList<>();
                    if (type.equals("Gadget")) l.addAll(b.gadgets);
                    else if (type.equals("StarPower")) l.addAll(b.starPowers);
                    else if (b.hypercharge != null) l.add(b.hypercharge);
                    for (String s : l) pool.add(new String[]{b.code, s});
                }
                if (pool.isEmpty()) return null;
                String[] p = pool.get(rnd.nextInt(pool.size()));
                Reward r = new Reward();
                r.type = type;
                r.brawler = db.brawler(p[0]);
                r.title = p[1];
                r.subtitle = (type.equals("Gadget") ? "Гаджет" : type.equals("StarPower") ? "Звёздная сила" : "Гиперзаряд") + " · "
                        + (r.brawler != null ? r.brawler.name : "");
                r.color = type.equals("Gadget") ? 0xFF68FD58 : type.equals("StarPower") ? 0xFFFFF11E : 0xFFD850FF;
                return r;
            }
            default: {
                Reward r = new Reward();
                r.type = type;
                r.title = GameDb.spaced(t.name);
                r.subtitle = GameDb.spaced(type);
                r.amount = t.min;
                return r;
            }
        }
    }

    static Reward amount(String type, int n, GameDb.Container c) {
        Reward r = new Reward();
        r.type = type;
        r.amount = n;
        String name;
        switch (type) {
            case "Coins": name = "Монеты"; r.color = 0xFFFFC93C; break;
            case "PowerPoints": name = "Очки силы"; r.color = 0xFFD07CFF; break;
            case "Credits": name = "Кредиты"; r.color = 0xFF5AD8FF; break;
            case "Bling": name = "Блинги"; r.color = 0xFFFF7AD9; break;
            case "Gems": name = "Гемы"; r.color = 0xFF4CE07A; break;
            case "TokenDoubler": name = "Удвоитель жетонов"; r.color = 0xFFFFE15C; break;
            case "ProXP": name = "Опыт Pro"; break;
            default: name = GameDb.spaced(type); break;
        }
        r.title = String.format(Locale.ROOT, "%d · %s", n, name);
        r.subtitle = name;
        return r;
    }
}
