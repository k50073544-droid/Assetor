package com.weker.assetexplorer;

import android.app.Activity;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Table viewer for big csv files. Rows are drawn lazily by a ListView (only what is on screen),
 * so even huge tables don't freeze or crash the app.
 */
public final class CsvActivity extends Activity {

    static final int MAX_ROWS = 50_000;
    static final int MAX_COL_CHARS = 28;

    private final Handler main = new Handler(Looper.getMainLooper());
    private List<String[]> rows = new ArrayList<>();
    private List<Integer> visible = new ArrayList<>();
    private int[] widths = new int[0]; // characters per column
    private int filterGen;
    private TextView info, header, types;
    private Adapter adapter;
    private ListView list;
    private float charW;
    private String pendingQuery = "";
    private final Runnable runFilter = () -> applyFilter(pendingQuery);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        Db.Row row = Db.get(this).file(getIntent().getLongExtra("id", -1));
        if (row == null) {
            finish();
            return;
        }
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, row.name, 18, Ui.TEXT));
        info = Ui.text(this, "Загружаю…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 6));
        root.addView(info);

        EditText filter = new EditText(this);
        filter.setHint("Фильтр строк (по любому столбцу)…");
        filter.setHintTextColor(Ui.MUTED);
        filter.setTextColor(Ui.TEXT);
        filter.setSingleLine(true);
        filter.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 10)));
        filter.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        root.addView(filter);
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(Editable e) {
                pendingQuery = e.toString();
                main.removeCallbacks(runFilter);
                main.postDelayed(runFilter, 300);
            }
        });

        Paint paint = new Paint();
        paint.setTypeface(Typeface.MONOSPACE);
        paint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12, getResources().getDisplayMetrics()));
        charW = paint.measureText("M");

        // header + list scroll horizontally together
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setFillViewport(true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        header = mono(Ui.ACCENT, true);
        header.setBackgroundColor(Ui.CARD2);
        types = mono(Ui.MUTED, false);
        types.setBackgroundColor(0xFF20232F);
        inner.addView(header);
        inner.addView(types);
        list = new ListView(this);
        list.setDivider(null);
        list.setFastScrollEnabled(true);
        adapter = new Adapter();
        list.setAdapter(adapter);
        inner.addView(list, new LinearLayout.LayoutParams(-2, -1));
        hs.addView(inner, new FrameLayout.LayoutParams(-2, -1));
        LinearLayout.LayoutParams hlp = Ui.lp(-1, 0, 1);
        hlp.topMargin = Ui.dp(this, 8);
        root.addView(hs, hlp);
        setContentView(root);

        new Thread(() -> {
            try {
                byte[] d = Decoders.content(Blobs.file(this, row.blob));
                String text = new String(d, StandardCharsets.UTF_8);
                List<String[]> r = Decoders.parseCsv(text, MAX_ROWS);
                int cols = 0;
                for (String[] x : r) cols = Math.max(cols, x.length);
                int[] w = new int[cols];
                for (int i = 0; i < r.size() && i < 2000; i++) {
                    String[] x = r.get(i);
                    for (int c = 0; c < x.length; c++) w[c] = Math.max(w[c], Math.min(MAX_COL_CHARS, x[c].length()));
                }
                for (int c = 0; c < cols; c++) w[c] = Math.max(3, w[c]);
                int fc = cols;
                main.post(() -> {
                    rows = r;
                    widths = w;
                    if (!r.isEmpty()) header.setText(format(r.get(0)));
                    if (r.size() > 1) types.setText(format(r.get(1)));
                    int total = 0;
                    for (int x : w) total += x + 3;
                    int px = (int) (total * charW) + Ui.dp(this, 24);
                    list.getLayoutParams().width = px;
                    header.setMinWidth(px);
                    types.setMinWidth(px);
                    list.requestLayout();
                    info.setText("Строк: " + Math.max(0, r.size() - 2) + " · столбцов: " + fc
                            + (r.size() >= MAX_ROWS ? " (показаны первые " + MAX_ROWS + ")" : "")
                            + " · листай вбок и вниз");
                    applyFilter("");
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Не удалось открыть таблицу: " + e.getMessage()));
            }
        }, "csv").start();
    }

    private TextView mono(int color, boolean bold) {
        TextView t = Ui.text(this, "", 12, color);
        t.setTypeface(bold ? Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) : Typeface.MONOSPACE);
        t.setSingleLine(true);
        int p = Ui.dp(this, 6);
        t.setPadding(p, p, p, p);
        return t;
    }

    String format(String[] r) {
        StringBuilder sb = new StringBuilder();
        for (int c = 0; c < widths.length; c++) {
            String v = c < r.length ? r[c].replace('\n', ' ') : "";
            int w = widths[c];
            if (v.length() > w) v = v.substring(0, w - 1) + "…";
            sb.append(v);
            for (int k = v.length(); k < w; k++) sb.append(' ');
            sb.append(" │ ");
        }
        return sb.toString();
    }

    private void applyFilter(String q) {
        final int gen = ++filterGen;
        final String lq = q.toLowerCase(Locale.ROOT).trim();
        final List<String[]> src = rows;
        new Thread(() -> {
            List<Integer> v = new ArrayList<>();
            for (int i = 2; i < src.size(); i++) {
                if (gen != filterGen) return;
                if (lq.isEmpty()) {
                    v.add(i);
                    continue;
                }
                for (String c : src.get(i)) {
                    if (c.toLowerCase(Locale.ROOT).contains(lq)) {
                        v.add(i);
                        break;
                    }
                }
            }
            main.post(() -> {
                if (gen != filterGen) return;
                visible = v;
                adapter.notifyDataSetChanged();
                list.setSelection(0);
            });
        }, "csv-filter").start();
    }

    final class Adapter extends BaseAdapter {
        public int getCount() { return visible.size(); }

        public Object getItem(int i) { return visible.get(i); }

        public long getItemId(int i) { return i; }

        public View getView(int pos, View v, ViewGroup parent) {
            TextView t = v == null ? mono(Ui.TEXT, false) : (TextView) v;
            int r = visible.get(pos);
            t.setText(format(rows.get(r)));
            t.setBackgroundColor((pos & 1) == 0 ? Ui.CARD : 0xFF1E2130);
            return t;
        }
    }
}
