package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

/** A button drawn like the game's: bright face, darker bottom edge, white outlined LilitaOne text. */
public final class GameButton extends TextView {

    public static final int YELLOW = 0xFFFFC92B, BLUE = 0xFF2F8BFF, GREEN = 0xFF46D15A, RED = 0xFFF2453C, PURPLE = 0xFFB04CFF, GREY = 0xFF5D6478;

    public GameButton(Context c, String text, int color, Typeface font) {
        super(c);
        setText(text);
        setTypeface(font);
        setAllCaps(true);
        setTextColor(0xFFFFFFFF);
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        setShadowLayer(3f, 0, 2.5f, 0xFF000000);
        setGravity(Gravity.CENTER);
        int p = Ui.dp(c, 14);
        setPadding(p, Ui.dp(c, 8), p, Ui.dp(c, 12));
        setColor(color);
    }

    public void setColor(int color) {
        float r = Ui.dp(getContext(), 12);
        GradientDrawable edge = new GradientDrawable();
        edge.setColor(darker(color, 0.62f));
        edge.setCornerRadius(r);
        edge.setStroke(Ui.dp(getContext(), 2), 0xFF000000);
        GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{lighter(color), color});
        face.setCornerRadius(r);
        LayerDrawable ld = new LayerDrawable(new android.graphics.drawable.Drawable[]{edge, face});
        int s = Ui.dp(getContext(), 2);
        ld.setLayerInset(1, s, s, s, Ui.dp(getContext(), 6));
        setBackground(ld);
    }

    static int darker(int c, float k) {
        return 0xFF000000 | ((int) (((c >> 16) & 255) * k) << 16) | ((int) (((c >> 8) & 255) * k) << 8) | (int) ((c & 255) * k);
    }

    static int lighter(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return 0xFF000000 | ((r + (255 - r) / 3) << 16) | ((g + (255 - g) / 3) << 8) | (b + (255 - b) / 3);
    }
}
