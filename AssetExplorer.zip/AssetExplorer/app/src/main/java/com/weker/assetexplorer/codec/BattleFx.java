package com.weker.assetexplorer.codec;

import java.util.HashMap;
import java.util.Map;

/**
 * Turns what happens in a {@link Battle} into the game's effects: muzzle flashes and attack clips
 * (skin_confs / skills AttackEffect), projectiles and their shadows (projectiles_skin.csv), hits, range-end puffs,
 * explosions (area_effects_skin.csv), damage / death / spawn effects (characters.csv) and wall debris (tiles.csv).
 */
public final class BattleFx {

    final Battle b;
    final GameDb db;
    public final Fx fx;
    final Map<String, String[]> projSkin = new HashMap<>();
    final Map<String, String[]> areaSkin = new HashMap<>();

    public BattleFx(Battle b, GameDb db, GameDb.Source src, Fx.Sprites sprites) {
        this.b = b;
        this.db = db;
        fx = new Fx(src, sprites);
    }

    /** row of skin_confs for a skin name (skins.csv → Conf) */
    String[] conf(String skin) {
        if (skin == null) return null;
        GameDb.Table skins = db.table("skins.csv"), confs = db.table("skin_confs.csv");
        String[] s = skins.row(skin);
        return confs.row(s != null ? skins.get(s, "Conf") : skin);
    }

    String confValue(Battle.Fighter f, String col) {
        String[] c = conf(f.kit.skin);
        return c == null ? "" : db.table("skin_confs.csv").get(c, col);
    }

    /**
     * projectile look: {file, blue, red, shadow, hitEnv, hitChar, reached, trail, scale%, noRotate}.
     * A skin may replace it (skin_confs "Projectiles" lists skin rows whose LogicProjectile is the logic one).
     */
    public String[] projectile(String skin, String logic) {
        String key = skin + "/" + logic;
        if (projSkin.containsKey(key)) return projSkin.get(key);
        GameDb.Table t = db.table("projectiles_skin.csv");
        if (!t.has("LogicProjectile")) t = db.table("projectiles.csv");
        String[] row = null;
        String[] c = conf(skin);
        if (c != null) {
            for (String n : db.table("skin_confs.csv").get(c, "Projectiles").split("[;,]")) {
                String[] r = t.row(n.trim());
                if (r != null && logic.equals(t.get(r, "LogicProjectile"))) row = r;
            }
        }
        if (row == null) row = t.row(logic);
        if (row == null) for (String[] r : t.rows) if (logic.equals(t.get(r, "LogicProjectile"))) {
            row = r;
            break;
        }
        String[] out = null;
        if (row != null) {
            out = new String[]{GameDb.fileName(t.get(row, "FileName")), t.get(row, "BlueExportName"), t.get(row, "RedExportName"),
                    t.get(row, "ShadowExportName"), t.get(row, "HitEffectEnv"), t.get(row, "HitEffectChar"), t.get(row, "MaxRangeReachedEffect"),
                    t.get(row, "TrailEffect"), String.valueOf(t.num(row, "Scale", 100)), t.get(row, "Rendering")};
        }
        projSkin.put(key, out);
        return out;
    }

    /** explosion look: {effect, scale%} (skin_confs "AreaEffects" can replace it) */
    String[] area(String skin, String logic) {
        if (logic == null || logic.isEmpty()) return null;
        String key = skin + "/" + logic;
        if (areaSkin.containsKey(key)) return areaSkin.get(key);
        GameDb.Table t = db.table("area_effects_skin.csv");
        String[] row = null;
        String[] c = conf(skin);
        if (c != null) {
            for (String n : db.table("skin_confs.csv").get(c, "AreaEffects").split("[;,]")) {
                String[] r = t.row(n.trim());
                if (r != null && logic.equals(t.get(r, "Logic"))) row = r;
            }
        }
        if (row == null) row = t.row(logic);
        String[] out = row == null ? null : new String[]{t.get(row, "Effect"), String.valueOf(t.num(row, "Scale", 100))};
        areaSkin.put(key, out);
        return out;
    }

    String charEffect(Battle.Fighter f, String col) {
        GameDb.Table ch = db.table("characters.csv");
        String[] r = ch.row(f.kit.code);
        return r == null ? "" : ch.get(r, col);
    }

    /** prepares the pictures of a fighter's attack, super and their projectiles / hits / explosions */
    public void prewarm(Battle.Fighter f) {
        for (Battle.Skill s : new Battle.Skill[]{f.kit.weapon, f.kit.ulti}) {
            if (s == null) continue;
            fx.prewarm(s.effect, 0);
            String[] p = s.proj.isEmpty() ? null : projectile(f.kit.skin, s.proj);
            if (p != null) {
                fx.warmClip(p[0], p[1]);
                fx.prewarm(p[5], 0);
                fx.prewarm(p[4], 0);
                fx.prewarm(p[6], 0);
                fx.prewarm(p[7], 0);
            }
            String[] a = area(f.kit.skin, s.areaName);
            if (a != null) fx.prewarm(a[0], 0);
        }
        fx.prewarm(confValue(f, "MainAttackEffect"), 0);
        fx.prewarm(confValue(f, "UltiAttackEffect"), 0);
        fx.takeSounds();
    }

    /** reads the battle's new happenings and starts their effects */
    public void consume() {
        for (Object[] e : b.fx) {
            try {
                handle(e);
            } catch (Throwable ignored) {
                // a missing table entry only loses that effect
            }
        }
        b.fx.clear();
    }

    void handle(Object[] e) {
        switch ((String) e[0]) {
            case "cast": {
                Battle.Fighter f = (Battle.Fighter) e[1];
                Battle.Skill s = (Battle.Skill) e[2];
                float ang = (float) e[3];
                int what = (int) e[4];
                boolean hyper = f.hyperUntil > b.time;
                String name = what == 1 ? confValue(f, hyper ? "OverchargedUltiAttackEffect" : "UltiAttackEffect")
                        : what == 0 ? confValue(f, hyper ? "OverchargedMainAttackEffect" : "MainAttackEffect") : "";
                if (name.isEmpty() && what <= 1) name = what == 1 ? confValue(f, "UltiAttackEffect") : confValue(f, "MainAttackEffect");
                if (name.isEmpty() && s != null) name = s.effect;
                if (name.isEmpty() && f.dummy) name = charEffect(f, "AutoAttackStartEffect");
                String use = what == 1 ? confValue(f, "UltiUseEffect") : what == 0 ? confValue(f, "MainAttackUseEffect") : "";
                float fx0 = (float) Math.sin(ang), fz0 = (float) Math.cos(ang);
                fx.play(name, f.x + fx0 * 0.45f, 0.55f, f.z + fz0 * 0.45f, ang, 1);
                if (!use.isEmpty()) fx.play(use, f.x, 0.05f, f.z, ang, 1);
                break;
            }
            case "hitChar": case "hitEnv": case "reach": {
                Battle.Shot s = (Battle.Shot) e[3];
                Battle.Fighter owner = b.byId(s.owner);
                String[] p = s.skill == null ? null : projectile(owner != null ? owner.kit.skin : null, s.skill.proj);
                if (p == null) {
                    if (!"reach".equals(e[0])) fx.play("gen_hit", (float) e[1], 0.5f, (float) e[2], s.angle, 1);
                    break;
                }
                String name = "hitChar".equals(e[0]) ? p[5] : "hitEnv".equals(e[0]) ? p[4] : p[6];
                if (!"no_hit".equals(name)) fx.play(name, (float) e[1], "reach".equals(e[0]) ? 0.3f : 0.5f, (float) e[2], s.angle, 1);
                break;
            }
            case "area": {
                Battle.Fighter f = (Battle.Fighter) e[4];
                String[] a = area(f != null ? f.kit.skin : null, (String) e[3]);
                if (a != null) fx.play(a[0], (float) e[1], 0.05f, (float) e[2], 0, Float.parseFloat(a[1]) / 100f);
                else fx.play("gen_hit", (float) e[1], 0.3f, (float) e[2], 0, 1);
                break;
            }
            case "hyper": {
                Battle.Fighter f = (Battle.Fighter) e[1];
                fx.play(f.kit.hyperEffect, f.x, 0.05f, f.z, f.face, 1);
                break;
            }
            case "hurt": {
                Battle.Fighter f = (Battle.Fighter) e[1];
                fx.play(charEffect(f, "TakeDamageEffect"), f.x, 0.5f, f.z, f.face, 1);
                break;
            }
            case "dead": {
                Battle.Fighter f = (Battle.Fighter) e[1];
                fx.play(charEffect(f, "DeathEffect"), f.x, 0.3f, f.z, f.face, 1);
                break;
            }
            case "spawn": {
                Battle.Fighter f = (Battle.Fighter) e[1];
                String n = confValue(f, "SpawnEffect");
                fx.play(n.isEmpty() ? charEffect(f, "SpawnEffect") : n, f.x, 0.05f, f.z, f.face, 1);
                break;
            }
            case "wall": {
                char ch = (char) e[3];
                for (Map.Entry<Character, String[]> t : db.tiles().entrySet()) {
                    if (t.getKey() != ch) continue;
                    fx.play(db.table("tiles.csv").get(t.getValue(), "BaseExplosionEffect"), (int) e[1] + 0.5f, 0.3f, (int) e[2] + 0.5f, 0, 1);
                }
                break;
            }
            default:
                break;
        }
    }

    float trailClock;

    public void step(float dt) {
        trailClock += dt;
        if (trailClock > 0.07f) {
            trailClock = 0;
            for (Battle.Shot s : b.shots) {
                Battle.Fighter owner = b.byId(s.owner);
                String[] p = s.skill == null ? null : projectile(owner != null ? owner.kit.skin : null, s.skill.proj);
                if (p != null && !p[7].isEmpty() && (!s.lob || s.flight >= 0)) fx.play(p[7], s.x, s.h, s.z, s.angle, 1);
            }
        }
        fx.step(dt);
    }

    /** projectiles (their own clips, blue for your team and red for the others) and every live effect */
    public void addTo(Scene3d s, Battle.Fighter viewer) {
        Fx.Sprites sp = fx.sprites;
        for (Battle.Shot sh : b.shots) {
            if (sh.lob && sh.flight < 0) continue;
            Battle.Fighter owner = b.byId(sh.owner);
            String[] p = sh.skill == null ? null : projectile(owner != null ? owner.kit.skin : null, sh.skill.proj);
            boolean mine = viewer == null || sh.team == viewer.team;
            if (p == null || sp == null) {
                Scene3d.Item it = s.add(BattleScene.DOT, null, Scene3d.mul(Scene3d.translate(sh.x, sh.h, sh.z), Scene3d.scale(0.15f)));
                it.color = mine ? 0xFF8FD3FF : 0xFFFF6A50;
                it.overlay = true;
                continue;
            }
            String clip = mine || p[2].isEmpty() ? p[1] : p[2];
            float scale = Float.parseFloat(p[8]) / 100f;
            int frames = Math.max(1, sp.frames(p[0], clip)), fps = sp.fps(p[0], clip);
            float age = sh.lob ? sh.flight : sh.age;
            Fx.Sprite f = sp.get(p[0], clip, (int) (age * fps) % frames);
            boolean noRotate = p[9].contains("DoNotRotate") || sh.lob;
            Fx.billboard(s, f, sh.x, sh.h, sh.z, noRotate ? 0 : Fx.screenAngle(s, sh.angle), scale, 1, 1, 1, 1, false);
            if (!p[3].isEmpty()) {
                Fx.Sprite shadow = sp.get(p[0], p[3], 0);
                if (shadow == null) shadow = sp.get("effects.sc", p[3], 0);
                Fx.billboard(s, shadow, sh.x, 0.02f, sh.z, 0, scale * 0.8f, 0.5f, 1, 1, 1, false);
            }
        }
        fx.addTo(s);
    }
}
