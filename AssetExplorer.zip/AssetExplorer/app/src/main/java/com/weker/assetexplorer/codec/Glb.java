package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * glTF binary container. Supercell stores the glTF description as a FlatBuffer ("FLA2" chunk) instead of JSON;
 * it is converted here to the same Map/List structure a JSON glTF gives, so the rest of the code sees normal glTF.
 * FlatBuffer schema: Supercell-Flat-Converter by Daniil-SV (glTF.fbs).
 */
public final class Glb {

    public Map<String, Object> json;
    public byte[] bin = new byte[0];
    public boolean flat;

    public static boolean isGlb(byte[] d) {
        return d.length >= 12 && d[0] == 'g' && d[1] == 'l' && d[2] == 'T' && d[3] == 'F';
    }

    @SuppressWarnings("unchecked")
    public static Glb parse(byte[] d) throws IOException {
        if (!isGlb(d)) throw new IOException("Не glTF (GLB)");
        Glb g = new Glb();
        int p = 12;
        while (p + 8 <= d.length) {
            int len = le32(d, p);
            String type = new String(d, p + 4, 4, StandardCharsets.ISO_8859_1);
            int s = p + 8;
            if (len < 0 || s + len > d.length) break;
            if (type.equals("JSON")) {
                Object o = Json.parse(new String(d, s, len, StandardCharsets.UTF_8));
                if (o instanceof Map) g.json = (Map<String, Object>) o;
            } else if (type.startsWith("FLA")) {
                g.json = (Map<String, Object>) table(d, s + le32(d, s), "Root", 0);
                g.flat = true;
            } else if (type.startsWith("BIN")) {
                g.bin = java.util.Arrays.copyOfRange(d, s, s + len);
            }
            p = s + len;
        }
        if (g.json == null) throw new IOException("В GLB нет описания модели");
        return g;
    }

    // ------------------------------------------------------------------ flatbuffer -> map
    /**
     * Field lists in schema order (field id = position). Kinds: i int32, u uint32, f float, b bool, B ubyte,
     * H ushort, s string, x flexbuffer, vi [int], vf [float], vs [string], T:Name table, V:Name [table],
     * E:Name ubyte enum, G:Name ushort enum.
     */
    static final Map<String, String[]> SCHEMA = new HashMap<>();
    static final Map<String, String[]> ENUMS = new HashMap<>();

    static void t(String name, String fields) {
        SCHEMA.put(name, fields.split(","));
    }

    static {
        ENUMS.put("AccessorType", new String[]{"SCALAR", "VEC2", "VEC3", "VEC4", "MAT2", "MAT3", "MAT4"});
        ENUMS.put("Path", new String[]{"translation", "rotation", "scale", "weights"});
        ENUMS.put("Interp", new String[]{"LINEAR", "STEP", "CUBICSPLINE"});
        ENUMS.put("CameraType", new String[]{"orthographic", "perspective"});
        ENUMS.put("AlphaMode", new String[]{"OPAQUE", "MASK", "BLEND"});

        t("AccessorSparseIndices", "bufferView:i,byteOffset:u,componentType:u,extensions:x,extras:x");
        t("AccessorSparseValues", "bufferView:u,byteOffset:i,extensions:x,extras:x");
        t("AccessorSparse", "count:i,indices:T:AccessorSparseIndices,values:T:AccessorSparseValues,extensions:x,extras:x");
        t("Accessor", "bufferView:i,byteOffset:u,componentType:u,count:u,sparse:T:AccessorSparse,name:s,max:vf,min:vf,"
                + "extensions:x,normalized:b,extras:x,type:E:AccessorType");
        t("Asset", "copyright:s,extensions:x,extras:x,generator:s,minVersion:s,version:s");
        t("AnimationChannelTarget", "extensions:x,extras:x,node:i,path:E:Path");
        t("AnimationChannel", "extensions:x,extras:x,sampler:i,target:T:AnimationChannelTarget");
        t("AnimationSampler", "extras:x,extensions:x,input:i,interpolation:E:Interp,output:i");
        t("Animation", "channels:V:AnimationChannel,extensions:x,extras:x,name:s,samplers:V:AnimationSampler");
        t("Buffer", "byteLength:u,uri:s,name:s,extensions:x,extras:x");
        t("BufferView", "buffer:i,byteLength:u,byteOffset:u,byteStride:u,name:s,extensions:x,extras:x,target:u");
        t("CameraOrthographic", "xmag:f,ymag:f,zfar:f,znear:f,extensions:x,extras:x");
        t("CameraPerspective", "aspectRatio:f,extensions:x,extras:x,yfov:f,zfar:f,znear:f");
        t("Camera", "extensions:x,extras:x,type:G:CameraType,name:s,perspective:T:CameraPerspective,orthographic:T:CameraOrthographic");
        t("Image", "extensions:x,extras:x,bufferView:i,mimeType:s,name:s,uri:s");
        t("TextureInfo", "index:i,texCoord:i,extensions:x,extras:x");
        t("MaterialNormalTextureInfo", "scale:f,index:i,texCoord:i,extensions:x,extras:x");
        t("MaterialOcclusionTextureInfo", "strength:f,index:i,texCoord:i,extensions:x,extras:x");
        t("MaterialPbrMetallicRoughness", "baseColorFactor:vf,baseColorTexture:T:TextureInfo,metallicFactor:f,roughnessFactor:f,"
                + "metallicRoughnessTexture:T:TextureInfo,extensions:x,extras:x");
        t("Material", "pbrMetallicRoughness:T:MaterialPbrMetallicRoughness,normalTexture:T:MaterialNormalTextureInfo,"
                + "occlusionTexture:T:MaterialOcclusionTextureInfo,emissiveTexture:T:TextureInfo,emissiveFactor:vf,extensions:x,"
                + "extras:x,doubleSided:b,name:s,alphaCutoff:f,alphaMode:G:AlphaMode");
        t("MeshPrimitive", "attributes:x,extensions:x,targets:x,indices:i,material:i,mode:B,extras:x");
        t("Mesh", "extensions:x,extras:x,name:s,primitives:V:MeshPrimitive,weights:vf");
        t("Node", "camera:i,children:vi,extensions:x,extras:x,weights:vf,mesh:i,name:s,rotation:vf,scale:vf,skin:i,"
                + "translation:vf,matrix:vf");
        t("Scene", "extensions:x,extras:x,name:s,nodes:vi");
        t("Sampler", "wrapS:H,wrapT:H,magFilter:H,minFilter:H,name:s,extensions:x,extras:x");
        t("Texture", "name:s,extensions:x,extras:x,sampler:i,source:i");
        t("Skin", "extensions:x,extras:x,inverseBindMatrices:i,joints:vi,name:s,skeleton:i");
        t("Root", "accessors:V:Accessor,animations:V:Animation,asset:T:Asset,bufferViews:V:BufferView,buffers:V:Buffer,"
                + "cameras:V:Camera,extensions:x,extensionsRequired:vs,extensionsUsed:vs,extras:x,images:V:Image,"
                + "materials:V:Material,meshes:V:Mesh,nodes:V:Node,samplers:V:Sampler,scene:i,scenes:V:Scene,skins:V:Skin,"
                + "textures:V:Texture");
    }

    static Object table(byte[] d, int pos, String name, int depth) {
        String[] fields = SCHEMA.get(name);
        if (fields == null || depth > 16) return null;
        int vt = pos - le32(d, pos);
        int vtSize = le16(d, vt);
        Map<String, Object> m = new LinkedHashMap<>();
        for (int id = 0; id < fields.length; id++) {
            int o = 4 + id * 2;
            if (o + 2 > vtSize) break;
            int off = le16(d, vt + o);
            if (off == 0) continue;
            int f = pos + off;
            String[] spec = fields[id].split(":", 3);
            String key = spec[0], kind = spec[1];
            Object v;
            switch (kind) {
                case "i": v = (long) le32(d, f); break;
                case "u": v = le32(d, f) & 0xFFFFFFFFL; break;
                case "f": v = (double) Float.intBitsToFloat(le32(d, f)); break;
                case "b": v = d[f] != 0; break;
                case "B": v = (long) (d[f] & 0xFF); break;
                case "H": v = (long) le16(d, f); break;
                case "s": v = str(d, f); break;
                case "x": {
                    int vp = f + le32(d, f);
                    int len = le32(d, vp);
                    v = Flex.read(d, vp + 4, vp + 4 + len);
                    break;
                }
                case "vi": case "vf": case "vs": {
                    int vp = f + le32(d, f);
                    int n = le32(d, vp);
                    List<Object> l = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        int e = vp + 4 + i * 4;
                        if (kind.equals("vi")) l.add((long) le32(d, e));
                        else if (kind.equals("vf")) l.add((double) Float.intBitsToFloat(le32(d, e)));
                        else l.add(str(d, e));
                    }
                    v = l;
                    break;
                }
                case "T": v = table(d, f + le32(d, f), spec[2], depth + 1); break;
                case "V": {
                    int vp = f + le32(d, f);
                    int n = le32(d, vp);
                    List<Object> l = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        int e = vp + 4 + i * 4;
                        l.add(table(d, e + le32(d, e), spec[2], depth + 1));
                    }
                    v = l;
                    break;
                }
                case "E": case "G": {
                    int idx = kind.equals("E") ? d[f] & 0xFF : le16(d, f);
                    String[] names = ENUMS.get(spec[2]);
                    v = names != null && idx < names.length ? names[idx] : (Object) (long) idx;
                    break;
                }
                default: v = null;
            }
            if (v != null) m.put(key, v);
        }
        return m;
    }

    static String str(byte[] d, int f) {
        int s = f + le32(d, f);
        return new String(d, s + 4, le32(d, s), StandardCharsets.UTF_8);
    }

    static int le32(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
    }

    static int le16(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
    }

    // ------------------------------------------------------------------ tiny JSON (plain .glb files)
    public static final class Json {
        final String s;
        int p;

        Json(String s) { this.s = s; }

        public static Object parse(String s) throws IOException {
            try {
                Json j = new Json(s);
                return j.value();
            } catch (RuntimeException e) {
                throw new IOException("Повреждённый JSON");
            }
        }

        void ws() { while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++; }

        Object value() {
            ws();
            char c = s.charAt(p);
            if (c == '{') {
                p++;
                Map<String, Object> m = new LinkedHashMap<>();
                ws();
                if (s.charAt(p) == '}') { p++; return m; }
                while (true) {
                    ws();
                    String k = string();
                    ws();
                    p++; // :
                    m.put(k, value());
                    ws();
                    if (s.charAt(p++) == '}') return m;
                }
            }
            if (c == '[') {
                p++;
                List<Object> l = new ArrayList<>();
                ws();
                if (s.charAt(p) == ']') { p++; return l; }
                while (true) {
                    l.add(value());
                    ws();
                    if (s.charAt(p++) == ']') return l;
                }
            }
            if (c == '"') return string();
            if (s.startsWith("true", p)) { p += 4; return true; }
            if (s.startsWith("false", p)) { p += 5; return false; }
            if (s.startsWith("null", p)) { p += 4; return null; }
            int st = p;
            while (p < s.length() && "+-0123456789.eE".indexOf(s.charAt(p)) >= 0) p++;
            String n = s.substring(st, p);
            if (n.contains(".") || n.contains("e") || n.contains("E")) return Double.parseDouble(n);
            return Long.parseLong(n);
        }

        String string() {
            StringBuilder b = new StringBuilder();
            p++;
            while (true) {
                char c = s.charAt(p++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    char e = s.charAt(p++);
                    switch (e) {
                        case 'n': b.append('\n'); break;
                        case 't': b.append('\t'); break;
                        case 'r': b.append('\r'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'u': b.append((char) Integer.parseInt(s.substring(p, p + 4), 16)); p += 4; break;
                        default: b.append(e);
                    }
                } else {
                    b.append(c);
                }
            }
        }
    }

    /** JSON text of a value (for the "structure" view and debugging). */
    public static String toJson(Object o, int maxLen) {
        StringBuilder sb = new StringBuilder();
        write(sb, o, maxLen);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    static void write(StringBuilder sb, Object o, int max) {
        if (sb.length() > max) return;
        if (o instanceof Map) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> e : ((Map<String, Object>) o).entrySet()) {
                if (!first) sb.append(',');
                first = false;
                sb.append('"').append(e.getKey()).append("\":");
                write(sb, e.getValue(), max);
            }
            sb.append('}');
        } else if (o instanceof List) {
            sb.append('[');
            List<Object> l = (List<Object>) o;
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(',');
                write(sb, l.get(i), max);
            }
            sb.append(']');
        } else if (o instanceof String) {
            sb.append('"').append(((String) o).replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        } else if (o instanceof byte[]) {
            sb.append("\"<").append(((byte[]) o).length).append(" bytes>\"");
        } else if (o instanceof Double) {
            double v = (Double) o;
            if (Double.isNaN(v) || Double.isInfinite(v)) sb.append('0');
            else if (v == Math.rint(v) && Math.abs(v) < 1e15) sb.append((long) v);
            else sb.append((float) v);
        } else {
            sb.append(o);
        }
    }
}
