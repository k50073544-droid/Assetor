package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.GlbWriter;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Render3d;
import com.weker.assetexplorer.codec.SupercellFiles;


import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Interactive 3D view of a .glb model with its texture. */
public final class Model3dActivity extends Activity {

    static final int REQ_PNG = 1, REQ_GLB = 2;
    static final int[] BGS = {0xFF20232F, 0xFF8A8F9C, 0xFFF2F3F5};

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private Db.Row row;
    private Model3d model;
    /** material textures and lightmaps found in the archive, by file name */
    private java.util.Map<String, Img> images = new java.util.HashMap<>();
    /** manual texture for every part (null = textures named by the model's materials) */
    private Img texture;
    private Db.Row textureRow;
    private List<Db.Row> candidates = new ArrayList<>();
    private ModelDisplay view;
    private android.widget.FrameLayout viewBox;
    private Loaded loaded;
    private TextView info, texBtn, lightChip, animBtn, playChip, speedChip;
    private int bgIndex;
    private boolean pngTransparent;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        row = Db.get(this).file(getIntent().getLongExtra("id", -1));
        if (row == null) {
            finish();
            return;
        }
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, p);
        String title = getIntent().getStringExtra("title");
        root.addView(Ui.bold(this, title != null ? title : row.name, 17, Ui.TEXT));
        info = Ui.text(this, "Читаю модель…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(info);

        viewBox = new android.widget.FrameLayout(this);
        root.addView(viewBox, Ui.lp(-1, 0, 1));
        GlModelView gv = new GlModelView(this);
        gv.onFailed = this::useSoftwareView;
        view = gv;
        viewBox.addView(gv, new android.widget.FrameLayout.LayoutParams(-1, -1));

        TextView hint = Ui.text(this, "Один палец — вращать · два пальца — приблизить и сдвинуть · двойной тап — сброс", 11, Ui.MUTED);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        root.addView(hint);

        texBtn = Ui.button(this, "Текстура: …", false);
        texBtn.setSingleLine(true);
        texBtn.setOnClickListener(v -> pickTexture());
        root.addView(texBtn, Ui.lp(-1, -2, 0));

        LinearLayout animRow = new LinearLayout(this);
        animRow.setGravity(Gravity.CENTER_VERTICAL);
        animRow.setPadding(0, Ui.dp(this, 6), 0, 0);
        animBtn = Ui.button(this, "Анимация: …", false);
        animBtn.setSingleLine(true);
        animBtn.setOnClickListener(v -> pickAnimation());
        animRow.addView(animBtn, Ui.lp(0, -2, 1));
        playChip = Ui.chip(this, "❚❚");
        playChip.setOnClickListener(v -> {
            view.setPlaying(!view.isPlaying());
            updatePlayChip();
        });
        LinearLayout.LayoutParams pl = Ui.lp(-2, -2, 0);
        pl.leftMargin = Ui.dp(this, 6);
        animRow.addView(playChip, pl);
        speedChip = Ui.chip(this, "1×");
        speedChip.setOnClickListener(v -> {
            float sp = view.speed() == 1f ? 0.5f : view.speed() == 0.5f ? 0.25f : 1f;
            view.setSpeed(sp);
            speedChip.setText(sp == 1f ? "1×" : sp == 0.5f ? "½×" : "¼×");
        });
        animRow.addView(speedChip);
        root.addView(animRow);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(this, 8), 0, 0);
        lightChip = Ui.chip(this, "Свет");
        Ui.setChip(this, lightChip, true);
        lightChip.setOnClickListener(v -> {
            view.settings().lighting = !view.settings().lighting;
            Ui.setChip(this, lightChip, view.settings().lighting);
            view.request(false);
        });
        bar.addView(lightChip);
        TextView bgChip = Ui.chip(this, "Фон");
        bgChip.setOnClickListener(v -> {
            bgIndex = (bgIndex + 1) % BGS.length;
            view.settings().background = BGS[bgIndex];
            view.request(false);
        });
        bar.addView(bgChip);
        TextView partsChip = Ui.chip(this, "Части");
        partsChip.setOnClickListener(v -> pickParts());
        bar.addView(partsChip);
        TextView flip = Ui.chip(this, "Перевернуть UV");
        flip.setOnClickListener(v -> {
            view.settings().flipV = !view.settings().flipV;
            Ui.setChip(this, flip, view.settings().flipV);
            view.request(false);
        });
        bar.addView(flip);
        TextView save = Ui.button(this, "Сохранить", true);
        save.setOnClickListener(v -> saveMenu());
        bar.addView(save);
        hs.addView(bar);
        root.addView(hs);
        setContentView(root);

        bg.execute(() -> {
            try {
                Loaded l = load(this, row, getIntent().getStringExtra("texture"));
                main.post(() -> {
                    loaded = l;
                    model = l.model;
                    images = l.images;
                    candidates = l.candidates;
                    texture = l.override;
                    textureRow = l.overrideRow;
                    info.setText(l.describe());
                    updateTexButton();
                    view.setModel(l.model, l.images, l.override);
                    view.setAnimation(l.anim, l.animInfo == null ? 0 : l.animInfo.start, l.animInfo == null ? -1 : l.animInfo.end);
                    updateAnimButton();
                    String want = getIntent().getStringExtra("anim");
                    if (want != null) {
                        for (SkinTables.Anim a : l.anims) {
                            if (a.label.equals(want)) {
                                setAnimation(a);
                                break;
                            }
                        }
                    }
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Не удалось открыть модель: " + e.getMessage()));
            }
        });
    }

    /** Everything needed to draw a model: the model, its textures, and a fallback texture if it names none. */
    static final class Loaded {
        Model3d model;
        java.util.Map<String, Img> images = new java.util.HashMap<>();
        List<Db.Row> candidates = new ArrayList<>();
        Img override;
        Db.Row overrideRow;
        final List<String> found = new ArrayList<>(), missing = new ArrayList<>();
        /** textures before the face is painted on */
        java.util.Map<String, Img> rawImages = new java.util.HashMap<>();
        Img rawOverride;
        /** the 2D face (eyes, mouth) painted over the body texture */
        com.weker.assetexplorer.codec.Sc2 faceSc;
        String faceExport, bodyTex;
        List<SkinTables.Anim> anims = new ArrayList<>();
        com.weker.assetexplorer.codec.Anim3d anim;
        SkinTables.Anim animInfo;

        /** repaints the face on the body texture (and on a manually chosen texture) */
        void setFace(String export) {
            faceExport = export;
            images = new java.util.HashMap<>(rawImages);
            override = rawOverride;
            if (faceSc == null || export == null) return;
            try {
                if (bodyTex != null && rawImages.get(bodyTex) != null) {
                    images.put(bodyTex, com.weker.assetexplorer.codec.FaceOverlay.apply(rawImages.get(bodyTex), faceSc, export, 0));
                }
                if (rawOverride != null) override = com.weker.assetexplorer.codec.FaceOverlay.apply(rawOverride, faceSc, export, 0);
            } catch (Throwable ignored) {
                // keep the textures without a face
            }
        }

        void setOverride(Img tex) {
            rawOverride = tex;
            setFace(faceExport);
        }

        String describe() {
            StringBuilder sb = new StringBuilder(model.summary());
            if (!found.isEmpty()) sb.append("\nТекстуры модели: ").append(android.text.TextUtils.join(", ", found));
            if (!missing.isEmpty()) sb.append("\nНет в архиве: ").append(android.text.TextUtils.join(", ", missing));
            if (overrideRow != null) sb.append("\nТекстура подобрана по имени: ").append(overrideRow.name);
            else if (found.isEmpty()) sb.append("\nТекстура не найдена — выбери вручную.");
            sb.append(faceExport != null && faceSc != null ? "\nЛицо: " + faceExport : "\nЛицо (глаза) не найдено");
            sb.append(anims.isEmpty() ? " · анимаций не найдено" : " · анимаций: " + anims.size());
            if (!model.info.isEmpty()) sb.append('\n').append(model.info.get(0));
            return sb.toString();
        }
    }

    static Loaded load(Context c, Db.Row row) throws IOException {
        return load(c, row, null);
    }

    /** @param skinTexture texture of a skin (skins.csv DiffuseTexture) to use on the body instead of the model's own */
    static Loaded load(Context c, Db.Row row, String skinTexture) throws IOException {
        Loaded l = new Loaded();
        l.model = Model3d.load(Decoders.readAll(Blobs.file(c, row.blob)));
        Db db = Db.get(c);
        boolean anyDiffuse = false;
        java.util.Set<String> diffuse = new java.util.HashSet<>();
        for (Model3d.Part p : l.model.parts) if (p.diffuseTex != null) diffuse.add(p.diffuseTex);
        for (String name : l.model.materialTextures()) {
            List<String> one = new ArrayList<>();
            one.add(name);
            List<Db.Row> r = db.byPaths(row.vid, one);
            boolean isLightmap = !diffuse.contains(name);
            if (r.isEmpty()) {
                if (!isLightmap) l.missing.add(name);
                continue;
            }
            try {
                l.images.put(name, decodeTexture(c, r.get(0)));
                if (!isLightmap) {
                    l.found.add(name);
                    anyDiffuse = true;
                }
            } catch (Throwable e) {
                if (!isLightmap) l.missing.add(name + " (не читается)");
            }
        }
        l.candidates = textureCandidates(c, row, l.model);
        if (!anyDiffuse) { // older models don't name their texture: guess by file name
            for (int i = 0; i < l.candidates.size() && i < 3 && l.override == null; i++) {
                try {
                    l.override = decodeTexture(c, l.candidates.get(i));
                    l.overrideRow = l.candidates.get(i);
                } catch (Throwable ignored) {
                    // try the next one
                }
            }
        }
        // face and animations from the game tables (skin_confs / faces / animations.csv), else by file name
        l.bodyTex = com.weker.assetexplorer.codec.FaceOverlay.bodyTexture(l.model);
        if (skinTexture != null && !skinTexture.isEmpty()) {
            List<String> one = new ArrayList<>();
            one.add(skinTexture);
            List<Db.Row> sr = db.byPaths(row.vid, one);
            if (!sr.isEmpty()) {
                try {
                    Img st = decodeTexture(c, sr.get(0));
                    if (l.bodyTex != null) l.images.put(l.bodyTex, st);
                    else {
                        l.override = st;
                        l.overrideRow = sr.get(0);
                    }
                    l.found.add(skinTexture + " (скин)");
                } catch (Throwable ignored) {
                    // keep the model's own texture
                }
            }
        }
        l.rawImages = new java.util.HashMap<>(l.images);
        l.rawOverride = l.override;
        SkinTables t = SkinTables.get(c, row.vid);
        java.util.Map<String, String> conf = t.conf(row.name, skinTexture != null ? skinTexture
                : l.bodyTex != null ? l.bodyTex : l.overrideRow != null ? l.overrideRow.name : null);
        l.anims = t.animations(conf);
        if (l.anims.isEmpty()) l.anims = animationsByName(c, row);
        String[] face = t.face(conf != null ? conf.get("IdleFace") : null);
        String prefix = prefix(row.name);
        if (face != null) {
            l.faceSc = SkinTables.faceFile(c, row.vid, face[0]);
            l.faceExport = face[1];
        } else if (l.model.hasSkinning()) {
            com.weker.assetexplorer.codec.Sc2 sc = SkinTables.faceFile(c, row.vid, "characters.sc");
            if (sc != null && sc.exportIds.containsKey(prefix + "_face")) {
                l.faceSc = sc;
                l.faceExport = prefix + "_face";
            }
        }
        l.setFace(l.faceExport);
        // start with the idle animation, as the game shows it
        for (int i = 0; i < l.anims.size() && l.anim == null && i < 3; i++) {
            try {
                l.anim = loadAnim(c, row, l.model, l.anims.get(i));
                l.animInfo = l.anims.get(i);
                String[] f2 = t.face(l.animInfo.face);
                if (f2 != null && l.faceSc != null) l.setFace(f2[1]);
            } catch (Throwable ignored) {
                // try the next one
            }
        }
        return l;
    }

    /** first word of a file name: shelly_redux_geo.glb -> shelly */
    static String prefix(String name) {
        String base = name.toLowerCase(Locale.ROOT).replaceAll("\\.glb$", "");
        int i = base.indexOf('_');
        return i > 0 ? base.substring(0, i) : base;
    }

    /** without tables: .glb files next to the model that start like it and aren't geometry */
    static List<SkinTables.Anim> animationsByName(Context c, Db.Row row) {
        List<SkinTables.Anim> out = new ArrayList<>();
        for (Db.Row r : Db.get(c).modelsNear(row, prefix(row.name) + "_", 300)) {
            String n = r.name.toLowerCase(Locale.ROOT);
            if (r.path.equals(row.path) || n.contains("_geo") || n.contains("_cam") || n.contains("materials") || n.contains("_rig")) continue;
            SkinTables.Anim a = new SkinTables.Anim();
            a.label = r.name.replaceAll("(?i)\\.glb$", "");
            a.file = r.name;
            if (n.contains("idle")) out.add(0, a);
            else out.add(a);
        }
        return out;
    }

    static com.weker.assetexplorer.codec.Anim3d loadAnim(Context c, Db.Row row, Model3d m, SkinTables.Anim a) throws IOException {
        List<String> one = new ArrayList<>();
        one.add(a.file);
        List<Db.Row> r = Db.get(c).byPaths(row.vid, one);
        if (r.isEmpty()) throw new IOException("нет файла " + a.file);
        com.weker.assetexplorer.codec.Anim3d an = com.weker.assetexplorer.codec.Anim3d.load(Decoders.readAll(Blobs.file(c, r.get(0).blob)));
        if (m.matchingBones(an) == 0) throw new IOException("кости анимации не подходят к модели");
        return an;
    }

    private void updateTexButton() {
        String t;
        if (textureRow != null) t = textureRow.name;
        else if (texture == null && model != null && !model.materialTextures().isEmpty() && !images.isEmpty()) t = "из модели";
        else t = "нет";
        texBtn.setText("Текстура: " + t + "  ▾");
    }

    // ------------------------------------------------------------------ textures
    /**
     * Textures to offer, best first: the ones the model itself names, then textures in the same folder
     * whose name starts like the model's (shelly_redux_geo.glb -> shelly_redux_tex.sctx, shelly_*).
     */
    static List<Db.Row> textureCandidates(Context c, Db.Row row, Model3d m) {
        Db db = Db.get(c);
        List<Db.Row> out = new ArrayList<>();
        List<String> refs = new ArrayList<>();
        for (String r : m.textureRefs()) if (!r.toLowerCase(Locale.ROOT).contains("lightmap")) refs.add(r);
        for (Db.Row r : db.byPaths(row.vid, refs)) addUnique(out, r);
        String base = row.name.replaceAll("(?i)\\.glb$|\\.gltf$|\\.scw$", "").replaceAll("(?i)_(geo|rig|mesh|model)$", "");
        String first = base.contains("_") ? base.substring(0, base.indexOf('_')) : base;
        List<Db.Row> near = db.texturesNear(row, first, 400);
        List<Db.Row> sorted = new ArrayList<>(near);
        sorted.sort((a, b) -> Integer.compare(score(b.name, base), score(a.name, base)));
        for (Db.Row r : sorted) {
            if (r.name.toLowerCase(Locale.ROOT).contains("lightmap")) continue;
            addUnique(out, r);
        }
        return out;
    }

    static void addUnique(List<Db.Row> l, Db.Row r) {
        for (Db.Row x : l) if (x.path.equals(r.path)) return;
        l.add(r);
    }

    /** how well a texture name matches the model base name */
    static int score(String tex, String base) {
        String t = tex.toLowerCase(Locale.ROOT).replaceAll("\\.[a-z0-9]+$", "");
        String b = base.toLowerCase(Locale.ROOT);
        if (t.equals(b + "_tex") || t.equals(b)) return 10000;
        int common = 0;
        while (common < Math.min(t.length(), b.length()) && t.charAt(common) == b.charAt(common)) common++;
        int s = common * 10;
        if (t.endsWith("_tex")) s += 5;
        if (t.contains("chroma") || t.contains("_blue") || t.contains("_red")) s -= 3;
        return s - t.length() / 10;
    }

    static Img decodeTexture(Context c, Db.Row r) throws IOException {
        byte[] d = Decoders.readAll(Blobs.file(c, r.blob));
        if (Categorizer.T_IMG.equals(r.type)) {
            Bitmap b = BitmapFactory.decodeByteArray(d, 0, d.length);
            if (b == null) throw new IOException("картинка не читается");
            int[] px = new int[b.getWidth() * b.getHeight()];
            b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
            return new Img(b.getWidth(), b.getHeight(), px);
        }
        SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(d, r.name);
        if (ts.images.isEmpty()) throw new IOException("в файле нет картинки");
        return ts.images.get(0);
    }

    private void pickTexture() {
        if (model == null) return;
        List<String> names = new ArrayList<>();
        names.add("Авто — текстуры из материалов модели");
        names.add("— без текстуры —");
        for (Db.Row r : candidates) names.add((textureRow != null && r.path.equals(textureRow.path) ? "✓ " : "") + r.name);
        names.add("Найти другую текстуру…");
        new AlertDialog.Builder(this).setTitle("Текстура (лучшие совпадения сверху)")
                .setItems(names.toArray(new String[0]), (d, w) -> {
                    if (w == 0) {
                        textureRow = null;
                        loaded.setOverride(null);
                        texture = null;
                        images = loaded.images;
                        view.settings().textured = true;
                        updateTexButton();
                        view.setModel(model, images, null);
                    } else if (w == 1) {
                        textureRow = null;
                        texture = null;
                        view.settings().textured = false;
                        texBtn.setText("Текстура: нет  ▾");
                        view.request(false);
                    } else if (w == names.size() - 1) {
                        searchTexture();
                    } else {
                        setTexture(candidates.get(w - 2));
                    }
                }).show();
    }

    private void searchTexture() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 12);
        box.setPadding(p, p, p, 0);
        EditText q = new EditText(this);
        q.setHint("часть имени, например gold");
        q.setSingleLine(true);
        box.addView(q);
        ListView lv = new ListView(this);
        List<Db.Row> found = new ArrayList<>();
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(-1, Ui.dp(this, 360)));
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Текстуры в папке модели").setView(box)
                .setNegativeButton("Отмена", null).show();
        Runnable search = () -> {
            String text = q.getText().toString().trim();
            bg.execute(() -> {
                List<Db.Row> r = Db.get(this).texturesNear(row, text, 300);
                main.post(() -> {
                    found.clear();
                    found.addAll(r);
                    ad.clear();
                    for (Db.Row x : r) ad.add(x.name);
                    ad.notifyDataSetChanged();
                });
            });
        };
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(Editable e) {
                main.removeCallbacks(search);
                main.postDelayed(search, 250);
            }
        });
        lv.setOnItemClickListener((pa, v, pos, id) -> {
            dlg.dismiss();
            Db.Row r = found.get(pos);
            addUnique(candidates, r);
            setTexture(r);
        });
        search.run();
    }

    private void setTexture(Db.Row r) {
        view.settings().textured = true;
        texBtn.setText("Текстура: загружаю…");
        bg.execute(() -> {
            try {
                Img t = decodeTexture(this, r);
                loaded.setOverride(t); // paints the face on it too
                main.post(() -> {
                    textureRow = r;
                    texture = loaded.override;
                    images = loaded.images;
                    updateTexButton();
                    view.setModel(model, images, texture);
                });
            } catch (Throwable e) {
                main.post(() -> {
                    updateTexButton();
                    Toast.makeText(this, "Не удалось прочитать " + r.name + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    /** the GPU view failed on this phone: continue with the CPU renderer (slower, same picture) */
    private void useSoftwareView() {
        ModelDisplay old = view;
        SoftModelView sv = new SoftModelView(this);
        Render3d a = old.settings(), b = sv.settings();
        b.yaw = a.yaw;
        b.pitch = a.pitch;
        b.zoom = a.zoom;
        b.panX = a.panX;
        b.panY = a.panY;
        b.lighting = a.lighting;
        b.textured = a.textured;
        b.flipV = a.flipV;
        b.background = a.background;
        viewBox.removeAllViews();
        viewBox.addView(sv, new android.widget.FrameLayout.LayoutParams(-1, -1));
        view = sv;
        if (model != null) {
            sv.setModel(model, images, texture);
            if (loaded != null && loaded.anim != null) sv.setAnimation(loaded.anim, loaded.animInfo.start, loaded.animInfo.end);
        }
        updatePlayChip();
        Toast.makeText(this, "Видеокарта недоступна — рисую процессором", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (view instanceof GlModelView) ((GlModelView) view).onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (view instanceof GlModelView) ((GlModelView) view).onResume();
    }

    // ------------------------------------------------------------------ animations
    private void updateAnimButton() {
        String t = loaded == null || loaded.animInfo == null ? (loaded != null && loaded.anims.isEmpty() ? "не найдено" : "нет (исходная поза)")
                : loaded.animInfo.label + " · " + loaded.animInfo.file;
        animBtn.setText("Анимация: " + t + "  ▾");
        updatePlayChip();
    }

    private void updatePlayChip() {
        playChip.setText(view.isPlaying() ? "❚❚" : "▶");
        Ui.setChip(this, playChip, view.isPlaying());
    }

    private void pickAnimation() {
        if (loaded == null) return;
        List<String> names = new ArrayList<>();
        names.add("— без анимации (исходная поза) —");
        for (SkinTables.Anim a : loaded.anims) {
            boolean cur = loaded.animInfo != null && a.file.equals(loaded.animInfo.file) && a.start == loaded.animInfo.start;
            names.add((cur ? "✓ " : "") + a.label + "  ·  " + a.file);
        }
        names.add("Другой файл анимации…");
        new AlertDialog.Builder(this).setTitle("Анимация").setItems(names.toArray(new String[0]), (d, w) -> {
            if (w == 0) {
                loaded.anim = null;
                loaded.animInfo = null;
                view.setAnimation(null, 0, -1);
                updateAnimButton();
            } else if (w == names.size() - 1) {
                otherAnimation();
            } else {
                setAnimation(loaded.anims.get(w - 1));
            }
        }).show();
    }

    /** any .glb next to the model (animations of other skins with the same skeleton work too) */
    private void otherAnimation() {
        bg.execute(() -> {
            List<Db.Row> rows = Db.get(this).modelsNear(row, prefix(row.name), 500);
            List<Db.Row> list = new ArrayList<>();
            for (Db.Row r : rows) if (!r.name.toLowerCase(Locale.ROOT).contains("_geo") && !r.path.equals(row.path)) list.add(r);
            main.post(() -> {
                if (list.isEmpty()) {
                    Toast.makeText(this, "Рядом нет других .glb", Toast.LENGTH_SHORT).show();
                    return;
                }
                String[] n = new String[list.size()];
                for (int i = 0; i < n.length; i++) n[i] = list.get(i).name;
                new AlertDialog.Builder(this).setTitle("Файлы " + prefix(row.name) + "_*").setItems(n, (d, w) -> {
                    SkinTables.Anim a = new SkinTables.Anim();
                    a.label = list.get(w).name.replaceAll("(?i)\\.glb$", "");
                    a.file = list.get(w).name;
                    setAnimation(a);
                }).show();
            });
        });
    }

    private void setAnimation(SkinTables.Anim a) {
        animBtn.setText("Анимация: загружаю…");
        bg.execute(() -> {
            try {
                com.weker.assetexplorer.codec.Anim3d an = loadAnim(this, row, model, a);
                // the face that goes with this situation (happy for a win, sad for a loss)
                String[] f = SkinTables.get(this, row.vid).face(a.face);
                if (f != null && loaded.faceSc != null) loaded.setFace(f[1]);
                main.post(() -> {
                    loaded.anim = an;
                    loaded.animInfo = a;
                    images = loaded.images;
                    texture = loaded.override;
                    view.setModel(model, images, texture);
                    view.setAnimation(an, a.start, a.end);
                    updateAnimButton();
                    int miss = an.tracks.size() - model.matchingBones(an);
                    if (miss > 0) Toast.makeText(this, "Костей нет в модели: " + miss + " (часть движения не видна)", Toast.LENGTH_SHORT).show();
                });
            } catch (Throwable e) {
                main.post(() -> {
                    updateAnimButton();
                    Toast.makeText(this, a.file + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ------------------------------------------------------------------ parts
    private void pickParts() {
        if (model == null) return;
        int n = model.parts.size();
        String[] names = new String[n];
        boolean[] on = new boolean[n];
        for (int i = 0; i < n; i++) {
            Model3d.Part p = model.parts.get(i);
            names[i] = p.name + "  ·  " + p.triangles + " треуг.";
            on[i] = p.visible;
        }
        new AlertDialog.Builder(this).setTitle("Какие части показывать")
                .setMultiChoiceItems(names, on, (d, w, checked) -> {
                    model.parts.get(w).visible = checked;
                    view.request(false);
                })
                .setPositiveButton("Готово", null).show();
    }

    // ------------------------------------------------------------------ saving
    private void saveMenu() {
        if (model == null) return;
        String base = row.name.replaceAll("(?i)\\.glb$", "");
        String[] items = {"PNG 1024 px — прозрачный фон", "PNG 1024 px — с фоном", ".glb для Blender (с текстурой)"};
        new AlertDialog.Builder(this).setTitle("Сохранить").setItems(items, (d, w) -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            if (w < 2) {
                pngTransparent = w == 0;
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_TITLE, base + ".png");
                startActivityForResult(i, REQ_PNG);
            } else {
                i.setType("model/gltf-binary");
                i.putExtra(Intent.EXTRA_TITLE, base + "_blender.glb");
                startActivityForResult(i, REQ_GLB);
            }
        }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null || model == null) return;
        Uri uri = data.getData();
        Img tex = texture;
        java.util.Map<String, Img> imgs = images;
        Model3d posed = view.posedModel();
        boolean transparent = pngTransparent;
        Render3d r = new Render3d();
        r.yaw = view.settings().yaw;
        r.pitch = view.settings().pitch;
        r.zoom = view.settings().zoom;
        r.panX = view.settings().panX;
        r.panY = view.settings().panY;
        r.lighting = view.settings().lighting;
        r.flipV = view.settings().flipV;
        r.textured = view.settings().textured;
        r.frameBounds = view.settings().frameBounds;
        r.background = transparent ? 0 : view.settings().background;
        int vw = Math.max(1, view.view().getWidth()), vh = Math.max(1, view.view().getHeight());
        Toast.makeText(this, "Сохраняю…", Toast.LENGTH_SHORT).show();
        bg.execute(() -> {
            String msg;
            try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new IOException("нет доступа");
                if (req == REQ_PNG) {
                    int w = 1024, h = Math.max(1, Math.round(1024f * vh / vw));
                    if (h > 1024) {
                        w = Math.round(1024f * vw / vh);
                        h = 1024;
                    }
                    Img im = r.render(posed, imgs, tex, w, h, 2);
                    Decoders.toBitmap(im).compress(Bitmap.CompressFormat.PNG, 100, o);
                } else {
                    // one texture per material in the exported file
                    java.util.Map<String, byte[]> pngs = new java.util.HashMap<>();
                    for (Model3d.Part p : model.parts) {
                        Img t = !r.textured ? null : tex != null ? tex : p.diffuseTex != null ? imgs.get(p.diffuseTex) : null;
                        String key = tex != null ? "override" : p.diffuseTex;
                        if (t == null || key == null || pngs.containsKey(key)) continue;
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        Decoders.toBitmap(t).compress(Bitmap.CompressFormat.PNG, 100, bo);
                        pngs.put(key, bo.toByteArray());
                    }
                    BufferedOutputStream bout = new BufferedOutputStream(o, 1 << 16);
                    GlbWriter.write(model, pngs, tex != null ? "override" : null, bout);
                    bout.flush();
                }
                msg = "Сохранено";
            } catch (Throwable e) {
                msg = "Ошибка: " + e.getMessage();
            }
            String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (view != null) view.release();
        bg.shutdownNow();
    }
}
