package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A grid of cards (picture loaded in the background, title, subtitle, colour strip). */
public final class CardGrid extends GridView {

    public interface Loader {
        Bitmap load();
    }

    public static final class Card {
        public String key, title, subtitle = "";
        public int color = 0xFF3A4054;
        public Loader picture;
        public Runnable click, longClick;
        /** text drawn instead of a picture (when there is none) */
        public String glyph;
    }

    static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(48 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };
    /** the game's font for titles (set once the archive's LilitaOne is loaded) */
    public static volatile android.graphics.Typeface font;
    static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    static final Bitmap NONE = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);

    private final Handler main = new Handler(Looper.getMainLooper());
    private List<Card> cards = new ArrayList<>();
    private final Adapter adapter = new Adapter();
    private final int cellH;

    public CardGrid(Context c, int columnsDp, int cellHeightDp) {
        super(c);
        setColumnWidth(Ui.dp(c, columnsDp));
        setNumColumns(AUTO_FIT);
        setStretchMode(STRETCH_COLUMN_WIDTH);
        setHorizontalSpacing(Ui.dp(c, 8));
        setVerticalSpacing(Ui.dp(c, 8));
        setSelector(new android.graphics.drawable.ColorDrawable(0));
        cellH = Ui.dp(c, cellHeightDp);
        setAdapter(adapter);
        setOnItemClickListener((p, v, i, id) -> {
            Card k = cards.get(i);
            if (k.click != null) k.click.run();
        });
        setOnItemLongClickListener((p, v, i, id) -> {
            Card k = cards.get(i);
            if (k.longClick == null) return false;
            k.longClick.run();
            return true;
        });
    }

    public void setCards(List<Card> l) {
        cards = l;
        adapter.notifyDataSetChanged();
        setSelection(0);
    }

    final class Adapter extends BaseAdapter {
        @Override
        public int getCount() { return cards.size(); }

        @Override
        public Object getItem(int i) { return cards.get(i); }

        @Override
        public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            Context c = getContext();
            Holder h;
            if (v == null) {
                h = new Holder();
                LinearLayout cell = new LinearLayout(c);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setBackground(Ui.round(Ui.CARD, Ui.dp(c, 12)));
                cell.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 8));
                FrameLayout box = new FrameLayout(c);
                h.box = box;
                h.image = new ImageView(c);
                h.image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                box.addView(h.image, new FrameLayout.LayoutParams(-1, -1));
                h.glyph = Ui.bold(c, "", 26, Ui.TEXT);
                h.glyph.setGravity(Gravity.CENTER);
                box.addView(h.glyph, new FrameLayout.LayoutParams(-1, -1));
                cell.addView(box, new LinearLayout.LayoutParams(-1, cellH));
                h.title = Ui.bold(c, "", 13, Ui.TEXT);
                h.title.setMaxLines(2);
                h.title.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.addView(h.title);
                h.sub = Ui.text(c, "", 11, Ui.MUTED);
                h.sub.setSingleLine(true);
                h.sub.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.addView(h.sub);
                v = cell;
                v.setTag(h);
            } else {
                h = (Holder) v.getTag();
            }
            Card k = cards.get(i);
            if (font != null) {
                h.title.setTypeface(font);
                h.title.setShadowLayer(3f, 0, 2f, 0xFF000000);
                h.title.setTextColor(0xFFFFFFFF);
            }
            h.title.setText(k.title);
            h.sub.setText(k.subtitle);
            h.box.setBackground(Ui.round(k.color, Ui.dp(c, 9)));
            h.key = k.key;
            h.image.setImageBitmap(null);
            h.glyph.setText(k.glyph != null ? k.glyph : "");
            if (k.picture != null && k.key != null) {
                Bitmap b = CACHE.get(k.key);
                if (b != null) {
                    if (b != NONE) {
                        h.image.setImageBitmap(b);
                        h.glyph.setText("");
                    }
                } else {
                    final Holder hh = h;
                    POOL.execute(() -> {
                        if (!k.key.equals(hh.key)) return;
                        Bitmap bm = null;
                        try {
                            bm = k.picture.load();
                        } catch (Throwable ignored) {
                            // no picture
                        }
                        CACHE.put(k.key, bm != null ? bm : NONE);
                        Bitmap fb = bm;
                        main.post(() -> {
                            if (k.key.equals(hh.key) && fb != null) {
                                hh.image.setImageBitmap(fb);
                                hh.glyph.setText("");
                            }
                        });
                    });
                }
            }
            return v;
        }
    }

    static final class Holder {
        FrameLayout box;
        ImageView image;
        TextView title, sub, glyph;
        String key;
    }
}
