package com.weker.assetexplorer;

import android.opengl.GLES20;

import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Scene3d;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Draws a {@link Scene3d} with OpenGL ES 2.0 (call from a GLSurfaceView renderer).
 * Same shading as {@link GlModelView}; parts that never change go to GPU buffers once.
 */
public final class GlScene {

    static final String VS = "attribute vec3 aPos;\n"
            + "attribute vec3 aNrm;\n"
            + "attribute vec2 aUv;\n"
            + "attribute vec4 aCol;\n"
            + "uniform mat4 uMvp;\n"
            + "uniform mat3 uRot;\n"
            + "varying vec2 vUv;\n"
            + "varying vec3 vN;\n"
            + "varying vec4 vCol;\n"
            + "void main() {\n"
            + "  gl_Position = uMvp * vec4(aPos, 1.0);\n"
            + "  vN = uRot * aNrm;\n"
            + "  vUv = aUv;\n"
            + "  vCol = aCol;\n"
            + "}\n";

    /** uMode: 0 flat, 1 soft light, 2 matcap diffuse, 3 matcap diffuse + specular */
    static final String FS = "precision mediump float;\n"
            + "uniform sampler2D uTex;\n"
            + "uniform sampler2D uLmD;\n"
            + "uniform sampler2D uLmS;\n"
            + "uniform float uMode;\n"
            + "uniform float uTextured;\n"
            + "uniform float uVCol;\n"
            + "uniform vec4 uColor;\n"
            + "uniform vec3 uFlash;\n"
            + "varying vec2 vUv;\n"
            + "varying vec3 vN;\n"
            + "varying vec4 vCol;\n"
            + "void main() {\n"
            + "  vec4 c = uVCol > 0.5 ? vCol : vec4(0.77, 0.79, 0.83, 1.0);\n"
            + "  if (uTextured > 0.5) {\n"
            + "    c = texture2D(uTex, vUv);\n"
            + "    if (c.a < 0.4) discard;\n"
            + "  } else if (uVCol < 0.5 && uMode < 0.5) {\n"
            + "    c = vec4(1.0);\n"
            + "  }\n"
            + "  vec3 n = normalize(vN);\n"
            + "  if (n.z < 0.0) n = -n;\n"
            + "  vec3 col = c.rgb;\n"
            + "  if (uMode > 0.5 && uMode < 1.5) {\n"
            + "    col *= 0.52 + 0.58 * max(0.0, dot(n, vec3(-0.45, 0.62, 0.64)));\n"
            + "  } else if (uMode > 1.5) {\n"
            + "    vec2 m = vec2(n.x * 0.48 + 0.5, 0.5 - n.y * 0.48);\n"
            + "    col *= texture2D(uLmD, m).rgb;\n"
            + "    if (uMode > 2.5) col += texture2D(uLmS, m).rgb;\n"
            + "  }\n"
            + "  col = col * uColor.rgb + uFlash;\n"
            + "  gl_FragColor = vec4(min(col, vec3(1.0)), uColor.a);\n"
            + "}\n";

    private int program, aPos, aNrm, aUv, aCol, uMvp, uRot, uTex, uLmD, uLmS, uMode, uTextured, uVCol, uColor, uFlash;
    private int whiteTex;
    private boolean ready;
    private final Map<Img, Integer> gpuTextures = new IdentityHashMap<>();
    private final Map<float[], FloatBuffer> uvBuffers = new IdentityHashMap<>();
    /** still parts: pos, nrm, uv, colour buffer ids */
    private final Map<Model3d.Part, int[]> vbos = new IdentityHashMap<>();
    private FloatBuffer posBuf, nrmBuf;
    public int width = 1, height = 1;

    /** call from onSurfaceCreated (all GPU objects are new then) */
    public void init() {
        gpuTextures.clear();
        uvBuffers.clear();
        vbos.clear();
        program = GlModelView.link(GlModelView.compile(GLES20.GL_VERTEX_SHADER, VS), GlModelView.compile(GLES20.GL_FRAGMENT_SHADER, FS));
        aPos = GLES20.glGetAttribLocation(program, "aPos");
        aNrm = GLES20.glGetAttribLocation(program, "aNrm");
        aUv = GLES20.glGetAttribLocation(program, "aUv");
        aCol = GLES20.glGetAttribLocation(program, "aCol");
        uMvp = GLES20.glGetUniformLocation(program, "uMvp");
        uRot = GLES20.glGetUniformLocation(program, "uRot");
        uTex = GLES20.glGetUniformLocation(program, "uTex");
        uLmD = GLES20.glGetUniformLocation(program, "uLmD");
        uLmS = GLES20.glGetUniformLocation(program, "uLmS");
        uMode = GLES20.glGetUniformLocation(program, "uMode");
        uTextured = GLES20.glGetUniformLocation(program, "uTextured");
        uVCol = GLES20.glGetUniformLocation(program, "uVCol");
        uColor = GLES20.glGetUniformLocation(program, "uColor");
        uFlash = GLES20.glGetUniformLocation(program, "uFlash");
        whiteTex = GlModelView.upload(new Img(1, 1, new int[]{0xFFFFFFFF}));
        ready = true;
    }

    public void resize(int w, int h) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        GLES20.glViewport(0, 0, width, height);
    }

    public void draw(Scene3d s) {
        int bg = s.background;
        GLES20.glClearColor(((bg >> 16) & 255) / 255f, ((bg >> 8) & 255) / 255f, (bg & 255) / 255f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        if (!ready) return;
        GLES20.glUseProgram(program);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthFunc(GLES20.GL_LEQUAL);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        GLES20.glUniform1i(uTex, 0);
        GLES20.glUniform1i(uLmD, 1);
        GLES20.glUniform1i(uLmS, 2);
        float[] proj = s.projection(width / (float) height);
        // background, then solid things, then see-through things (shadows, bushes the brawler hides in)
        for (int pass = 0; pass < 3; pass++) {
            for (Scene3d.Item it : s.items) {
                boolean see = (it.color >>> 24) < 255 || it.overlay;
                int want = it.background ? 0 : see ? 2 : 1;
                if (want != pass) continue;
                GLES20.glDepthMask(pass == 1);
                if (pass == 0) GLES20.glDisable(GLES20.GL_DEPTH_TEST);
                else GLES20.glEnable(GLES20.GL_DEPTH_TEST);
                if (pass == 2) {
                    GLES20.glEnable(GLES20.GL_BLEND);
                    GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
                } else {
                    GLES20.glDisable(GLES20.GL_BLEND);
                }
                drawItem(s, it, proj);
            }
            if (pass == 0) GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT);
        }
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    private void drawItem(Scene3d s, Scene3d.Item it, float[] proj) {
        float[] mv = Scene3d.mul(s.view, it.matrix);
        float[] mvp = Scene3d.mul(proj, mv);
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
        float[] rot = {mv[0], mv[1], mv[2], mv[4], mv[5], mv[6], mv[8], mv[9], mv[10]};
        GLES20.glUniformMatrix3fv(uRot, 1, false, rot, 0);
        int c = it.color;
        GLES20.glUniform4f(uColor, ((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, (c >>> 24) / 255f);
        int f = it.flash;
        GLES20.glUniform3f(uFlash, ((f >> 16) & 255) / 255f, ((f >> 8) & 255) / 255f, (f & 255) / 255f);
        GLES20.glUniform1f(uVCol, it.vertexColors ? 1f : 0f);
        Map<String, Img> imgs = it.images;
        for (Model3d.Part p : it.model.parts) {
            if (!p.visible || p.triangles == 0) continue;
            if (it.onlyParts != null && !it.onlyParts.contains(p.name)) continue;
            Img tex = null;
            if (p.hasUv) tex = it.override != null ? it.override : imgs != null && p.diffuseTex != null ? imgs.get(p.diffuseTex) : null;
            Img lmD = !it.overlay && imgs != null && p.lightmapDiffuse != null ? imgs.get(p.lightmapDiffuse) : null;
            Img lmS = !it.overlay && imgs != null && p.lightmapSpecular != null ? imgs.get(p.lightmapSpecular) : null;
            float mode = it.overlay ? 0 : lmD == null ? 1 : lmS == null ? 2 : 3;
            GLES20.glUniform1f(uMode, mode);
            GLES20.glUniform1f(uTextured, tex != null ? 1f : 0f);
            bind(0, tex);
            bind(1, lmD);
            bind(2, lmS);
            int n = p.triangles * 3;
            if (it.still) {
                int[] b = vbos.get(p);
                if (b == null) {
                    b = upload(p);
                    vbos.put(p, b);
                }
                attrib(aPos, 3, b[0]);
                attrib(aNrm, 3, b[1]);
                attrib(aUv, 2, b[2]);
                if (b[3] != 0) {
                    GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, b[3]);
                    GLES20.glEnableVertexAttribArray(aCol);
                    GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_UNSIGNED_BYTE, true, 0, 0);
                } else {
                    GLES20.glDisableVertexAttribArray(aCol);
                    GLES20.glVertexAttrib4f(aCol, 1, 1, 1, 1);
                }
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
            } else {
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
                posBuf = GlModelView.fill(posBuf, p.pos, n * 3);
                nrmBuf = GlModelView.fill(nrmBuf, normals(p), n * 3);
                FloatBuffer uv = uvBuffers.get(p.uv);
                if (uv == null) {
                    uv = GlModelView.fill(null, p.uv, n * 2);
                    if (uvBuffers.size() > 400) uvBuffers.clear();
                    uvBuffers.put(p.uv, uv);
                }
                GLES20.glEnableVertexAttribArray(aPos);
                GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, posBuf);
                GLES20.glEnableVertexAttribArray(aNrm);
                GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 0, nrmBuf);
                GLES20.glEnableVertexAttribArray(aUv);
                GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 0, uv);
                GLES20.glDisableVertexAttribArray(aCol);
                GLES20.glVertexAttrib4f(aCol, 1, 1, 1, 1);
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, n);
        }
    }

    private void attrib(int loc, int size, int buffer) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, buffer);
        GLES20.glEnableVertexAttribArray(loc);
        GLES20.glVertexAttribPointer(loc, size, GLES20.GL_FLOAT, false, 0, 0);
    }

    static float[] normals(Model3d.Part p) {
        if (p.hasNormals && p.nrm != null) return p.nrm;
        float[] out = new float[p.triangles * 9];
        for (int t = 0; t < p.triangles; t++) {
            int i = t * 9;
            float ax = p.pos[i + 3] - p.pos[i], ay = p.pos[i + 4] - p.pos[i + 1], az = p.pos[i + 5] - p.pos[i + 2];
            float bx = p.pos[i + 6] - p.pos[i], by = p.pos[i + 7] - p.pos[i + 1], bz = p.pos[i + 8] - p.pos[i + 2];
            float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            for (int k = 0; k < 3; k++) {
                out[i + k * 3] = nx;
                out[i + k * 3 + 1] = ny;
                out[i + k * 3 + 2] = nz;
            }
        }
        if (p.nrm == null || !p.hasNormals) p.nrm = out;
        p.hasNormals = true;
        return out;
    }

    private int[] upload(Model3d.Part p) {
        int n = p.triangles * 3;
        int[] ids = new int[4];
        GLES20.glGenBuffers(p.colors != null ? 4 : 3, ids, 0);
        buffer(ids[0], p.pos, n * 3);
        buffer(ids[1], normals(p), n * 3);
        buffer(ids[2], p.uv, n * 2);
        if (p.colors != null) {
            ByteBuffer bb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder());
            for (int i = 0; i < n; i++) {
                int c = p.colors[i];
                bb.put((byte) (c >> 16)).put((byte) (c >> 8)).put((byte) c).put((byte) (c >>> 24));
            }
            bb.position(0);
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[3]);
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 4, bb, GLES20.GL_STATIC_DRAW);
        } else {
            ids[3] = 0;
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        return ids;
    }

    private static void buffer(int id, float[] data, int n) {
        FloatBuffer fb = GlModelView.fill(null, data, n);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, id);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, Math.min(n, data.length) * 4, fb, GLES20.GL_STATIC_DRAW);
    }

    private void bind(int unit, Img im) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit);
        int id = whiteTex;
        if (im != null) {
            Integer t = gpuTextures.get(im);
            if (t == null) {
                if (gpuTextures.size() > 48) {
                    for (Integer old : gpuTextures.values()) GLES20.glDeleteTextures(1, new int[]{old}, 0);
                    gpuTextures.clear();
                }
                t = GlModelView.upload(im);
                gpuTextures.put(im, t);
            }
            id = t;
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
    }
}
