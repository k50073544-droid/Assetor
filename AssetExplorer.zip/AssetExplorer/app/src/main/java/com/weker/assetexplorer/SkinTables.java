package com.weker.assetexplorer;

import android.content.Context;

import com.weker.assetexplorer.codec.Sc2;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The game's tables that tie a 3D model to its animations and faces:
 * skin_confs.csv (model + animation / face per situation), animations.csv (file and frame range),
 * faces.csv (2D face export), skins.csv (which texture a skin uses). Loaded once per version.
 */
public final class SkinTables {

    /** one animation choice for a model */
    public static final class Anim {
        public String label, file, face;
        public int start, end = -1;
    }

    private static SkinTables cached;
    private static long cachedVid = -1;

    final Map<String, List<Map<String, String>>> confsByModel = new HashMap<>();
    final Map<String, String> textureByConf = new HashMap<>();
    final Map<String, String[]> anims = new HashMap<>();   // name -> file, start, end
    final Map<String, String[]> faces = new HashMap<>();   // name -> file, export
    public boolean loaded;

    /** situation columns in skin_confs.csv, in the order they are offered, with Russian names */
    static final String[][] SLOTS = {
            {"Idle", "Стоит"}, {"Walk", "Идёт"}, {"PrimarySkill", "Атака"}, {"SecondarySkill", "Супер"},
            {"OverchargedSecondarySkill", "Супер (гиперзаряд)"}, {"Reloading", "Перезарядка"}, {"Pushback", "Отброс"},
            {"Happy", "Победа"}, {"HappyLoop", "Победа (цикл)"}, {"Sad", "Поражение"}, {"SadLoop", "Поражение (цикл)"},
            {"Lobby", "Лобби"}, {"LobbyLoop", "Лобби (цикл)"}, {"HeroScreen", "Экран бойца"}, {"Signature", "Фирменная"},
            {"Profile", "Профиль"}, {"Intro", "Появление"}, {"GadgetActive", "Гаджет"}, {"Surprise", "Удивление"},
            {"ChargeMove", "Рывок"}, {"Deploy", "Выход"}};

    public static synchronized SkinTables get(Context c, long vid) {
        if (cached != null && cachedVid == vid) return cached;
        SkinTables t = new SkinTables();
        t.load(c, vid);
        cached = t;
        cachedVid = vid;
        return t;
    }

    private void load(Context c, long vid) {
        List<String[]> confs = table(c, vid, "skin_confs.csv");
        List<String[]> skins = table(c, vid, "skins.csv");
        List<String[]> an = table(c, vid, "animations.csv");
        List<String[]> fc = table(c, vid, "faces.csv");
        if (confs.size() > 2) {
            String[] h = confs.get(0);
            for (int i = 2; i < confs.size(); i++) {
                Map<String, String> row = new LinkedHashMap<>();
                String[] r = confs.get(i);
                for (int k = 0; k < h.length && k < r.length; k++) if (!r[k].isEmpty()) row.put(h[k], r[k]);
                String model = row.get("Model");
                if (model == null) continue;
                List<Map<String, String>> l = confsByModel.get(model.toLowerCase(Locale.ROOT));
                if (l == null) confsByModel.put(model.toLowerCase(Locale.ROOT), l = new ArrayList<>());
                l.add(row);
            }
            loaded = true;
        }
        if (skins.size() > 2) {
            int conf = col(skins.get(0), "Conf"), tex = col(skins.get(0), "DiffuseTexture");
            for (int i = 2; i < skins.size(); i++) {
                String[] r = skins.get(i);
                if (conf >= 0 && tex >= 0 && conf < r.length && tex < r.length && !r[tex].isEmpty() && !textureByConf.containsKey(r[conf])) {
                    textureByConf.put(r[conf], r[tex]);
                }
            }
        }
        if (an.size() > 2) {
            String[] h = an.get(0);
            int fn = col(h, "FileName"), sf = col(h, "StartFrame"), ef = col(h, "EndFrame");
            for (int i = 2; i < an.size(); i++) {
                String[] r = an.get(i);
                anims.put(r[0], new String[]{get(r, fn), get(r, sf), get(r, ef)});
            }
        }
        if (fc.size() > 2) {
            String[] h = fc.get(0);
            int fn = col(h, "FileName"), ex = col(h, "ExportName");
            for (int i = 2; i < fc.size(); i++) {
                String[] r = fc.get(i);
                faces.put(r[0], new String[]{get(r, fn), get(r, ex)});
            }
        }
    }

    static String get(String[] r, int i) {
        return i >= 0 && i < r.length ? r[i].trim() : "";
    }

    static int col(String[] h, String name) {
        for (int i = 0; i < h.length; i++) if (h[i].trim().equals(name)) return i;
        return -1;
    }

    static List<String[]> table(Context c, long vid, String name) {
        try {
            List<String> one = new ArrayList<>();
            one.add(name);
            List<Db.Row> rows = Db.get(c).byPaths(vid, one);
            if (rows.isEmpty()) return new ArrayList<>();
            String text = new String(Decoders.content(Blobs.file(c, rows.get(0).blob)), StandardCharsets.UTF_8);
            return Decoders.parseCsv(text, 200_000);
        } catch (Throwable e) {
            return new ArrayList<>();
        }
    }

    /** skin configuration rows using this model file (gold / silver skins can share one model) */
    public List<Map<String, String>> confs(String model) {
        List<Map<String, String>> l = confsByModel.get(model.toLowerCase(Locale.ROOT));
        return l == null ? new ArrayList<>() : l;
    }

    /** the conf whose skin uses this texture, else the first one */
    public Map<String, String> conf(String model, String texture) {
        List<Map<String, String>> l = confs(model);
        if (l.isEmpty()) return null;
        if (texture != null) {
            for (Map<String, String> r : l) {
                String t = textureByConf.get(r.get("Name"));
                if (t != null && t.equalsIgnoreCase(texture)) return r;
            }
        }
        return l.get(0);
    }

    /** animations for a model from its skin configuration (each file once, in situation order) */
    public List<Anim> animations(Map<String, String> conf) {
        List<Anim> out = new ArrayList<>();
        if (conf == null) return out;
        List<String> seen = new ArrayList<>();
        for (String[] slot : SLOTS) {
            String name = conf.get(slot[0] + "Anim");
            if (name == null) continue;
            String[] a = anims.get(name);
            if (a == null || a[0].isEmpty()) continue;
            String key = a[0] + "/" + a[1] + "/" + a[2];
            if (seen.contains(key)) continue;
            seen.add(key);
            Anim x = new Anim();
            x.label = slot[1];
            x.file = a[0];
            x.start = parse(a[1], 0);
            x.end = parse(a[2], -1);
            x.face = conf.get(slot[0] + "Face");
            if (x.face == null) x.face = conf.get("IdleFace");
            out.add(x);
        }
        return out;
    }

    static int parse(String s, int def) {
        try {
            return s.isEmpty() ? def : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** face file + export for a face name from faces.csv */
    public String[] face(String name) {
        return name == null ? null : faces.get(name);
    }

    // ------------------------------------------------------------------ face sc files
    private static final Map<String, Sc2> FACE_SC = new HashMap<>();

    /** parsed characters.sc (or whatever file the face lives in), cached */
    public static Sc2 faceFile(Context c, long vid, String file) {
        synchronized (FACE_SC) {
            String key = vid + "/" + file;
            if (FACE_SC.containsKey(key)) return FACE_SC.get(key);
            Sc2 s = null;
            try {
                List<String> one = new ArrayList<>();
                one.add(file);
                List<Db.Row> rows = Db.get(c).byPaths(vid, one);
                if (!rows.isEmpty()) s = Sc2.parse(Decoders.readAll(Blobs.file(c, rows.get(0).blob)));
            } catch (Throwable ignored) {
                // no faces
            }
            if (FACE_SC.size() > 2) FACE_SC.clear();
            FACE_SC.put(key, s);
            return s;
        }
    }
}
