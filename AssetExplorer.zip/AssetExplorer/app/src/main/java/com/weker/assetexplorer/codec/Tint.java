package com.weker.assetexplorer.codec;

/** Recolouring of textures (Starr Drop rarities share one yellow texture). */
public final class Tint {

    private Tint() {}

    /** hue of a rarity as the game shows Starr Drops: rare green … legendary yellow, ultra cyan; -1 = keep */
    public static float rarityHue(int rarity) {
        switch (rarity) {
            case 1: return 105;
            case 2: return 205;
            case 3: return 282;
            case 4: return 350;
            case 6: return 175;
            default: return -1;
        }
    }

    /** the picture with its hues turned so that yellow-orange (45°) becomes {@code hue} */
    public static Img hue(Img src, float hue) {
        if (src == null || hue < 0) return src;
        float shift = hue - 45;
        int[] out = new int[src.argb.length];
        float[] hsv = new float[3];
        for (int i = 0; i < out.length; i++) {
            int c = src.argb[i];
            float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
            float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
            float h = 0;
            if (d > 1e-5f) {
                if (max == r) h = 60 * (((g - b) / d) % 6);
                else if (max == g) h = 60 * ((b - r) / d + 2);
                else h = 60 * ((r - g) / d + 4);
            }
            hsv[0] = ((h + shift) % 360 + 360) % 360;
            hsv[1] = max == 0 ? 0 : d / max;
            hsv[2] = max;
            out[i] = (c & 0xFF000000) | rgb(hsv);
        }
        return new Img(src.width, src.height, out);
    }

    static int rgb(float[] hsv) {
        float h = hsv[0] / 60, s = hsv[1], v = hsv[2];
        int k = (int) Math.floor(h) % 6;
        float f = h - (float) Math.floor(h), p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (k) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
    }
}
