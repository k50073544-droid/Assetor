package com.weker.assetexplorer.codec;

import java.io.IOException;

/**
 * Pixel-format dispatch for Supercell (ScPixel), OpenGL (KTX) and the old SC1 _tex.sc formats.
 */
public final class PixelFormats {

    private PixelFormats() {}

    // -------------------------------------------------------------- ScPixel (SCTX)
    public static Img decodeScPixel(int type, byte[] d, int off, int w, int h) throws IOException {
        int[] astc = astcDims(type);
        if (astc != null) return new Img(w, h, Astc.decode(d, off, w, h, astc[0], astc[1]));
        switch (type) {
            case 1: return raw(d, off, w, h, RAW_A8);
            case 10: case 11: case 12: case 13: case 14: return raw(d, off, w, h, RAW_L8);
            case 30: case 31: case 32: case 33: case 34: return raw(d, off, w, h, RAW_RG8);
            case 40: return raw(d, off, w, h, RAW_565);
            case 42: return raw(d, off, w, h, RAW_4444);
            case 43: return raw(d, off, w, h, RAW_5551);
            case 70: case 71: case 72: case 73: case 74: return raw(d, off, w, h, RAW_RGBA8);
            case 80: case 81: return raw(d, off, w, h, RAW_BGRA8);
            case 264: return raw(d, off, w, h, RAW_L8);
            case 265: return raw(d, off, w, h, RAW_LA8);
            case 266: case 267: return raw(d, off, w, h, RAW_RGB8);
            case 170: case 172: return new Img(w, h, Etc.decode(d, off, w, h, Etc.R11));
            case 174: case 176: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RG11));
            case 178: case 179: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RGBA_EAC));
            case 180: case 181: case 263: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RGB));
            case 182: case 183: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RGB_A1));
            default:
                throw new IOException("Неподдерживаемый формат пикселей SCTX: " + type);
        }
    }

    static int[] astcDims(int type) {
        int[][] dims = {{4, 4}, {5, 4}, {5, 5}, {6, 5}, {6, 6}, {8, 5}, {8, 6}, {8, 8},
                {10, 5}, {10, 6}, {10, 8}, {10, 10}, {12, 10}, {12, 12}};
        if (type >= 186 && type <= 190) return dims[type - 186];
        if (type >= 192 && type <= 200) return dims[type - 192 + 5];
        if (type >= 204 && type <= 208) return dims[type - 204];
        if (type >= 210 && type <= 218) return dims[type - 210 + 5];
        return null;
    }

    public static String scPixelName(int type) {
        int[] a = astcDims(type);
        if (a != null) return "ASTC " + a[0] + "x" + a[1];
        switch (type) {
            case 70: case 71: return "RGBA8";
            case 80: case 81: return "BGRA8";
            case 178: case 179: return "ETC2 RGBA";
            case 180: case 181: return "ETC2 RGB";
            case 263: return "ETC1";
            default: return "тип " + type;
        }
    }

    // -------------------------------------------------------------- GL (KTX)
    public static Img decodeGl(int internalFormat, int format, int type, byte[] d, int off, int w, int h) throws IOException {
        int f = internalFormat;
        if (f >= 0x93B0 && f <= 0x93BD) return astcGl(f - 0x93B0, d, off, w, h);
        if (f >= 0x93D0 && f <= 0x93DD) return astcGl(f - 0x93D0, d, off, w, h);
        switch (f) {
            case 0x8D64: case 0x9274: case 0x9275: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RGB));
            case 0x9276: case 0x9277: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RGB_A1));
            case 0x9278: case 0x9279: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RGBA_EAC));
            case 0x9270: case 0x9271: return new Img(w, h, Etc.decode(d, off, w, h, Etc.R11));
            case 0x9272: case 0x9273: return new Img(w, h, Etc.decode(d, off, w, h, Etc.RG11));
            default: break;
        }
        // uncompressed
        if (type == 0x8033) return raw(d, off, w, h, RAW_4444);
        if (type == 0x8034) return raw(d, off, w, h, RAW_5551);
        if (type == 0x8363) return raw(d, off, w, h, RAW_565);
        switch (format) {
            case 0x1908: return raw(d, off, w, h, RAW_RGBA8);
            case 0x80E1: return raw(d, off, w, h, RAW_BGRA8);
            case 0x1907: return raw(d, off, w, h, RAW_RGB8);
            case 0x1909: case 0x1903: return raw(d, off, w, h, RAW_L8);
            case 0x190A: case 0x8227: return raw(d, off, w, h, format == 0x190A ? RAW_LA8 : RAW_RG8);
            case 0x1906: return raw(d, off, w, h, RAW_A8);
            default:
                throw new IOException(String.format("Неподдерживаемый формат KTX: 0x%04X", f));
        }
    }

    static Img astcGl(int idx, byte[] d, int off, int w, int h) {
        int[][] dims = {{4, 4}, {5, 4}, {5, 5}, {6, 5}, {6, 6}, {8, 5}, {8, 6}, {8, 8},
                {10, 5}, {10, 6}, {10, 8}, {10, 10}, {12, 10}, {12, 12}};
        int[] a = dims[idx];
        return new Img(w, h, Astc.decode(d, off, w, h, a[0], a[1]));
    }

    // -------------------------------------------------------------- raw
    public static final int RAW_RGBA8 = 0, RAW_4444 = 1, RAW_5551 = 2, RAW_565 = 3, RAW_LA8 = 4,
            RAW_L8 = 5, RAW_A8 = 6, RAW_RGB8 = 7, RAW_BGRA8 = 8, RAW_RG8 = 9;

    public static int bytesPerPixel(int raw) {
        switch (raw) {
            case RAW_RGBA8: case RAW_BGRA8: return 4;
            case RAW_RGB8: return 3;
            case RAW_4444: case RAW_5551: case RAW_565: case RAW_LA8: case RAW_RG8: return 2;
            default: return 1;
        }
    }

    public static int readPixel(byte[] d, int p, int raw) {
        switch (raw) {
            case RAW_RGBA8:
                return ((d[p + 3] & 0xFF) << 24) | ((d[p] & 0xFF) << 16) | ((d[p + 1] & 0xFF) << 8) | (d[p + 2] & 0xFF);
            case RAW_BGRA8:
                return ((d[p + 3] & 0xFF) << 24) | ((d[p + 2] & 0xFF) << 16) | ((d[p + 1] & 0xFF) << 8) | (d[p] & 0xFF);
            case RAW_RGB8:
                return 0xFF000000 | ((d[p] & 0xFF) << 16) | ((d[p + 1] & 0xFF) << 8) | (d[p + 2] & 0xFF);
            case RAW_4444: {
                int v = (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
                int r = (v >> 12) & 0xF, g = (v >> 8) & 0xF, b = (v >> 4) & 0xF, a = v & 0xF;
                return (a * 17) << 24 | (r * 17) << 16 | (g * 17) << 8 | (b * 17);
            }
            case RAW_5551: {
                int v = (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
                int r = (v >> 11) & 0x1F, g = (v >> 6) & 0x1F, b = (v >> 1) & 0x1F, a = v & 1;
                return (a * 255) << 24 | ((r * 255 / 31) << 16) | ((g * 255 / 31) << 8) | (b * 255 / 31);
            }
            case RAW_565: {
                int v = (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
                int r = (v >> 11) & 0x1F, g = (v >> 5) & 0x3F, b = v & 0x1F;
                return 0xFF000000 | ((r * 255 / 31) << 16) | ((g * 255 / 63) << 8) | (b * 255 / 31);
            }
            case RAW_LA8: {
                int l = d[p] & 0xFF, a = d[p + 1] & 0xFF;
                return a << 24 | l << 16 | l << 8 | l;
            }
            case RAW_RG8:
                return 0xFF000000 | (d[p] & 0xFF) << 16 | (d[p + 1] & 0xFF) << 8;
            case RAW_A8:
                return (d[p] & 0xFF) << 24 | 0xFFFFFF;
            default: {
                int l = d[p] & 0xFF;
                return 0xFF000000 | l << 16 | l << 8 | l;
            }
        }
    }

    public static Img raw(byte[] d, int off, int w, int h, int raw) throws IOException {
        int bpp = bytesPerPixel(raw);
        if ((long) off + (long) w * h * bpp > d.length) throw new IOException("Данные текстуры обрезаны");
        int[] out = new int[w * h];
        for (int i = 0; i < w * h; i++) out[i] = readPixel(d, off + i * bpp, raw);
        return new Img(w, h, out);
    }
}
