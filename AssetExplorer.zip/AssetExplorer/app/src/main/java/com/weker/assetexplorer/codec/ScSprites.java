package com.weker.assetexplorer.codec;

/** {@link Fx.Sprites} from .sc files: frames are rendered when first needed and kept in a small cache. */
public final class ScSprites implements Fx.Sprites {

    public interface ScSource {
        Sc2 sc(String file);
    }

    final ScSource src;
    final Fx.FrameCache cache = new Fx.FrameCache(500);
    /** pixels per .sc unit */
    public float pixels = 1.3f;
    /** frames kept per clip at most (long clips skip frames) */
    public int maxFrames = 16;

    public ScSprites(ScSource src) {
        this.src = src;
    }

    @Override
    public int frames(String file, String export) {
        Sc2 s = src.sc(file);
        if (s == null || !s.exportIds.containsKey(export)) return 1;
        return Math.max(1, s.frameCount(export));
    }

    @Override
    public int fps(String file, String export) {
        Sc2 s = src.sc(file);
        return s == null ? 30 : s.fps(export);
    }

    @Override
    public Fx.Sprite get(String file, String export, int frame) {
        Sc2 s = src.sc(file);
        if (s == null || !s.exportIds.containsKey(export)) return null;
        int n = Math.max(1, s.frameCount(export));
        int step = Math.max(1, (n + maxFrames - 1) / maxFrames);
        int f = Math.max(0, Math.min(n - 1, frame / step * step));
        String key = file + "/" + export + "/" + f;
        synchronized (cache) {
            if (cache.containsKey(key)) return cache.get(key);
        }
        Fx.Sprite sp = null;
        try {
            synchronized (s) {
                float[] b = s.bounds(export, f);
                if (b != null && b[2] > b[0] && b[3] > b[1]) {
                    float w = b[2] - b[0], h = b[3] - b[1];
                    int size = Math.max(8, Math.min(160, Math.round(Math.max(w, h) * pixels)));
                    Img im = s.renderFrame(export, f, b, size, 1);
                    if (im != null) {
                        sp = new Fx.Sprite();
                        sp.img = im;
                        sp.x0 = b[0];
                        sp.y0 = b[1];
                        sp.x1 = b[2];
                        sp.y1 = b[3];
                    }
                }
            }
        } catch (Throwable ignored) {
            sp = null;
        }
        synchronized (cache) {
            cache.put(key, sp);
        }
        return sp;
    }
}
