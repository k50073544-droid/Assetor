package com.weker.assetexplorer.codec;

/** ETC1 / ETC2 / EAC decoders. Output ARGB ints. */
public final class Etc {

    private Etc() {}

    public static final int RGB = 0;          // ETC1 or ETC2 RGB8
    public static final int RGBA_EAC = 1;     // ETC2 RGBA8 (EAC alpha + ETC2 color)
    public static final int RGB_A1 = 2;       // ETC2 punch-through alpha
    public static final int R11 = 3;          // EAC R11
    public static final int RG11 = 4;         // EAC RG11

    static final int[][] MOD = {
            {2, 8, -2, -8}, {5, 17, -5, -17}, {9, 29, -9, -29}, {13, 42, -13, -42},
            {18, 60, -18, -60}, {24, 80, -24, -80}, {33, 106, -33, -106}, {47, 183, -47, -183}};
    static final int[] DIST = {3, 6, 11, 16, 23, 32, 41, 64};
    static final int[][] EAC = {
            {-3, -6, -9, -15, 2, 5, 8, 14}, {-3, -7, -10, -13, 2, 6, 9, 12}, {-2, -5, -8, -13, 1, 4, 7, 12},
            {-2, -4, -6, -13, 1, 3, 5, 12}, {-3, -6, -8, -12, 2, 5, 7, 11}, {-3, -7, -9, -11, 2, 6, 8, 10},
            {-4, -7, -8, -11, 3, 6, 7, 10}, {-3, -5, -8, -11, 2, 4, 7, 10}, {-2, -6, -8, -10, 1, 5, 7, 9},
            {-2, -5, -8, -10, 1, 4, 7, 9}, {-2, -4, -8, -10, 1, 3, 7, 9}, {-2, -5, -7, -10, 1, 4, 6, 9},
            {-3, -4, -7, -10, 2, 3, 6, 9}, {-1, -2, -3, -10, 0, 1, 2, 9}, {-4, -6, -8, -9, 3, 5, 7, 8},
            {-3, -5, -7, -9, 2, 4, 6, 8}};

    public static int dataSize(int w, int h, int kind) {
        int blocks = ((w + 3) / 4) * ((h + 3) / 4);
        return blocks * ((kind == RGBA_EAC || kind == RG11) ? 16 : 8);
    }

    public static int[] decode(byte[] d, int off, int w, int h, int kind) {
        int[] out = new int[w * h];
        int bx = (w + 3) / 4, by = (h + 3) / 4;
        int bsize = (kind == RGBA_EAC || kind == RG11) ? 16 : 8;
        int[] blk = new int[16];
        int[] alpha = new int[16];
        int[] g = new int[16];
        for (int y = 0; y < by; y++) {
            for (int x = 0; x < bx; x++) {
                int p = off + (y * bx + x) * bsize;
                if (p + bsize > d.length) return out;
                switch (kind) {
                    case RGBA_EAC:
                        eac(d, p, alpha, false);
                        color(d, p + 8, blk, false, true);
                        for (int i = 0; i < 16; i++) blk[i] = (blk[i] & 0xFFFFFF) | (alpha[i] << 24);
                        break;
                    case RGB_A1:
                        color(d, p, blk, true, true);
                        break;
                    case R11:
                        eac(d, p, alpha, true);
                        for (int i = 0; i < 16; i++) blk[i] = 0xFF000000 | (alpha[i] << 16);
                        break;
                    case RG11:
                        eac(d, p, alpha, true);
                        eac(d, p + 8, g, true);
                        for (int i = 0; i < 16; i++) blk[i] = 0xFF000000 | (alpha[i] << 16) | (g[i] << 8);
                        break;
                    default:
                        color(d, p, blk, false, true);
                        break;
                }
                for (int j = 0; j < 4; j++) {
                    int py = y * 4 + j;
                    if (py >= h) break;
                    for (int i = 0; i < 4; i++) {
                        int px = x * 4 + i;
                        if (px >= w) break;
                        out[py * w + px] = blk[j * 4 + i];
                    }
                }
            }
        }
        return out;
    }

    static int c(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    static int rgb(int r, int g, int b) { return 0xFF000000 | (c(r) << 16) | (c(g) << 8) | c(b); }

    static int ext3(int v) { return (v & 4) != 0 ? v - 8 : v; }

    /** out index = y*4 + x */
    static void color(byte[] d, int p, int[] out, boolean punch, boolean etc2) {
        int b0 = d[p] & 0xFF, b1 = d[p + 1] & 0xFF, b2 = d[p + 2] & 0xFF, b3 = d[p + 3] & 0xFF;
        int msb = (d[p + 4] & 0xFF) << 8 | (d[p + 5] & 0xFF);
        int lsb = (d[p + 6] & 0xFF) << 8 | (d[p + 7] & 0xFF);
        boolean diff = (b3 & 2) != 0;
        boolean opaque = !punch || diff;
        if (punch) diff = true;
        boolean flip = (b3 & 1) != 0;

        if (diff && etc2) {
            int r = b0 >> 3, dr = ext3(b0 & 7);
            int g = b1 >> 3, dg = ext3(b1 & 7);
            int b = b2 >> 3, db = ext3(b2 & 7);
            if (r + dr < 0 || r + dr > 31) { modeT(d, p, out, msb, lsb, punch && !opaque); return; }
            if (g + dg < 0 || g + dg > 31) { modeH(d, p, out, msb, lsb, punch && !opaque); return; }
            if (b + db < 0 || b + db > 31) { planar(d, p, out); return; }
        }

        int[][] base = new int[2][3];
        if (!diff) {
            base[0][0] = (b0 >> 4) * 17; base[1][0] = (b0 & 0xF) * 17;
            base[0][1] = (b1 >> 4) * 17; base[1][1] = (b1 & 0xF) * 17;
            base[0][2] = (b2 >> 4) * 17; base[1][2] = (b2 & 0xF) * 17;
        } else {
            int r = b0 >> 3, g = b1 >> 3, b = b2 >> 3;
            int r2 = r + ext3(b0 & 7), g2 = g + ext3(b1 & 7), bb2 = b + ext3(b2 & 7);
            base[0][0] = e5(r); base[0][1] = e5(g); base[0][2] = e5(b);
            base[1][0] = e5(r2 & 31); base[1][1] = e5(g2 & 31); base[1][2] = e5(bb2 & 31);
        }
        int t0 = b3 >> 5, t1 = (b3 >> 2) & 7;
        for (int x = 0; x < 4; x++) {
            for (int y = 0; y < 4; y++) {
                int i = x * 4 + y;
                int idx = (((msb >> i) & 1) << 1) | ((lsb >> i) & 1);
                int sub = flip ? (y >= 2 ? 1 : 0) : (x >= 2 ? 1 : 0);
                int[] bc = base[sub];
                int[] mod = MOD[sub == 0 ? t0 : t1];
                if (punch && !opaque) {
                    if (idx == 2) { out[y * 4 + x] = 0; continue; }
                    if (idx == 0) { out[y * 4 + x] = rgb(bc[0], bc[1], bc[2]); continue; }
                }
                int m = mod[idx];
                out[y * 4 + x] = rgb(bc[0] + m, bc[1] + m, bc[2] + m);
            }
        }
    }

    static int e5(int v) { return (v << 3) | (v >> 2); }

    static void paint(int[] out, int msb, int lsb, int[] colors, boolean transparent) {
        for (int x = 0; x < 4; x++) {
            for (int y = 0; y < 4; y++) {
                int i = x * 4 + y;
                int idx = (((msb >> i) & 1) << 1) | ((lsb >> i) & 1);
                out[y * 4 + x] = (transparent && idx == 2) ? 0 : colors[idx];
            }
        }
    }

    static void modeT(byte[] d, int p, int[] out, int msb, int lsb, boolean transparent) {
        int b0 = d[p] & 0xFF, b1 = d[p + 1] & 0xFF, b2 = d[p + 2] & 0xFF, b3 = d[p + 3] & 0xFF;
        int r1 = (((b0 >> 3) & 3) << 2 | (b0 & 3)) * 17;
        int g1 = (b1 >> 4) * 17, bl1 = (b1 & 0xF) * 17;
        int r2 = (b2 >> 4) * 17, g2 = (b2 & 0xF) * 17, bl2 = (b3 >> 4) * 17;
        int dd = DIST[((b3 >> 2) & 3) << 1 | (b3 & 1)];
        int[] cols = {rgb(r1, g1, bl1), rgb(r2 + dd, g2 + dd, bl2 + dd), rgb(r2, g2, bl2), rgb(r2 - dd, g2 - dd, bl2 - dd)};
        paint(out, msb, lsb, cols, transparent);
    }

    static void modeH(byte[] d, int p, int[] out, int msb, int lsb, boolean transparent) {
        int b0 = d[p] & 0xFF, b1 = d[p + 1] & 0xFF, b2 = d[p + 2] & 0xFF, b3 = d[p + 3] & 0xFF;
        int r1 = (b0 >> 3) & 0xF;
        int g1 = ((b0 & 7) << 1) | ((b1 >> 4) & 1);
        int bl1 = (b1 & 8) | ((b1 & 3) << 1) | (b2 >> 7);
        int r2 = (b2 >> 3) & 0xF;
        int g2 = ((b2 & 7) << 1) | (b3 >> 7);
        int bl2 = (b3 >> 3) & 0xF;
        int v1 = (r1 << 8) | (g1 << 4) | bl1, v2 = (r2 << 8) | (g2 << 4) | bl2;
        int di = (b3 & 4) | ((b3 & 1) << 1) | (v1 >= v2 ? 1 : 0);
        int dd = DIST[di];
        r1 *= 17; g1 *= 17; bl1 *= 17; r2 *= 17; g2 *= 17; bl2 *= 17;
        int[] cols = {rgb(r1 + dd, g1 + dd, bl1 + dd), rgb(r1 - dd, g1 - dd, bl1 - dd),
                rgb(r2 + dd, g2 + dd, bl2 + dd), rgb(r2 - dd, g2 - dd, bl2 - dd)};
        paint(out, msb, lsb, cols, transparent);
    }

    static void planar(byte[] d, int p, int[] out) {
        int b0 = d[p] & 0xFF, b1 = d[p + 1] & 0xFF, b2 = d[p + 2] & 0xFF, b3 = d[p + 3] & 0xFF;
        int b4 = d[p + 4] & 0xFF, b5 = d[p + 5] & 0xFF, b6 = d[p + 6] & 0xFF, b7 = d[p + 7] & 0xFF;
        int ro = (b0 >> 1) & 0x3F;
        int go = ((b0 & 1) << 6) | ((b1 >> 1) & 0x3F);
        int bo = ((b1 & 1) << 5) | (b2 & 0x18) | ((b2 & 3) << 1) | ((b3 >> 7) & 1);
        int rh = ((b3 >> 1) & 0x3E) | (b3 & 1);
        int gh = (b4 >> 1) & 0x7F;
        int bh = ((b4 & 1) << 5) | ((b5 >> 3) & 0x1F);
        int rv = ((b5 & 7) << 3) | ((b6 >> 5) & 7);
        int gv = ((b6 & 0x1F) << 2) | ((b7 >> 6) & 3);
        int bv = b7 & 0x3F;
        ro = e6(ro); bo = e6(bo); rh = e6(rh); bh = e6(bh); rv = e6(rv); bv = e6(bv);
        go = e7(go); gh = e7(gh); gv = e7(gv);
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                int r = (x * (rh - ro) + y * (rv - ro) + 4 * ro + 2) >> 2;
                int g = (x * (gh - go) + y * (gv - go) + 4 * go + 2) >> 2;
                int b = (x * (bh - bo) + y * (bv - bo) + 4 * bo + 2) >> 2;
                out[y * 4 + x] = rgb(r, g, b);
            }
        }
    }

    static int e6(int v) { return (v << 2) | (v >> 4); }

    static int e7(int v) { return (v << 1) | (v >> 6); }

    /** EAC 8-bit alpha or 11-bit channel (returned as 8 bit). out index y*4+x */
    static void eac(byte[] d, int p, int[] out, boolean is11) {
        int base = d[p] & 0xFF;
        int mul = (d[p + 1] & 0xFF) >> 4;
        int[] tbl = EAC[(d[p + 1] & 0xFF) & 0xF];
        long bits = 0;
        for (int i = 2; i < 8; i++) bits = (bits << 8) | (d[p + i] & 0xFF);
        for (int i = 0; i < 16; i++) {
            int idx = (int) ((bits >> (45 - 3 * i)) & 7);
            int x = i / 4, y = i % 4;
            int v;
            if (is11) {
                int m = mul == 0 ? 1 : mul * 8;
                int v11 = base * 8 + 4 + tbl[idx] * m;
                v11 = Math.max(0, Math.min(2047, v11));
                v = v11 >> 3;
            } else {
                v = c(base + tbl[idx] * mul);
            }
            out[y * 4 + x] = v;
        }
    }
}
