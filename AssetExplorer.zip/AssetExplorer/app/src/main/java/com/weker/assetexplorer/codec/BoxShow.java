package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The 3D part of opening a box or Starr Drop: the container's model with its own animation
 * (intro → idle → upgrade… → open, frame ranges from random_reward_containers.csv), Starr's face
 * and the rarity colour. Tap to go on; {@link #events} tells the screen when to play sounds or show rewards.
 */
public final class BoxShow {

    public enum State { INTRO, IDLE, UPGRADE, OPEN, DONE }

    public final GameDb.Container box;
    /** rarities the drop goes through (one entry for a normal box) */
    public final List<GameDb.Container> steps = new ArrayList<>();
    public int step;
    public State state = State.INTRO;
    public double t; // seconds in this state
    public final List<String> events = new ArrayList<>();

    Model3d model;
    Anim3d anim;
    Map<String, Img> images = new HashMap<>();
    String body;
    Img baseTex;
    Sc2 faceSc;
    float[] bounds;
    final Map<String, Img> texCache = new HashMap<>();
    String face;

    public BoxShow(Assets a, GameDb.Container box, List<GameDb.Container> steps) {
        this.box = box;
        if (steps == null || steps.isEmpty()) this.steps.add(box);
        else this.steps.addAll(steps);
        model = box.model == null || box.model.isEmpty() ? null : a.model(box.model);
        if (model != null) {
            anim = a.anim(box.model);
            if (anim != null && model.matchingBones(anim) == 0) anim = null;
            images = a.imagesFor(model);
            body = FaceOverlay.bodyTexture(model);
            if (body == null && !model.parts.isEmpty()) body = model.parts.get(0).diffuseTex;
            baseTex = body != null ? images.get(body) : null;
            if (box.faceFile != null && !box.faceFile.isEmpty()) faceSc = a.sc(box.faceFile);
            bounds = model.bounds;
            if (anim != null && box.idle != null) {
                try {
                    bounds = model.animationBounds(anim, box.idle[0], box.idle[1]);
                } catch (Throwable ignored) {
                    bounds = model.bounds;
                }
            }
        }
        face = box.faceIdle;
        if (range(box.intro) == null) state = State.IDLE;
    }

    public boolean hasModel() {
        return model != null;
    }

    public GameDb.Container current() {
        return steps.get(Math.min(step, steps.size() - 1));
    }

    public GameDb.Container last() {
        return steps.get(steps.size() - 1);
    }

    int[] range(int[] r) {
        return anim == null || r == null ? null : r;
    }

    /** the player tapped the box */
    public void tap() {
        if (state == State.INTRO) {
            state = State.IDLE;
            t = 0;
        }
        if (state != State.IDLE) return;
        if (step < steps.size() - 1) {
            state = State.UPGRADE;
            t = 0;
            step++;
            face = box.faceUpgrade != null && !box.faceUpgrade.isEmpty() ? box.faceUpgrade : face;
            events.add("upgrade");
        } else {
            state = State.OPEN;
            t = 0;
            face = box.faceOpen != null && !box.faceOpen.isEmpty() ? box.faceOpen : face;
            events.add("open");
        }
    }

    double seconds(int[] r) {
        if (r == null) return 0.6;
        return Math.max(1, r[1] - r[0]) / (double) Math.max(1, anim.fps);
    }

    int[] upgradeRange() {
        // the legendary step has its own longer upgrade in the game file (85–120)
        if (current().rarity >= 5 && anim != null && anim.frames > 120 && box.upgrade != null && box.upgrade[0] == 65) return new int[]{85, 120};
        return range(box.upgrade);
    }

    public void advance(double dt) {
        t += dt;
        switch (state) {
            case INTRO:
                if (t >= seconds(range(box.intro))) {
                    state = State.IDLE;
                    t = 0;
                }
                break;
            case UPGRADE:
                if (t >= seconds(upgradeRange())) {
                    state = State.IDLE;
                    t = 0;
                    face = box.faceIdle;
                }
                break;
            case OPEN:
                if (t >= seconds(range(box.open))) {
                    state = State.DONE;
                    t = 0;
                    events.add("reward");
                }
                break;
            default:
                break;
        }
    }

    double frame() {
        if (anim == null) return 0;
        int[] r;
        boolean loop = false;
        switch (state) {
            case INTRO: r = box.intro; break;
            case UPGRADE: r = upgradeRange(); break;
            case OPEN: case DONE: r = box.open; break;
            default: r = box.idle; loop = true; break;
        }
        if (r == null) r = box.idle != null ? box.idle : new int[]{0, Math.max(0, anim.frames - 1)};
        double len = Math.max(1, r[1] - r[0]);
        double f = t * anim.fps;
        f = loop ? f % len : Math.min(f, len);
        if (state == State.DONE) f = len;
        return Math.min(anim.frames - 1, r[0] + f);
    }

    Img texture() {
        if (baseTex == null) return null;
        int rar = current().rarity;
        if (state == State.UPGRADE && t < seconds(upgradeRange()) * 0.45) rar = steps.get(Math.max(0, step - 1)).rarity;
        boolean star = box.starr || box.name.endsWith("Star");
        String key = rar + "/" + face;
        Img im = texCache.get(key);
        if (im == null) {
            im = star ? Tint.hue(baseTex, Tint.rarityHue(rar)) : baseTex;
            if (faceSc != null && face != null && !face.isEmpty()) {
                try {
                    im = FaceOverlay.apply(im, faceSc, face, 0);
                } catch (Throwable ignored) {
                    // no face
                }
            }
            texCache.put(key, im);
        }
        return im;
    }

    /** the scene at this moment, camera in front of the box */
    public Scene3d scene() {
        Scene3d s = new Scene3d();
        s.background = 0xFF141B33;
        if (model == null) return s;
        float[] b = bounds != null ? bounds : new float[]{-1, -1, -1, 1, 1, 1};
        float cx = (b[0] + b[3]) / 2, cy = (b[1] + b[4]) / 2, cz = (b[2] + b[5]) / 2;
        float size = Math.max(b[4] - b[1], Math.max(b[3] - b[0], b[5] - b[2]));
        s.fovY = 30;
        s.near = size * 0.05f;
        s.far = size * 20;
        s.view = Scene3d.lookAt(cx, cy + size * 0.25f, cz + size * 2.9f, cx, cy, cz);
        Model3d m = anim != null ? model.pose(anim, frame()) : model;
        float[] mat = Scene3d.identity();
        if (anim == null) { // boxes without their own animation: turn slowly, spin and grow when opening
            double ang = state == State.OPEN ? t * 9 : Math.sin(t * 0.8) * 0.35;
            float sc = state == State.OPEN ? (float) (1 + t * 0.6) : state == State.DONE ? 0.001f : 1f;
            mat = Scene3d.mul(Scene3d.translate(cx, cy, cz), Scene3d.mul(Scene3d.rotateY((float) ang), Scene3d.mul(Scene3d.scale(sc), Scene3d.translate(-cx, -cy, -cz))));
        }
        Map<String, Img> imgs = images;
        Img tex = texture();
        if (tex != null && body != null) {
            imgs = new HashMap<>(images);
            imgs.put(body, tex);
        }
        Scene3d.Item it = s.add(m, imgs, mat);
        if (state == State.UPGRADE) {
            double k = Math.max(0, 1 - Math.abs(t - seconds(upgradeRange()) * 0.45) * 4);
            int fl = (int) (k * 160);
            it.flash = (fl << 16) | (fl << 8) | fl;
        }
        return s;
    }
}
