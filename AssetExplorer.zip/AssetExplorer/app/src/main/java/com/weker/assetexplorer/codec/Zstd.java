package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.util.Arrays;

/** Pure-Java Zstandard decoder (RFC 8878). Decompression only, no dictionaries. */
public final class Zstd {

    public static final int MAGIC = 0xFD2FB528;

    public static boolean isZstd(byte[] d, int off) {
        return d.length - off >= 4 && readInt(d, off) == MAGIC;
    }

    public static byte[] decompress(byte[] src) throws IOException {
        return decompress(src, 0, src.length);
    }

    public static byte[] decompress(byte[] src, int off, int end) throws IOException {
        Out out = new Out(Math.max(1024, (end - off) * 4));
        int p = off;
        while (p + 4 <= end) {
            int magic = readInt(src, p);
            if ((magic & 0xFFFFFFF0) == 0x184D2A50) {
                int size = readInt(src, p + 4);
                p += 8 + size;
                continue;
            }
            if (magic != MAGIC) {
                if (out.size > 0) break;
                throw new IOException("Not a zstd frame");
            }
            p = new Frame(src, p + 4, end, out).decode();
        }
        return out.toArray();
    }

    static int readInt(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
    }

    // ---------------------------------------------------------------- output buffer
    static final class Out {
        byte[] buf;
        int size;

        Out(int cap) { buf = new byte[cap]; }

        void ensure(int extra) {
            if (size + extra > buf.length) {
                long n = Math.max((long) buf.length * 2, (long) size + extra);
                if (n > Integer.MAX_VALUE - 16) n = Integer.MAX_VALUE - 16;
                buf = Arrays.copyOf(buf, (int) n);
            }
        }

        void put(byte[] s, int o, int n) {
            ensure(n);
            System.arraycopy(s, o, buf, size, n);
            size += n;
        }

        byte[] toArray() { return Arrays.copyOf(buf, size); }
    }

    // ---------------------------------------------------------------- tables
    static final int[] LL_BASE = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            16, 18, 20, 22, 24, 28, 32, 40, 48, 64, 128, 256, 512, 1024, 2048, 4096,
            8192, 16384, 32768, 65536};
    static final int[] LL_BITS = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 1, 1, 1, 2, 2, 3, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    static final int[] ML_BASE = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
            19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
            35, 37, 39, 41, 43, 47, 51, 59, 67, 83, 99, 131, 259, 515, 1027, 2051,
            4099, 8195, 16387, 32771, 65539};
    static final int[] ML_BITS = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            1, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    static final short[] LL_DEF = {4, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1,
            2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 1, 1, 1, 1, -1, -1, -1, -1};
    static final short[] ML_DEF = {1, 4, 3, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1};
    static final short[] OF_DEF = {1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1};

    static Fse LL_PREDEF, ML_PREDEF, OF_PREDEF;

    static {
        LL_PREDEF = Fse.build(LL_DEF, LL_DEF.length - 1, 6);
        ML_PREDEF = Fse.build(ML_DEF, ML_DEF.length - 1, 6);
        OF_PREDEF = Fse.build(OF_DEF, OF_DEF.length - 1, 5);
    }

    // ---------------------------------------------------------------- backward bit reader
    static final class BackBits {
        final byte[] d;
        final int start;
        final int end;
        long pos; // number of bits still unread, counted from start

        BackBits(byte[] d, int start, int end) throws IOException {
            if (end <= start) throw new IOException("empty bitstream");
            this.d = d;
            this.start = start;
            this.end = end;
            int last = d[end - 1] & 0xFF;
            if (last == 0) throw new IOException("bad bitstream padding");
            int hb = 31 - Integer.numberOfLeadingZeros(last);
            pos = (long) (end - start - 1) * 8 + hb;
        }

        private long load(long bytePos) {
            long v = 0;
            for (int i = 7; i >= 0; i--) {
                long bp = bytePos + i;
                int b = (bp >= 0 && bp < end - start) ? (d[start + (int) bp] & 0xFF) : 0;
                v = (v << 8) | b;
            }
            return v;
        }

        int peek(int n) {
            if (n == 0) return 0;
            long p = pos - n;
            if (p >= 0) {
                long v = load(p >> 3);
                return (int) ((v >>> (p & 7)) & ((1L << n) - 1));
            } else {
                if (pos <= 0) return 0;
                long v = load(0) & ((1L << pos) - 1);
                return (int) (v << (-p));
            }
        }

        void skip(int n) { pos -= n; }

        int read(int n) {
            int v = peek(n);
            pos -= n;
            return v;
        }

        boolean overflowed() { return pos < 0; }
    }

    // ---------------------------------------------------------------- forward bit reader
    static final class FwdBits {
        final byte[] d;
        final int start, end;
        long pos;

        FwdBits(byte[] d, int start, int end) { this.d = d; this.start = start; this.end = end; }

        int read(int n) {
            int v = 0;
            for (int i = 0; i < n; i++) {
                long bp = pos + i;
                int byteI = start + (int) (bp >> 3);
                int bit = byteI < end ? (d[byteI] >> (bp & 7)) & 1 : 0;
                v |= bit << i;
            }
            pos += n;
            return v;
        }

        int peek(int n) {
            long save = pos;
            int v = read(n);
            pos = save;
            return v;
        }

        int bytesUsed() { return (int) ((pos + 7) >> 3); }
    }

    // ---------------------------------------------------------------- FSE
    static final class Fse {
        int log;
        int[] sym, nb, base;

        static Fse rle(int symbol) {
            Fse f = new Fse();
            f.log = 0;
            f.sym = new int[]{symbol};
            f.nb = new int[]{0};
            f.base = new int[]{0};
            return f;
        }

        static Fse build(short[] norm, int maxSym, int log) {
            Fse f = new Fse();
            int size = 1 << log;
            f.log = log;
            f.sym = new int[size];
            f.nb = new int[size];
            f.base = new int[size];
            int[] next = new int[maxSym + 1];
            int high = size - 1;
            for (int s = 0; s <= maxSym; s++) {
                if (norm[s] == -1) {
                    f.sym[high--] = s;
                    next[s] = 1;
                } else {
                    next[s] = Math.max(norm[s], 0);
                }
            }
            int step = (size >> 1) + (size >> 3) + 3;
            int mask = size - 1;
            int p = 0;
            for (int s = 0; s <= maxSym; s++) {
                for (int i = 0; i < norm[s]; i++) {
                    f.sym[p] = s;
                    do { p = (p + step) & mask; } while (p > high);
                }
            }
            for (int u = 0; u < size; u++) {
                int s = f.sym[u];
                int ns = next[s]++;
                int bits = log - (31 - Integer.numberOfLeadingZeros(ns));
                f.nb[u] = bits;
                f.base[u] = (ns << bits) - size;
            }
            return f;
        }

        /** Reads normalized counts and builds the table. Returns bytes consumed via holder[0]. */
        static Fse read(byte[] d, int start, int end, int maxSymAllowed, int maxLog, int[] used) throws IOException {
            FwdBits br = new FwdBits(d, start, end);
            int log = br.read(4) + 5;
            if (log > maxLog) throw new IOException("FSE table log too large");
            short[] norm = new short[maxSymAllowed + 2];
            int remaining = (1 << log) + 1;
            int threshold = 1 << log;
            int nbBits = log + 1;
            int sym = 0;
            boolean prev0 = false;
            while (remaining > 1 && sym <= maxSymAllowed) {
                if (prev0) {
                    int n0 = sym;
                    while (true) {
                        int r = br.read(2);
                        n0 += r;
                        if (r != 3) break;
                    }
                    if (n0 > maxSymAllowed + 1) throw new IOException("FSE repeat overflow");
                    while (sym < n0) norm[sym++] = 0;
                    if (sym > maxSymAllowed) break;
                }
                int max = (2 * threshold - 1) - remaining;
                int count;
                int low = br.peek(nbBits - 1);
                if (low < max) {
                    count = low;
                    br.pos += nbBits - 1;
                } else {
                    count = br.peek(nbBits);
                    if (count >= threshold) count -= max;
                    br.pos += nbBits;
                }
                count--;
                remaining -= Math.abs(count);
                norm[sym++] = (short) count;
                prev0 = count == 0;
                while (remaining < threshold) {
                    nbBits--;
                    threshold >>= 1;
                }
            }
            if (remaining != 1) throw new IOException("FSE bad normalized counts");
            used[0] = br.bytesUsed();
            return build(norm, sym - 1, log);
        }
    }

    // ---------------------------------------------------------------- Huffman
    static final class Huf {
        int maxBits;
        int[] sym, nb;

        static Huf read(byte[] d, int p, int end, int[] used) throws IOException {
            int header = d[p] & 0xFF;
            int[] weights = new int[256];
            int numW;
            if (header < 128) {
                int csize = header;
                int s = p + 1;
                if (s + csize > end) throw new IOException("huffman weights overflow");
                int[] u = new int[1];
                Fse t = Fse.read(d, s, s + csize, 255, 6, u);
                BackBits br = new BackBits(d, s + u[0], s + csize);
                int st1 = br.read(t.log);
                int st2 = br.read(t.log);
                numW = 0;
                while (true) {
                    if (numW >= 255) throw new IOException("too many huffman weights");
                    weights[numW++] = t.sym[st1];
                    st1 = t.base[st1] + br.read(t.nb[st1]);
                    if (br.overflowed()) {
                        weights[numW++] = t.sym[st2];
                        break;
                    }
                    if (numW >= 255) throw new IOException("too many huffman weights");
                    weights[numW++] = t.sym[st2];
                    st2 = t.base[st2] + br.read(t.nb[st2]);
                    if (br.overflowed()) {
                        weights[numW++] = t.sym[st1];
                        break;
                    }
                }
                used[0] = 1 + csize;
            } else {
                numW = header - 127;
                int nbytes = (numW + 1) / 2;
                for (int i = 0; i < numW; i++) {
                    int b = d[p + 1 + i / 2] & 0xFF;
                    weights[i] = (i % 2 == 0) ? (b >> 4) : (b & 0xF);
                }
                used[0] = 1 + nbytes;
            }
            long sum = 0;
            for (int i = 0; i < numW; i++) {
                if (weights[i] > 0) sum += 1L << (weights[i] - 1);
            }
            if (sum == 0) throw new IOException("bad huffman weights");
            int maxBits = 64 - Long.numberOfLeadingZeros(sum); // next power of two
            long total = 1L << maxBits;
            long rest = total - sum;
            if (Long.bitCount(rest) != 1) throw new IOException("bad huffman last weight");
            int lastW = 63 - Long.numberOfLeadingZeros(rest) + 1;
            weights[numW++] = lastW;
            if (maxBits > 11) throw new IOException("huffman max bits too large");
            Huf h = new Huf();
            h.maxBits = maxBits;
            int size = 1 << maxBits;
            h.sym = new int[size];
            h.nb = new int[size];
            int pos = 0;
            for (int w = 1; w <= maxBits; w++) {
                for (int s = 0; s < numW; s++) {
                    if (weights[s] != w) continue;
                    int len = 1 << (w - 1);
                    int bits = maxBits + 1 - w;
                    for (int i = 0; i < len; i++) {
                        h.sym[pos] = s;
                        h.nb[pos] = bits;
                        pos++;
                    }
                }
            }
            if (pos != size) throw new IOException("huffman table incomplete");
            return h;
        }

        void decodeStream(byte[] d, int start, int end, byte[] out, int op, int count) throws IOException {
            BackBits br = new BackBits(d, start, end);
            for (int i = 0; i < count; i++) {
                int v = br.peek(maxBits);
                out[op + i] = (byte) sym[v];
                br.skip(nb[v]);
            }
            if (br.pos != 0) {
                if (br.pos < 0) throw new IOException("huffman stream overflow");
            }
        }
    }

    // ---------------------------------------------------------------- frame
    static final class Frame {
        final byte[] d;
        int p;
        final int end;
        final Out out;
        final int frameStart;
        Huf huf;
        Fse llT, ofT, mlT;
        int rep1 = 1, rep2 = 4, rep3 = 8;
        byte[] lit = new byte[1 << 17];
        int litSize;

        Frame(byte[] d, int p, int end, Out out) {
            this.d = d;
            this.p = p;
            this.end = end;
            this.out = out;
            this.frameStart = out.size;
        }

        int decode() throws IOException {
            int fhd = d[p++] & 0xFF;
            int fcsFlag = fhd >> 6;
            boolean single = (fhd & 0x20) != 0;
            boolean checksum = (fhd & 0x04) != 0;
            int dictFlag = fhd & 3;
            if (!single) p++; // window descriptor
            int[] dictSizes = {0, 1, 2, 4};
            if (dictFlag != 0) {
                long dictId = 0;
                for (int i = 0; i < dictSizes[dictFlag]; i++) dictId |= (long) (d[p + i] & 0xFF) << (8 * i);
                p += dictSizes[dictFlag];
                if (dictId != 0) throw new IOException("zstd dictionaries are not supported");
            }
            int fcsSize = fcsFlag == 0 ? (single ? 1 : 0) : (1 << fcsFlag);
            long fcs = 0;
            for (int i = 0; i < fcsSize; i++) fcs |= (long) (d[p + i] & 0xFF) << (8 * i);
            if (fcsSize == 2) fcs += 256;
            p += fcsSize;
            if (fcs > 0 && fcs < Integer.MAX_VALUE - 64) out.ensure((int) fcs);

            while (true) {
                if (p + 3 > end) throw new IOException("truncated zstd block header");
                int bh = (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16;
                p += 3;
                boolean last = (bh & 1) != 0;
                int type = (bh >> 1) & 3;
                int size = bh >>> 3;
                if (type == 0) {
                    if (p + size > end) throw new IOException("truncated raw block");
                    out.put(d, p, size);
                    p += size;
                } else if (type == 1) {
                    out.ensure(size);
                    Arrays.fill(out.buf, out.size, out.size + size, d[p]);
                    out.size += size;
                    p += 1;
                } else if (type == 2) {
                    if (p + size > end) throw new IOException("truncated compressed block");
                    compressedBlock(p, p + size);
                    p += size;
                } else {
                    throw new IOException("reserved block type");
                }
                if (last) break;
            }
            if (checksum) p += 4;
            return p;
        }

        void compressedBlock(int bp, int bend) throws IOException {
            int q = decodeLiterals(bp, bend);
            decodeSequences(q, bend);
        }

        int decodeLiterals(int q, int bend) throws IOException {
            int b0 = d[q] & 0xFF;
            int type = b0 & 3;
            int sf = (b0 >> 2) & 3;
            if (type == 0 || type == 1) {
                int regen, hs;
                if (sf == 0 || sf == 2) { regen = b0 >> 3; hs = 1; }
                else if (sf == 1) { regen = (b0 >> 4) + ((d[q + 1] & 0xFF) << 4); hs = 2; }
                else { regen = (b0 >> 4) + ((d[q + 1] & 0xFF) << 4) + ((d[q + 2] & 0xFF) << 12); hs = 3; }
                q += hs;
                ensureLit(regen);
                if (type == 0) {
                    if (q + regen > bend) throw new IOException("raw literals overflow");
                    System.arraycopy(d, q, lit, 0, regen);
                    q += regen;
                } else {
                    Arrays.fill(lit, 0, regen, d[q]);
                    q += 1;
                }
                litSize = regen;
                return q;
            }
            int regen, csize, hs;
            boolean fourStreams = sf != 0;
            if (sf == 0 || sf == 1) {
                int h = b0 | (d[q + 1] & 0xFF) << 8 | (d[q + 2] & 0xFF) << 16;
                regen = (h >> 4) & 0x3FF;
                csize = (h >> 14) & 0x3FF;
                hs = 3;
            } else if (sf == 2) {
                long h = (b0 | (d[q + 1] & 0xFF) << 8 | (d[q + 2] & 0xFF) << 16) | ((long) (d[q + 3] & 0xFF) << 24);
                regen = (int) ((h >> 4) & 0x3FFF);
                csize = (int) ((h >> 18) & 0x3FFF);
                hs = 4;
            } else {
                long h = (b0 | (d[q + 1] & 0xFF) << 8 | (d[q + 2] & 0xFF) << 16) | ((long) (d[q + 3] & 0xFF) << 24)
                        | ((long) (d[q + 4] & 0xFF) << 32);
                regen = (int) ((h >> 4) & 0x3FFFF);
                csize = (int) ((h >> 22) & 0x3FFFF);
                hs = 5;
            }
            q += hs;
            int cend = q + csize;
            if (cend > bend) throw new IOException("compressed literals overflow");
            if (type == 2) {
                int[] used = new int[1];
                huf = Huf.read(d, q, cend, used);
                q += used[0];
            } else if (huf == null) {
                throw new IOException("treeless literals without previous table");
            }
            ensureLit(regen);
            if (!fourStreams) {
                huf.decodeStream(d, q, cend, lit, 0, regen);
            } else {
                int s1 = (d[q] & 0xFF) | (d[q + 1] & 0xFF) << 8;
                int s2 = (d[q + 2] & 0xFF) | (d[q + 3] & 0xFF) << 8;
                int s3 = (d[q + 4] & 0xFF) | (d[q + 5] & 0xFF) << 8;
                int a = q + 6, b = a + s1, c = b + s2, e = c + s3;
                if (e > cend) throw new IOException("bad jump table");
                int seg = (regen + 3) / 4;
                huf.decodeStream(d, a, b, lit, 0, seg);
                huf.decodeStream(d, b, c, lit, seg, seg);
                huf.decodeStream(d, c, e, lit, 2 * seg, seg);
                huf.decodeStream(d, e, cend, lit, 3 * seg, regen - 3 * seg);
            }
            litSize = regen;
            return cend;
        }

        void ensureLit(int n) {
            if (lit.length < n) lit = new byte[n];
        }

        Fse readTable(int mode, int[] qref, int bend, Fse predef, Fse prev, int maxSym, int maxLog) throws IOException {
            switch (mode) {
                case 0: return predef;
                case 1: {
                    int s = d[qref[0]] & 0xFF;
                    qref[0]++;
                    return Fse.rle(s);
                }
                case 2: {
                    int[] used = new int[1];
                    Fse t = Fse.read(d, qref[0], bend, maxSym, maxLog, used);
                    qref[0] += used[0];
                    return t;
                }
                default:
                    if (prev == null) throw new IOException("repeat FSE table without previous");
                    return prev;
            }
        }

        void decodeSequences(int q, int bend) throws IOException {
            int nbSeq;
            if (q >= bend) {
                nbSeq = 0;
            } else {
                int b0 = d[q] & 0xFF;
                if (b0 < 128) { nbSeq = b0; q += 1; }
                else if (b0 < 255) { nbSeq = ((b0 - 128) << 8) + (d[q + 1] & 0xFF); q += 2; }
                else { nbSeq = (d[q + 1] & 0xFF) + ((d[q + 2] & 0xFF) << 8) + 0x7F00; q += 3; }
            }
            if (nbSeq == 0) {
                out.put(lit, 0, litSize);
                return;
            }
            int modes = d[q++] & 0xFF;
            int[] qr = {q};
            llT = readTable((modes >> 6) & 3, qr, bend, LL_PREDEF, llT, 35, 9);
            ofT = readTable((modes >> 4) & 3, qr, bend, OF_PREDEF, ofT, 31, 8);
            mlT = readTable((modes >> 2) & 3, qr, bend, ML_PREDEF, mlT, 52, 9);
            q = qr[0];

            BackBits br = new BackBits(d, q, bend);
            int llS = br.read(llT.log);
            int ofS = br.read(ofT.log);
            int mlS = br.read(mlT.log);
            int litPos = 0;
            for (int i = 0; i < nbSeq; i++) {
                int ofCode = ofT.sym[ofS];
                int llCode = llT.sym[llS];
                int mlCode = mlT.sym[mlS];
                if (llCode > 35 || mlCode > 52 || ofCode > 31) throw new IOException("bad sequence code");
                long ofVal = (1L << ofCode) + readLong(br, ofCode);
                int ml = ML_BASE[mlCode] + br.read(ML_BITS[mlCode]);
                int ll = LL_BASE[llCode] + br.read(LL_BITS[llCode]);

                int offset;
                if (ofVal > 3) {
                    offset = (int) (ofVal - 3);
                    rep3 = rep2;
                    rep2 = rep1;
                    rep1 = offset;
                } else {
                    int r = (int) ofVal;
                    if (ll == 0) r++;
                    if (r == 1) {
                        offset = rep1;
                    } else if (r == 2) {
                        offset = rep2;
                        rep2 = rep1;
                        rep1 = offset;
                    } else if (r == 3) {
                        offset = rep3;
                        rep3 = rep2;
                        rep2 = rep1;
                        rep1 = offset;
                    } else {
                        offset = rep1 - 1;
                        if (offset == 0) offset = 1;
                        rep3 = rep2;
                        rep2 = rep1;
                        rep1 = offset;
                    }
                }

                if (litPos + ll > litSize) throw new IOException("literal overflow");
                out.put(lit, litPos, ll);
                litPos += ll;
                if (offset > out.size - frameStart || offset <= 0) throw new IOException("bad match offset");
                out.ensure(ml);
                byte[] b = out.buf;
                int dst = out.size;
                int src = dst - offset;
                if (offset >= ml) {
                    System.arraycopy(b, src, b, dst, ml);
                } else {
                    for (int k = 0; k < ml; k++) b[dst + k] = b[src + k];
                }
                out.size += ml;

                if (i != nbSeq - 1) {
                    llS = llT.base[llS] + br.read(llT.nb[llS]);
                    mlS = mlT.base[mlS] + br.read(mlT.nb[mlS]);
                    ofS = ofT.base[ofS] + br.read(ofT.nb[ofS]);
                }
            }
            if (litPos < litSize) out.put(lit, litPos, litSize - litPos);
        }

        static long readLong(BackBits br, int n) {
            if (n <= 24) return br.read(n);
            int hi = br.read(n - 24);
            int lo = br.read(24);
            return ((long) hi << 24) | lo;
        }
    }
}
