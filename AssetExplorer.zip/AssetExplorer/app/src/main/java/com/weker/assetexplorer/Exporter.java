package com.weker.assetexplorer;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Writes a list of files into a user-picked folder, keeping the game's folder structure. */
public final class Exporter {

    public interface Progress {
        void onProgress(int done, int total, String current);
    }

    private final Context ctx;
    private final ContentResolver cr;
    private volatile boolean cancelled;
    private final Map<String, Uri> dirs = new HashMap<>();

    public Exporter(Context c) {
        ctx = c.getApplicationContext();
        cr = c.getContentResolver();
    }

    public void cancel() { cancelled = true; }

    public int export(Uri tree, String rootName, List<Db.Row> rows, boolean png, Progress progress) throws IOException {
        Uri base = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        String stamp = new java.text.SimpleDateFormat("MMdd_HHmm", java.util.Locale.ROOT).format(new java.util.Date());
        Uri root = DocumentsContract.createDocument(cr, base, DocumentsContract.Document.MIME_TYPE_DIR, rootName + "_" + stamp);
        if (root == null) throw new IOException("Не удалось создать папку");
        dirs.put("", root);
        int done = 0;
        for (Db.Row r : rows) {
            if (cancelled) break;
            String folder = r.path.contains("/") ? r.path.substring(0, r.path.lastIndexOf('/')) : "";
            Uri dir = dir(folder);
            File src = Blobs.file(ctx, r.blob);
            Uri out = DocumentsContract.createDocument(cr, dir, "application/octet-stream", r.name);
            if (out != null) {
                try (InputStream in = new FileInputStream(src); OutputStream o = cr.openOutputStream(out)) {
                    if (o == null) throw new IOException("Нет доступа к папке");
                    Importer.copy(in, o, null);
                }
            }
            if (png && Categorizer.T_TEX.equals(r.type)) {
                try {
                    Decoders.Decoded d = Decoders.decodeImages(src, r);
                    for (int i = 0; i < d.images.size(); i++) {
                        String n = r.name + (d.images.size() > 1 ? "_" + i : "") + ".png";
                        Uri po = DocumentsContract.createDocument(cr, dir, "image/png", n);
                        if (po == null) continue;
                        try (OutputStream o = cr.openOutputStream(po)) {
                            if (o != null) d.images.get(i).compress(Bitmap.CompressFormat.PNG, 100, o);
                        }
                        d.images.get(i).recycle();
                    }
                } catch (Throwable ignored) {
                    // texture not decodable - original is still exported
                }
            }
            done++;
            if (progress != null && (done % 10 == 0 || done == rows.size())) progress.onProgress(done, rows.size(), r.path);
        }
        return done;
    }

    private Uri dir(String folder) throws IOException {
        Uri u = dirs.get(folder);
        if (u != null) return u;
        String parent = folder.contains("/") ? folder.substring(0, folder.lastIndexOf('/')) : "";
        String name = folder.contains("/") ? folder.substring(folder.lastIndexOf('/') + 1) : folder;
        Uri p = dir(parent);
        u = DocumentsContract.createDocument(cr, p, DocumentsContract.Document.MIME_TYPE_DIR, name);
        if (u == null) throw new IOException("Не удалось создать папку " + folder);
        dirs.put(folder, u);
        return u;
    }
}
