package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

public final class PreviewActivity extends Activity {

    static final int REQ_SAVE_FILE = 10, REQ_SAVE_PNG = 11;

    private Db db;
    private Db.Row row;
    private File file;
    private final Handler main = new Handler(Looper.getMainLooper());
    private LinearLayout content;
    private ZoomImageView zoom;
    private TextView pageLabel;
    private List<Bitmap> images;
    private int page;
    private MediaPlayer player;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        db = Db.get(this);
        row = db.file(getIntent().getLongExtra("id", -1));
        if (row == null) {
            finish();
            return;
        }
        file = Blobs.file(this, row.blob);
        build();
    }

    private void build() {
        int p = Ui.dp(this, 12);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);
        scroll.addView(root);

        TextView title = Ui.bold(this, row.name, 18, Ui.TEXT);
        root.addView(title);
        String st = row.status == Db.ST_NEW ? "  ·  НОВЫЙ" : row.status == Db.ST_CHANGED ? "  ·  ИЗМЕНЁН" : "";
        TextView meta = Ui.text(this, row.path + "\n" + Ui.size(row.size) + "  ·  "
                + Categorizer.TYPE_NAMES.get(row.type) + "  ·  версия " + db.versionName(row.vid) + st, 12, Ui.MUTED);
        meta.setTextIsSelectable(true);
        meta.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 10));
        root.addView(meta);

        LinearLayout actions = new LinearLayout(this);
        TextView save = Ui.button(this, "Сохранить файл", true);
        save.setOnClickListener(v -> saveAs(REQ_SAVE_FILE, row.name, "application/octet-stream"));
        actions.addView(save);
        root.addView(actions);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, Ui.dp(this, 12), 0, 0);
        root.addView(content);
        setContentView(scroll);

        if (Decoders.isPreviewableImage(row)) {
            TextView png = Ui.button(this, "Сохранить PNG", false);
            LinearLayout.LayoutParams lp = Ui.lp(-2, -2, 0);
            lp.leftMargin = Ui.dp(this, 8);
            png.setOnClickListener(v -> {
                if (images == null || images.isEmpty()) {
                    Toast.makeText(this, "Нет картинки для сохранения", Toast.LENGTH_SHORT).show();
                    return;
                }
                saveAs(REQ_SAVE_PNG, row.name + (images.size() > 1 ? "_" + page : "") + ".png", "image/png");
            });
            actions.addView(png, lp);
            showImage();
        } else if (Decoders.isAudio(row)) {
            showAudio();
        } else if (Decoders.isVideo(row)) {
            showVideo();
        } else if (Decoders.isFont(row)) {
            showFont();
        } else if (Categorizer.T_3D.equals(row.type)) {
            show3d();
        } else {
            showText(); // csv → table, json → formatted, text → text, binary → hex
        }
        addHistory(root);
    }

    // ------------------------------------------------------------------ image
    private void showImage() {
        ProgressBar pb = new ProgressBar(this);
        content.addView(pb);
        new Thread(() -> {
            try {
                Decoders.Decoded d = Decoders.decodeImages(file, row);
                List<Db.Row> related = Categorizer.T_SC.equals(row.type) ? db.related(row) : null;
                List<Db.Row> refs = d.externalRefs.isEmpty() ? null : db.byPaths(row.vid, d.externalRefs);
                main.post(() -> {
                    content.removeView(pb);
                    images = d.images;
                    if (!d.images.isEmpty()) {
                        zoom = new ZoomImageView(this);
                        content.addView(zoom, new LinearLayout.LayoutParams(-1, Ui.dp(this, 420)));
                        if (d.images.size() > 1) {
                            LinearLayout nav = new LinearLayout(this);
                            nav.setGravity(Gravity.CENTER);
                            TextView prev = Ui.button(this, "‹", false);
                            TextView next = Ui.button(this, "›", false);
                            pageLabel = Ui.text(this, "", 14, Ui.TEXT);
                            pageLabel.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
                            prev.setOnClickListener(v -> setPage(page - 1));
                            next.setOnClickListener(v -> setPage(page + 1));
                            nav.addView(prev);
                            nav.addView(pageLabel);
                            nav.addView(next);
                            nav.setPadding(0, Ui.dp(this, 8), 0, 0);
                            content.addView(nav);
                        }
                        setPage(0);
                        content.addView(Ui.text(this, "Щипок — зум, двойной тап — приблизить/вписать.", 11, Ui.MUTED));
                    }
                    StringBuilder sb = new StringBuilder();
                    for (String s : d.info) sb.append("• ").append(s).append('\n');
                    if (d.images.isEmpty()) {
                        sb.append(Categorizer.T_SC.equals(row.type)
                                ? "В этом .sc нет встроенных текстур — картинки лежат в отдельных файлах текстур (см. ниже).\n"
                                : "Не удалось показать картинку.\n");
                    }
                    if (sb.length() > 0) addInfo(sb.toString());
                    if (!d.exportNames.isEmpty()) {
                        StringBuilder e = new StringBuilder("Объекты внутри (" + d.exportNames.size() + "):\n");
                        for (int i = 0; i < Math.min(300, d.exportNames.size()); i++) e.append(d.exportNames.get(i)).append('\n');
                        addInfo(e.toString());
                    }
                    if (d.sc2 != null && !d.sc2.shapes.isEmpty()) {
                        TextView sp = Ui.button(this, "Объекты (" + d.sc2.exportOrder.size() + ") и детали (" + d.sc2.shapes.size() + ") — смотреть и сохранить", true);
                        LinearLayout.LayoutParams slp = Ui.lp(-1, -2, 0);
                        slp.topMargin = Ui.dp(this, 12);
                        sp.setOnClickListener(v -> {
                            Intent i = new Intent(this, SpritesActivity.class);
                            i.putExtra("id", row.id);
                            startActivity(i);
                        });
                        content.addView(sp, slp);
                    }
                    if (refs != null && !refs.isEmpty()) addLinks("Используемые текстуры", refs);
                    if (related != null && !related.isEmpty()) addLinks("Связанные текстуры", related);
                });
            } catch (Throwable e) {
                main.post(() -> {
                    content.removeView(pb);
                    addInfo("Не удалось декодировать: " + e.getMessage()
                            + "\n\nМожно сохранить оригинальный файл кнопкой выше.");
                });
            }
        }, "decode").start();
    }

    private void setPage(int p) {
        if (images == null || images.isEmpty()) return;
        page = (p + images.size()) % images.size();
        Bitmap b = images.get(page);
        zoom.setBitmap(b);
        if (pageLabel != null) pageLabel.setText((page + 1) + " / " + images.size() + "  ·  " + b.getWidth() + "x" + b.getHeight());
    }

    // ------------------------------------------------------------------ audio
    private void showAudio() {
        TextView play = Ui.button(this, "▶  Воспроизвести", true);
        play.setOnClickListener(v -> {
            try {
                if (player != null && player.isPlaying()) {
                    player.pause();
                    play.setText("▶  Воспроизвести");
                    return;
                }
                if (player == null) {
                    player = new MediaPlayer();
                    try (FileInputStream in = new FileInputStream(file)) {
                        player.setDataSource(in.getFD());
                    }
                    player.prepare();
                    player.setOnCompletionListener(mp -> play.setText("▶  Воспроизвести"));
                }
                player.start();
                play.setText("❚❚  Пауза");
            } catch (Exception e) {
                Toast.makeText(this, "Не удалось воспроизвести: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        content.addView(play);
    }

    // ------------------------------------------------------------------ text / csv / json / binary
    private void showText() {
        ProgressBar pb = new ProgressBar(this);
        content.addView(pb);
        new Thread(() -> {
            byte[] data;
            String err = null;
            try {
                data = Decoders.content(file);
            } catch (Exception e) {
                data = new byte[0];
                err = e.getMessage();
            }
            byte[] fd = data;
            String fe = err;
            boolean text = Decoders.looksText(data);
            String ext = row.ext;
            List<String[]> table = null;
            String body;
            if (fe != null) {
                body = "Не удалось прочитать: " + fe;
            } else if (text && ext.equals("csv")) {
                body = null; // opened in the table viewer
            } else if (text) {
                String all = new String(fd, 0, Math.min(fd.length, 1_500_000), java.nio.charset.StandardCharsets.UTF_8);
                if (ext.equals("json")) all = Decoders.prettyJson(all);
                if (all.length() > 100_000) all = all.substring(0, 100_000) + "\n…(обрезано, сохрани файл, чтобы увидеть целиком)";
                body = all;
            } else {
                body = "Двоичный файл — показаны первые байты:\n\n" + Decoders.hexDump(fd, 16 * 1024);
            }
            List<String[]> ft = table;
            main.post(() -> {
                content.removeView(pb);
                if (body == null) {
                    TextView open = Ui.button(this, "Открыть таблицу", true);
                    open.setOnClickListener(v -> {
                        Intent i = new Intent(this, CsvActivity.class);
                        i.putExtra("id", row.id);
                        startActivity(i);
                    });
                    content.addView(open);
                    open.performClick();
                } else {
                    showMono(body);
                }
            });
        }).start();
    }

    private void showMono(String body) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        TextView t = Ui.text(this, body, 12, Ui.TEXT);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 10)));
        int p = Ui.dp(this, 10);
        t.setPadding(p, p, p, p);
        hs.addView(t);
        content.addView(hs);
    }

    // ------------------------------------------------------------------ video
    private void showVideo() {
        android.widget.VideoView vv = new android.widget.VideoView(this);
        android.widget.MediaController mc = new android.widget.MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        vv.setVideoPath(file.getPath());
        vv.setOnPreparedListener(mp -> {
            mp.setLooping(true);
            vv.start();
        });
        vv.setOnErrorListener((mp, what, extra) -> {
            Toast.makeText(this, "Видео не воспроизводится на этом устройстве — сохрани файл и открой плеером", Toast.LENGTH_LONG).show();
            return true;
        });
        android.widget.FrameLayout fl = new android.widget.FrameLayout(this);
        fl.setBackgroundColor(0xFF000000);
        fl.addView(vv, new android.widget.FrameLayout.LayoutParams(-1, -2, android.view.Gravity.CENTER));
        content.addView(fl, new LinearLayout.LayoutParams(-1, Ui.dp(this, 260)));
        content.addView(Ui.text(this, "Нажми на видео — появятся кнопки управления.", 11, Ui.MUTED));
    }

    // ------------------------------------------------------------------ font
    private void showFont() {
        Typeface tf;
        try {
            tf = Typeface.createFromFile(file);
        } catch (Exception e) {
            showMono("Не удалось загрузить шрифт: " + e.getMessage());
            return;
        }
        String[] samples = {
                "Съешь же ещё этих мягких французских булок, да выпей чаю",
                "The quick brown fox jumps over the lazy dog",
                "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ\nабвгдеёжзийклмнопрстуфхцчшщъыьэюя",
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ\nabcdefghijklmnopqrstuvwxyz",
                "0123456789 !?.,:;-+*/=()[]{}#%&@$€₽"};
        android.widget.EditText custom = new android.widget.EditText(this);
        custom.setHint("Свой текст для проверки…");
        custom.setHintTextColor(Ui.MUTED);
        custom.setTextColor(Ui.TEXT);
        custom.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 10)));
        int p = Ui.dp(this, 10);
        custom.setPadding(p, p, p, p);
        content.addView(custom);
        TextView big = Ui.text(this, "Aa Бб 123", 44, Ui.TEXT);
        big.setTypeface(tf);
        big.setPadding(0, p, 0, p);
        content.addView(big);
        custom.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s1, int a1, int b1, int c1) {}
            public void onTextChanged(CharSequence s1, int a1, int b1, int c1) {}
            public void afterTextChanged(android.text.Editable e) {
                big.setText(e.length() == 0 ? "Aa Бб 123" : e.toString());
            }
        });
        int[] sizes = {14, 20, 28};
        for (String sm : samples) {
            for (int sz : sizes) {
                if (sm.contains("\n") && sz != 20) continue;
                TextView t = Ui.text(this, sm, sz, Ui.TEXT);
                t.setTypeface(tf);
                t.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
                content.addView(t);
            }
        }
        TextView note = Ui.text(this, "Если вместо букв квадраты — в шрифте нет этих символов (например, кириллицы).", 11, Ui.MUTED);
        note.setPadding(0, p, 0, 0);
        content.addView(note);
    }

    // ------------------------------------------------------------------ 3d
    private void show3d() {
        boolean glb = row.ext.equals("glb") || row.ext.equals("gltf");
        android.widget.ImageView preview = null;
        if (glb) {
            TextView open = Ui.button(this, "Открыть 3D-просмотр", true);
            open.setOnClickListener(v -> open3d());
            content.addView(open, Ui.lp(-1, -2, 0));
            preview = new android.widget.ImageView(this);
            preview.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            preview.setBackground(Ui.round(0xFF20232F, Ui.dp(this, 12)));
            preview.setOnClickListener(v -> open3d());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 360));
            lp.topMargin = Ui.dp(this, 8);
            content.addView(preview, lp);
        }
        android.widget.ImageView pv = preview;
        new Thread(() -> {
            String s = Decoders.describe3d(file);
            Bitmap shot = null;
            String err = null;
            if (pv != null) {
                try {
                    Model3dActivity.Loaded l = Model3dActivity.load(this, row);
                    com.weker.assetexplorer.codec.Render3d r = new com.weker.assetexplorer.codec.Render3d();
                    com.weker.assetexplorer.codec.Model3d drawn = l.anim != null ? l.model.pose(l.anim, l.animInfo.start) : l.model;
                    if (l.anim != null) r.frameBounds = drawn.measure();
                    shot = Decoders.toBitmap(r.render(drawn, l.images, l.override, 480, 480, 2));
                    s = l.describe() + "\n\n" + s;
                } catch (Throwable e) {
                    err = e.getMessage();
                }
            }
            Bitmap fs = shot;
            String fe = err;
            String fs2 = s;
            main.post(() -> {
                if (pv != null) {
                    if (fs != null) pv.setImageBitmap(fs);
                    else pv.setVisibility(View.GONE);
                }
                if (fe != null) addInfo("Нарисовать не получилось: " + fe);
                addInfo(fs2);
            });
        }).start();
    }

    private void open3d() {
        Intent i = new Intent(this, Model3dActivity.class);
        i.putExtra("id", row.id);
        startActivity(i);
    }

    // ------------------------------------------------------------------ helpers
    private void addInfo(String s) {
        TextView t = Ui.text(this, s.trim(), 12, Ui.TEXT);
        t.setTextIsSelectable(true);
        t.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 10)));
        int p = Ui.dp(this, 10);
        t.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2, 0);
        lp.topMargin = Ui.dp(this, 10);
        content.addView(t, lp);
    }

    private void addLinks(String title, List<Db.Row> list) {
        TextView h = Ui.bold(this, title, 14, Ui.TEXT);
        h.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 4));
        content.addView(h);
        for (Db.Row r : list) content.addView(link(r, r.path));
    }

    private View link(Db.Row r, String label) {
        TextView t = Ui.text(this, label, 13, Ui.ACCENT);
        int p = Ui.dp(this, 6);
        t.setPadding(0, p, 0, p);
        t.setOnClickListener(v -> {
            Intent i = new Intent(this, PreviewActivity.class);
            i.putExtra("id", r.id);
            startActivity(i);
        });
        return t;
    }

    private void addHistory(LinearLayout root) {
        new Thread(() -> {
            List<Db.Row> h = db.history(row.path);
            if (h.size() <= 1) return;
            main.post(() -> {
                TextView t = Ui.bold(this, "Этот файл в других версиях", 14, Ui.TEXT);
                t.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 4));
                root.addView(t);
                for (Db.Row r : h) {
                    if (r.id == row.id) continue;
                    String st = r.status == Db.ST_NEW ? " — появился" : r.status == Db.ST_CHANGED ? " — изменён" : " — без изменений";
                    root.addView(link(r, db.versionName(r.vid) + st + " (" + Ui.size(r.size) + ")"));
                }
            });
        }).start();
    }

    private void saveAs(int req, String name, String mime) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для сохранения файлов", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        Bitmap bm = (req == REQ_SAVE_PNG && images != null && !images.isEmpty()) ? images.get(page) : null;
        new Thread(() -> {
            String msg;
            try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new java.io.IOException("нет доступа");
                if (req == REQ_SAVE_PNG && bm != null) {
                    bm.compress(Bitmap.CompressFormat.PNG, 100, o);
                } else {
                    try (InputStream in = new FileInputStream(file)) {
                        Importer.copy(in, o, null);
                    }
                }
                msg = "Сохранено";
            } catch (Exception e) {
                msg = "Ошибка: " + e.getMessage();
            }
            String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
