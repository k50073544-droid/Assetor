package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Background thumbnail loader with memory + disk cache. */
public final class Thumbs {

    private static Thumbs instance;

    public static synchronized Thumbs get(Context c) {
        if (instance == null) instance = new Thumbs(c.getApplicationContext());
        return instance;
    }

    static final int SIZE = 256;

    private final Context ctx;
    private final File dir;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> mem;
    private final Set<String> failed = new HashSet<>();

    private Thumbs(Context c) {
        ctx = c;
        dir = new File(c.getCacheDir(), "thumbs");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        int kb = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8);
        mem = new LruCache<String, Bitmap>(kb) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
    }

    public void load(Db.Row r, ImageView view) {
        String key = r.blob;
        view.setTag(key);
        Bitmap b = mem.get(key);
        if (b != null) {
            view.setImageBitmap(b);
            return;
        }
        view.setImageDrawable(null);
        synchronized (failed) {
            if (failed.contains(key)) return;
        }
        pool.execute(() -> {
            if (!key.equals(view.getTag())) return; // view was recycled
            Bitmap bm = null;
            File cached = new File(dir, key + ".png");
            File fail = new File(dir, key + ".x");
            if (cached.exists()) {
                bm = BitmapFactory.decodeFile(cached.getPath());
            } else if (!fail.exists()) {
                bm = Decoders.thumbnail(Blobs.file(ctx, key), r, SIZE);
                try {
                    if (bm != null) {
                        try (FileOutputStream o = new FileOutputStream(cached)) {
                            bm.compress(Bitmap.CompressFormat.PNG, 100, o);
                        }
                    } else {
                        //noinspection ResultOfMethodCallIgnored
                        fail.createNewFile();
                    }
                } catch (Exception ignored) {
                    // cache is optional
                }
            }
            if (bm == null) {
                synchronized (failed) {
                    failed.add(key);
                }
                return;
            }
            mem.put(key, bm);
            Bitmap fbm = bm;
            main.post(() -> {
                if (key.equals(view.getTag())) view.setImageBitmap(fbm);
            });
        });
    }
}
