package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Loads and caches 3D models, textures and animations by file name (through a {@link GameDb.Source}),
 * and builds animated characters from the game's skin tables (skins.csv → skin_confs.csv → animations.csv / faces.csv).
 */
public final class Assets {

    /** turns a .png / .jpg into pixels (platform dependent); .sctx / .ktx are decoded here */
    public interface ImageDecoder {
        Img decode(byte[] data);
    }

    public final GameDb db;
    final GameDb.Source src;
    public ImageDecoder images;
    final Map<String, Model3d> models = new HashMap<>();
    final Map<String, Img> textures = new HashMap<>();
    final Map<String, Anim3d> anims = new HashMap<>();
    final Map<String, Sc2> scs = new HashMap<>();
    public final List<String> missing = new ArrayList<>();

    public Assets(GameDb db, GameDb.Source src) {
        this.db = db;
        this.src = src;
    }

    public synchronized Model3d model(String file) {
        if (file == null) return null;
        if (models.containsKey(file)) return models.get(file);
        Model3d m = null;
        try {
            byte[] d = src.read(file);
            if (d != null) m = Model3d.load(d);
            else missing.add(file);
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        models.put(file, m);
        return m;
    }

    public synchronized Img texture(String name) {
        if (name == null) return null;
        if (textures.containsKey(name)) return textures.get(name);
        String file = name;
        Img im = null;
        try {
            byte[] d = src.read(file);
            String base = file.contains(".") ? file.substring(0, file.lastIndexOf('.')) : file;
            for (String ext : new String[]{".sctx", ".ktx", ".png"}) {
                if (d != null) break;
                if (file.endsWith(ext)) continue;
                d = src.read(base + ext);
                if (d != null) file = base + ext;
            }
            if (d == null) {
                missing.add(file);
            } else {
                String n = file.toLowerCase(Locale.ROOT);
                if ((n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")) && images != null) {
                    im = images.decode(d);
                } else {
                    SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(d, file);
                    if (!ts.images.isEmpty()) im = ts.images.get(0);
                }
            }
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        textures.put(name, im);
        return im;
    }

    /** the textures a model's materials name (diffuse + lightmaps), by file name */
    public Map<String, Img> imagesFor(Model3d m) {
        Map<String, Img> out = new HashMap<>();
        if (m == null) return out;
        for (String t : m.materialTextures()) {
            Img im = texture(t);
            if (im != null) out.put(t, im);
        }
        return out;
    }

    public synchronized Anim3d anim(String file) {
        if (file == null) return null;
        if (anims.containsKey(file)) return anims.get(file);
        Anim3d a = null;
        try {
            byte[] d = src.read(file);
            if (d != null) a = Anim3d.load(d);
            else missing.add(file);
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        anims.put(file, a);
        return a;
    }

    public synchronized Sc2 sc(String file) {
        if (scs.containsKey(file)) return scs.get(file);
        Sc2 s = null;
        try {
            byte[] d = src.read(file);
            if (d != null) s = Sc2.parse(d);
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        scs.put(file, s);
        return s;
    }

    // ------------------------------------------------------------------ characters
    public static final class Clip {
        public Anim3d anim;
        public int start, end;
        public String name;

        public double length() {
            return Math.max(1, end - start) / (double) Math.max(1, anim.fps);
        }
    }

    /** an animated character (brawler skin, training dummy…) */
    public static final class Actor {
        public Model3d model;
        public Map<String, Img> images = new HashMap<>();
        public Img override;
        /** idle, walk, attack, ulti, win, lose… */
        public final Map<String, Clip> clips = new LinkedHashMap<>();
        public String skin, conf, modelFile, face;
        /** posed copies, newest last (dummies standing together share one) */
        private final LinkedHashMap<String, Model3d> cache = new LinkedHashMap<>();

        /** the model in an action at a time since the action started */
        public synchronized Model3d posed(String action, double seconds, boolean loop) {
            Clip c = clips.get(action);
            if (c == null) c = clips.get("idle");
            if (c == null || c.anim == null) return model;
            double len = Math.max(1, c.end - c.start);
            double f = seconds * c.anim.fps;
            f = loop ? f % len : Math.min(f, len);
            f = Math.round((c.start + f) * 2) / 2.0; // half frames: smooth enough, and shared between equal actors
            String key = action + "@" + f;
            Model3d m = cache.get(key);
            if (m == null) {
                m = model.pose(c.anim, f);
                cache.put(key, m);
                if (cache.size() > 6) cache.remove(cache.keySet().iterator().next());
            }
            return m;
        }

        /** model height (rest pose) */
        public float height() {
            return model == null || model.bounds == null ? 1 : model.bounds[4] - model.bounds[1];
        }
    }

    static final String[][] SLOTS = {
            {"idle", "Idle"}, {"walk", "Walk"}, {"attack", "PrimarySkill"}, {"ulti", "SecondarySkill"},
            {"win", "Happy"}, {"lose", "Sad"}, {"reload", "Reloading"}};

    /** a character from a skin name (skins.csv), e.g. "BanditGirlDefault" or "MeleeBotDefault" */
    public Actor actor(String skin) {
        GameDb.Table skins = db.table("skins.csv");
        GameDb.Table confs = db.table("skin_confs.csv");
        String[] s = skins.row(skin);
        String confName = s != null ? skins.get(s, "Conf") : skin;
        String[] c = confs.row(confName);
        Actor a = new Actor();
        a.skin = skin;
        a.conf = confName;
        if (c == null) return a;
        a.modelFile = GameDb.fileName(confs.get(c, "Model"));
        a.model = model(a.modelFile);
        if (a.model == null) return a;
        a.images = imagesFor(a.model);
        String skinTex = s != null ? skins.get(s, "DiffuseTexture") : "";
        String body = FaceOverlay.bodyTexture(a.model);
        if (!skinTex.isEmpty()) {
            Img t = texture(GameDb.fileName(skinTex));
            if (t != null) {
                if (body != null) a.images.put(body, t);
                else a.override = t;
            }
        }
        // the 2D face painted on the body texture
        String[] face = faceOf(confs.get(c, "IdleFace"));
        if (face != null) {
            Sc2 sc = sc(face[0]);
            a.face = face[1];
            try {
                if (body != null && a.images.get(body) != null) a.images.put(body, FaceOverlay.apply(a.images.get(body), sc, face[1], 0));
                else if (a.override != null) a.override = FaceOverlay.apply(a.override, sc, face[1], 0);
            } catch (Throwable ignored) {
                // without a face
            }
        }
        for (String[] slot : SLOTS) {
            String an = confs.get(c, slot[1] + "Anim");
            Clip clip = clip(an);
            if (clip != null && a.model.matchingBones(clip.anim) > 0) a.clips.put(slot[0], clip);
        }
        if (!a.clips.containsKey("ulti") && a.clips.containsKey("attack")) a.clips.put("ulti", a.clips.get("attack"));
        return a;
    }

    /** animations.csv row -> loaded clip */
    public Clip clip(String name) {
        if (name == null || name.isEmpty()) return null;
        GameDb.Table t = db.table("animations.csv");
        String[] r = t.row(name);
        if (r == null) return null;
        Anim3d an = anim(GameDb.fileName(t.get(r, "FileName")));
        if (an == null) return null;
        Clip c = new Clip();
        c.name = name;
        c.anim = an;
        c.start = Math.max(0, Math.min(an.frames - 1, t.num(r, "StartFrame", 0)));
        int e = t.num(r, "EndFrame", -1);
        c.end = e < 0 || e >= an.frames ? an.frames - 1 : Math.max(c.start, e);
        return c;
    }

    /** faces.csv row -> {file, export} */
    public String[] faceOf(String name) {
        if (name == null || name.isEmpty()) return null;
        GameDb.Table t = db.table("faces.csv");
        String[] r = t.row(name);
        if (r == null) return null;
        String f = GameDb.fileName(t.get(r, "FileName")), e = t.get(r, "ExportName");
        return f.isEmpty() || e.isEmpty() ? null : new String[]{f, e};
    }
}
