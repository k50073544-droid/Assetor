package com.weker.assetexplorer.codec;

/** Decoded image: ARGB pixels (not premultiplied). */
public final class Img {
    public final int width, height;
    public final int[] argb;
    public String note = "";

    public Img(int width, int height, int[] argb) {
        this.width = width;
        this.height = height;
        this.argb = argb;
    }
}
