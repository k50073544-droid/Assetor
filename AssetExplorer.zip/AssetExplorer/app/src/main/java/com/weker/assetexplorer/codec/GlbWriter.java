package com.weker.assetexplorer.codec;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Writes a {@link Model3d} (bind pose, visible parts) as a plain glTF binary that Blender and other tools open. */
public final class GlbWriter {

    private GlbWriter() {}

    /** One texture for the whole model (png may be null). */
    public static void write(Model3d m, byte[] png, OutputStream out) throws IOException {
        java.util.Map<String, byte[]> one = new java.util.HashMap<>();
        if (png != null) one.put("texture", png);
        write(m, one, png != null ? "texture" : null, out);
    }

    /**
     * @param pngs        PNG bytes by texture name (part.diffuseTex, or overrideKey)
     * @param overrideKey when not null, every part uses pngs.get(overrideKey)
     */
    public static void write(Model3d m, java.util.Map<String, byte[]> pngs, String overrideKey, OutputStream out) throws IOException {
        java.util.List<String> texKeys = new java.util.ArrayList<>();
        StringBuilder materials = new StringBuilder();
        ByteArrayOutputStream bin = new ByteArrayOutputStream();
        StringBuilder accessors = new StringBuilder(), views = new StringBuilder(), meshes = new StringBuilder(), nodes = new StringBuilder();
        StringBuilder sceneNodes = new StringBuilder();
        int acc = 0, view = 0, mesh = 0;
        for (Model3d.Part p : m.parts) {
            if (!p.visible || p.triangles == 0) continue;
            int n = p.triangles * 3;
            float[] mn = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE}, mx = {-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < 3; k++) {
                    mn[k] = Math.min(mn[k], p.pos[i * 3 + k]);
                    mx[k] = Math.max(mx[k], p.pos[i * 3 + k]);
                }
            }
            int posA = acc;
            view = addView(bin, floats(p.pos, n * 3), views, view);
            sep(accessors).append(String.format(Locale.ROOT,
                    "{\"bufferView\":%d,\"componentType\":5126,\"count\":%d,\"type\":\"VEC3\",\"min\":[%f,%f,%f],\"max\":[%f,%f,%f]}",
                    view - 1, n, mn[0], mn[1], mn[2], mx[0], mx[1], mx[2]));
            acc++;
            StringBuilder attrs = new StringBuilder("\"POSITION\":" + posA);
            if (p.hasNormals) {
                float[] nr = p.nrm.clone();
                for (int i = 0; i < n; i++) { // glTF wants unit normals
                    float x = nr[i * 3], y = nr[i * 3 + 1], z = nr[i * 3 + 2];
                    float l = (float) Math.sqrt(x * x + y * y + z * z);
                    if (l > 0) { nr[i * 3] = x / l; nr[i * 3 + 1] = y / l; nr[i * 3 + 2] = z / l; }
                    else nr[i * 3 + 1] = 1;
                }
                view = addView(bin, floats(nr, n * 3), views, view);
                sep(accessors).append(String.format(Locale.ROOT, "{\"bufferView\":%d,\"componentType\":5126,\"count\":%d,\"type\":\"VEC3\"}", view - 1, n));
                attrs.append(",\"NORMAL\":").append(acc++);
            }
            if (p.hasUv) {
                view = addView(bin, floats(p.uv, n * 2), views, view);
                sep(accessors).append(String.format(Locale.ROOT, "{\"bufferView\":%d,\"componentType\":5126,\"count\":%d,\"type\":\"VEC2\"}", view - 1, n));
                attrs.append(",\"TEXCOORD_0\":").append(acc++);
            }
            String key = overrideKey != null ? overrideKey : p.diffuseTex;
            if (key == null || !pngs.containsKey(key)) key = "";
            int mat = texKeys.indexOf(key);
            if (mat < 0) {
                mat = texKeys.size();
                texKeys.add(key);
                sep(materials).append("{\"name\":").append(q(key.isEmpty() ? "no_texture" : key))
                        .append(",\"pbrMetallicRoughness\":{\"metallicFactor\":0,\"roughnessFactor\":1")
                        .append(key.isEmpty() ? "" : ",\"baseColorTexture\":{\"index\":" + TEX_PLACEHOLDER + key + TEX_PLACEHOLDER + "}")
                        .append("},\"alphaMode\":\"MASK\",\"alphaCutoff\":0.4,\"doubleSided\":true}");
            }
            sep(meshes).append("{\"name\":").append(q(p.name)).append(",\"primitives\":[{\"attributes\":{").append(attrs)
                    .append("},\"material\":").append(mat).append("}]}");
            sep(nodes).append("{\"name\":").append(q(p.name)).append(",\"mesh\":").append(mesh).append('}');
            sep(sceneNodes).append(mesh);
            mesh++;
        }
        if (mesh == 0) throw new IOException("нет видимых частей");
        // embed each used texture once, then point the materials at it
        StringBuilder imgs = new StringBuilder(), texs = new StringBuilder();
        String material = materials.toString();
        int ti = 0;
        for (String key : texKeys) {
            if (key.isEmpty()) continue;
            view = addView(bin, pngs.get(key), views, view);
            sep(imgs).append("{\"bufferView\":").append(view - 1).append(",\"mimeType\":\"image/png\",\"name\":").append(q(key)).append('}');
            sep(texs).append("{\"source\":").append(ti).append('}');
            material = material.replace(TEX_PLACEHOLDER + key + TEX_PLACEHOLDER, String.valueOf(ti));
            ti++;
        }
        String images = ti == 0 ? "" : ",\"images\":[" + imgs + "],\"textures\":[" + texs + "]";
        String json = "{\"asset\":{\"version\":\"2.0\",\"generator\":\"Asset Explorer\"},\"scene\":0,\"scenes\":[{\"nodes\":[" + sceneNodes
                + "]}],\"nodes\":[" + nodes + "],\"meshes\":[" + meshes + "],\"materials\":[" + material + "]" + images
                + ",\"accessors\":[" + accessors + "],\"bufferViews\":[" + views + "],\"buffers\":[{\"byteLength\":" + bin.size() + "}]}";
        byte[] js = json.getBytes(StandardCharsets.UTF_8);
        int jsPad = (4 - js.length % 4) % 4;
        int binLen = bin.size();
        int total = 12 + 8 + js.length + jsPad + 8 + binLen;
        ByteBuffer h = ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(0x46546C67).putInt(2).putInt(total).putInt(js.length + jsPad).putInt(0x4E4F534A);
        out.write(h.array());
        out.write(js);
        for (int i = 0; i < jsPad; i++) out.write(' ');
        ByteBuffer bh = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        bh.putInt(binLen).putInt(0x004E4942);
        out.write(bh.array());
        bin.writeTo(out);
    }

    static final String TEX_PLACEHOLDER = "\u0001";

    static int addView(ByteArrayOutputStream bin, byte[] data, StringBuilder views, int view) {
        int off = bin.size();
        bin.write(data, 0, data.length);
        while (bin.size() % 4 != 0) bin.write(0);
        sep(views).append("{\"buffer\":0,\"byteOffset\":").append(off).append(",\"byteLength\":").append(data.length).append('}');
        return view + 1;
    }

    static byte[] floats(float[] v, int n) {
        ByteBuffer b = ByteBuffer.allocate(n * 4).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < n; i++) b.putFloat(v[i]);
        return b.array();
    }

    static StringBuilder sep(StringBuilder sb) {
        if (sb.length() > 0) sb.append(',');
        return sb;
    }

    static String q(String s) {
        return "\"" + (s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"")) + "\"";
    }
}
