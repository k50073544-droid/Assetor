package com.weker.assetexplorer.codec;

/** Pure-Java ASTC LDR decoder (2D blocks). Output is ARGB int pixels. */
public final class Astc {

    private Astc() {}

    public static int[] decode(byte[] data, int off, int width, int height, int bw, int bh) {
        int[] out = new int[width * height];
        int bx = (width + bw - 1) / bw;
        int by = (height + bh - 1) / bh;
        int[] block = new int[bw * bh];
        Decoder dec = new Decoder(bw, bh);
        for (int y = 0; y < by; y++) {
            for (int x = 0; x < bx; x++) {
                int p = off + (y * bx + x) * 16;
                if (p + 16 > data.length) return out;
                dec.decodeBlock(data, p, block);
                for (int j = 0; j < bh; j++) {
                    int py = y * bh + j;
                    if (py >= height) break;
                    for (int i = 0; i < bw; i++) {
                        int px = x * bw + i;
                        if (px >= width) break;
                        out[py * width + px] = block[j * bw + i];
                    }
                }
            }
        }
        return out;
    }

    public static int dataSize(int width, int height, int bw, int bh) {
        return ((width + bw - 1) / bw) * ((height + bh - 1) / bh) * 16;
    }

    // ------------------------------------------------------------------ ISE tables
    static final int[] Q_LEVELS = {2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 160, 192, 256};
    static final int[] Q_TRITS = {0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0};
    static final int[] Q_QUINTS = {0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0};
    static final int[] Q_BITS = {1, 0, 2, 0, 1, 3, 1, 2, 4, 2, 3, 5, 3, 4, 6, 4, 5, 7, 5, 6, 8};

    static final int[][] TRITS = new int[256][5];
    static final int[][] QUINTS = new int[128][3];

    static {
        for (int T = 0; T < 256; T++) {
            int c, t4, t3, t2, t1, t0;
            if (((T >> 2) & 7) == 7) {
                c = ((T >> 5) & 7) << 2 | (T & 3);
                t4 = 2;
                t3 = 2;
            } else {
                c = T & 0x1F;
                if (((T >> 5) & 3) == 3) {
                    t4 = 2;
                    t3 = (T >> 7) & 1;
                } else {
                    t4 = (T >> 7) & 1;
                    t3 = (T >> 5) & 3;
                }
            }
            if ((c & 3) == 3) {
                t2 = 2;
                t1 = (c >> 4) & 1;
                int c3 = (c >> 3) & 1, c2 = (c >> 2) & 1;
                t0 = (c3 << 1) | (c2 & ~c3 & 1);
            } else if (((c >> 2) & 3) == 3) {
                t2 = 2;
                t1 = 2;
                t0 = c & 3;
            } else {
                t2 = (c >> 4) & 1;
                t1 = (c >> 2) & 3;
                int c1 = (c >> 1) & 1, c0 = c & 1;
                t0 = (c1 << 1) | (c0 & ~c1 & 1);
            }
            TRITS[T] = new int[]{t0, t1, t2, t3, t4};
        }
        for (int Q = 0; Q < 128; Q++) {
            int q0, q1, q2;
            if (((Q >> 1) & 3) == 3 && ((Q >> 5) & 3) == 0) {
                int q00 = Q & 1, q4 = (Q >> 4) & 1, q3 = (Q >> 3) & 1;
                q2 = (q00 << 2) | ((q4 & ~q00 & 1) << 1) | (q3 & ~q00 & 1);
                q1 = 4;
                q0 = 4;
            } else {
                int c;
                if (((Q >> 1) & 3) == 3) {
                    q2 = 4;
                    c = (((Q >> 3) & 3) << 3) | ((~(Q >> 5) & 3) << 1) | (Q & 1);
                } else {
                    q2 = (Q >> 5) & 3;
                    c = Q & 0x1F;
                }
                if ((c & 7) == 5) {
                    q1 = 4;
                    q0 = (c >> 3) & 3;
                } else {
                    q1 = (c >> 3) & 3;
                    q0 = c & 7;
                }
            }
            QUINTS[Q] = new int[]{q0, q1, q2};
        }
    }

    static int iseBits(int count, int q) {
        int b = Q_BITS[q];
        if (Q_TRITS[q] != 0) return (8 * count + 4) / 5 + count * b;
        if (Q_QUINTS[q] != 0) return (7 * count + 2) / 3 + count * b;
        return count * b;
    }

    /** Reads bits [start, start+n) (LSB-first) from a 128-bit block stored as 16 bytes. */
    static int bits(byte[] b, int start, int n) {
        int v = 0;
        for (int i = 0; i < n; i++) {
            int bp = start + i;
            v |= ((b[bp >> 3] >> (bp & 7)) & 1) << i;
        }
        return v;
    }

    /** Decodes integer sequence: returns values (trit/quint part as high, bits as low). */
    static void decodeIse(byte[] src, int start, int count, int q, int[] out) {
        int nb = Q_BITS[q];
        int p = start;
        // bits past the end of the sequence must read as zero
        byte[] b = new byte[24];
        int limit = start + iseBits(count, q);
        for (int i = start; i < limit; i++) {
            if (((src[i >> 3] >> (i & 7)) & 1) != 0) b[i >> 3] |= (byte) (1 << (i & 7));
        }
        if (Q_TRITS[q] != 0) {
            for (int i = 0; i < count; i += 5) {
                int[] m = new int[5];
                int T;
                m[0] = bits(b, p, nb); p += nb;
                T = bits(b, p, 2); p += 2;
                m[1] = bits(b, p, nb); p += nb;
                T |= bits(b, p, 2) << 2; p += 2;
                m[2] = bits(b, p, nb); p += nb;
                T |= bits(b, p, 1) << 4; p += 1;
                m[3] = bits(b, p, nb); p += nb;
                T |= bits(b, p, 2) << 5; p += 2;
                m[4] = bits(b, p, nb); p += nb;
                T |= bits(b, p, 1) << 7; p += 1;
                int[] t = TRITS[T];
                for (int k = 0; k < 5 && i + k < count; k++) out[i + k] = (t[k] << nb) | m[k];
            }
        } else if (Q_QUINTS[q] != 0) {
            for (int i = 0; i < count; i += 3) {
                int[] m = new int[3];
                int Q;
                m[0] = bits(b, p, nb); p += nb;
                Q = bits(b, p, 3); p += 3;
                m[1] = bits(b, p, nb); p += nb;
                Q |= bits(b, p, 2) << 3; p += 2;
                m[2] = bits(b, p, nb); p += nb;
                Q |= bits(b, p, 2) << 5; p += 2;
                int[] t = QUINTS[Q];
                for (int k = 0; k < 3 && i + k < count; k++) out[i + k] = (t[k] << nb) | m[k];
            }
        } else {
            for (int i = 0; i < count; i++) {
                out[i] = bits(b, p, nb);
                p += nb;
            }
        }
    }

    static int replicate(int v, int from, int to) {
        if (from == 0) return 0;
        int r = 0;
        int shift = to - from;
        while (shift > -from) {
            if (shift >= 0) r |= v << shift;
            else r |= v >> -shift;
            shift -= from;
        }
        return r & ((1 << to) - 1);
    }

    static int unquantColor(int v, int q) {
        int nb = Q_BITS[q];
        if (Q_TRITS[q] == 0 && Q_QUINTS[q] == 0) return replicate(v, nb, 8);
        int m = v & ((1 << nb) - 1);
        int D = v >> nb;
        int A = (m & 1) != 0 ? 0x1FF : 0;
        int b = (m >> 1) & 1, c = (m >> 2) & 1, d = (m >> 3) & 1, e = (m >> 4) & 1, f = (m >> 5) & 1;
        int B = 0, C = 0;
        if (Q_TRITS[q] != 0) {
            switch (nb) {
                case 1: C = 204; B = 0; break;
                case 2: C = 93; B = (b << 8) | (b << 4) | (b << 2) | (b << 1); break;
                case 3: C = 44; B = (c << 8) | (b << 7) | (c << 3) | (b << 2) | (c << 1) | b; break;
                case 4: C = 22; B = (d << 8) | (c << 7) | (b << 6) | (d << 2) | (c << 1) | b; break;
                case 5: C = 11; B = (e << 8) | (d << 7) | (c << 6) | (b << 5) | (e << 1) | d; break;
                case 6: C = 5; B = (f << 8) | (e << 7) | (d << 6) | (c << 5) | (b << 4) | f; break;
                default: return (D * 255) / 2; // nb==0 cannot happen for colors
            }
        } else {
            switch (nb) {
                case 1: C = 113; B = 0; break;
                case 2: C = 54; B = (b << 8) | (b << 3) | (b << 2); break;
                case 3: C = 26; B = (c << 8) | (b << 7) | (c << 2) | (b << 1) | c; break;
                case 4: C = 13; B = (d << 8) | (c << 7) | (b << 6) | (d << 1) | c; break;
                case 5: C = 6; B = (e << 8) | (d << 7) | (c << 6) | (b << 5) | e; break;
                default: return (D * 255) / 4;
            }
        }
        int T = D * C + B;
        T ^= A;
        T = (A & 0x80) | (T >> 2);
        return T & 0xFF;
    }

    static int unquantWeight(int v, int q) {
        int nb = Q_BITS[q];
        int r;
        if (Q_TRITS[q] == 0 && Q_QUINTS[q] == 0) {
            r = replicate(v, nb, 6);
        } else if (nb == 0) {
            int D = v;
            if (Q_TRITS[q] != 0) r = new int[]{0, 32, 63}[D];
            else r = new int[]{0, 16, 32, 47, 63}[D];
        } else {
            int m = v & ((1 << nb) - 1);
            int D = v >> nb;
            int A = (m & 1) != 0 ? 0x7F : 0;
            int b = (m >> 1) & 1, c = (m >> 2) & 1;
            int B, C;
            if (Q_TRITS[q] != 0) {
                switch (nb) {
                    case 1: C = 50; B = 0; break;
                    case 2: C = 23; B = (b << 6) | (b << 2) | b; break;
                    default: C = 11; B = (c << 6) | (b << 5) | (c << 1) | b; break;
                }
            } else {
                switch (nb) {
                    case 1: C = 28; B = 0; break;
                    default: C = 13; B = (b << 6) | (b << 1); break;
                }
            }
            int T = D * C + B;
            T ^= A;
            r = (A & 0x20) | (T >> 2);
        }
        if (r > 32) r++;
        return r;
    }

    static int hash52(int p) {
        p ^= p >>> 15;
        p -= p << 17;
        p += p << 7;
        p += p << 4;
        p ^= p >>> 5;
        p += p << 16;
        p ^= p >>> 7;
        p ^= p >>> 3;
        p ^= p << 6;
        p ^= p >>> 17;
        return p;
    }

    static int selectPartition(int seed, int x, int y, int z, int count, boolean small) {
        if (small) {
            x <<= 1;
            y <<= 1;
            z <<= 1;
        }
        seed += (count - 1) * 1024;
        int rnum = hash52(seed);
        int s1 = rnum & 0xF, s2 = (rnum >>> 4) & 0xF, s3 = (rnum >>> 8) & 0xF, s4 = (rnum >>> 12) & 0xF;
        int s5 = (rnum >>> 16) & 0xF, s6 = (rnum >>> 20) & 0xF, s7 = (rnum >>> 24) & 0xF, s8 = (rnum >>> 28) & 0xF;
        int s9 = (rnum >>> 18) & 0xF, s10 = (rnum >>> 22) & 0xF, s11 = (rnum >>> 26) & 0xF;
        int s12 = ((rnum >>> 30) | (rnum << 2)) & 0xF;
        s1 *= s1; s2 *= s2; s3 *= s3; s4 *= s4; s5 *= s5; s6 *= s6;
        s7 *= s7; s8 *= s8; s9 *= s9; s10 *= s10; s11 *= s11; s12 *= s12;
        int sh1, sh2;
        if ((seed & 1) != 0) {
            sh1 = (seed & 2) != 0 ? 4 : 5;
            sh2 = count == 3 ? 6 : 5;
        } else {
            sh1 = count == 3 ? 6 : 5;
            sh2 = (seed & 2) != 0 ? 4 : 5;
        }
        int sh3 = (seed & 0x10) != 0 ? sh1 : sh2;
        s1 >>= sh1; s2 >>= sh2; s3 >>= sh1; s4 >>= sh2; s5 >>= sh1; s6 >>= sh2;
        s7 >>= sh1; s8 >>= sh2; s9 >>= sh3; s10 >>= sh3; s11 >>= sh3; s12 >>= sh3;
        int a = s1 * x + s2 * y + s11 * z + (rnum >>> 14);
        int b = s3 * x + s4 * y + s12 * z + (rnum >>> 10);
        int c = s5 * x + s6 * y + s9 * z + (rnum >>> 6);
        int d = s7 * x + s8 * y + s10 * z + (rnum >>> 2);
        a &= 0x3F; b &= 0x3F; c &= 0x3F; d &= 0x3F;
        if (count < 4) d = 0;
        if (count < 3) c = 0;
        if (a >= b && a >= c && a >= d) return 0;
        if (b >= c && b >= d) return 1;
        if (c >= d) return 2;
        return 3;
    }

    static final int ERROR_COLOR = 0xFFFF00FF;

    // ------------------------------------------------------------------ block decoder
    static final class Decoder {
        final int bw, bh;
        final byte[] rev = new byte[16];
        final int[] ise = new int[128];
        final int[] colorVals = new int[32];
        final int[] grid = new int[128];
        final int[] w0, w1;
        final int[][] ep0 = new int[4][4], ep1 = new int[4][4];

        Decoder(int bw, int bh) {
            this.bw = bw;
            this.bh = bh;
            w0 = new int[bw * bh];
            w1 = new int[bw * bh];
        }

        void decodeBlock(byte[] data, int off, int[] out) {
            byte[] b = new byte[16];
            System.arraycopy(data, off, b, 0, 16);
            try {
                if (!decode(b, out)) java.util.Arrays.fill(out, ERROR_COLOR);
            } catch (RuntimeException e) {
                java.util.Arrays.fill(out, ERROR_COLOR);
            }
        }

        boolean decode(byte[] b, int[] out) {
            int mode = bits(b, 0, 11);
            // void extent
            if ((mode & 0x1FF) == 0x1FC) {
                boolean hdr = (mode & 0x200) != 0;
                int r = bits(b, 64, 16), g = bits(b, 80, 16), bl = bits(b, 96, 16), a = bits(b, 112, 16);
                int color;
                if (hdr) {
                    color = argb(half2u8(a), half2u8(r), half2u8(g), half2u8(bl));
                } else {
                    color = argb(a >> 8, r >> 8, g >> 8, bl >> 8);
                }
                java.util.Arrays.fill(out, color);
                return true;
            }
            // block mode
            int xw, yw;
            int baseQ = (mode >> 4) & 1;
            int H = (mode >> 9) & 1;
            int D = (mode >> 10) & 1;
            int A = (mode >> 5) & 3;
            if ((mode & 3) != 0) {
                baseQ |= (mode & 3) << 1;
                int B = (mode >> 7) & 3;
                switch ((mode >> 2) & 3) {
                    case 0: xw = B + 4; yw = A + 2; break;
                    case 1: xw = B + 8; yw = A + 2; break;
                    case 2: xw = A + 2; yw = B + 8; break;
                    default:
                        B &= 1;
                        if ((mode & 0x100) != 0) { xw = B + 2; yw = A + 2; }
                        else { xw = A + 2; yw = B + 6; }
                        break;
                }
            } else {
                baseQ |= ((mode >> 2) & 3) << 1;
                if (((mode >> 2) & 3) == 0) return false;
                int B = (mode >> 9) & 3;
                switch ((mode >> 7) & 3) {
                    case 0: xw = 12; yw = A + 2; break;
                    case 1: xw = A + 2; yw = 12; break;
                    case 2: xw = A + 6; yw = B + 6; D = 0; H = 0; break;
                    default:
                        switch ((mode >> 5) & 3) {
                            case 0: xw = 6; yw = 10; break;
                            case 1: xw = 10; yw = 6; break;
                            default: return false;
                        }
                        break;
                }
            }
            if (xw > bw || yw > bh) return false;
            int wq = (baseQ - 2) + 6 * H;
            if (wq < 0 || wq > 11) return false;
            int planes = D + 1;
            int wCount = xw * yw * planes;
            if (wCount > 64) return false;
            int wBits = iseBits(wCount, wq);
            if (wBits < 24 || wBits > 96) return false;

            int parts = bits(b, 11, 2) + 1;
            if (D == 1 && parts == 4) return false;

            int[] cem = new int[4];
            int colorStart;
            int extraCemBits = 0;
            int partIndex = 0;
            if (parts == 1) {
                cem[0] = bits(b, 13, 4);
                colorStart = 17;
            } else {
                partIndex = bits(b, 13, 10);
                int cemField = bits(b, 23, 6);
                colorStart = 29;
                if ((cemField & 3) == 0) {
                    int c = cemField >> 2;
                    for (int i = 0; i < parts; i++) cem[i] = c;
                } else {
                    extraCemBits = 3 * parts - 4;
                    int extra = bits(b, 128 - wBits - extraCemBits, extraCemBits);
                    int all = (cemField >> 2) | (extra << 4);
                    int baseClass = (cemField & 3) - 1;
                    for (int i = 0; i < parts; i++) {
                        int cbit = (all >> i) & 1;
                        int m = (all >> (parts + 2 * i)) & 3;
                        cem[i] = ((baseClass + cbit) << 2) | m;
                    }
                }
            }
            int belowWeights = 128 - wBits - extraCemBits;
            int ccs = 0;
            if (D == 1) {
                belowWeights -= 2;
                ccs = bits(b, belowWeights, 2);
            }
            int colorInts = 0;
            for (int i = 0; i < parts; i++) colorInts += ((cem[i] >> 2) + 1) * 2;
            if (colorInts > 18) return false;
            int avail = belowWeights - colorStart;
            int cq = -1;
            for (int q = 20; q >= 0; q--) {
                if (iseBits(colorInts, q) <= avail) {
                    cq = q;
                    break;
                }
            }
            if (cq < 4) return false;
            decodeIse(b, colorStart, colorInts, cq, ise);
            for (int i = 0; i < colorInts; i++) colorVals[i] = unquantColor(ise[i], cq);

            boolean hdrMode = false;
            int ci = 0;
            for (int i = 0; i < parts; i++) {
                if (!endpoints(cem[i], colorVals, ci, ep0[i], ep1[i])) hdrMode = true;
                ci += ((cem[i] >> 2) + 1) * 2;
            }
            if (hdrMode) return false;

            // weights (stored bit-reversed from the top of the block)
            for (int i = 0; i < 16; i++) rev[i] = (byte) (Integer.reverse(b[15 - i] & 0xFF) >>> 24);
            decodeIse(rev, 0, wCount, wq, ise);
            for (int i = 0; i < wCount; i++) grid[i] = unquantWeight(ise[i], wq);
            infill(xw, yw, planes, 0, w0);
            if (planes == 2) infill(xw, yw, planes, 1, w1);

            boolean small = bw * bh < 31;
            for (int y = 0; y < bh; y++) {
                for (int x = 0; x < bw; x++) {
                    int t = y * bw + x;
                    int p = parts == 1 ? 0 : selectPartition(partIndex, x, y, 0, parts, small);
                    int[] e0 = ep0[p], e1 = ep1[p];
                    int[] c = new int[4];
                    for (int ch = 0; ch < 4; ch++) {
                        int w = (planes == 2 && ch == ccs) ? w1[t] : w0[t];
                        int c0 = (e0[ch] << 8) | e0[ch];
                        int c1 = (e1[ch] << 8) | e1[ch];
                        int v = (c0 * (64 - w) + c1 * w + 32) >> 6;
                        c[ch] = (v * 255 + 32767) / 65535;
                    }
                    out[t] = argb(c[3], c[0], c[1], c[2]);
                }
            }
            return true;
        }

        void infill(int xw, int yw, int planes, int plane, int[] dst) {
            if (xw == bw && yw == bh) {
                for (int i = 0; i < bw * bh; i++) dst[i] = grid[i * planes + plane];
                return;
            }
            int ds = (1024 + bw / 2) / (bw - 1);
            int dt = (1024 + bh / 2) / (bh - 1);
            for (int t = 0; t < bh; t++) {
                for (int s = 0; s < bw; s++) {
                    int cs = ds * s;
                    int ct = dt * t;
                    int gs = (cs * (xw - 1) + 32) >> 6;
                    int gt = (ct * (yw - 1) + 32) >> 6;
                    int js = gs >> 4, fs = gs & 0xF;
                    int jt = gt >> 4, ft = gt & 0xF;
                    int w11 = (fs * ft + 8) >> 4;
                    int w10 = ft - w11;
                    int w01 = fs - w11;
                    int w00 = 16 - fs - ft + w11;
                    int v0 = js + jt * xw;
                    int p00 = g(v0, xw, yw, planes, plane);
                    int p01 = (js + 1 < xw) ? g(v0 + 1, xw, yw, planes, plane) : 0;
                    int p10 = (jt + 1 < yw) ? g(v0 + xw, xw, yw, planes, plane) : 0;
                    int p11 = (js + 1 < xw && jt + 1 < yw) ? g(v0 + xw + 1, xw, yw, planes, plane) : 0;
                    dst[t * bw + s] = (p00 * w00 + p01 * w01 + p10 * w10 + p11 * w11 + 8) >> 4;
                }
            }
        }

        int g(int idx, int xw, int yw, int planes, int plane) {
            return grid[idx * planes + plane];
        }
    }

    static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    /** returns false for HDR modes. */
    static boolean endpoints(int mode, int[] v, int o, int[] e0, int[] e1) {
        switch (mode) {
            case 0: {
                set(e0, v[o], v[o], v[o], 255);
                set(e1, v[o + 1], v[o + 1], v[o + 1], 255);
                return true;
            }
            case 1: {
                int l0 = (v[o] >> 2) | (v[o + 1] & 0xC0);
                int l1 = Math.min(l0 + (v[o + 1] & 0x3F), 255);
                set(e0, l0, l0, l0, 255);
                set(e1, l1, l1, l1, 255);
                return true;
            }
            case 4: {
                set(e0, v[o], v[o], v[o], v[o + 2]);
                set(e1, v[o + 1], v[o + 1], v[o + 1], v[o + 3]);
                return true;
            }
            case 5: {
                int[] a = bts(v[o + 1], v[o]);
                int[] c = bts(v[o + 3], v[o + 2]);
                set(e0, a[1], a[1], a[1], c[1]);
                int l = clamp(a[1] + a[0]);
                set(e1, l, l, l, clamp(c[1] + c[0]));
                return true;
            }
            case 6: {
                int r = v[o], g = v[o + 1], bl = v[o + 2], s = v[o + 3];
                set(e0, (r * s) >> 8, (g * s) >> 8, (bl * s) >> 8, 255);
                set(e1, r, g, bl, 255);
                return true;
            }
            case 8:
            case 12: {
                boolean alpha = mode == 12;
                int a0 = alpha ? v[o + 6] : 255, a1 = alpha ? v[o + 7] : 255;
                int s0 = v[o] + v[o + 2] + v[o + 4];
                int s1 = v[o + 1] + v[o + 3] + v[o + 5];
                if (s1 >= s0) {
                    set(e0, v[o], v[o + 2], v[o + 4], a0);
                    set(e1, v[o + 1], v[o + 3], v[o + 5], a1);
                } else {
                    blue(e0, v[o + 1], v[o + 3], v[o + 5], a1);
                    blue(e1, v[o], v[o + 2], v[o + 4], a0);
                }
                return true;
            }
            case 9:
            case 13: {
                boolean alpha = mode == 13;
                int[] r = bts(v[o + 1], v[o]);
                int[] g = bts(v[o + 3], v[o + 2]);
                int[] bl = bts(v[o + 5], v[o + 4]);
                int[] al = alpha ? bts(v[o + 7], v[o + 6]) : new int[]{0, 255};
                if (r[0] + g[0] + bl[0] >= 0) {
                    set(e0, r[1], g[1], bl[1], al[1]);
                    set(e1, clamp(r[1] + r[0]), clamp(g[1] + g[0]), clamp(bl[1] + bl[0]), clamp(al[1] + al[0]));
                } else {
                    blue(e0, clamp(r[1] + r[0]), clamp(g[1] + g[0]), clamp(bl[1] + bl[0]), clamp(al[1] + al[0]));
                    blue(e1, r[1], g[1], bl[1], al[1]);
                }
                return true;
            }
            case 10: {
                int r = v[o], g = v[o + 1], bl = v[o + 2], s = v[o + 3];
                set(e0, (r * s) >> 8, (g * s) >> 8, (bl * s) >> 8, v[o + 4]);
                set(e1, r, g, bl, v[o + 5]);
                return true;
            }
            default:
                return false;
        }
    }

    /** bit_transfer_signed(a, b): returns {a, b}. */
    static int[] bts(int a, int b) {
        b >>= 1;
        b |= a & 0x80;
        a >>= 1;
        a &= 0x3F;
        if ((a & 0x20) != 0) a -= 0x40;
        return new int[]{a, b};
    }

    static void set(int[] e, int r, int g, int b, int a) {
        e[0] = r; e[1] = g; e[2] = b; e[3] = a;
    }

    static void blue(int[] e, int r, int g, int b, int a) {
        e[0] = (r + b) >> 1;
        e[1] = (g + b) >> 1;
        e[2] = b;
        e[3] = a;
    }

    static int argb(int a, int r, int g, int b) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    static int half2u8(int h) {
        int exp = (h >> 10) & 0x1F;
        int man = h & 0x3FF;
        float f;
        if (exp == 0) f = man / 1024f / 16384f;
        else if (exp == 31) f = 1f;
        else f = (float) Math.pow(2, exp - 15) * (1 + man / 1024f);
        if ((h & 0x8000) != 0) f = 0;
        return clamp(Math.round(Math.min(f, 1f) * 255));
    }
}
