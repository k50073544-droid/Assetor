package com.weker.assetexplorer.codec;

/**
 * Brawlers' eyes and mouths are not in the 3D model: the game draws an animated 2D face (an export in
 * characters.sc, see faces.csv) over the body texture. The export is laid out in a 1024×1024 space with the
 * origin at the bottom-left corner of the texture, scaled to the texture's real size.
 */
public final class FaceOverlay {

    private FaceOverlay() {}

    public static final float SPACE = 1024f;

    /** A copy of tex with the face export (at the given frame) painted over it; tex itself is not changed. */
    public static Img apply(Img tex, Sc2 sc, String export, int frame) throws java.io.IOException {
        if (tex == null || sc == null || export == null || !sc.exportIds.containsKey(export)) return tex;
        Img face = sc.renderFrame(export, frame, new float[]{0, -SPACE, SPACE, 0}, Math.max(tex.width, tex.height), 2);
        if (face == null) return tex;
        int[] out = tex.argb.clone();
        int w = Math.min(tex.width, face.width), h = Math.min(tex.height, face.height);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int s = face.argb[y * face.width + x];
                int sa = s >>> 24;
                if (sa == 0) continue;
                int o = y * tex.width + x;
                int d = out[o];
                int r = (((s >> 16) & 255) * sa + ((d >> 16) & 255) * (255 - sa)) / 255;
                int g = (((s >> 8) & 255) * sa + ((d >> 8) & 255) * (255 - sa)) / 255;
                int b = ((s & 255) * sa + (d & 255) * (255 - sa)) / 255;
                out[o] = (d & 0xFF000000) | (r << 16) | (g << 8) | b;
            }
        }
        return new Img(tex.width, tex.height, out);
    }

    /** the texture the face belongs on: the one used by the biggest part (the body) */
    public static String bodyTexture(Model3d m) {
        java.util.Map<String, Integer> tris = new java.util.HashMap<>();
        for (Model3d.Part p : m.parts) if (p.diffuseTex != null && p.hasUv) tris.merge(p.diffuseTex, p.triangles, Integer::sum);
        String best = null;
        for (java.util.Map.Entry<String, Integer> e : tris.entrySet()) if (best == null || e.getValue() > tris.get(best)) best = e.getKey();
        return best;
    }
}
