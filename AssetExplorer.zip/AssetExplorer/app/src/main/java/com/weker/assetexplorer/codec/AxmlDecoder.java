package com.weker.assetexplorer.codec;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class AxmlDecoder {
    private static final int CHUNK_AXML_FILE = 0x00080003;
    private static final int CHUNK_STRING_POOL = 0x001c0001;
    private static final int CHUNK_START_TAG = 0x00100102;
    private static final int CHUNK_END_TAG = 0x00100103;

    private AxmlDecoder() {}

    public static boolean isAxml(byte[] bytes) {
        if (bytes == null || bytes.length < 8) return false;
        int magic = (bytes[0] & 0xFF) | ((bytes[1] & 0xFF) << 8) | ((bytes[2] & 0xFF) << 16) | ((bytes[3] & 0xFF) << 24);
        return magic == CHUNK_AXML_FILE;
    }

    public static String decode(byte[] bytes) {
        if (!isAxml(bytes)) return new String(bytes, StandardCharsets.UTF_8);
        ByteBuffer buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int magic = buffer.getInt();
        if (magic != CHUNK_AXML_FILE) return new String(bytes, StandardCharsets.UTF_8);
        int fileSize = buffer.getInt();
        List<String> stringPool = new ArrayList<>();
        StringBuilder xml = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        int indentLevel = 0;

        while (buffer.hasRemaining() && buffer.position() < fileSize) {
            int chunkPos = buffer.position();
            int chunkType = buffer.getInt();
            int chunkSize = buffer.getInt();
            if (chunkSize <= 0 || chunkPos + chunkSize > bytes.length) break;

            switch (chunkType) {
                case CHUNK_STRING_POOL:
                    parseStringPool(buffer, chunkPos, stringPool);
                    break;
                case CHUNK_START_TAG: {
                    buffer.getInt(); buffer.getInt(); buffer.getInt();
                    int nameIdx = buffer.getInt();
                    buffer.getShort(); buffer.getShort();
                    int attrCount = buffer.getShort() & 0xFFFF;
                    String tagName = getString(stringPool, nameIdx);
                    indent(xml, indentLevel);
                    xml.append("<").append(tagName);
                    buffer.position(chunkPos + 36);
                    for (int i = 0; i < attrCount; i++) {
                        buffer.getInt();
                        int attrNameIdx = buffer.getInt();
                        int attrRawValIdx = buffer.getInt();
                        buffer.getShort(); buffer.get();
                        int attrDataType = buffer.get() & 0xFF;
                        int attrData = buffer.getInt();
                        String attrName = getString(stringPool, attrNameIdx);
                        String attrVal = getString(stringPool, attrRawValIdx);
                        if (attrVal == null || attrVal.isEmpty()) attrVal = formatValue(attrDataType, attrData);
                        xml.append(" ").append(attrName).append("=\"").append(escapeXml(attrVal)).append("\"");
                    }
                    xml.append(">\n");
                    indentLevel++;
                    break;
                }
                case CHUNK_END_TAG: {
                    indentLevel = Math.max(0, indentLevel - 1);
                    buffer.getInt(); buffer.getInt(); buffer.getInt();
                    int nameIdx = buffer.getInt();
                    String tagName = getString(stringPool, nameIdx);
                    indent(xml, indentLevel);
                    xml.append("</").append(tagName).append(">\n");
                    break;
                }
            }
            buffer.position(chunkPos + chunkSize);
        }
        return xml.toString();
    }

    private static void parseStringPool(ByteBuffer buffer, int chunkPos, List<String> stringPool) {
        int stringCount = buffer.getInt();
        buffer.getInt();
        int flags = buffer.getInt();
        int stringsStart = buffer.getInt();
        buffer.getInt();
        boolean isUtf8 = (flags & (1 << 8)) != 0;
        int[] offsets = new int[stringCount];
        for (int i = 0; i < stringCount; i++) offsets[i] = buffer.getInt();
        int stringsBase = chunkPos + stringsStart;
        for (int i = 0; i < stringCount; i++) {
            buffer.position(stringsBase + offsets[i]);
            if (isUtf8) {
                decodeUtf8Len(buffer);
                int u8len = decodeUtf8Len(buffer);
                byte[] strBytes = new byte[u8len];
                buffer.get(strBytes);
                stringPool.add(new String(strBytes, StandardCharsets.UTF_8));
            } else {
                int len = buffer.getShort() & 0xFFFF;
                char[] chars = new char[len];
                for (int c = 0; c < len; c++) chars[c] = buffer.getChar();
                stringPool.add(new String(chars));
            }
        }
    }

    private static int decodeUtf8Len(ByteBuffer buffer) {
        int len = buffer.get() & 0xFF;
        if ((len & 0x80) != 0) len = ((len & 0x7F) << 8) | (buffer.get() & 0xFF);
        return len;
    }

    private static String getString(List<String> pool, int index) {
        return (index >= 0 && index < pool.size()) ? pool.get(index) : "";
    }

    private static String formatValue(int type, int data) {
        if (type == 18) return data != 0 ? "true" : "false";
        if (type == 1) return String.format("@0x%08x", data);
        if (type == 2) return String.format("?0x%08x", data);
        return String.valueOf(data);
    }

    private static void indent(StringBuilder sb, int level) {
        for (int i = 0; i < level; i++) sb.append("  ");
    }

    private static String escapeXml(String str) {
        return str == null ? "" : str.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
