package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Minimal animated GIF89a writer: one global 255-colour palette (median cut) + a transparent index,
 * LZW compression, infinite loop.
 */
public final class GifEncoder {

    private final OutputStream out;
    private final int width, height;
    private final int[] palette;       // 256 RGB entries, index 0 = transparent
    private final short[] lookup = new short[1 << 15];
    private final int background;      // -1 = transparent, else RGB to composite onto
    private boolean first = true;

    /**
     * @param sampleFrames frames used to build the palette
     * @param background   -1 for a transparent GIF, or 0xRRGGBB to composite onto a solid colour
     */
    public GifEncoder(OutputStream out, int width, int height, List<int[]> sampleFrames, int background) {
        this.out = out;
        this.width = width;
        this.height = height;
        this.background = background;
        this.palette = buildPalette(sampleFrames);
        Arrays.fill(lookup, (short) -1);
    }

    private int flatten(int argb) {
        int a = argb >>> 24;
        if (background < 0) return a < 128 ? -1 : (argb & 0xFFFFFF);
        int br = (background >> 16) & 255, bg = (background >> 8) & 255, bb = background & 255;
        int r = (((argb >> 16) & 255) * a + br * (255 - a)) / 255;
        int g = (((argb >> 8) & 255) * a + bg * (255 - a)) / 255;
        int b = ((argb & 255) * a + bb * (255 - a)) / 255;
        return (r << 16) | (g << 8) | b;
    }

    // ----------------------------------------------------------------- palette (median cut)
    private int[] buildPalette(List<int[]> frames) {
        int total = 0;
        for (int[] f : frames) total += f.length;
        int step = Math.max(1, total / 200_000);
        List<Integer> samples = new ArrayList<>();
        int k = 0;
        for (int[] f : frames) {
            for (int p : f) {
                if (k++ % step != 0) continue;
                int c = flatten(p);
                if (c >= 0) samples.add(c);
            }
        }
        int[] pal = new int[256];
        if (samples.isEmpty()) return pal;
        int[] arr = new int[samples.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = samples.get(i);
        List<int[]> boxes = new ArrayList<>();
        boxes.add(arr);
        while (boxes.size() < 255) {
            int bi = -1;
            int bestRange = -1;
            for (int i = 0; i < boxes.size(); i++) {
                int[] b = boxes.get(i);
                if (b.length < 2) continue;
                int r = range(b);
                if (r > bestRange) {
                    bestRange = r;
                    bi = i;
                }
            }
            if (bi < 0 || bestRange <= 0) break;
            int[] b = boxes.remove(bi);
            int ch = channel(b);
            Integer[] boxed = new Integer[b.length];
            for (int i = 0; i < b.length; i++) boxed[i] = b[i];
            final int shift = ch == 0 ? 16 : ch == 1 ? 8 : 0;
            Arrays.sort(boxed, (x, y) -> ((x >> shift) & 255) - ((y >> shift) & 255));
            int mid = b.length / 2;
            int[] l = new int[mid], r = new int[b.length - mid];
            for (int i = 0; i < mid; i++) l[i] = boxed[i];
            for (int i = mid; i < b.length; i++) r[i - mid] = boxed[i];
            boxes.add(l);
            boxes.add(r);
        }
        for (int i = 0; i < boxes.size() && i < 255; i++) {
            long r = 0, g = 0, bl = 0;
            int[] b = boxes.get(i);
            for (int c : b) {
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                bl += c & 255;
            }
            int n = Math.max(1, b.length);
            pal[i + 1] = (int) ((r / n) << 16 | (g / n) << 8 | (bl / n));
        }
        return pal;
    }

    private static int range(int[] b) {
        int[] mn = {255, 255, 255}, mx = {0, 0, 0};
        for (int c : b) {
            for (int ch = 0; ch < 3; ch++) {
                int v = (c >> (16 - 8 * ch)) & 255;
                if (v < mn[ch]) mn[ch] = v;
                if (v > mx[ch]) mx[ch] = v;
            }
        }
        return Math.max(mx[0] - mn[0], Math.max(mx[1] - mn[1], mx[2] - mn[2]));
    }

    private static int channel(int[] b) {
        int[] mn = {255, 255, 255}, mx = {0, 0, 0};
        for (int c : b) {
            for (int ch = 0; ch < 3; ch++) {
                int v = (c >> (16 - 8 * ch)) & 255;
                if (v < mn[ch]) mn[ch] = v;
                if (v > mx[ch]) mx[ch] = v;
            }
        }
        int best = 0;
        for (int ch = 1; ch < 3; ch++) if (mx[ch] - mn[ch] > mx[best] - mn[best]) best = ch;
        return best;
    }

    private int nearest(int rgb) {
        int key = ((rgb >> 9) & 0x7C00) | ((rgb >> 6) & 0x3E0) | ((rgb >> 3) & 0x1F);
        short cached = lookup[key];
        if (cached >= 0) return cached;
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        int best = 1;
        int bestD = Integer.MAX_VALUE;
        for (int i = 1; i < 256; i++) {
            int p = palette[i];
            int dr = ((p >> 16) & 255) - r, dg = ((p >> 8) & 255) - g, db = (p & 255) - b;
            int d = dr * dr * 2 + dg * dg * 4 + db * db * 3;
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        lookup[key] = (short) best;
        return best;
    }

    // ----------------------------------------------------------------- stream
    private void header() throws IOException {
        out.write("GIF89a".getBytes("US-ASCII"));
        short16(width);
        short16(height);
        out.write(0xF7); // global colour table, 8 bits, 256 entries
        out.write(0);    // background index
        out.write(0);    // aspect
        for (int i = 0; i < 256; i++) {
            int p = palette[i];
            out.write((p >> 16) & 255);
            out.write((p >> 8) & 255);
            out.write(p & 255);
        }
        // NETSCAPE2.0 loop forever
        out.write(new byte[]{0x21, (byte) 0xFF, 0x0B});
        out.write("NETSCAPE2.0".getBytes("US-ASCII"));
        out.write(new byte[]{3, 1, 0, 0, 0});
    }

    /** @param delayCs frame delay in 1/100 s */
    public void addFrame(int[] argb, int delayCs) throws IOException {
        if (first) {
            header();
            first = false;
        }
        boolean transparent = background < 0;
        // graphic control extension
        out.write(new byte[]{0x21, (byte) 0xF9, 4});
        out.write((transparent ? (2 << 2) | 1 : 0)); // disposal: restore to background
        short16(Math.max(2, delayCs));
        out.write(0); // transparent index
        out.write(0);
        // image descriptor
        out.write(0x2C);
        short16(0);
        short16(0);
        short16(width);
        short16(height);
        out.write(0);
        byte[] idx = new byte[width * height];
        for (int i = 0; i < idx.length; i++) {
            int c = flatten(argb[i]);
            idx[i] = (byte) (c < 0 ? 0 : nearest(c));
        }
        lzw(idx);
    }

    public void finish() throws IOException {
        if (first) header();
        out.write(0x3B);
        out.flush();
    }

    private void short16(int v) throws IOException {
        out.write(v & 255);
        out.write((v >> 8) & 255);
    }

    // ----------------------------------------------------------------- LZW
    private int bitBuf, bitCount;
    private final byte[] block = new byte[255];
    private int blockLen;

    private void lzw(byte[] data) throws IOException {
        final int minCode = 8;
        out.write(minCode);
        int clear = 1 << minCode, eoi = clear + 1;
        int codeSize = minCode + 1;
        int next = eoi + 1;
        int[] table = new int[1 << 20];
        Arrays.fill(table, -1);
        bitBuf = 0;
        bitCount = 0;
        blockLen = 0;
        emit(clear, codeSize);
        int prefix = data.length > 0 ? data[0] & 255 : 0;
        for (int i = 1; i < data.length; i++) {
            int c = data[i] & 255;
            int key = (prefix << 8) | c;
            int found = table[key];
            if (found >= 0) {
                prefix = found;
                continue;
            }
            emit(prefix, codeSize);
            if (next < 4096) {
                table[key] = next++;
                if (next > (1 << codeSize) && codeSize < 12) codeSize++;
            } else {
                emit(clear, codeSize);
                Arrays.fill(table, -1);
                codeSize = minCode + 1;
                next = eoi + 1;
            }
            prefix = c;
        }
        if (data.length > 0) emit(prefix, codeSize);
        emit(eoi, codeSize);
        if (bitCount > 0) pushByte(bitBuf & 255);
        flushBlock();
        out.write(0);
    }

    private void emit(int code, int size) throws IOException {
        bitBuf |= code << bitCount;
        bitCount += size;
        while (bitCount >= 8) {
            pushByte(bitBuf & 255);
            bitBuf >>>= 8;
            bitCount -= 8;
        }
    }

    private void pushByte(int b) throws IOException {
        block[blockLen++] = (byte) b;
        if (blockLen == 255) flushBlock();
    }

    private void flushBlock() throws IOException {
        if (blockLen == 0) return;
        out.write(blockLen);
        out.write(block, 0, blockLen);
        blockLen = 0;
    }
}
