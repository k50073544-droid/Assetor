package com.weker.assetexplorer;

import android.media.MediaPlayer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Plays the game's sounds by their sounds.csv name (a random one of the files, as the game does). */
public final class Sfx {

    private final GameData gd;
    private final List<MediaPlayer> playing = new ArrayList<>();
    private final Random rnd = new Random();
    /** a few at once at most; voice lines cut each other off */
    public int maxAtOnce = 4;

    public Sfx(GameData gd) {
        this.gd = gd;
    }

    /** returns the file that is played, or null when the sound isn't in the archive */
    public String play(String sound) {
        if (sound == null || sound.isEmpty()) return null;
        List<String> files = gd.db.soundFiles(sound);
        if (files.isEmpty()) files.add(sound.contains(".") ? sound : sound + ".ogg");
        String name = files.get(rnd.nextInt(files.size()));
        return playFile(name) ? name : null;
    }

    /** a sound file by name (sfx/xxx.ogg or xxx.ogg) */
    public boolean playFile(String name) {
        File f = gd.file(GameDbName.base(name));
        if (f == null || !f.exists()) return false;
        try {
            synchronized (playing) {
                while (playing.size() >= maxAtOnce) {
                    MediaPlayer old = playing.remove(0);
                    try {
                        old.release();
                    } catch (Throwable ignored) {
                        // already gone
                    }
                }
            }
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnCompletionListener(p -> {
                synchronized (playing) {
                    playing.remove(p);
                }
                p.release();
            });
            mp.prepare();
            mp.start();
            synchronized (playing) {
                playing.add(mp);
            }
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ short effect sounds (shots, hits)
    private android.media.SoundPool pool;
    private final java.util.Map<String, Integer> poolIds = new java.util.HashMap<>();
    private final java.util.Set<Integer> ready = new java.util.HashSet<>();
    private final java.util.Map<String, Long> lastPlayed = new java.util.HashMap<>();

    /**
     * A short sound by its sounds.csv name through a SoundPool (fast, many at once, no stutter);
     * the same sound is not repeated within 60 ms (five pellets hitting make one "hit").
     */
    public void effect(String sound) {
        if (sound == null || sound.isEmpty()) return;
        long now = System.currentTimeMillis();
        Long last = lastPlayed.get(sound);
        if (last != null && now - last < 60) return;
        lastPlayed.put(sound, now);
        if (pool == null) {
            pool = new android.media.SoundPool.Builder().setMaxStreams(12).build();
            pool.setOnLoadCompleteListener((sp, id, status) -> {
                if (status != 0) return;
                synchronized (ready) {
                    ready.add(id);
                }
                sp.play(id, 1, 1, 1, 0, 1);
            });
        }
        List<String> files = gd.db.soundFiles(sound);
        if (files.isEmpty()) return;
        String name = GameDbName.base(files.get(rnd.nextInt(files.size())));
        Integer id = poolIds.get(name);
        if (id == null) {
            File f = gd.file(name);
            if (f == null || !f.exists()) {
                poolIds.put(name, -1);
                return;
            }
            poolIds.put(name, pool.load(f.getAbsolutePath(), 1)); // plays when loaded
            return;
        }
        boolean ok;
        synchronized (ready) {
            ok = ready.contains(id);
        }
        if (id >= 0 && ok) pool.play(id, 1, 1, 1, 0, 1);
    }

    public void stopAll() {
        if (pool != null) {
            pool.release();
            pool = null;
            poolIds.clear();
            synchronized (ready) {
                ready.clear();
            }
        }
        synchronized (playing) {
            for (MediaPlayer p : playing) {
                try {
                    p.release();
                } catch (Throwable ignored) {
                    // gone
                }
            }
            playing.clear();
        }
    }

    /** file name without folders */
    static final class GameDbName {
        static String base(String p) {
            int i = p.lastIndexOf('/');
            return i < 0 ? p : p.substring(i + 1);
        }
    }
}
