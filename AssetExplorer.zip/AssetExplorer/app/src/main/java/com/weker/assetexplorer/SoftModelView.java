package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Render3d;

/**
 * Shows a {@link Model3d}: one finger rotates, two fingers zoom and move, double tap resets.
 * Rendering runs on a background thread; while the finger moves a smaller, faster picture is drawn,
 * then a sharp one when it stops.
 */
public final class SoftModelView extends View implements ModelDisplay {

    public final Render3d render = new Render3d();
    private Model3d model;
    private Img texture;
    private java.util.Map<String, Img> images;
    // animation
    private com.weker.assetexplorer.codec.Anim3d anim;
    private int animStart, animEnd;
    private volatile boolean playing;
    public volatile float speed = 1f;
    private long playBase;
    private double pausedFrame;
    /** called on the UI thread with the current frame number while playing */
    public java.util.function.IntConsumer onFrame;
    private Bitmap frame;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Object lock = new Object();
    private boolean dirty, fast, running = true;
    private Thread worker;
    private final ScaleGestureDetector scale;
    private float lastX, lastY, downX, downY;
    private long lastTap;
    private boolean moved;

    public SoftModelView(Context c) {
        super(c);
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                render.zoom = Math.max(0.3f, Math.min(12f, render.zoom * d.getScaleFactor()));
                request(true);
                return true;
            }
        });
        worker = new Thread(this::loop, "model-render");
        worker.start();
    }

    /** @param images material textures by name; tex overrides them when not null */
    public void setModel(Model3d m, java.util.Map<String, Img> images, Img tex) {
        synchronized (lock) {
            model = m;
            this.images = images;
            texture = tex;
        }
        request(false);
    }

    /**
     * Plays an animation (null = bind pose). start/end are frames from animations.csv (end -1 = last frame).
     */
    public void setAnimation(com.weker.assetexplorer.codec.Anim3d a, int start, int end) {
        synchronized (lock) {
            anim = a;
            if (a != null) {
                animStart = Math.max(0, Math.min(start, a.frames - 1));
                animEnd = end < 0 || end >= a.frames ? a.frames - 1 : Math.max(animStart, end);
            }
            pausedFrame = animStart;
            playBase = System.currentTimeMillis();
            playing = a != null;
            render.frameBounds = a != null && model != null ? model.animationBounds(a, animStart, animEnd) : null;
        }
        request(false);
    }

    public boolean isPlaying() { return playing; }

    public void setPlaying(boolean p) {
        synchronized (lock) {
            if (anim == null) return;
            if (p && !playing) {
                double len = Math.max(1, animEnd - animStart);
                playBase = System.currentTimeMillis() - (long) ((pausedFrame - animStart) / (anim.fps * speed) * 1000);
                if (pausedFrame - animStart >= len) playBase = System.currentTimeMillis();
            } else if (!p && playing) {
                pausedFrame = currentFrame();
            }
            playing = p;
        }
        request(false);
    }

    public void setSpeed(float s) {
        synchronized (lock) {
            double f = currentFrame();
            speed = s;
            if (anim != null) playBase = System.currentTimeMillis() - (long) ((f - animStart) / (anim.fps * speed) * 1000);
        }
    }

    /** fractional frame shown now */
    public double currentFrame() {
        com.weker.assetexplorer.codec.Anim3d a = anim;
        if (a == null) return 0;
        if (!playing) return pausedFrame;
        double len = Math.max(1, animEnd - animStart);
        double f = (System.currentTimeMillis() - playBase) / 1000.0 * a.fps * speed;
        return animStart + (f % len);
    }

    /** the model in the pose currently shown (bind pose without animation) */
    public Model3d posedModel() {
        Model3d m = model;
        com.weker.assetexplorer.codec.Anim3d a = anim;
        if (m == null || a == null) return m;
        return m.pose(a, currentFrame());
    }

    @Override
    public Render3d settings() { return render; }

    @Override
    public float speed() { return speed; }

    @Override
    public android.view.View view() { return this; }

    public void setTexture(Img tex) {
        synchronized (lock) {
            texture = tex;
        }
        request(false);
    }

    public void resetView() {
        render.yaw = 0.5f;
        render.pitch = 0.2f;
        render.zoom = 1f;
        render.panX = render.panY = 0;
        request(false);
    }

    /** redraw; fast = low resolution while the finger is moving */
    public void request(boolean fast) {
        synchronized (lock) {
            dirty = true;
            this.fast = fast;
            lock.notifyAll();
        }
    }

    private void loop() {
        while (true) {
            Model3d m;
            Img tex;
            java.util.Map<String, Img> imgs;
            boolean f;
            boolean play;
            int w, h;
            synchronized (lock) {
                while (running && ((!dirty && !playing) || model == null || getWidth() == 0)) {
                    try {
                        lock.wait(200);
                    } catch (InterruptedException e) {
                        return;
                    }
                }
                if (!running) return;
                dirty = false;
                m = model;
                tex = texture;
                imgs = images;
                f = fast;
                play = playing;
                w = getWidth();
                h = getHeight();
            }
            // fast: about 1/3 of the screen pixels; final: full size with light smoothing
            // while an animation plays: medium size, one sample per pixel, as fast as the phone can
            float k = f ? 0.4f : play ? Math.min(0.6f, 560f / Math.max(w, h)) : Math.min(1f, 900f / Math.max(w, h));
            int rw = Math.max(1, (int) (w * k)), rh = Math.max(1, (int) (h * k));
            try {
                Model3d drawn = m;
                int shownFrame = -1;
                com.weker.assetexplorer.codec.Anim3d a = anim;
                if (a != null) {
                    double fr = currentFrame();
                    drawn = m.pose(a, fr);
                    shownFrame = (int) fr;
                }
                Img im = render.render(drawn, imgs, tex, rw, rh, f || play ? 1 : 2);
                int sf = shownFrame;
                if (sf >= 0 && onFrame != null) main.post(() -> onFrame.accept(sf));
                Bitmap b = Bitmap.createBitmap(im.argb, im.width, im.height, Bitmap.Config.ARGB_8888);
                main.post(() -> {
                    frame = b;
                    invalidate();
                });
            } catch (Throwable ignored) {
                // keep the last picture
            }
            if (play) {
                // next frame right away; when playback stops a sharp frame is drawn
                synchronized (lock) {
                    if (!playing) dirty = true;
                }
                continue;
            }
            if (f) {
                synchronized (lock) {
                    // no new movement for a moment: draw the sharp version
                    if (!dirty) {
                        try {
                            lock.wait(150);
                        } catch (InterruptedException e) {
                            return;
                        }
                        if (!dirty) {
                            dirty = true;
                            fast = false;
                        }
                    }
                }
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        request(false);
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(render.background);
        if (frame != null) c.drawBitmap(frame, null, new Rect(0, 0, getWidth(), getHeight()), paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        getParent().requestDisallowInterceptTouchEvent(true);
        scale.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = downX = e.getX();
                lastY = downY = e.getY();
                moved = false;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_POINTER_UP:
                lastX = avgX(e);
                lastY = avgY(e);
                moved = true;
                break;
            case MotionEvent.ACTION_MOVE: {
                float x = avgX(e), y = avgY(e);
                float dx = x - lastX, dy = y - lastY;
                lastX = x;
                lastY = y;
                if (Math.abs(e.getX() - downX) + Math.abs(e.getY() - downY) > 12) moved = true;
                if (e.getPointerCount() >= 2) {
                    render.panX += dx / Math.max(1, getWidth());
                    render.panY += dy / Math.max(1, getHeight());
                } else if (!scale.isInProgress()) {
                    float s = (float) (Math.PI / Math.max(1, getWidth()));
                    render.yaw += dx * s;
                    render.pitch = Math.max(-1.5f, Math.min(1.5f, render.pitch + dy * s));
                }
                request(true);
                break;
            }
            case MotionEvent.ACTION_UP: {
                long now = System.currentTimeMillis();
                if (!moved) {
                    if (now - lastTap < 300) resetView();
                    lastTap = now;
                }
                request(false);
                break;
            }
            default:
                break;
        }
        return true;
    }

    static float avgX(MotionEvent e) {
        float s = 0;
        int n = e.getPointerCount();
        for (int i = 0; i < n; i++) s += e.getX(i);
        return s / n;
    }

    static float avgY(MotionEvent e) {
        float s = 0;
        int n = e.getPointerCount();
        for (int i = 0; i < n; i++) s += e.getY(i);
        return s / n;
    }

    /** stops the render thread */
    public void release() {
        synchronized (lock) {
            running = false;
            lock.notifyAll();
        }
        worker.interrupt();
    }
}
