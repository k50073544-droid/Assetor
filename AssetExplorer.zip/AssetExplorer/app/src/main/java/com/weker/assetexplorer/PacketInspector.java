package com.weker.assetexplorer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PacketInspector {
    private static final List<String> interceptedPackets = Collections.synchronizedList(new ArrayList<>());

    public static void captureServerPacket(String packetData) {
        synchronized (interceptedPackets) {
            if (interceptedPackets.size() >= 5000) {
                interceptedPackets.remove(0);
            }
            interceptedPackets.add("[SERVER -> CLIENT] " + System.currentTimeMillis() + ":\n" + packetData);
        }
    }

    public static List<String> getInterceptedPackets() {
        synchronized (interceptedPackets) {
            return new ArrayList<>(interceptedPackets);
        }
    }
}
