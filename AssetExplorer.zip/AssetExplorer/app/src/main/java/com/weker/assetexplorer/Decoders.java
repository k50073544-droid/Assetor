package com.weker.assetexplorer;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.SupercellFiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Android glue: turns stored files into bitmaps / text. */
public final class Decoders {

    private Decoders() {}

    public static final long MAX_DECODE = 96L << 20;

    public static boolean isPreviewableImage(Db.Row r) {
        return Categorizer.T_IMG.equals(r.type) || Categorizer.T_TEX.equals(r.type) || Categorizer.T_SC.equals(r.type);
    }

    public static boolean isAudio(Db.Row r) {
        return Categorizer.T_SFX.equals(r.type) || Categorizer.T_MUSIC.equals(r.type);
    }

    public static boolean isText(Db.Row r) {
        return Categorizer.T_CSV.equals(r.type) || Categorizer.T_DATA.equals(r.type) || Categorizer.T_SHADER.equals(r.type);
    }

    public static boolean isVideo(Db.Row r) { return Categorizer.T_VIDEO.equals(r.type); }

    public static boolean isFont(Db.Row r) { return Categorizer.T_FONT.equals(r.type); }

    /** Decompressed bytes (Supercell csv etc. are LZMA/Zstd packed). */
    public static byte[] content(File f) throws IOException {
        byte[] data = readAll(f);
        try {
            data = SupercellFiles.unwrap(data).data;
        } catch (IOException ignored) {
            // plain file
        }
        return data;
    }

    /** True when the start of the data looks like readable text. */
    public static boolean looksText(byte[] d) {
        int n = Math.min(d.length, 4096);
        if (n == 0) return true;
        int bad = 0;
        for (int i = 0; i < n; i++) {
            int b = d[i] & 0xFF;
            if (b == 0) return false;
            if (b < 9 || (b > 13 && b < 32)) bad++;
        }
        return bad * 20 < n;
    }

    /** Pretty-printed JSON, or the raw text if it does not parse. */
    public static String prettyJson(String s) {
        try {
            String t = s.trim();
            if (t.startsWith("[")) return new org.json.JSONArray(t).toString(2);
            return new org.json.JSONObject(t).toString(2);
        } catch (Exception e) {
            return s;
        }
    }

    public static String hexDump(byte[] d, int max) {
        StringBuilder sb = new StringBuilder();
        int n = Math.min(d.length, max);
        for (int i = 0; i < n; i += 16) {
            sb.append(String.format(java.util.Locale.ROOT, "%08X  ", i));
            StringBuilder asc = new StringBuilder();
            for (int j = 0; j < 16; j++) {
                if (i + j < n) {
                    int b = d[i + j] & 0xFF;
                    sb.append(String.format(java.util.Locale.ROOT, "%02X ", b));
                    asc.append(b >= 32 && b < 127 ? (char) b : '.');
                } else {
                    sb.append("   ");
                }
            }
            sb.append(' ').append(asc).append('\n');
        }
        if (d.length > n) sb.append("…(показано ").append(n).append(" из ").append(d.length).append(" байт)");
        return sb.toString();
    }

    /** Minimal CSV parser with quotes. */
    public static List<String[]> parseCsv(String text, int maxRows) {
        List<String[]> rows = new ArrayList<>();
        List<String> cur = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length() && rows.size() < maxRows; i++) {
            char c = text.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        cell.append('"');
                        i++;
                    } else {
                        q = false;
                    }
                } else {
                    cell.append(c);
                }
            } else if (c == '"') {
                q = true;
            } else if (c == ',') {
                cur.add(cell.toString());
                cell.setLength(0);
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                cur.add(cell.toString());
                cell.setLength(0);
                rows.add(cur.toArray(new String[0]));
                cur.clear();
            } else {
                cell.append(c);
            }
        }
        if (cell.length() > 0 || !cur.isEmpty()) {
            cur.add(cell.toString());
            rows.add(cur.toArray(new String[0]));
        }
        return rows;
    }

    public static byte[] readAll(File f) throws IOException {
        long len = f.length();
        if (len > MAX_DECODE) throw new IOException("Файл слишком большой для просмотра");
        byte[] b = new byte[(int) len];
        try (InputStream in = new FileInputStream(f)) {
            int p = 0;
            while (p < b.length) {
                int n = in.read(b, p, b.length - p);
                if (n < 0) break;
                p += n;
            }
        }
        return b;
    }

    public static Bitmap toBitmap(Img im) {
        return Bitmap.createBitmap(im.argb, im.width, im.height, Bitmap.Config.ARGB_8888);
    }

    public static final class Decoded {
        public final List<Bitmap> images = new ArrayList<>();
        public final List<String> info = new ArrayList<>();
        public final List<String> externalRefs = new ArrayList<>();
        public final List<String> exportNames = new ArrayList<>();
        public com.weker.assetexplorer.codec.Sc2 sc2;
    }

    /** Decodes all images in the file (several for atlases). */
    public static Decoded decodeImages(File f, Db.Row r) throws IOException {
        Decoded d = new Decoded();
        if (Categorizer.T_IMG.equals(r.type)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            int sample = 1;
            while (o.outWidth / sample > 4096 || o.outHeight / sample > 4096) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeFile(f.getPath(), o2);
            if (b == null) throw new IOException("Не удалось открыть картинку");
            d.images.add(b);
            d.info.add(o.outWidth + "x" + o.outHeight);
            return d;
        }
        byte[] data = readAll(f);
        SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(data, r.name);
        for (Img im : ts.images) d.images.add(toBitmap(im));
        d.info.addAll(ts.info);
        d.externalRefs.addAll(ts.externalRefs);
        d.exportNames.addAll(ts.exportNames);
        d.sc2 = ts.sc2;
        return d;
    }

    public static Bitmap thumbnail(File f, Db.Row r, int size) {
        try {
            Bitmap full;
            if (Categorizer.T_IMG.equals(r.type)) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(f.getPath(), o);
                int sample = 1;
                while (o.outWidth / (sample * 2) >= size && o.outHeight / (sample * 2) >= size) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                full = BitmapFactory.decodeFile(f.getPath(), o2);
            } else {
                if (f.length() > 48L << 20) return null;
                SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(readAll(f), r.name);
                if (ts.images.isEmpty()) return null;
                full = toBitmap(ts.images.get(0));
            }
            if (full == null) return null;
            float s = Math.min(1f, (float) size / Math.max(full.getWidth(), full.getHeight()));
            if (s < 1f) {
                Bitmap sc = Bitmap.createScaledBitmap(full, Math.max(1, Math.round(full.getWidth() * s)),
                        Math.max(1, Math.round(full.getHeight() * s)), true);
                if (sc != full) full.recycle();
                return sc;
            }
            return full;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Text preview (decompresses Supercell csv). */
    public static String text(File f, int maxChars) throws IOException {
        byte[] data = readAll(f);
        try {
            data = SupercellFiles.unwrap(data).data;
        } catch (IOException ignored) {
            // plain text
        }
        if (com.weker.assetexplorer.codec.AxmlDecoder.isAxml(data)) {
            return com.weker.assetexplorer.codec.AxmlDecoder.decode(data);
        }
        String s = new String(data, 0, Math.min(data.length, maxChars * 2), StandardCharsets.UTF_8);
        if (s.length() > maxChars) s = s.substring(0, maxChars) + "\n…(обрезано)";
        return s;
    }

    /** Short description of a 3D file (glTF chunk list / json names). */
    public static String describe3d(File f) {
        try {
            byte[] d = readAll(f);
            StringBuilder sb = new StringBuilder();
            if (d.length >= 12 && d[0] == 'g' && d[1] == 'l' && d[2] == 'T' && d[3] == 'F') {
                sb.append("Контейнер glTF (GLB)\n");
                int p = 12;
                boolean flat = false;
                while (p + 8 <= d.length) {
                    int len = (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
                    String type = new String(d, p + 4, 4, StandardCharsets.ISO_8859_1);
                    sb.append("• блок ").append(type.trim()).append(": ").append(len).append(" байт\n");
                    if (type.startsWith("FLA")) flat = true;
                    if (type.equals("JSON") && len > 0 && p + 8 + len <= d.length) {
                        String js = new String(d, p + 8, Math.min(len, 4000), StandardCharsets.UTF_8);
                        sb.append(js.length() >= 4000 ? js + "…\n" : js + "\n");
                    }
                    if (len < 0) break;
                    p += 8 + len;
                }
                if (flat) {
                    sb.append("\nЭто «сжатый» glTF Supercell (flatbuffer + Odin). Обычный Blender его не откроет — ")
                            .append("в 3D-просмотре есть «Сохранить → .glb для Blender».");
                }
            } else if (d.length >= 4 && d[0] == 'S' && d[1] == 'C' && d[2] == '3' && d[3] == 'D') {
                sb.append("Модель SC3D (.scw, старый формат Supercell). Открывается конвертерами scw → dae.");
            } else {
                sb.append("3D файл, ").append(d.length).append(" байт");
            }
            List<String> refs = new ArrayList<>();
            for (String ext : new String[]{".sctx", ".ktx", ".png"}) {
                int i = 0;
                byte[] e = ext.getBytes(StandardCharsets.US_ASCII);
                while ((i = SupercellFiles.indexOf(d, e, i)) >= 0 && refs.size() < 30) {
                    int s = i;
                    while (s > 0 && isName(d[s - 1])) s--;
                    String n = new String(d, s, i + e.length - s, StandardCharsets.UTF_8);
                    if (n.length() > ext.length() && !refs.contains(n)) refs.add(n);
                    i += e.length;
                }
            }
            if (!refs.isEmpty()) {
                sb.append("\n\nТекстуры, на которые ссылается модель:\n");
                for (String r : refs) sb.append("• ").append(r).append('\n');
            }
            return sb.toString();
        } catch (IOException e) {
            return "Не удалось прочитать: " + e.getMessage();
        }
    }

    static boolean isName(byte b) {
        return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '_' || b == '-' || b == '/';
    }
}
