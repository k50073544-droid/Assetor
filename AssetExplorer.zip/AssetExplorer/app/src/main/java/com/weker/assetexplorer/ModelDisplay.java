package com.weker.assetexplorer;

import com.weker.assetexplorer.codec.Anim3d;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Render3d;

/** A view that shows a 3D model: {@link GlModelView} (GPU) or {@link SoftModelView} (CPU fallback). */
public interface ModelDisplay {

    /** camera and drawing settings (yaw, zoom, lighting, background…) shared with the PNG export */
    Render3d settings();

    /** @param images material textures by name; tex overrides them when not null */
    void setModel(Model3d m, java.util.Map<String, Img> images, Img tex);

    /** plays an animation (null = bind pose); end -1 = last frame */
    void setAnimation(Anim3d a, int start, int end);

    boolean isPlaying();

    void setPlaying(boolean p);

    float speed();

    void setSpeed(float s);

    double currentFrame();

    /** the model in the pose currently shown */
    Model3d posedModel();

    void resetView();

    /** redraw after a settings change */
    void request(boolean fast);

    void release();

    android.view.View view();
}
