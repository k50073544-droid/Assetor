package com.weker.assetexplorer;

import android.app.Activity;
import android.graphics.Bitmap;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.weker.assetexplorer.codec.BoxShow;
import com.weker.assetexplorer.codec.BoxSim;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Scene3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Opens a box or a Starr Drop like the game: the 3D drop with its own animation, upgrades with the game's odds,
 * then the reward. Only a simulation — nothing is sent anywhere.
 */
public final class BoxActivity extends Activity implements GLSurfaceView.Renderer {

    private final Handler main = new Handler(Looper.getMainLooper());
    private GameData gd;
    private Sfx sfx;
    private BoxSim sim;
    private String what;
    private GameDb.Container container;
    private final Object lock = new Object();
    private BoxShow show;
    private List<BoxSim.Reward> pending = new ArrayList<>();
    private long last;
    private final GlScene glScene = new GlScene();
    private GLSurfaceView gl;
    private TextView hint, title, stats;
    private LinearLayout rewards;
    private int opened;
    private final Map<String, Integer> tally = new TreeMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF141B33);
        getWindow().setNavigationBarColor(Ui.BG);
        gd = GameData.get(this, getIntent().getLongExtra("vid", -1));
        sfx = new Sfx(gd);
        sim = new BoxSim(gd.db, System.nanoTime());
        what = getIntent().getStringExtra("what");
        if (what == null) what = "starr:";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        FrameLayout stage = new FrameLayout(this);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(new GlModelView.Chooser());
        gl.setRenderer(this);
        stage.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        title = Ui.bold(this, "", 20, Ui.TEXT);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(this, 14), 0, 0);
        stage.addView(title, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        hint = Ui.bold(this, "", 15, Ui.TEXT);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 0, 0, Ui.dp(this, 14));
        stage.addView(hint, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        View tapper = new View(this);
        tapper.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) tap();
            return true;
        });
        stage.addView(tapper, new FrameLayout.LayoutParams(-1, -1));
        root.addView(stage, Ui.lp(-1, 0, 1.15f));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 12);
        panel.setPadding(p, p, p, p);
        stats = Ui.text(this, "", 12, Ui.MUTED);
        panel.addView(stats);
        ScrollView sv = new ScrollView(this);
        rewards = new LinearLayout(this);
        rewards.setOrientation(LinearLayout.VERTICAL);
        sv.addView(rewards);
        panel.addView(sv, Ui.lp(-1, 0, 1));
        LinearLayout btns = new LinearLayout(this);
        TextView again = Ui.button(this, "Ещё один", true);
        again.setOnClickListener(v -> next());
        btns.addView(again, Ui.lp(0, -2, 1));
        TextView ten = Ui.button(this, "Открыть 100 сразу", false);
        ten.setOnClickListener(v -> hundred());
        LinearLayout.LayoutParams tl = Ui.lp(0, -2, 1);
        tl.leftMargin = Ui.dp(this, 8);
        btns.addView(ten, tl);
        panel.addView(btns);
        root.addView(panel, Ui.lp(-1, 0, 1));
        setContentView(root);
        next();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
        sfx.stopAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
        last = 0;
    }

    private boolean starr() {
        return what.startsWith("starr:");
    }

    /** a new drop: roll it now (the game decides at once too), then let the player tap through */
    private void next() {
        hint.setText("Загрузка…");
        new Thread(() -> {
            try {
                BoxShow s;
                List<BoxSim.Reward> rw = new ArrayList<>();
                if (starr()) {
                    BoxSim.StarrResult r = sim.openStarr(what.substring(6));
                    if (r.fin == null) throw new IllegalStateException("в таблицах нет Старр-дропов");
                    rw.add(r.reward);
                    s = new BoxShow(gd.assets, r.steps.get(0), r.steps);
                } else {
                    String name = what.substring(4);
                    container = null;
                    for (GameDb.Container c : gd.db.containers()) if (c.name.equals(name)) container = c;
                    if (container == null) throw new IllegalStateException("нет контейнера " + name);
                    rw.addAll(sim.open(container));
                    s = new BoxShow(gd.assets, container, null);
                }
                synchronized (lock) {
                    show = s;
                    pending = rw;
                }
                main.post(this::updateLabels);
            } catch (Throwable e) {
                main.post(() -> hint.setText("Не получилось: " + e.getMessage()));
            }
        }).start();
    }

    private void tap() {
        BoxShow s;
        synchronized (lock) {
            s = show;
            if (s == null) return;
            if (s.state == BoxShow.State.DONE) {
                main.post(this::next);
                return;
            }
            if (!s.hasModel()) { // drops without a 3D model: open at once
                s.state = BoxShow.State.DONE;
                s.events.add("open");
                s.events.add("reward");
            } else {
                s.tap();
            }
        }
        updateLabels();
    }

    private void updateLabels() {
        BoxShow s = show;
        if (s == null) return;
        GameDb.Container c = s.current();
        String name = starr() ? (what.endsWith("Splitting") ? "Хаос-дроп" : "Старр-дроп") + " · " + c.title : c.title;
        title.setText(name);
        title.setTextColor(starr() ? GameDb.rarityColor(String.valueOf(Math.min(5, c.rarity))) : Ui.TEXT);
        switch (s.state) {
            case DONE: hint.setText("Нажми — следующий"); break;
            case OPEN: hint.setText("Открывается…"); break;
            default:
                hint.setText(s.hasModel() ? "Нажимай на дроп" + (starr() ? " — может улучшиться!" : "") : "Нажми, чтобы открыть (у этого дропа нет 3D-модели)");
                break;
        }
        stats.setText(String.format(Locale.ROOT, "Открыто: %d%s", opened, tally.isEmpty() ? "" : " · " + tally.toString().replaceAll("[{}]", "")));
    }

    // ------------------------------------------------------------------ GL
    @Override
    public void onSurfaceCreated(GL10 g, EGLConfig c) {
        try {
            glScene.init();
        } catch (RuntimeException e) {
            main.post(() -> hint.setText("OpenGL ES 2.0 недоступен"));
        }
    }

    @Override
    public void onSurfaceChanged(GL10 g, int w, int h) {
        glScene.resize(w, h);
    }

    @Override
    public void onDrawFrame(GL10 g) {
        Scene3d sc;
        List<String> ev = new ArrayList<>();
        BoxShow s;
        synchronized (lock) {
            s = show;
            if (s == null) {
                glScene.draw(new Scene3d());
                return;
            }
            long now = System.nanoTime();
            double dt = last == 0 ? 0 : (now - last) / 1e9;
            last = now;
            s.advance(Math.min(0.1, dt));
            ev.addAll(s.events);
            s.events.clear();
            sc = s.scene();
        }
        try {
            glScene.draw(sc);
        } catch (RuntimeException ignored) {
            // skip the frame
        }
        if (!ev.isEmpty()) main.post(() -> events(s, ev));
    }

    private void events(BoxShow s, List<String> ev) {
        for (String e : ev) {
            if (e.equals("upgrade")) sfx.play(s.box.soundUpgrade);
            else if (e.equals("open")) sfx.play(s.box.soundOpen);
            else if (e.equals("reward")) {
                List<BoxSim.Reward> rw;
                synchronized (lock) {
                    rw = pending;
                    pending = new ArrayList<>();
                }
                opened++;
                String key = starr() ? s.last().title : s.box.title;
                tally.merge(key, 1, Integer::sum);
                rewards.removeAllViews();
                for (BoxSim.Reward r : rw) rewards.addView(card(r));
            }
        }
        updateLabels();
    }

    private View card(BoxSim.Reward r) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 8);
        row.setPadding(p, p, p, p);
        row.setBackground(Ui.round(HubActivity.dim(r.color), Ui.dp(this, 12)));
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int s = Ui.dp(this, 64);
        row.addView(iv, new LinearLayout.LayoutParams(s, s));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(Ui.dp(this, 10), 0, 0, 0);
        tx.addView(Ui.bold(this, r.title, 16, Ui.TEXT));
        if (r.subtitle != null && !r.subtitle.isEmpty() && !r.subtitle.equals(r.title)) tx.addView(Ui.text(this, r.subtitle, 12, 0xFFD6DAE6));
        if (r.skin != null) tx.addView(Ui.text(this, "Нажми, чтобы посмотреть в 3D", 11, Ui.ACCENT));
        else if (r.sound != null && !r.sound.isEmpty()) tx.addView(Ui.text(this, "Нажми — звук пина", 11, Ui.ACCENT));
        row.addView(tx, Ui.lp(0, -2, 1));
        row.setOnClickListener(v -> {
            if (r.skin != null && r.brawler != null) HubActivity.openSkin(this, gd, r.brawler, r.skin);
            else if (r.sound != null) sfx.play(r.sound);
        });
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2, 0);
        lp.bottomMargin = Ui.dp(this, 6);
        row.setLayoutParams(lp);
        new Thread(() -> {
            Bitmap bm = null;
            if (r.iconFile != null) bm = gd.export(r.iconFile, r.iconExport, 192);
            if (bm == null && r.skin != null && r.skin.iconFile != null && !r.skin.iconFile.isEmpty()) bm = gd.export(r.skin.iconFile, r.skin.iconExport, 192);
            if (bm == null && r.brawler != null) bm = gd.export(r.brawler.portraitFile, r.brawler.portraitExport, 192);
            Bitmap fb = bm;
            main.post(() -> {
                if (fb != null) iv.setImageBitmap(fb);
            });
        }).start();
        return row;
    }

    /** opens a hundred without animation and shows what came out, to see the odds */
    private void hundred() {
        hint.setText("Считаю 100 открытий…");
        new Thread(() -> {
            Map<String, Integer> types = new TreeMap<>(), rar = new TreeMap<>();
            for (int i = 0; i < 100; i++) {
                List<BoxSim.Reward> rw = new ArrayList<>();
                if (starr()) {
                    BoxSim.StarrResult r = sim.openStarr(what.substring(6));
                    if (r.fin == null) break;
                    rar.merge(r.fin.title, 1, Integer::sum);
                    rw.add(r.reward);
                } else if (container != null) {
                    rw.addAll(sim.open(container));
                }
                for (BoxSim.Reward w : rw) types.merge(w.subtitle == null || w.subtitle.isEmpty() ? w.type : w.type.equals("Skin") ? "Скин" : w.subtitle.split(" · ")[0], 1, Integer::sum);
            }
            main.post(() -> {
                rewards.removeAllViews();
                StringBuilder sb = new StringBuilder("100 открытий:\n");
                if (!rar.isEmpty()) {
                    sb.append("\nРедкость:\n");
                    for (Map.Entry<String, Integer> e : rar.entrySet()) sb.append("  ").append(e.getKey()).append(" — ").append(e.getValue()).append('\n');
                }
                sb.append("\nНаграды:\n");
                for (Map.Entry<String, Integer> e : types.entrySet()) sb.append("  ").append(e.getKey()).append(" — ").append(e.getValue()).append('\n');
                rewards.addView(Ui.text(this, sb.toString(), 13, Ui.TEXT));
                updateLabels();
            });
        }).start();
    }
}
