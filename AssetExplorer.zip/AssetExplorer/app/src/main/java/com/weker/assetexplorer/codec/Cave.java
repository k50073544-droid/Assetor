package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Rules of the training cave: the "Training" map from maps.csv, the training dummies from characters.csv,
 * and the chosen brawler's attack and super from skills.csv / projectiles. Positions are in tiles
 * (1 tile = 300 game units), x to the right, z down the map (row number). No drawing here.
 */
public final class Cave {

    public static final float UNIT = 300f;

    /** an attack or super as the tables describe it, in tiles and seconds */
    public static final class Weapon {
        public String skill = "", projectile = "";
        public int damage = 500, bullets = 1, maxCharge = 3;
        public float spread, range = 6, speed = 10, radius = 0.15f;
        public float reload = 1.5f, between = 0.1f, cooldown = 0.25f;
        public boolean pierceChars, pierceEnv, melee;
    }

    public static final class Unit {
        public String kind, code;
        public float x, z, radius = 0.4f;
        public float hp, maxHp;
        /** facing, radians: 0 = towards +z (down the map, to the camera) */
        public float face;
        public boolean alive = true, moving, inBush;
        public float deadFor, flash, spawnX, spawnZ;
        public float lastHurt = -99, lastAttack = -99;
        public float cooldown;
        /** what the model plays: idle, walk, attack, ulti */
        public String action = "idle";
        public float actionStart;
        /** model scale from characters.csv (100 = normal) */
        public int scale = 100;
    }

    public static final class Shot {
        public float x, z, dx, dz, speed, left, radius, age;
        public int damage;
        public boolean enemy, ulti, pierceChars, pierceEnv, dead;
        final List<Unit> hit = new ArrayList<>();
    }

    public static final class Popup {
        public float x, z, age;
        public String text;
        public int color;
    }

    static final class Burst {
        float at, angle;
        Weapon w;
        boolean ulti;
    }

    public final int width, height;
    public final char[][] cells;
    final boolean[] moveBlock = new boolean[128], shotBlock = new boolean[128], destructible = new boolean[128], bush = new boolean[128];

    public final Unit player = new Unit();
    public final List<Unit> dummies = new ArrayList<>();
    public final List<Shot> shots = new ArrayList<>();
    public final List<Popup> popups = new ArrayList<>();
    /** things that happened this step, for sounds and effects: attack, ulti, hit, kill, wall, hurt, dead, respawn, empty */
    public final List<String> events = new ArrayList<>();
    final List<Burst> bursts = new ArrayList<>();

    public Weapon weapon = new Weapon(), ulti = new Weapon();
    public float speed = 2.4f, ammo = 3, superCharge, ultiChargeMul = 100, respawnTime = 5;
    public float time;
    public String brawlerCode, brawlerName;
    public int shooterDamage = 500;
    public float shooterRange = 6.67f, shooterEvery = 1.4f;
    public Weapon shooterShot = new Weapon();
    public int damageDealt, kills;

    /** the map as rows of tile codes; cave layout of the game when {@code db} has it */
    public Cave(GameDb db, String brawler) {
        GameDb.MapData m = db == null ? null : db.map("Training");
        if (m == null) m = fallbackMap();
        width = m.width;
        height = m.height;
        cells = m.cells;
        tileFlags(db);
        loadBrawler(db, brawler);
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                char ch = cells[r][c];
                String code = null;
                switch (ch) {
                    case '1': player.x = player.spawnX = c + 0.5f; player.z = player.spawnZ = r + 0.5f; cells[r][c] = '.'; break;
                    case '2': code = "TrainingDummySmall"; break;
                    case '0': code = "TrainingDummyMedium"; break;
                    case '3': code = "TrainingDummyBig"; break;
                    case '4': code = "TrainingDummyShooting"; break;
                    default: break;
                }
                if (code != null) {
                    cells[r][c] = '.';
                    Unit u = dummy(db, code);
                    u.x = u.spawnX = c + 0.5f;
                    u.z = u.spawnZ = r + 0.5f;
                    u.face = 0;
                    dummies.add(u);
                }
            }
        }
        if (player.spawnX == 0) {
            player.x = player.spawnX = width / 2f;
            player.z = player.spawnZ = height - 4.5f;
        }
        player.face = (float) Math.PI; // looks up the map, at the dummies
    }

    static GameDb.MapData fallbackMap() {
        String[] rows = {".................", "....2.2.2.2.2....", ".................", "....2.2.2.2.2....", ".................",
                ".................", "MMMMMMM...IIIIIII", "............I..4.", "..3.........I....", ".................",
                ".................", "..0...........0..", ".................", "........1........", "................."};
        GameDb.MapData d = new GameDb.MapData();
        d.height = rows.length;
        d.width = rows[0].length();
        d.cells = new char[d.height][];
        for (int i = 0; i < rows.length; i++) d.cells[i] = rows[i].toCharArray();
        d.theme = "OldTownTutorial";
        return d;
    }

    private void tileFlags(GameDb db) {
        Map<Character, String[]> tiles = db == null ? null : db.tiles();
        GameDb.Table t = db == null ? null : db.table("tiles.csv");
        if (tiles != null && t != null && !tiles.isEmpty()) {
            for (Map.Entry<Character, String[]> e : tiles.entrySet()) {
                char c = e.getKey();
                if (c >= 128) continue;
                moveBlock[c] = t.flag(e.getValue(), "BlocksMovement");
                shotBlock[c] = t.flag(e.getValue(), "BlocksProjectiles");
                destructible[c] = t.flag(e.getValue(), "IsDestructible");
                bush[c] = t.flag(e.getValue(), "IsForest");
            }
        } else {
            moveBlock['M'] = moveBlock['I'] = moveBlock['W'] = moveBlock['X'] = moveBlock['Y'] = true;
            shotBlock['M'] = shotBlock['I'] = shotBlock['X'] = shotBlock['Y'] = true;
            destructible['M'] = destructible['F'] = destructible['X'] = true;
            bush['F'] = true;
        }
    }

    private void loadBrawler(GameDb db, String code) {
        brawlerCode = code;
        brawlerName = code;
        player.kind = "player";
        player.code = code;
        player.maxHp = player.hp = 3200;
        if (db == null) return;
        GameDb.Table ch = db.table("characters.csv");
        String[] r = ch.row(code);
        if (r == null) return;
        GameDb.Brawler b = db.brawler(code);
        if (b != null) brawlerName = b.name;
        player.maxHp = player.hp = ch.num(r, "Hitpoints", 3200);
        speed = ch.num(r, "Speed", 720) / UNIT;
        player.radius = ch.num(r, "CollisionRadius", 120) / UNIT;
        player.scale = ch.num(r, "Scale", 100);
        ultiChargeMul = ch.num(r, "UltiChargeMul", 100);
        weapon = weapon(db, ch.get(r, "WeaponSkill"));
        ulti = weapon(db, ch.get(r, "UltimateSkill"));
        ammo = weapon.maxCharge;
    }

    private Unit dummy(GameDb db, String code) {
        Unit u = new Unit();
        u.kind = code.replace("TrainingDummy", "").toLowerCase(Locale.ROOT);
        u.code = code;
        u.maxHp = code.endsWith("Big") ? 100000 : code.endsWith("Small") ? 1500 : 4000;
        if (db != null) {
            GameDb.Table ch = db.table("characters.csv");
            String[] r = ch.row(code);
            if (r != null) {
                u.maxHp = ch.num(r, "Hitpoints", (int) u.maxHp);
                u.radius = ch.num(r, "CollisionRadius", 120) / UNIT;
                u.scale = ch.num(r, "Scale", 100);
                if (code.endsWith("Shooting")) {
                    shooterDamage = ch.num(r, "AutoAttackDamage", 500);
                    shooterEvery = ch.num(r, "AutoAttackSpeedMs", 1400) / 1000f;
                    shooterRange = ch.num(r, "AutoAttackRange", 20) / 3f;
                    shooterShot = projectile(db, ch.get(r, "AutoAttackProjectile"), new Weapon());
                }
            }
        }
        u.hp = u.maxHp;
        return u;
    }

    /** a skill from skills.csv with its projectile */
    public static Weapon weapon(GameDb db, String skill) {
        Weapon w = new Weapon();
        w.skill = skill;
        GameDb.Table t = db.table("skills.csv");
        String[] r = skill == null ? null : t.row(skill);
        if (r == null) return w;
        w.damage = Math.max(0, t.num(r, "Damage", 500));
        w.bullets = Math.max(1, t.num(r, "NumBulletsInOneAttack", 1));
        w.spread = t.num(r, "Spread", 0);
        w.range = Math.max(1.5f, t.num(r, "CastingRange", 18) / 3f);
        w.maxCharge = Math.max(1, t.num(r, "MaxCharge", 3));
        w.reload = t.num(r, "RechargeTime", 1500) / 1000f;
        w.between = Math.max(0.03f, t.num(r, "MsBetweenAttacks", 100) / 1000f);
        w.cooldown = Math.max(0.1f, t.num(r, "Cooldown", 250) / 1000f);
        w.projectile = t.get(r, "Projectiles");
        if (w.projectile.isEmpty()) { // melee, beams, dashes: a short invisible hit
            w.melee = true;
            w.speed = 30;
            w.radius = 0.5f;
            w.pierceChars = true;
            if (w.damage == 0) w.damage = 500;
            return w;
        }
        return projectile(db, w.projectile, w);
    }

    static Weapon projectile(GameDb db, String name, Weapon w) {
        GameDb.Table p = db.table("projectiles_logic.csv");
        String[] r = p.row(name);
        if (r == null) {
            p = db.table("projectiles.csv");
            r = p.row(name);
        }
        if (r == null) return w;
        w.speed = Math.max(2, p.num(r, "Speed", 3000) / UNIT);
        w.radius = Math.max(0.12f, p.num(r, "Radius", 0) / UNIT);
        w.pierceChars = p.flag(r, "PiercesCharacters");
        w.pierceEnv = p.flag(r, "PiercesEnvironment") || p.flag(r, "PiercesEnvironmentLikeButter");
        return w;
    }

    // ------------------------------------------------------------------ map queries
    public char cell(int c, int r) {
        if (c < 0 || r < 0 || c >= width || r >= height) return 'I';
        return cells[r][c];
    }

    public boolean blocksMove(int c, int r) {
        char ch = cell(c, r);
        return ch < 128 && moveBlock[ch];
    }

    public boolean blocksShot(int c, int r) {
        char ch = cell(c, r);
        return ch < 128 && shotBlock[ch];
    }

    public boolean isBush(int c, int r) {
        char ch = cell(c, r);
        return ch < 128 && bush[ch];
    }

    /** does a circle at x,z touch a blocking tile or the map edge? */
    boolean collides(float x, float z, float rad) {
        if (x - rad < 0 || z - rad < 0 || x + rad > width || z + rad > height) return true;
        for (int r = (int) Math.floor(z - rad); r <= (int) Math.floor(z + rad); r++) {
            for (int c = (int) Math.floor(x - rad); c <= (int) Math.floor(x + rad); c++) {
                if (!blocksMove(c, r)) continue;
                float nx = Math.max(c, Math.min(x, c + 1)), nz = Math.max(r, Math.min(z, r + 1));
                float dx = x - nx, dz = z - nz;
                if (dx * dx + dz * dz < rad * rad * 0.92f) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ actions
    /**
     * Attack (or super) towards a direction; a tiny direction means "aim at the nearest dummy".
     * Returns false when there is no ammo / super isn't charged.
     */
    public boolean attack(float ax, float az, boolean isUlti) {
        Unit p = player;
        if (!p.alive) return false;
        Weapon w = isUlti ? ulti : weapon;
        if (isUlti) {
            if (superCharge < 1) return false;
        } else {
            if (ammo < 1 || time - p.lastAttack < w.cooldown) {
                if (ammo < 1) events.add("empty");
                return false;
            }
        }
        float len = (float) Math.sqrt(ax * ax + az * az);
        float angle;
        if (len < 0.15f) {
            Unit t = nearest(w.range * 1.15f);
            angle = t != null ? (float) Math.atan2(t.x - p.x, t.z - p.z) : p.face;
        } else {
            angle = (float) Math.atan2(ax, az);
        }
        if (isUlti) superCharge = 0;
        else ammo -= 1;
        p.lastAttack = time;
        p.face = angle;
        p.action = isUlti ? "ulti" : "attack";
        p.actionStart = time;
        events.add(isUlti ? "ulti" : "attack");
        if (w.spread > 0 && w.bullets > 1) {
            for (int i = 0; i < w.bullets; i++) {
                float off = (float) Math.toRadians(w.spread) * (i / (float) (w.bullets - 1) - 0.5f);
                fire(w, angle + off, isUlti, false);
            }
        } else {
            for (int i = 0; i < w.bullets; i++) {
                Burst b = new Burst();
                b.at = time + i * w.between;
                b.angle = angle;
                b.w = w;
                b.ulti = isUlti;
                bursts.add(b);
            }
        }
        return true;
    }

    /** nearest living dummy within a range */
    public Unit nearest(float range) {
        Unit best = null;
        float bd = range * range;
        for (Unit u : dummies) {
            if (!u.alive) continue;
            float dx = u.x - player.x, dz = u.z - player.z, d = dx * dx + dz * dz;
            if (d < bd) {
                bd = d;
                best = u;
            }
        }
        return best;
    }

    void fire(Weapon w, float angle, boolean isUlti, boolean enemy) {
        Shot s = new Shot();
        s.dx = (float) Math.sin(angle);
        s.dz = (float) Math.cos(angle);
        Unit from = enemy ? null : player;
        s.x = (from != null ? from.x : 0) + s.dx * 0.35f;
        s.z = (from != null ? from.z : 0) + s.dz * 0.35f;
        s.speed = w.speed;
        s.left = w.range;
        s.radius = w.radius;
        s.damage = w.damage;
        s.ulti = isUlti;
        s.enemy = enemy;
        s.pierceChars = w.pierceChars;
        s.pierceEnv = w.pierceEnv;
        shots.add(s);
    }

    // ------------------------------------------------------------------ simulation
    /** advances the game by dt seconds; mx/mz = movement stick (-1..1) */
    public void step(float dt, float mx, float mz) {
        dt = Math.min(dt, 0.1f);
        time += dt;
        Unit p = player;
        // player
        if (p.alive) {
            float len = (float) Math.sqrt(mx * mx + mz * mz);
            p.moving = len > 0.12f;
            if (p.moving) {
                float k = Math.min(1, len) / len * speed * dt;
                float nx = p.x + mx * k, nz = p.z + mz * k;
                if (!collides(nx, p.z, p.radius) && !hitsDummy(nx, p.z, p.radius)) p.x = nx;
                if (!collides(p.x, nz, p.radius) && !hitsDummy(p.x, nz, p.radius)) p.z = nz;
                if (time - p.lastAttack > 0.45f) p.face = (float) Math.atan2(mx, mz);
            }
            p.inBush = isBush((int) Math.floor(p.x), (int) Math.floor(p.z));
            if (ammo < weapon.maxCharge) ammo = Math.min(weapon.maxCharge, ammo + dt / Math.max(0.2f, weapon.reload));
            if (time - p.lastHurt > 3 && time - p.lastAttack > 3 && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.13f * dt);
            if (!"idle".equals(p.action) && !"walk".equals(p.action) && time - p.actionStart > 0.55f) p.action = "idle";
            if ("idle".equals(p.action) || "walk".equals(p.action)) {
                String a = p.moving ? "walk" : "idle";
                if (!a.equals(p.action)) {
                    p.action = a;
                    p.actionStart = time;
                }
            }
        } else {
            p.deadFor += dt;
            if (p.deadFor >= respawnTime) {
                p.alive = true;
                p.hp = p.maxHp;
                p.x = p.spawnX;
                p.z = p.spawnZ;
                p.deadFor = 0;
                p.action = "idle";
                p.actionStart = time;
                ammo = weapon.maxCharge;
                events.add("respawn");
            }
        }
        p.flash = Math.max(0, p.flash - dt);

        // queued bullets of a burst (Colt, Rico…)
        for (Iterator<Burst> it = bursts.iterator(); it.hasNext(); ) {
            Burst b = it.next();
            if (b.at > time) continue;
            if (p.alive) fire(b.w, b.angle + (float) ((Math.random() - 0.5) * 0.05), b.ulti, false);
            it.remove();
        }

        // dummies
        for (Unit u : dummies) {
            u.flash = Math.max(0, u.flash - dt);
            if (!u.alive) {
                u.deadFor += dt;
                if (u.deadFor >= respawnTime) {
                    u.alive = true;
                    u.hp = u.maxHp;
                    u.deadFor = 0;
                    events.add("spawn");
                }
                continue;
            }
            if ("shooting".equals(u.kind) && p.alive) {
                float dx = p.x - u.x, dz = p.z - u.z;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                u.cooldown -= dt;
                if (d <= shooterRange) {
                    u.face = (float) Math.atan2(dx, dz);
                    if (u.cooldown <= 0) {
                        u.cooldown = shooterEvery;
                        Shot s = new Shot();
                        s.dx = dx / d;
                        s.dz = dz / d;
                        s.x = u.x + s.dx * 0.4f;
                        s.z = u.z + s.dz * 0.4f;
                        s.speed = shooterShot.speed > 2 ? shooterShot.speed : 13.3f;
                        s.radius = Math.max(0.2f, shooterShot.radius);
                        s.left = shooterRange + 1;
                        s.damage = shooterDamage;
                        s.enemy = true;
                        shots.add(s);
                        u.action = "attack";
                        u.actionStart = time;
                        events.add("enemyShot");
                    }
                } else if (u.cooldown < 0) {
                    u.cooldown = 0;
                }
                if ("attack".equals(u.action) && time - u.actionStart > 0.6f) u.action = "idle";
            }
        }

        // projectiles, in small steps so nothing tunnels through a wall
        for (Shot s : shots) {
            float dist = s.speed * dt;
            s.age += dt;
            while (dist > 0 && !s.dead) {
                float d = Math.min(0.1f, dist);
                dist -= d;
                s.x += s.dx * d;
                s.z += s.dz * d;
                s.left -= d;
                if (s.left <= 0) {
                    s.dead = true;
                    break;
                }
                int c = (int) Math.floor(s.x), r = (int) Math.floor(s.z);
                if (blocksShot(c, r)) {
                    char ch = cell(c, r);
                    if (s.pierceEnv && ch < 128 && destructible[ch] && c >= 0 && r >= 0 && c < width && r < height) {
                        cells[r][c] = '.';
                        events.add("wall");
                    } else {
                        s.dead = true;
                        events.add("wallHit");
                        break;
                    }
                }
                if (s.pierceEnv && isBush(c, r) && s.ulti && c >= 0 && r >= 0 && c < width && r < height) cells[r][c] = '.';
                if (s.enemy) {
                    if (p.alive && touches(s, p)) hurtPlayer(s);
                } else {
                    for (Unit u : dummies) {
                        if (!u.alive || s.hit.contains(u) || !touches(s, u)) continue;
                        hitDummy(s, u);
                        if (!s.pierceChars) {
                            s.dead = true;
                            break;
                        }
                    }
                }
            }
        }
        shots.removeIf(s -> s.dead);
        for (Popup pp : popups) pp.age += dt;
        popups.removeIf(pp -> pp.age > 1.1f);
    }

    boolean hitsDummy(float x, float z, float rad) {
        for (Unit u : dummies) {
            if (!u.alive) continue;
            float dx = u.x - x, dz = u.z - z, r = u.radius + rad;
            if (dx * dx + dz * dz < r * r * 0.8f) {
                // allow walking out of an overlap
                float ox = u.x - player.x, oz = u.z - player.z;
                if (ox * ox + oz * oz < r * r * 0.8f) continue;
                return true;
            }
        }
        return false;
    }

    static boolean touches(Shot s, Unit u) {
        float dx = u.x - s.x, dz = u.z - s.z, r = u.radius + s.radius;
        return dx * dx + dz * dz <= r * r;
    }

    void hitDummy(Shot s, Unit u) {
        s.hit.add(u);
        int dmg = s.damage;
        u.hp -= dmg;
        u.flash = 0.12f;
        u.lastHurt = time;
        damageDealt += dmg;
        popup(u, String.valueOf(dmg), s.ulti ? 0xFFFFD84A : 0xFFFFFFFF);
        if (!s.ulti) superCharge = Math.min(1, superCharge + dmg * ultiChargeMul / 100f / 4400f);
        events.add("hit");
        if (u.hp <= 0) {
            u.hp = 0;
            u.alive = false;
            u.deadFor = 0;
            kills++;
            events.add("kill");
        }
    }

    void hurtPlayer(Shot s) {
        Unit p = player;
        s.dead = true;
        p.hp -= s.damage;
        p.flash = 0.12f;
        p.lastHurt = time;
        popup(p, String.valueOf(s.damage), 0xFFFF5A5A);
        events.add("hurt");
        if (p.hp <= 0) {
            p.hp = 0;
            p.alive = false;
            p.deadFor = 0;
            events.add("dead");
        }
    }

    void popup(Unit u, String text, int color) {
        Popup pp = new Popup();
        pp.x = u.x + (float) (Math.random() - 0.5) * 0.3f;
        pp.z = u.z;
        pp.text = text;
        pp.color = color;
        popups.add(pp);
    }

    /** the old-version "charge the super" button of the training cave */
    public void chargeSuper() {
        superCharge = 1;
    }
}
