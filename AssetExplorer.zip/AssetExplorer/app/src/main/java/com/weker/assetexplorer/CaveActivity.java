package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.Battle;
import com.weker.assetexplorer.codec.BattleFx;
import com.weker.assetexplorer.codec.BattleScene;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Scene3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * The training cave as in the game: the "Training" map with its dummies, and the brawler with the attack,
 * super and gadget the game files describe (shots, throws, dashes, pets, turrets, shields…).
 * Controls and look come from the game's own ui.sc and font.
 */
public final class CaveActivity extends Activity implements GLSurfaceView.Renderer {

    private final Handler main = new Handler(Looper.getMainLooper());
    private GameData gd;
    private Sfx sfx;
    private GLSurfaceView gl;
    private Hud hud;
    private TextView status;
    private final GlScene glScene = new GlScene();
    private final Object lock = new Object();
    private Battle battle;
    private BattleScene scene;
    private Battle.Fighter me;
    private Scene3d lastScene;
    private long lastNanos;
    private volatile float moveX, moveZ;
    /** {what, dx, dz}: 0 attack, 1 super, 2 gadget */
    private final ConcurrentLinkedQueue<float[]> fire = new ConcurrentLinkedQueue<>();
    private String skin, brawler;
    private GameDb.Brawler info;
    // game pictures
    private Bitmap moveBg, moveStick, attackBg, attackStick, ultiBg, ultiStick, itemBg, itemStick, gadgetIcon, skull, hyperIcon;
    private BattleFx effects;
    /** damage of the last second, shown as "Урон в секунду" */
    private volatile int dps;
    private final java.util.ArrayDeque<long[]> dmgLog = new java.util.ArrayDeque<>();
    private int lastDamage;
    private Typeface font = Typeface.DEFAULT_BOLD;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        long vid = getIntent().getLongExtra("vid", -1);
        brawler = getIntent().getStringExtra("brawler");
        skin = getIntent().getStringExtra("skin");
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        sfx.maxAtOnce = 10;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1E2230);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(new GlModelView.Chooser());
        gl.setRenderer(this);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        hud = new Hud(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        status = Ui.bold(this, "Загружаю тренировочную пещеру…", 18, Ui.TEXT);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0xEE0F1A3A);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        new Thread(() -> {
            try {
                font = GameUi.font(gd);
                main.post(() -> status.setTypeface(font));
                GameDb db = gd.db;
                info = db.brawler(brawler);
                if (skin == null && info != null) skin = info.defaultSkin;
                Battle bt = new Battle(db, Battle.Mode.TRAINING, null, System.nanoTime());
                Battle.Fighter f = bt.add(brawler, skin, 0, "me", info != null ? info.name : brawler);
                bt.start();
                BattleScene sc = new BattleScene(bt, gd.assets);
                sc.viewer = f;
                sc.preload();
                BattleFx bfx = new BattleFx(bt, db, gd::read, new com.weker.assetexplorer.codec.ScSprites(gd::sc));
                sc.effects = bfx;
                main.post(() -> status.setText("Готовлю эффекты…"));
                try {
                    bfx.prewarm(f);
                } catch (Throwable ignored) {
                    // effects appear on first use instead
                }
                effects = bfx;
                sc.camX = f.x;
                sc.camZ = f.z;
                loadPictures();
                gd.forget("ui.sc");
                synchronized (lock) {
                    battle = bt;
                    scene = sc;
                    me = f;
                    lastNanos = 0;
                }
                main.post(() -> {
                    status.setVisibility(View.GONE);
                    if (info != null) sfx.play(info.voice.get("Появление"));
                    if (sc.actor(f.kit.skin) == null || sc.actor(f.kit.skin).model == null) {
                        android.widget.Toast.makeText(this, "Модели бойца нет в архиве — он показан тенью", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Throwable e) {
                main.post(() -> status.setText("Не удалось открыть пещеру: " + e.getMessage()
                        + "\nНужны таблицы игры (maps.csv, characters.csv, skills.csv…) и 3D-модели в импортированном архиве."));
            }
        }, "cave-load").start();
    }

    /** joysticks and buttons from ui.sc, the gadget icon from cards.csv */
    private void loadPictures() {
        int s = Ui.dp(this, 120);
        moveBg = GameUi.pic(gd, "virtuastick_move_bg", s);
        moveStick = GameUi.pic(gd, "virtuastick_move_stick", s);
        attackBg = GameUi.pic(gd, "virtuastick_attack_bg", s);
        attackStick = GameUi.pic(gd, "virtuastick_attack_stick", s);
        ultiBg = GameUi.pic(gd, "virtuastick_ulti_bg", s);
        ultiStick = GameUi.pic(gd, "ulti_stick", s);
        itemBg = GameUi.pic(gd, "virtuastick_item_bg", s);
        itemStick = GameUi.pic(gd, "item_base_stick", s);
        skull = GameUi.pic(gd, "button_ulti_skull", s / 2);
        hyperIcon = GameUi.pic(gd, "overcharge_button", s);
        GameDb.Table cards = gd.db.table("cards.csv");
        for (String[] c : cards.rows) {
            if (!brawler.equals(cards.get(c, "Target"))) continue;
            String meta = cards.get(c, "MetaType");
            String file = GameDb.fileName(cards.get(c, "IconSWF")), ex = cards.get(c, "IconExportName");
            if (ex.isEmpty()) continue;
            if ("5".equals(meta) && gadgetIcon == null) gadgetIcon = gd.export(file.isEmpty() ? "ui.sc" : file, ex, Ui.dp(this, 96));
            if ("6".equals(meta)) { // the hypercharge button shows the brawler's own hypercharge icon
                Bitmap hb = gd.export(file.isEmpty() ? "ui.sc" : file, ex, Ui.dp(this, 96));
                if (hb != null) hyperIcon = hb;
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
        sfx.stopAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
        lastNanos = 0;
    }

    // ------------------------------------------------------------------ GL thread: step + draw
    @Override
    public void onSurfaceCreated(GL10 g, EGLConfig config) {
        try {
            glScene.init();
        } catch (RuntimeException e) {
            main.post(() -> {
                status.setVisibility(View.VISIBLE);
                status.setText("OpenGL ES 2.0 недоступен: " + e.getMessage());
            });
        }
    }

    @Override
    public void onSurfaceChanged(GL10 g, int w, int h) {
        glScene.resize(w, h);
    }

    @Override
    public void onDrawFrame(GL10 g) {
        Scene3d s = null;
        List<String> events = new ArrayList<>();
        synchronized (lock) {
            if (battle != null) {
                long now = System.nanoTime();
                float dt = lastNanos == 0 ? 0 : (now - lastNanos) / 1e9f;
                lastNanos = now;
                float[] f;
                while ((f = fire.poll()) != null) battle.use(me, (int) f[0], f[1], f[2]);
                battle.input(me, moveX, moveZ);
                battle.step(dt);
                if (effects != null) {
                    effects.consume();
                    effects.step(dt);
                    events.addAll(effects.fx.takeSounds());
                }
                scene.follow(dt);
                events.addAll(battle.events);
                battle.events.clear();
                long ms = System.currentTimeMillis();
                if (me.damageDone != lastDamage) {
                    dmgLog.add(new long[]{ms, me.damageDone - lastDamage});
                    lastDamage = me.damageDone;
                }
                while (!dmgLog.isEmpty() && ms - dmgLog.peekFirst()[0] > 1000) dmgLog.pollFirst();
                int sum = 0;
                for (long[] x : dmgLog) sum += x[1];
                dps = sum;
                s = scene.build();
                lastScene = s;
            }
        }
        try {
            glScene.draw(s != null ? s : new Scene3d());
        } catch (RuntimeException e) {
            // a bad frame is skipped
        }
        if (!events.isEmpty()) main.post(() -> sounds(events));
        hud.postInvalidate();
    }

    private long lastVoice;

    private void sounds(List<String> events) {
        if (info == null || me == null) return;
        long now = System.currentTimeMillis();
        String mine = ":" + me.id;
        for (String e : events) {
            if (!e.contains(":")) { // an effect's own sound (shots, hits, explosions)
                sfx.effect(e);
                continue;
            }
            String voice = null;
            if (e.equals("ulti" + mine)) voice = info.voice.get("Супер");
            else if (e.equals("kill" + mine)) voice = info.voice.get("Победил врага");
            else if (e.equals("hit" + mine) && now - lastVoice > 2500) voice = info.voice.get("Получил урон");
            else if (e.equals("dead" + mine)) voice = info.voice.get("Поражение");
            else if (e.equals("respawn" + mine)) voice = info.voice.get("Появление");
            else if (e.equals("attack" + mine) && now - lastVoice > 4000 && Math.random() < 0.25) voice = info.voice.get("Атака");
            if (voice != null && sfx.play(voice) != null) lastVoice = now;
        }
    }

    // ------------------------------------------------------------------ HUD
    /**
     * The game's battle screen: sticks where the game puts them (measured from its screenshots, as parts of the
     * screen size), the super button with its skull, the gadget and hypercharge buttons, thin health bars with the
     * number above, ammo / super / hypercharge bars under yours, "Урон в секунду" and "Выйти".
     */
    final class Hud extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint grey = new Paint(Paint.FILTER_BITMAP_FLAG);
        int movePtr = -1;
        float moveCx, moveCy, moveX0, moveY0;
        int aimPtr = -1, aimWhat;
        boolean aimMoved;
        float aimCx, aimCy, aimDx, aimDy;

        Hud(Context c) {
            super(c);
            text.setTextAlign(Paint.Align.CENTER);
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(0);
            grey.setColorFilter(new ColorMatrixColorFilter(cm));
            grey.setAlpha(170);
        }

        /** ring radius of a stick: 14% of the screen height, like the game */
        float ring() { return getHeight() * 0.14f; }

        float moveHomeX() { return getWidth() * 0.1475f; }

        float moveHomeY() { return getHeight() * 0.77f; }

        float attackX() { return getWidth() * 0.8425f; }

        float attackY() { return getHeight() * 0.63f; }

        float ultiX() { return getWidth() * 0.715f; }

        float ultiY() { return getHeight() * 0.74f; }

        float itemX() { return getWidth() * 0.795f; }

        float itemY() { return getHeight() * 0.88f; }

        float hyperX() { return getWidth() * 0.65f; }

        float hyperY() { return getHeight() * 0.88f; }

        RectF exitRect() {
            float w = getWidth(), h = getHeight();
            return new RectF(w * 0.565f, h * 0.885f, w * 0.62f, h * 0.96f);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            int idx = e.getActionIndex();
            float R = ring();
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    float x = e.getX(idx), y = e.getY(idx);
                    int id = e.getPointerId(idx);
                    if (exitRect().contains(x, y)) {
                        finish();
                        return true;
                    }
                    if (me != null && !me.kit.hyperName.isEmpty() && Math.hypot(x - hyperX(), y - hyperY()) < R * 0.5f) {
                        fire.add(new float[]{3, 0, 0});
                        return true;
                    }
                    if (x < getWidth() * 0.45f && movePtr < 0) {
                        movePtr = id;
                        moveCx = moveX0 = x;
                        moveCy = moveY0 = y;
                    } else if (aimPtr < 0) {
                        int what = 0;
                        float cx = attackX(), cy = attackY();
                        if (Math.hypot(x - ultiX(), y - ultiY()) < R * 0.6f) {
                            what = 1;
                            cx = ultiX();
                            cy = ultiY();
                        } else if (Math.hypot(x - itemX(), y - itemY()) < R * 0.55f) {
                            what = 2;
                            cx = itemX();
                            cy = itemY();
                        } else if (Math.hypot(x - cx, y - cy) > R * 1.4f) {
                            cx = x;
                            cy = y;
                        }
                        aimPtr = id;
                        aimWhat = what;
                        aimCx = cx;
                        aimCy = cy;
                        aimDx = aimDy = 0;
                        aimMoved = false;
                    }
                    break;
                }
                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        int id = e.getPointerId(i);
                        float x = e.getX(i), y = e.getY(i);
                        if (id == movePtr) {
                            moveX0 = x;
                            moveY0 = y;
                            float dx = (x - moveCx) / R, dy = (y - moveCy) / R;
                            float l = (float) Math.sqrt(dx * dx + dy * dy);
                            if (l > 1) {
                                dx /= l;
                                dy /= l;
                            }
                            moveX = dx;
                            moveZ = dy;
                        } else if (id == aimPtr) {
                            aimDx = (x - aimCx) / R;
                            aimDy = (y - aimCy) / R;
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (l > 0.2f) aimMoved = true;
                            if (l > 1) {
                                aimDx /= l;
                                aimDy /= l;
                            }
                        }
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL: {
                    int id = e.getPointerId(idx);
                    if (id == movePtr) {
                        movePtr = -1;
                        moveX = moveZ = 0;
                    } else if (id == aimPtr) {
                        aimPtr = -1;
                        if (a != MotionEvent.ACTION_CANCEL) {
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (!aimMoved || l > 0.2f) fire.add(new float[]{aimWhat, aimMoved ? aimDx : 0, aimMoved ? aimDy : 0});
                        }
                        aimDx = aimDy = 0;
                    }
                    break;
                }
                default:
                    break;
            }
            invalidate();
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            text.setTypeface(font);
            synchronized (lock) {
                if (battle == null || lastScene == null) return;
                drawWorld(c, battle, scene, lastScene);
                drawControls(c, battle, me);
            }
        }

        private void drawWorld(Canvas c, Battle b, BattleScene sc, Scene3d s) {
            int w = getWidth(), h = getHeight();
            // aim guide: a light cone (or a circle where a throw lands), yellow for the super
            if (aimPtr >= 0 && aimMoved && me.alive && aimWhat <= 2) {
                Battle.Skill sk = aimWhat == 0 ? me.kit.weapon : aimWhat == 1 ? me.kit.ulti : me.kit.gadget;
                if (sk != null) {
                    float ang = (float) Math.atan2(aimDx, aimDy);
                    float len = (float) Math.min(1, Math.hypot(aimDx, aimDy));
                    Path path = new Path();
                    if (sk.kind == Battle.Kind.LOB || sk.kind == Battle.Kind.SUMMON || sk.kind == Battle.Kind.JUMP) {
                        float tx = me.x + (float) Math.sin(ang) * sk.range * len, tz = me.z + (float) Math.cos(ang) * sk.range * len;
                        float rad = Math.max(0.8f, sk.areaRadius);
                        for (int i = 0; i <= 24; i++) {
                            double t = Math.PI * 2 * i / 24;
                            float[] q = s.project(tx + (float) Math.cos(t) * rad, 0.05f, tz + (float) Math.sin(t) * rad, w, h);
                            if (i == 0) path.moveTo(q[0], q[1]);
                            else path.lineTo(q[0], q[1]);
                        }
                    } else {
                        float half = (float) Math.toRadians(Math.max(4, Math.min(170, sk.spread / 2f + 2)));
                        float[] a0 = s.project(me.x, 0.05f, me.z, w, h);
                        path.moveTo(a0[0], a0[1]);
                        for (int i = 0; i <= 12; i++) {
                            float t = ang - half + 2 * half * i / 12f;
                            float[] q = s.project(me.x + (float) Math.sin(t) * sk.range, 0.05f, me.z + (float) Math.cos(t) * sk.range, w, h);
                            path.lineTo(q[0], q[1]);
                        }
                    }
                    path.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(aimWhat == 1 ? 0x66FFD23A : aimWhat == 2 ? 0x6668E05A : 0x66FFFFFF);
                    c.drawPath(path, p);
                }
            }
            for (Battle.Fighter f : b.fighters) {
                if (!f.alive || (f != me && !b.visibleTo(f, me))) continue;
                bar(c, s, sc, f, w, h);
            }
            float th = h * 0.032f;
            text.setTextSize(th);
            for (Battle.Popup pp : b.popups) {
                float[] q = s.project(pp.x, 2.0f + pp.age * 0.9f, pp.z, w, h);
                text.setAlpha((int) (255 * Math.max(0, 1 - pp.age / 1.1f)));
                GameUi.outlined(c, pp.text, q[0], q[1], text, pp.color, th * 0.22f);
            }
            text.setAlpha(255);
            if (!me.alive) {
                text.setTextSize(h * 0.05f);
                GameUi.outlined(c, String.format(Locale.ROOT, "ВОЗРОЖДЕНИЕ ЧЕРЕЗ %d", (int) Math.ceil(Math.max(0, me.respawnIn))), w / 2f, h * 0.4f, text, 0xFFFFFFFF, h * 0.009f);
            }
        }

        /** as in the game: number above a thin bar; for you also the name, ammo, super and hypercharge bars */
        private void bar(Canvas c, Scene3d s, BattleScene sc, Battle.Fighter f, int w, int h) {
            float[] q = s.project(f.x, sc.headHeight(f), f.z, w, h);
            boolean mine = f == me;
            float bw = h * (mine ? 0.1f : f.maxHp >= 50000 ? 0.1f : 0.085f), bh = h * 0.012f, o = h * 0.0035f;
            // everything sits above the head: under the bar only your ammo / super / hypercharge strips
            float below = mine ? h * (0.011f + 0.008f + (f.kit.hyperName.isEmpty() ? 0 : 0.008f)) + o * 8 : 0;
            float x = q[0] - bw / 2, y = q[1] - bh - below;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF22223A);
            c.drawRoundRect(new RectF(x - o, y - o, x + bw + o, y + bh + o), bh, bh, p);
            float part = Math.max(0, Math.min(1, f.hp / f.maxHp));
            p.setColor(mine ? 0xFF5BE04B : f.team == me.team ? 0xFF3D9BFF : 0xFFE5333B);
            c.drawRoundRect(new RectF(x, y, x + Math.max(bh, bw * part), y + bh), bh / 2, bh / 2, p);
            p.setColor(mine ? 0x66FFFFFF : 0x44FFFFFF);
            c.drawRoundRect(new RectF(x + bh * 0.3f, y + bh * 0.15f, x + Math.max(bh, bw * part) - bh * 0.3f, y + bh * 0.45f), bh / 4, bh / 4, p);
            float th = h * 0.022f;
            text.setTextSize(th);
            GameUi.outlined(c, String.valueOf((int) Math.ceil(f.hp)), q[0], y - o * 1.5f, text, 0xFFFFFFFF, th * 0.2f);
            if (!mine) return;
            text.setTextSize(h * 0.025f);
            GameUi.outlined(c, f.name, q[0], y - th - o * 2, text, 0xFF63E356, h * 0.005f);
            float yy = y + bh + o * 2.5f;
            int max = f.kit.weapon.maxCharge;
            float gap = h * 0.003f, sw = (bw - gap * (max - 1)) / max, ah = h * 0.011f;
            for (int i = 0; i < max; i++) {
                float fill = Math.max(0, Math.min(1, f.ammo - i));
                float ax = x + i * (sw + gap);
                p.setColor(0xFF22223A);
                c.drawRoundRect(new RectF(ax - o * 0.6f, yy - o * 0.6f, ax + sw + o * 0.6f, yy + ah + o * 0.6f), ah / 3, ah / 3, p);
                p.setColor(fill >= 1 ? 0xFFFF8A1C : 0xFF8C4E1A);
                if (fill > 0) c.drawRoundRect(new RectF(ax, yy, ax + sw * fill, yy + ah), ah / 3, ah / 3, p);
            }
            yy += ah + o * 2.2f;
            float sh = h * 0.008f;
            p.setColor(0xFF22223A);
            c.drawRoundRect(new RectF(x - o * 0.6f, yy - o * 0.6f, x + bw + o * 0.6f, yy + sh + o * 0.6f), sh, sh, p);
            p.setColor(0xFFFFD02A);
            if (f.superCharge > 0) c.drawRoundRect(new RectF(x, yy, x + bw * Math.min(1, f.superCharge), yy + sh), sh / 2, sh / 2, p);
            if (!f.kit.hyperName.isEmpty()) {
                yy += sh + o * 1.8f;
                p.setColor(0xFF22223A);
                c.drawRoundRect(new RectF(x - o * 0.6f, yy - o * 0.6f, x + bw + o * 0.6f, yy + sh + o * 0.6f), sh, sh, p);
                p.setColor(f.hyperUntil > b().time ? 0xFFFF4FD8 : 0xFFE0337A);
                float hp = f.hyperUntil > b().time ? (f.hyperUntil - b().time) / 5f : f.hyper;
                if (hp > 0) c.drawRoundRect(new RectF(x, yy, x + bw * Math.min(1, hp), yy + sh), sh / 2, sh / 2, p);
            }
        }

        Battle b() {
            return battle;
        }

        private void drawControls(Canvas c, Battle b, Battle.Fighter f) {
            int w = getWidth(), h = getHeight();
            float R = ring();
            // damage per second, top right
            text.setTextAlign(Paint.Align.RIGHT);
            text.setTextSize(h * 0.03f);
            GameUi.outlined(c, String.valueOf(dps), w * 0.985f, h * 0.1f, text, 0xFF56B4FF, h * 0.006f);
            float vw = text.measureText(String.valueOf(dps));
            GameUi.outlined(c, "Урон в секунду:", w * 0.985f - vw - h * 0.05f, h * 0.1f, text, 0xFFFFFFFF, h * 0.006f);
            text.setTextAlign(Paint.Align.CENTER);
            // movement stick: home place when idle, under the finger when held
            float mcx = movePtr >= 0 ? moveCx : moveHomeX(), mcy = movePtr >= 0 ? moveCy : moveHomeY();
            float mdx = 0, mdy = 0;
            if (movePtr >= 0) {
                mdx = moveX0 - moveCx;
                mdy = moveY0 - moveCy;
                float l = (float) Math.hypot(mdx, mdy);
                if (l > R) {
                    mdx = mdx / l * R;
                    mdy = mdy / l * R;
                }
            }
            stick(c, moveBg, moveStick, mcx, mcy, mdx, mdy, R, R * 0.46f, movePtr >= 0 ? 255 : 170, false, 0xFF2F6FE0);
            // attack
            boolean aA = aimPtr >= 0 && aimWhat == 0;
            stick(c, attackBg, attackStick, aA ? aimCx : attackX(), aA ? aimCy : attackY(), aA ? aimDx * R : 0, aA ? aimDy * R : 0,
                    R, R * 0.46f, aA ? 255 : 170, false, 0xFFE0352F);
            // super: yellow skull button inside its ring, grey and filling while it charges
            boolean ready = f.superCharge >= 1;
            boolean aU = aimPtr >= 0 && aimWhat == 1;
            float ux = ultiX() + (aU ? aimDx * R * 0.9f : 0), uy = ultiY() + (aU ? aimDy * R * 0.9f : 0);
            float ub = R * 0.47f;
            if (ultiBg != null) c.drawBitmap(ultiBg, null, new RectF(ultiX() - R * 0.95f, ultiY() - R * 0.95f, ultiX() + R * 0.95f, ultiY() + R * 0.95f), ready ? p : grey);
            if (ultiStick != null) c.drawBitmap(ultiStick, null, new RectF(ux - ub, uy - ub, ux + ub, uy + ub), ready ? p : grey);
            else {
                p.setColor(ready ? 0xFFFFC21F : 0xFF777777);
                c.drawCircle(ux, uy, ub * 0.8f, p);
            }
            if (skull != null) { // the skull picture is square: the game shows it inside the round button
                float sk = ub * 0.78f;
                c.save();
                Path clip = new Path();
                clip.addCircle(ux, uy, ub * 0.74f, Path.Direction.CW);
                c.clipPath(clip);
                c.drawBitmap(skull, null, new RectF(ux - sk, uy - sk, ux + sk, uy + sk), ready ? p : grey);
                c.restore();
            }
            if (!ready) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(h * 0.012f);
                p.setColor(0xFFFFC21F);
                c.drawArc(new RectF(ultiX() - ub * 1.05f, ultiY() - ub * 1.05f, ultiX() + ub * 1.05f, ultiY() + ub * 1.05f), -90, 360 * f.superCharge, false, p);
                p.setStyle(Paint.Style.FILL);
            }
            // gadget: the game's green button with this brawler's gadget icon
            if (f.kit.gadget != null) {
                boolean aG = aimPtr >= 0 && aimWhat == 2;
                float gx = itemX() + (aG ? aimDx * R * 0.5f : 0), gy = itemY() + (aG ? aimDy * R * 0.5f : 0);
                boolean has = f.gadgets > 0;
                if (itemBg != null) c.drawBitmap(itemBg, null, new RectF(itemX() - R, itemY() - R, itemX() + R, itemY() + R), has ? p : grey);
                float gb = R * 0.5f;
                if (gadgetIcon != null) c.drawBitmap(gadgetIcon, null, new RectF(gx - gb, gy - gb, gx + gb, gy + gb), has ? p : grey);
                else if (itemStick != null) c.drawBitmap(itemStick, null, new RectF(gx - gb, gy - gb, gx + gb, gy + gb), has ? p : grey);
                text.setTextSize(h * 0.028f);
                GameUi.outlined(c, String.valueOf(f.gadgets), gx + gb * 0.85f, gy + gb * 0.95f, text, 0xFFFFFFFF, h * 0.005f);
            }
            // hypercharge
            if (!f.kit.hyperName.isEmpty()) {
                boolean on = f.hyper >= 1 || f.hyperUntil > b.time;
                float hb = R * 0.5f;
                // the game's purple round button with the brawler's hypercharge picture on it
                p.setStyle(Paint.Style.FILL);
                p.setColor(on ? 0xFF7A1FD0 : 0xFF55505E);
                c.drawCircle(hyperX(), hyperY(), hb * 0.92f, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(h * 0.006f);
                p.setColor(on ? 0xFFE7B8FF : 0xFF999999);
                c.drawCircle(hyperX(), hyperY(), hb * 0.92f, p);
                p.setStyle(Paint.Style.FILL);
                float hi = hb * 0.7f;
                if (hyperIcon != null) c.drawBitmap(hyperIcon, null, new RectF(hyperX() - hi, hyperY() - hi, hyperX() + hi, hyperY() + hi), on ? p : grey);
                else {
                    p.setColor(on ? 0xFFB040FF : 0xFF666666);
                    c.drawCircle(hyperX(), hyperY(), hb * 0.8f, p);
                }
                if (f.hyper < 1 && f.hyperUntil <= b.time) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(h * 0.01f);
                    p.setColor(0xFFD050FF);
                    c.drawArc(new RectF(hyperX() - hb, hyperY() - hb, hyperX() + hb, hyperY() + hb), -90, 360 * f.hyper, false, p);
                    p.setStyle(Paint.Style.FILL);
                }
            }
            // "Выйти", like the game's translucent box
            RectF ex = exitRect();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x88555570);
            c.drawRoundRect(ex, h * 0.01f, h * 0.01f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(h * 0.003f);
            p.setColor(0xCCFFFFFF);
            c.drawRoundRect(ex, h * 0.01f, h * 0.01f, p);
            p.setStyle(Paint.Style.FILL);
            text.setTextSize(h * 0.03f);
            GameUi.outlined(c, "Выйти", ex.centerX(), ex.centerY() + h * 0.011f, text, 0xFFFFFFFF, h * 0.005f);
        }

        /** one of the game's sticks: its ring, and the knob moved by the finger */
        private void stick(Canvas c, Bitmap bg, Bitmap knob, float cx, float cy, float dx, float dy, float rb, float rk, int alpha, boolean off, int fallback) {
            Paint bp = off ? grey : p;
            int oldA = p.getAlpha();
            if (!off) p.setAlpha(alpha);
            if (bg != null) {
                c.drawBitmap(bg, null, new RectF(cx - rb, cy - rb, cx + rb, cy + rb), bp);
            } else {
                p.setColor((fallback & 0x00FFFFFF) | 0x44000000);
                c.drawCircle(cx, cy, rb, p);
            }
            if (knob != null) {
                c.drawBitmap(knob, null, new RectF(cx + dx - rk, cy + dy - rk, cx + dx + rk, cy + dy + rk), bp);
            } else {
                p.setColor(off ? 0xFF777777 : fallback);
                c.drawCircle(cx + dx, cy + dy, rk * 0.8f, p);
            }
            p.setAlpha(oldA);
        }
    }
}
