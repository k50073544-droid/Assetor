package com.weker.assetexplorer.codec;

import org.tukaani.xz.LZMAInputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Readers for Supercell containers: compressed wrappers, .sctx, .ktx/.zktx, SC1 texture tags. */
public final class SupercellFiles {

    private SupercellFiles() {}

    static final byte[] KTX_ID = {(byte) 0xAB, 'K', 'T', 'X', ' ', '1', '1', (byte) 0xBB, '\r', '\n', 0x1A, '\n'};

    // ================================================================= unwrap
    public static final class Unwrapped {
        public byte[] data;
        public String chain = "";
        public int scVersion = -1;
    }

    /** Removes signatures / SC headers / LZMA / Zstd layers. */
    public static Unwrapped unwrap(byte[] d) throws IOException {
        Unwrapped u = new Unwrapped();
        u.data = d;
        for (int iter = 0; iter < 6; iter++) {
            byte[] x = u.data;
            if (x.length >= 68 && x[0] == 'S' && x[1] == 'i' && x[2] == 'g' && x[3] == ':') {
                u.data = slice(x, 68, x.length);
                u.chain += "sig ";
                continue;
            }
            if (x.length >= 10 && x[0] == 'S' && x[1] == 'C' && beInt(x, 2) >= 1 && beInt(x, 2) <= 100) {
                int p = 2;
                int version = beInt(x, p);
                p += 4;
                int end = x.length;
                if (version == 4) {
                    version = beInt(x, p);
                    p += 4;
                    int s = indexOf(x, "START".getBytes(StandardCharsets.US_ASCII), p);
                    if (s > 0) end = s;
                }
                u.scVersion = version;
                if (version >= 5) {
                    // SC2: header followed by (possibly compressed) flatbuffer data
                    u.chain += "sc2 ";
                    int z = indexOf(x, new byte[]{0x28, (byte) 0xB5, 0x2F, (byte) 0xFD}, p);
                    if (z >= 0 && z < p + 64) {
                        u.data = Zstd.decompress(x, z, x.length);
                        u.chain += "zstd ";
                    } else {
                        u.data = slice(x, p, x.length);
                    }
                    return u;
                }
                int hashLen = beInt(x, p);
                p += 4;
                if (hashLen < 0 || hashLen > 64) throw new IOException("Повреждённый SC заголовок");
                p += hashLen;
                u.data = slice(x, p, end);
                u.chain += "sc" + version + " ";
                continue;
            }
            if (Zstd.isZstd(x, 0)) {
                u.data = Zstd.decompress(x);
                u.chain += "zstd ";
                continue;
            }
            if (isLzma(x)) {
                u.data = lzma(x);
                u.chain += "lzma ";
                continue;
            }
            if (x.length >= 4 && x[0] == 'S' && x[1] == 'C' && x[2] == 'L' && x[3] == 'Z') {
                throw new IOException("Сжатие LZHAM (очень старые версии) не поддерживается");
            }
            break;
        }
        return u;
    }

    static boolean isLzma(byte[] x) {
        return x.length > 13 && ((x[0] & 0xFF) == 0x5D || (x[0] & 0xFF) == 0x5E) && x[1] == 0 && x[2] == 0
                && (x[8] & 0xFF) < 0x20;
    }

    static byte[] lzma(byte[] x) throws IOException {
        byte props = x[0];
        int dict = leInt(x, 1);
        long size = leInt(x, 5) & 0xFFFFFFFFL;
        if (size == 0xFFFFFFFFL) size = -1;
        try (LZMAInputStream in = new LZMAInputStream(new ByteArrayInputStream(x, 9, x.length - 9), size, props, dict)) {
            if (size >= 0) in.enableRelaxedEndCondition();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(size > 0 && size < Integer.MAX_VALUE ? (int) size : 1 << 16);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }

    // ================================================================= textures
    public static final class TextureSet {
        public final List<Img> images = new ArrayList<>();
        public final List<String> info = new ArrayList<>();
        public final List<String> externalRefs = new ArrayList<>();
        public final List<String> exportNames = new ArrayList<>();
        public Sc2 sc2;
    }

    /** Tries to decode any texture-bearing file. */
    public static TextureSet decodeTextures(byte[] file, String name) throws IOException {
        TextureSet ts = new TextureSet();
        String lower = name.toLowerCase();
        if (Sc2.isSc2(file)) {
            Sc2 s = Sc2.parse(file);
            ts.sc2 = s;
            ts.info.add("Формат SC2 v" + s.version + ": атласов " + s.textures.size() + ", спрайтов " + s.shapes.size()
                    + ", объектов " + s.exportNames.size());
            for (int i = 0; i < s.textures.size(); i++) {
                Sc2.Tex t = s.textures.get(i);
                if (t.data == null || t.data.length == 0) {
                    if (t.external != null) ts.externalRefs.add(t.external);
                    continue;
                }
                if (ts.images.size() >= 3) {
                    ts.info.add("Остальные атласы не показаны (экономия памяти) — открой «Спрайты».");
                    break;
                }
                try {
                    Img im = s.texture(i, ts.info);
                    if (im != null) ts.images.add(im);
                } catch (IOException e) {
                    ts.info.add("Атлас " + i + ": " + e.getMessage());
                }
            }
            ts.exportNames.addAll(s.exportNames);
            return ts;
        }
        Unwrapped u = unwrap(file);
        byte[] d = u.data;
        if (!u.chain.isEmpty()) ts.info.add("Слои: " + u.chain.trim());

        if (startsWith(d, KTX_ID, 0)) {
            ts.images.add(readKtx(d, 0, ts.info));
            return ts;
        }
        if (isSctx(d)) {
            ts.images.add(readSctx(d, ts.info));
            return ts;
        }
        if (lower.endsWith(".sc") || u.scVersion >= 0) {
            if (u.scVersion >= 5) {
                ts.info.add("Формат SC2 (версия " + u.scVersion + ")");
                scanEmbedded(d, ts);
                collectStrings(d, ts.externalRefs);
                return ts;
            }
            boolean texFile = lower.endsWith("_tex.sc");
            if (!texFile) {
                int p = readSc1Header(d, ts);
                if (p > 0) readTags(d, p, ts);
            }
            if (ts.images.isEmpty()) readTags(d, 0, ts);
            if (ts.images.isEmpty()) scanEmbedded(d, ts);
            return ts;
        }
        scanEmbedded(d, ts);
        return ts;
    }

    static boolean isSctx(byte[] d) {
        if (d.length < 16) return false;
        int hlen = leInt(d, 0);
        if (hlen <= 0 || hlen + 4 > d.length) return false;
        return d[8] == 'S' && d[9] == 'C' && d[10] == 'T' && d[11] == 'X';
    }

    // ----------------------------------------------------------------- KTX 1
    public static Img readKtx(byte[] d, int o, List<String> info) throws IOException {
        if (!startsWith(d, KTX_ID, o)) throw new IOException("Не KTX");
        boolean le = leInt(d, o + 12) == 0x04030201;
        int[] f = new int[13];
        for (int i = 0; i < 13; i++) f[i] = le ? leInt(d, o + 12 + i * 4) : beInt(d, o + 12 + i * 4);
        int glType = f[1], glFormat = f[3], glInternal = f[4];
        int w = f[6], h = Math.max(1, f[7]);
        int kv = f[12];
        int p = o + 64 + kv;
        int imageSize = le ? leInt(d, p) : beInt(d, p);
        p += 4;
        if (imageSize < 0 || p + imageSize > d.length) throw new IOException("KTX обрезан");
        info.add(String.format("KTX %dx%d, формат 0x%04X", w, h, glInternal));
        return PixelFormats.decodeGl(glInternal, glFormat, glType, d, p, w, h);
    }

    // ----------------------------------------------------------------- SCTX
    public static Img readSctx(byte[] d, List<String> info) throws IOException {
        int hlen = leInt(d, 0);
        int hs = 4;
        FlatTable header = FlatTable.root(d, hs);
        int pixelType = header.u32(1, 0);
        int w = header.u16(2, 0);
        int h = header.u16(3, 0);
        int levels = header.u8(4, 1);
        int flags = header.u32(6, 0);
        int texLen = header.i32(7, 0);
        int p = hs + hlen;
        int mipLen = leInt(d, p);
        p += 4;
        int dataStart = p + mipLen;
        int level0Offset = 0;
        int lw = w, lh = h;
        if (levels > 0 && mipLen > 4) {
            int l0len = leInt(d, p);
            FlatTable mip = FlatTable.root(d, p + 4);
            lw = mip.u16(0, w);
            lh = mip.u16(1, h);
            level0Offset = mip.u32(2, 0);
            if (l0len <= 0) lw = w;
        }
        int q = dataStart;
        if ((flags & 8) != 0) q = (q + 15) & ~15;
        byte[] data;
        int off;
        if (Zstd.isZstd(d, q)) {
            data = Zstd.decompress(d, q, d.length);
            off = 0;
        } else {
            data = d;
            off = q;
        }
        info.add("SCTX " + w + "x" + h + ", " + PixelFormats.scPixelName(pixelType)
                + (levels > 1 ? ", мип-уровней: " + levels : "") + (texLen == 0 ? " (стриминговая)" : ""));
        if (lw <= 0 || lh <= 0) {
            lw = w;
            lh = h;
        }
        return PixelFormats.decodeScPixel(pixelType, data, off + level0Offset, lw, lh);
    }

    // ----------------------------------------------------------------- SC1
    static final int[] TEX_TAGS = {1, 16, 19, 24, 27, 28, 29, 34, 45, 47};

    static boolean isTexTag(int t) {
        for (int x : TEX_TAGS) if (x == t) return true;
        return false;
    }

    /** returns offset of first tag, or -1. */
    static int readSc1Header(byte[] d, TextureSet ts) {
        try {
            int p = 12; // shapes, movieclips, textures, textfields, matrices, colortransforms
            if (d.length < 20) return -1;
            p += 5;
            int exports = leU16(d, p);
            p += 2;
            p += exports * 2;
            for (int i = 0; i < exports; i++) {
                int len = d[p] & 0xFF;
                p++;
                if (p + len > d.length) return -1;
                if (ts.exportNames.size() < 2000) ts.exportNames.add(new String(d, p, len, StandardCharsets.UTF_8));
                p += len;
            }
            return p;
        } catch (RuntimeException e) {
            return -1;
        }
    }

    static void readTags(byte[] d, int p, TextureSet ts) {
        try {
            while (p + 5 <= d.length) {
                int tag = d[p] & 0xFF;
                int len = leInt(d, p + 1);
                p += 5;
                if (tag == 0) break;
                if (len < 0 || p + len > d.length) break;
                if (isTexTag(tag) && len >= 5) {
                    int fmt = d[p] & 0xFF;
                    int w = leU16(d, p + 1), h = leU16(d, p + 3);
                    int body = p + 5;
                    int ktx = indexOf(d, KTX_ID, body);
                    if (ktx >= 0 && ktx < p + len) {
                        ts.images.add(readKtx(d, ktx, ts.info));
                    } else if (len - 5 >= (long) w * h * bppSc1(fmt)) {
                        ts.images.add(readSc1Pixels(d, body, w, h, fmt, tag == 27 || tag == 28 || tag == 29));
                        ts.info.add("Текстура " + w + "x" + h + " (формат " + fmt + ")");
                    } else {
                        List<String> s = new ArrayList<>();
                        collectStringsIn(d, body, p + len, s);
                        ts.externalRefs.addAll(s);
                        ts.info.add("Внешняя текстура " + w + "x" + h + (s.isEmpty() ? "" : ": " + s.get(0)));
                    }
                }
                p += len;
            }
        } catch (IOException | RuntimeException e) {
            ts.info.add("Ошибка разбора тегов: " + e.getMessage());
        }
    }

    static int sc1Raw(int fmt) {
        switch (fmt) {
            case 2: case 8: return PixelFormats.RAW_4444;
            case 3: return PixelFormats.RAW_5551;
            case 4: return PixelFormats.RAW_565;
            case 6: return PixelFormats.RAW_LA8;
            case 10: return PixelFormats.RAW_L8;
            default: return PixelFormats.RAW_RGBA8;
        }
    }

    static int bppSc1(int fmt) { return PixelFormats.bytesPerPixel(sc1Raw(fmt)); }

    static Img readSc1Pixels(byte[] d, int p, int w, int h, int fmt, boolean blocks) {
        int raw = sc1Raw(fmt);
        int bpp = PixelFormats.bytesPerPixel(raw);
        int[] out = new int[w * h];
        if (!blocks) {
            for (int i = 0; i < w * h; i++) out[i] = PixelFormats.readPixel(d, p + i * bpp, raw);
        } else {
            int bs = 32;
            int bxn = (w + bs - 1) / bs, byn = (h + bs - 1) / bs;
            int q = p;
            for (int by = 0; by < byn; by++) {
                for (int bx = 0; bx < bxn; bx++) {
                    for (int y = by * bs; y < Math.min(h, (by + 1) * bs); y++) {
                        for (int x = bx * bs; x < Math.min(w, (bx + 1) * bs); x++) {
                            out[y * w + x] = PixelFormats.readPixel(d, q, raw);
                            q += bpp;
                        }
                    }
                }
            }
        }
        return new Img(w, h, out);
    }

    /** Finds embedded KTX / SCTX blobs anywhere in the data. */
    static void scanEmbedded(byte[] d, TextureSet ts) {
        int p = 0;
        int guard = 0;
        while (guard++ < 64) {
            int k = indexOf(d, KTX_ID, p);
            if (k < 0) break;
            try {
                ts.images.add(readKtx(d, k, ts.info));
            } catch (IOException | RuntimeException e) {
                ts.info.add("Встроенный KTX не прочитан: " + e.getMessage());
            }
            p = k + 12;
        }
    }

    static void collectStrings(byte[] d, List<String> out) {
        collectStringsIn(d, 0, d.length, out);
    }

    /** Collects file-name-like strings (*.sctx, *.ktx, *.zktx, *.png). */
    static void collectStringsIn(byte[] d, int from, int to, List<String> out) {
        String[] exts = {".sctx", ".zktx", ".ktx", ".png"};
        for (int i = from; i < to && out.size() < 64; i++) {
            if (d[i] != '.') continue;
            for (String e : exts) {
                if (i + e.length() <= to && new String(d, i, e.length(), StandardCharsets.ISO_8859_1).equalsIgnoreCase(e)) {
                    int s = i;
                    while (s > from && isNameChar(d[s - 1])) s--;
                    String str = new String(d, s, i + e.length() - s, StandardCharsets.UTF_8);
                    if (str.length() > e.length() && !out.contains(str)) out.add(str);
                }
            }
        }
    }

    static boolean isNameChar(byte b) {
        return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '_' || b == '-' || b == '/';
    }

    // ================================================================= helpers
    static byte[] slice(byte[] d, int a, int b) {
        byte[] r = new byte[Math.max(0, b - a)];
        System.arraycopy(d, a, r, 0, r.length);
        return r;
    }

    static int beInt(byte[] d, int p) {
        return (d[p] & 0xFF) << 24 | (d[p + 1] & 0xFF) << 16 | (d[p + 2] & 0xFF) << 8 | (d[p + 3] & 0xFF);
    }

    static int leInt(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
    }

    static int leU16(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
    }

    static boolean startsWith(byte[] d, byte[] m, int o) {
        if (o < 0 || o + m.length > d.length) return false;
        for (int i = 0; i < m.length; i++) if (d[o + i] != m[i]) return false;
        return true;
    }

    public static int indexOf(byte[] d, byte[] m, int from) {
        outer:
        for (int i = Math.max(0, from); i <= d.length - m.length; i++) {
            for (int j = 0; j < m.length; j++) if (d[i + j] != m[j]) continue outer;
            return i;
        }
        return -1;
    }

    /** Minimal FlatBuffers table accessor. */
    static final class FlatTable {
        final byte[] d;
        final int pos;
        final int vt;
        final int vtSize;

        FlatTable(byte[] d, int pos) {
            this.d = d;
            this.pos = pos;
            this.vt = pos - leInt(d, pos);
            this.vtSize = leU16(d, vt);
        }

        static FlatTable root(byte[] d, int base) throws IOException {
            int t = base + leInt(d, base);
            if (t < 0 || t + 4 > d.length) throw new IOException("Повреждённый flatbuffer");
            return new FlatTable(d, t);
        }

        int field(int id) {
            int o = 4 + id * 2;
            if (o + 2 > vtSize) return 0;
            int off = leU16(d, vt + o);
            return off == 0 ? 0 : pos + off;
        }

        int u8(int id, int def) {
            int f = field(id);
            return f == 0 ? def : d[f] & 0xFF;
        }

        int u16(int id, int def) {
            int f = field(id);
            return f == 0 ? def : leU16(d, f);
        }

        int u32(int id, int def) {
            int f = field(id);
            return f == 0 ? def : leInt(d, f);
        }

        int i32(int id, int def) { return u32(id, def); }
    }
}
