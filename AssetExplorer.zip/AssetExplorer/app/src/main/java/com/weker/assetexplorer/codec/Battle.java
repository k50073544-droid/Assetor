package com.weker.assetexplorer.codec;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * A battle on a real map from maps.csv: Gem Grab, Showdown, Brawl Ball, Bounty, Knockout.
 * Brawlers come from characters.csv / skills.csv / projectiles / area effects / cards (gadgets) at power 11.
 * Bots play the free slots. The host runs {@link #step}; other players get {@link #snapshot()} and send input.
 * Positions are in tiles (1 tile = 300 game units); x right, z down the map (row). Team 0 starts at the bottom.
 */
public final class Battle {

    public enum Mode {
        GEM("GemGrab", "Захват кристаллов", 3), SHOWDOWN("Showdown", "Столкновение", 1), BALL("BrawlBall", "Броулбол", 3),
        BOUNTY("Bounty", "Награда за поимку", 3), KNOCKOUT("Knockout", "Нокаут", 3), TRAINING("Training", "Тренировочная пещера", 1);

        public final String variation, title;
        public final int teamSize;

        Mode(String v, String t, int n) {
            variation = v;
            title = t;
            teamSize = n;
        }
    }

    public static final float UNIT = 300f;
    /** power 11: health and damage are twice the level-1 numbers in the tables */
    public static final float POWER = 2f;

    // ------------------------------------------------------------------ skills
    public enum Kind { SHOT, LOB, CHARGE, AREA, SPIN, SUMMON, HEAL_AREA, SHIELD, INVISIBLE, SPEED, JUMP, RELOAD, NONE }

    public static final class Skill {
        public String name = "";
        public Kind kind = Kind.SHOT;
        public int damage = 500, bullets = 1, maxCharge = 3;
        public float spread, range = 6, speed = 10, radius = 0.15f;
        public float reload = 1.5f, between = 0.1f, cooldown = 0.3f, active = 0.2f;
        public boolean pierceChars, pierceEnv, breaksWalls;
        /** explosion / area: radius in tiles, damage, how long it stays (s), tick */
        public float areaRadius, areaTime, areaTick = 0.5f;
        public int areaDamage;
        public float chargeSpeed;
        public String summon;
        public int summonCount = 1;
        /** names in the tables, for the effects: projectile, area effect, attack effect */
        public String proj = "", areaName = "", effect = "";

        boolean projectileless() {
            return damage == 0 && areaDamage == 0 && summon == null;
        }
    }

    public static final class Kit {
        public String code, name, skin;
        public int hp = 3200, scale = 100;
        public float speed = 2.4f, radius = 0.4f, ultiMul = 100, ultiUltiMul = 60;
        public Skill weapon = new Skill(), ulti = new Skill(), gadget;
        public String gadgetName = "";
        public String archetype = "";
        public boolean hero = true;
        /** pets and turrets: their own attack */
        public int autoDamage;
        public float autoRange, autoEvery = 1;
        public String autoProjectile = "";
        /** hypercharge (cards.csv MetaType 6): its name and boosts from characters.csv */
        public String hyperName = "";
        public float hyperMul, hyperSpeed, hyperDamage, hyperShield;
        /** the super while hypercharged (characters.csv OverchargedUltimateSkill) and the hypercharge look */
        public Skill hyperUlti;
        public String hyperEffect = "";
    }

    // ------------------------------------------------------------------ objects
    public static final class Fighter {
        public int id, team;
        public String owner = "bot", name = "";
        public Kit kit;
        public float x, z, face;
        public float hp, maxHp;
        public float ammo, superCharge, hyper, hyperUntil;
        public int gadgets = 3;
        public boolean alive = true, bot = true, box, pet, dummy;
        public int ownerId = -1;
        public float respawnIn;
        public int gems, bounty = 2, cubes;
        public String action = "idle";
        public float actionStart;
        public float lastHurt = -99, lastAttack = -99, flash;
        public float stunUntil, slowUntil, speedUntil, invisUntil, shieldUntil, spinUntil, nextAttackBoost;
        public float dashVx, dashVz, dashLeft;
        public int dashDamage;
        public final List<Integer> dashHit = new ArrayList<>();
        public float spinTick;
        public float autoCd;
        public boolean inBush, moving;
        public int kills, deaths, damageDone;
        public float spawnX, spawnZ;
        // input (players) / plan (bots)
        public float mx, mz;
        float thinkIn, aimErr;
        public float goalX = -1, goalZ = -1;
        float strafe = 1, keep, poisonTick;

        public boolean invisible(float now) {
            return invisUntil > now;
        }
    }

    public static final class Shot {
        public int id, team, owner;
        public float x, z, dx, dz, speed, left, radius, h;
        public int damage;
        public boolean ulti, pierceChars, pierceEnv, breaksWalls, lob, dead, enemyPet;
        public float tx, tz, flight, total;
        public Skill skill;
        public float angle, age;
        final List<Integer> hit = new ArrayList<>();
    }

    public static final class Area {
        public float x, z, radius, left, tick, next;
        public int team, owner, damage;
        public boolean heal, follow;
        int hitOnce = -1;
    }

    public static final class Item {
        public int type; // 0 gem, 1 bounty star, 2 power cube
        public float x, z, vx, vz, age;
    }

    public static final class Popup {
        public float x, z, age;
        public String text;
        public int color;
    }

    // ------------------------------------------------------------------ state
    public final Mode mode;
    public String mapName = "", theme = "", locationTitle = "";
    public int width, height;
    public char[][] cells;
    char[][] startCells;
    final boolean[] moveBlock = new boolean[256], shotBlock = new boolean[256], destructible = new boolean[256], bush = new boolean[256];
    public final List<Fighter> fighters = new ArrayList<>();
    public final List<Shot> shots = new ArrayList<>();
    public final List<Area> areas = new ArrayList<>();
    public final List<Item> items = new ArrayList<>();
    public final List<Popup> popups = new ArrayList<>();
    /** what happened this step (for sounds / voice lines): kind:fighterId */
    public final List<String> events = new ArrayList<>();
    /** what the effects layer should show: {kind, …} (cast, hit, reach, area, hurt, dead, spawn, wall) */
    public final List<Object[]> fx = new ArrayList<>();
    public float time, timeLimit = 150, respawnTime = 5;
    public final int[] score = new int[2];
    public int round = 1;
    public final int[] roundWins = new int[2];
    public float gemCountdown = -1;
    public int gemCountdownTeam = -1;
    public float poison; // tiles of gas from each edge
    public float roundTime;
    /** -1 playing, team number (or fighter id in showdown) of the winner, -2 draw */
    public int winner = -1;
    public boolean over;
    public String message = "";
    public float messageUntil;
    // ball
    public float ballX, ballZ, ballVx, ballVz, ballH;
    public int ballCarrier = -1;
    float ballNoPick;
    int ballLastTouch = -1;
    public float resetIn;
    public int goalLeft, goalRight; // goal columns (inclusive)
    public float mineX, mineZ, gemTimer;
    // misc
    public int mapVersion;
    final Random rnd;
    int nextId = 1;
    final GameDb db;
    public boolean client;
    final Map<String, Kit> kits = new HashMap<>();
    public final List<int[]> brokenCells = new ArrayList<>();

    // ------------------------------------------------------------------ setup
    /**
     * @param map map name from maps.csv (null = a random enabled map of the mode)
     */
    public Battle(GameDb db, Mode mode, String map, long seed) {
        this.db = db;
        this.mode = mode;
        this.rnd = new Random(seed);
        if (mode == Mode.TRAINING && map == null) map = "Training";
        GameDb.Table loc = db.table("locations.csv");
        List<String[]> choices = new ArrayList<>();
        for (String[] r : loc.rows) {
            String v = loc.get(r, "GameModeVariation");
            if (!v.equals(mode.variation)) continue;
            if (map != null ? map.equals(loc.get(r, "Map")) : !loc.flag(r, "Disabled")) choices.add(r);
        }
        if (choices.isEmpty()) for (String[] r : loc.rows) if (loc.get(r, "GameModeVariation").equals(mode.variation)) choices.add(r);
        String[] pick = choices.isEmpty() ? null : choices.get(rnd.nextInt(choices.size()));
        mapName = pick != null ? loc.get(pick, "Map") : map;
        theme = pick != null ? loc.get(pick, "LocationTheme") : "Default";
        String t = pick != null ? db.text(loc.get(pick, "TID")) : null;
        locationTitle = t != null ? GameDb.nice(t) : mapName;
        GameDb.MapData md = mapName == null ? null : db.map(mapName);
        if (md == null) md = Cave.fallbackMap();
        width = md.width;
        height = md.height;
        cells = md.cells;
        startCells = new char[height][];
        for (int r = 0; r < height; r++) startCells[r] = cells[r].clone();
        tileFlags();
        GameDb.Table gmv = db.table("game_mode_variations.csv");
        String[] g = gmv.row(mode.variation);
        if (g != null) {
            int rs = gmv.num(g, "RespawnSeconds", 5);
            respawnTime = rs < 0 ? -1 : rs;
            int bt = gmv.num(g, "BattleTicks", 150);
            timeLimit = bt > 0 && bt < 600 ? bt : 150;
        }
        if (mode == Mode.TRAINING) {
            respawnTime = 5;
            timeLimit = 99999;
        }
        if (mode == Mode.SHOWDOWN || mode == Mode.KNOCKOUT) respawnTime = -1;
        if (mode == Mode.SHOWDOWN) timeLimit = 9999;
        if (mode == Mode.KNOCKOUT) timeLimit = 9999;
        if (mode == Mode.BALL) respawnTime = Math.max(3, respawnTime);
        mineX = width / 2f;
        mineZ = height / 2f;
        findGoals();
        resetBall();
    }

    /** a battle for a client: map only, everything else comes from snapshots */
    public static Battle forClient(GameDb db, Mode mode, String map) {
        Battle b = new Battle(db, mode, map, 1);
        b.client = true;
        return b;
    }

    private void tileFlags() {
        GameDb.Table t = db.table("tiles.csv");
        Map<Character, String[]> tiles = db.tiles();
        if (!tiles.isEmpty()) {
            for (Map.Entry<Character, String[]> e : tiles.entrySet()) {
                char c = e.getKey();
                if (c >= 256) continue;
                moveBlock[c] = t.flag(e.getValue(), "BlocksMovement");
                shotBlock[c] = t.flag(e.getValue(), "BlocksProjectiles");
                destructible[c] = t.flag(e.getValue(), "IsDestructible");
                bush[c] = t.flag(e.getValue(), "IsForest");
            }
        } else {
            for (char c : "MXYCITBNJEW".toCharArray()) moveBlock[c] = true;
            for (char c : "MXYCITBNJE".toCharArray()) shotBlock[c] = true;
            for (char c : "MXYCTBNF".toCharArray()) destructible[c] = true;
            bush['F'] = bush['R'] = true;
        }
    }

    void findGoals() {
        // the opening in the top row (Brawl Ball maps wall the rest off with J)
        goalLeft = width / 2 - 2;
        goalRight = width / 2 + 2;
        if (height > 0) {
            int best = -1, bl = 0;
            for (int c = 0; c < width; c++) {
                if (blocksMove(c, 0)) continue;
                int e = c;
                while (e + 1 < width && !blocksMove(e + 1, 0)) e++;
                if (e - c + 1 > bl && e - c + 1 < width) {
                    bl = e - c + 1;
                    best = c;
                }
                c = e;
            }
            if (best >= 0 && bl <= width - 4) {
                goalLeft = best;
                goalRight = best + bl - 1;
            }
        }
    }

    // ------------------------------------------------------------------ kits from the tables
    public Kit kit(String code) {
        Kit k = kits.get(code);
        if (k != null) return k;
        k = new Kit();
        k.code = code;
        k.name = code;
        GameDb.Table ch = db.table("characters.csv");
        String[] r = ch.row(code);
        if (r != null) {
            GameDb.Brawler b = db.brawler(code);
            if (b != null) k.name = b.name;
            float power = code.startsWith("TrainingDummy") ? 1 : POWER;
            k.hp = Math.round(ch.num(r, "Hitpoints", 3200) * power);
            k.speed = ch.num(r, "Speed", 720) / UNIT;
            k.radius = Math.max(0.25f, ch.num(r, "CollisionRadius", 120) / UNIT);
            k.scale = ch.num(r, "Scale", 100);
            k.ultiMul = ch.num(r, "UltiChargeMul", 100);
            k.ultiUltiMul = ch.num(r, "UltiChargeUltiMul", 60);
            k.skin = ch.get(r, "DefaultSkin");
            k.archetype = ch.get(r, "ClassArchetype");
            k.hero = "Hero".equals(ch.get(r, "Type"));
            k.weapon = skill(ch.get(r, "WeaponSkill"), true);
            k.ulti = skill(ch.get(r, "UltimateSkill"), false);
            k.autoDamage = Math.round(ch.num(r, "AutoAttackDamage", 0) * power);
            k.autoProjectile = ch.get(r, "AutoAttackProjectile");
            k.autoRange = ch.num(r, "AutoAttackRange", 6) / 3f;
            k.autoEvery = ch.num(r, "AutoAttackSpeedMs", 1000) / 1000f;
            if (b != null && !b.gadgets.isEmpty()) gadget(k);
            if (b != null && b.hypercharge != null) {
                k.hyperName = b.hypercharge;
                k.hyperMul = ch.num(r, "OverchargeChargeMul", 30);
                k.hyperSpeed = ch.num(r, "OverchargeSpeedPercent", 20) / 100f;
                k.hyperDamage = ch.num(r, "OverchargeDamagePercent", 5) / 100f;
                k.hyperShield = ch.num(r, "OverchargeShieldPercent", 5) / 100f;
                String hu = ch.get(r, "OverchargedUltimateSkill");
                if (!hu.isEmpty()) k.hyperUlti = skill(hu, false);
                k.hyperEffect = ch.get(r, "OverchargedEffect");
            }
        }
        kits.put(code, k);
        return k;
    }

    /** first gadget of the brawler (cards.csv MetaType 5 → accessories.csv → its skill) */
    void gadget(Kit k) {
        GameDb.Table cards = db.table("cards.csv");
        GameDb.Table acc = db.table("accessories.csv");
        for (String[] c : cards.rows) {
            if (!k.code.equals(cards.get(c, "Target")) || !"5".equals(cards.get(c, "MetaType"))) continue;
            String n = db.text(cards.get(c, "TID"));
            k.gadgetName = n != null ? GameDb.nice(n) : c[0];
            String[] a = acc.row(cards.get(c, "Skill"));
            String type = a == null ? "" : acc.get(a, "Type");
            Skill s;
            switch (type) {
                case "heal": s = new Skill(); s.kind = Kind.HEAL_AREA; s.areaRadius = 0.1f; s.areaDamage = Math.round(k.hp * 0.25f); break;
                case "dash": case "teleport_forward": case "teleport_to_pet": s = new Skill(); s.kind = Kind.JUMP; s.range = 3; break;
                case "consumable_shield": case "cocoon_self": s = new Skill(); s.kind = Kind.SHIELD; s.active = 3; break;
                case "give_buff_to_self": case "movement_speed": s = new Skill(); s.kind = Kind.SPEED; s.active = 3; break;
                case "spin_shoot": case "repeat_shot": s = copy(k.weapon); s.bullets = Math.max(6, s.bullets * 2); s.spread = 360; break;
                case "spawn": case "turret_barrage": s = copy(k.ulti); break;
                case "next_attack_change": s = new Skill(); s.kind = Kind.RELOAD; s.damage = 1; break;
                default: {
                    String sk = a == null ? "" : acc.get(a, "Skill");
                    s = sk.isEmpty() ? null : skill(sk, false);
                    if (s == null || (s.kind == Kind.SHOT && s.projectileless())) {
                        s = new Skill();
                        s.kind = Kind.RELOAD;
                    }
                    break;
                }
            }
            s.name = k.gadgetName;
            k.gadget = s;
            return;
        }
    }

    static Skill copy(Skill o) {
        Skill s = new Skill();
        s.name = o.name;
        s.kind = o.kind;
        s.damage = o.damage;
        s.bullets = o.bullets;
        s.maxCharge = o.maxCharge;
        s.spread = o.spread;
        s.range = o.range;
        s.speed = o.speed;
        s.radius = o.radius;
        s.reload = o.reload;
        s.between = o.between;
        s.cooldown = o.cooldown;
        s.active = o.active;
        s.pierceChars = o.pierceChars;
        s.pierceEnv = o.pierceEnv;
        s.breaksWalls = o.breaksWalls;
        s.areaRadius = o.areaRadius;
        s.areaTime = o.areaTime;
        s.areaTick = o.areaTick;
        s.areaDamage = o.areaDamage;
        s.chargeSpeed = o.chargeSpeed;
        s.summon = o.summon;
        s.summonCount = o.summonCount;
        s.proj = o.proj;
        s.areaName = o.areaName;
        s.effect = o.effect;
        return s;
    }

    /** a skill row → what it does in this engine */
    public Skill skill(String name, boolean weapon) {
        Skill s = new Skill();
        s.name = name == null ? "" : name;
        GameDb.Table t = db.table("skills.csv");
        String[] r = name == null ? null : t.row(name);
        if (r == null) {
            s.kind = Kind.SHOT;
            s.damage = Math.round(500 * POWER);
            return s;
        }
        String behavior = t.get(r, "BehaviorType");
        s.effect = t.get(r, "AttackEffect");
        int base = t.num(r, "Damage", 0);
        s.damage = Math.round(base * POWER);
        s.bullets = Math.max(1, t.num(r, "NumBulletsInOneAttack", 1));
        s.spread = t.num(r, "Spread", 0);
        if (s.spread > 360) s.spread = 0;
        s.range = Math.max(1.2f, t.num(r, "CastingRange", 18) / 3f);
        s.maxCharge = Math.max(1, t.num(r, "MaxCharge", 3));
        s.reload = Math.max(0.2f, t.num(r, "RechargeTime", 1500) / 1000f);
        s.between = Math.max(0.03f, t.num(r, "MsBetweenAttacks", 100) / 1000f);
        s.cooldown = Math.max(0.1f, t.num(r, "Cooldown", 250) / 1000f);
        s.active = Math.max(0.1f, t.num(r, "ActiveTime", 200) / 1000f);
        s.chargeSpeed = t.num(r, "ChargeSpeed", 0) / UNIT;
        String proj = t.get(r, "Projectiles");
        String summon = t.get(r, "SummonedCharacters");
        String area = t.get(r, "AreaEffectObject");
        if (!summon.isEmpty()) {
            s.summon = summon.split("[;,]")[0];
            s.summonCount = Math.max(1, t.num(r, "NumSpawns", 1));
        }
        if (!area.isEmpty()) {
            area(s, area, base);
            s.areaName = area;
        }
        switch (behavior) {
            case "Charge":
                s.kind = Kind.CHARGE;
                if (s.chargeSpeed <= 0) s.chargeSpeed = 7;
                if (s.damage == 0) s.damage = Math.round(800 * POWER);
                return s;
            case "AreaBuff":
                s.kind = s.areaDamage > 0 && area.toLowerCase(Locale.ROOT).contains("heal") ? Kind.HEAL_AREA : s.areaDamage > 0 ? Kind.SPIN : Kind.SPEED;
                if (s.kind == Kind.SPIN && s.areaRadius <= 0) s.areaRadius = 3;
                return s;
            case "Shield": case "ProjectileShield": s.kind = Kind.SHIELD; return s;
            case "Invisibility": s.kind = Kind.INVISIBLE; return s;
            case "StatusEffect": case "ChangeCharacter": case "MountUp": s.kind = Kind.SPEED; return s;
            case "Blink": case "FlyJump": case "Portals":
                s.kind = Kind.JUMP;
                if (s.damage == 0) s.damage = Math.round(800 * POWER);
                if (s.areaRadius <= 0) s.areaRadius = 1.5f;
                return s;
            case "Ww":
                s.kind = Kind.SPIN;
                if (s.areaRadius <= 0) s.areaRadius = Math.max(1.5f, s.range);
                if (s.areaDamage <= 0) s.areaDamage = s.damage;
                s.areaTime = s.active;
                return s;
            case "RapidFireArea":
                s.kind = Kind.AREA;
                if (s.areaDamage <= 0) s.areaDamage = s.damage;
                return s;
            default:
                break;
        }
        if (!proj.isEmpty()) {
            projectile(s, proj);
            if (s.summon != null) s.kind = Kind.SUMMON;
            return s;
        }
        if (s.summon != null) {
            s.kind = Kind.SUMMON;
            return s;
        }
        // no projectile: a melee / area hit in front (Bibi, Frank, Mortis…)
        s.kind = Kind.AREA;
        if (s.areaRadius <= 0) s.areaRadius = Math.max(1f, Math.min(2.5f, s.range * 0.6f));
        if (s.areaDamage <= 0) s.areaDamage = s.damage > 0 ? s.damage : Math.round(1000 * POWER);
        return s;
    }

    void area(Skill s, String name, int baseDamage) {
        GameDb.Table a = db.table("area_effects_logic.csv");
        String[] r = a.row(name);
        if (r == null) {
            a = db.table("area_effects.csv");
            r = a.row(name);
        }
        if (r == null) return;
        s.areaRadius = a.num(r, "Radius", 450) / UNIT;
        int d = a.num(r, "Damage", 0);
        s.areaDamage = Math.round((d > 0 ? d : baseDamage) * POWER);
        s.areaTime = a.num(r, "TimeMs", 0) / 1000f;
        if (a.get(r, "Type").equals("Dot")) s.areaTick = 0.5f;
        s.breaksWalls |= a.flag(r, "DestroysEnvironment");
        if (a.get(r, "Type").equals("Heal")) s.areaDamage = -Math.abs(s.areaDamage);
    }

    void projectile(Skill s, String name) {
        s.proj = name;
        GameDb.Table p = db.table("projectiles_logic.csv");
        String[] r = p.row(name);
        if (r == null) {
            p = db.table("projectiles.csv");
            r = p.row(name);
        }
        s.kind = Kind.SHOT;
        if (r == null) return;
        s.speed = Math.max(2, p.num(r, "Speed", 3000) / UNIT);
        s.radius = Math.max(0.15f, p.num(r, "Radius", 0) / UNIT);
        s.pierceChars = p.flag(r, "PiercesCharacters");
        s.pierceEnv = p.flag(r, "PiercesEnvironment") || p.flag(r, "PiercesEnvironmentLikeButter");
        s.breaksWalls = s.pierceEnv;
        boolean lob = p.flag(r, "Indirect") || p.num(r, "Gravity", 0) > 0;
        String ar = p.get(r, "SpawnAreaEffectObject");
        if (ar.isEmpty()) ar = p.get(r, "OnCreateAreaEffect");
        if (!ar.isEmpty()) {
            s.areaName = ar;
            float keep = s.areaRadius;
            area(s, ar, s.damage == 0 ? 0 : Math.round(s.damage / POWER));
            if (s.areaRadius <= 0) s.areaRadius = keep;
        }
        if (lob) {
            s.kind = Kind.LOB;
            if (s.areaRadius <= 0) s.areaRadius = 1.2f;
            if (s.areaDamage <= 0) s.areaDamage = s.damage;
            if (s.areaDamage == 0) s.areaDamage = Math.round(800 * POWER);
        }
    }

    // ------------------------------------------------------------------ players
    /** adds a brawler (a person when {@code owner} is not "bot") to a team and returns it */
    public Fighter add(String brawler, String skin, int team, String owner, String name) {
        Fighter f = new Fighter();
        f.id = nextId++;
        f.team = team;
        f.kit = kit(brawler);
        f.owner = owner == null ? "bot" : owner;
        f.bot = "bot".equals(f.owner);
        f.name = name != null ? name : f.kit.name;
        if (skin != null && !skin.isEmpty()) {
            f.kit = copyKit(f.kit);
            f.kit.skin = skin;
        }
        f.maxHp = f.hp = f.kit.hp;
        f.ammo = f.kit.weapon.maxCharge;
        f.aimErr = 0.05f + rnd.nextFloat() * 0.12f;
        f.strafe = rnd.nextBoolean() ? 1 : -1;
        fighters.add(f);
        return f;
    }

    static Kit copyKit(Kit o) {
        Kit k = new Kit();
        k.code = o.code;
        k.name = o.name;
        k.skin = o.skin;
        k.hp = o.hp;
        k.scale = o.scale;
        k.speed = o.speed;
        k.radius = o.radius;
        k.ultiMul = o.ultiMul;
        k.ultiUltiMul = o.ultiUltiMul;
        k.weapon = o.weapon;
        k.ulti = o.ulti;
        k.gadget = o.gadget;
        k.gadgetName = o.gadgetName;
        k.archetype = o.archetype;
        k.hero = o.hero;
        k.autoDamage = o.autoDamage;
        k.autoRange = o.autoRange;
        k.autoEvery = o.autoEvery;
        k.autoProjectile = o.autoProjectile;
        k.hyperName = o.hyperName;
        k.hyperMul = o.hyperMul;
        k.hyperSpeed = o.hyperSpeed;
        k.hyperDamage = o.hyperDamage;
        k.hyperShield = o.hyperShield;
        k.hyperUlti = o.hyperUlti;
        k.hyperEffect = o.hyperEffect;
        return k;
    }

    /** random playable brawlers for the bots */
    public String randomBrawler() {
        List<GameDb.Brawler> l = db.brawlers();
        for (int i = 0; i < 30 && !l.isEmpty(); i++) {
            GameDb.Brawler b = l.get(rnd.nextInt(l.size()));
            if (!b.skins.isEmpty() && b.skins.get(0).model != null && !b.skins.get(0).model.isEmpty()) return b.code;
        }
        return "ShotgunGirl";
    }

    /** puts everybody on their spawn tiles and starts; fills empty slots with bots */
    public void start() {
        if (mode == Mode.TRAINING) {
            startTraining();
            return;
        }
        int teams = mode == Mode.SHOWDOWN ? 10 : 2;
        if (mode == Mode.SHOWDOWN) {
            int i = 0;
            for (Fighter f : fighters) f.team = i++;
            while (fighters.size() < 10) add(randomBrawler(), null, fighters.size(), "bot", null);
        } else {
            int[] n = new int[2];
            for (Fighter f : fighters) if (!f.pet) n[f.team]++;
            for (int t = 0; t < 2; t++) while (n[t]++ < mode.teamSize) add(randomBrawler(), null, t, "bot", null);
        }
        placeSpawns(teams);
        if (mode == Mode.SHOWDOWN) addBoxes();
        message = mode.title;
        messageUntil = 2.5f;
        events.add("start:0");
    }

    /** the training cave: the player at '1', dummies on the digits of the "Training" map (as the game places them) */
    void startTraining() {
        Fighter me = null;
        for (Fighter f : fighters) if (!f.pet) me = f;
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                char ch = cells[r][c];
                String code = null;
                switch (ch) {
                    case '1':
                        if (me != null) spawnAt(me, c + 0.5f, r + 0.5f);
                        break;
                    case '2': code = "TrainingDummySmall"; break;
                    case '0': code = "TrainingDummyMedium"; break;
                    case '3': code = "TrainingDummyBig"; break;
                    case '4': code = "TrainingDummyShooting"; break;
                    default: break;
                }
                if (ch >= '0' && ch <= '9') cells[r][c] = startCells[r][c] = '.';
                if (code == null) continue;
                Fighter d = add(code, null, 1, "dummy", null);
                d.bot = false;
                d.dummy = true;
                spawnAt(d, c + 0.5f, r + 0.5f);
                d.face = 0;
            }
        }
        if (me != null && me.spawnX == 0) spawnAt(me, width / 2f, height - 4.5f);
        if (me != null) me.face = (float) Math.PI;
        events.add("start:0");
    }

    void placeSpawns(int teams) {
        List<float[]> a = new ArrayList<>(), b = new ArrayList<>(), any = new ArrayList<>();
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                char ch = cells[r][c];
                if (ch >= '0' && ch <= '9') {
                    float[] p = {c + 0.5f, r + 0.5f};
                    if (ch == '1') a.add(p);
                    else if (ch == '2') b.add(p);
                    if (ch != '4' || mode != Mode.SHOWDOWN) cells[r][c] = '.';
                    if (ch != '4') startCells[r][c] = '.';
                    any.add(p);
                }
            }
        }
        if (mode == Mode.SHOWDOWN) {
            List<float[]> sp = new ArrayList<>(a);
            if (sp.size() < 10) sp.addAll(b);
            while (sp.size() < 10) sp.add(freeCell());
            java.util.Collections.shuffle(sp, rnd);
            int i = 0;
            for (Fighter f : fighters) {
                if (f.pet) continue;
                float[] p = sp.get(i++ % sp.size());
                spawnAt(f, p[0], p[1]);
            }
            return;
        }
        if (a.isEmpty()) a.add(new float[]{width / 2f, height - 2.5f});
        if (b.isEmpty()) b.add(new float[]{width / 2f, 2.5f});
        // team 0 must start at the bottom
        float az = 0, bz = 0;
        for (float[] p : a) az += p[1];
        for (float[] p : b) bz += p[1];
        if (az / a.size() < bz / b.size()) {
            List<float[]> tmp = a;
            a = b;
            b = tmp;
        }
        int[] i = new int[2];
        for (Fighter f : fighters) {
            if (f.pet) continue;
            List<float[]> l = f.team == 0 ? a : b;
            float[] p = l.get(i[f.team]++ % l.size());
            spawnAt(f, p[0], p[1]);
        }
    }

    float[] freeCell() {
        for (int k = 0; k < 500; k++) {
            int c = rnd.nextInt(width), r = rnd.nextInt(height);
            if (!blocksMove(c, r) && !isBush(c, r)) return new float[]{c + 0.5f, r + 0.5f};
        }
        return new float[]{width / 2f, height / 2f};
    }

    void spawnAt(Fighter f, float x, float z) {
        f.x = f.spawnX = x;
        f.z = f.spawnZ = z;
        f.face = f.team == 0 ? (float) Math.PI : 0;
        f.alive = true;
        f.hp = f.maxHp;
        f.ammo = f.kit.weapon.maxCharge;
        f.action = "idle";
        f.actionStart = time;
    }

    void addBoxes() {
        Kit box = kit("LootBox");
        box.hp = Math.max(box.hp, 6000);
        int n = 0;
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                if (cells[r][c] != '4') continue;
                cells[r][c] = '.';
                startCells[r][c] = '.';
                Fighter f = add("LootBox", null, -1, "box", "Ящик");
                f.box = true;
                f.bot = false;
                f.x = f.spawnX = c + 0.5f;
                f.z = f.spawnZ = r + 0.5f;
                n++;
            }
        }
        for (; n < 14; n++) {
            float[] p = freeCell();
            Fighter f = add("LootBox", null, -1, "box", "Ящик");
            f.box = true;
            f.bot = false;
            f.x = f.spawnX = p[0];
            f.z = f.spawnZ = p[1];
        }
    }

    public Fighter byId(int id) {
        for (Fighter f : fighters) if (f.id == id) return f;
        return null;
    }

    public Fighter byOwner(String owner) {
        for (Fighter f : fighters) if (owner.equals(f.owner) && !f.pet) return f;
        return null;
    }

    // ------------------------------------------------------------------ map
    public char cell(int c, int r) {
        if (c < 0 || r < 0 || c >= width || r >= height) return 'J';
        return cells[r][c];
    }

    public boolean blocksMove(int c, int r) {
        char ch = cell(c, r);
        return ch < 256 && moveBlock[ch];
    }

    public boolean blocksShot(int c, int r) {
        char ch = cell(c, r);
        return ch < 256 && shotBlock[ch];
    }

    public boolean isBush(int c, int r) {
        char ch = cell(c, r);
        return ch < 256 && bush[ch];
    }

    boolean breakable(int c, int r) {
        char ch = cell(c, r);
        return ch < 256 && destructible[ch] && c >= 0 && r >= 0 && c < width && r < height;
    }

    void breakCell(int c, int r) {
        if (!breakable(c, r)) return;
        cells[r][c] = '.';
        brokenCells.add(new int[]{c, r});
        mapVersion++;
    }

    boolean collides(float x, float z, float rad) {
        if (x - rad < 0 || z - rad < 0 || x + rad > width || z + rad > height) return true;
        for (int r = (int) Math.floor(z - rad); r <= (int) Math.floor(z + rad); r++) {
            for (int c = (int) Math.floor(x - rad); c <= (int) Math.floor(x + rad); c++) {
                if (!blocksMove(c, r)) continue;
                float nx = Math.max(c, Math.min(x, c + 1)), nz = Math.max(r, Math.min(z, r + 1));
                float dx = x - nx, dz = z - nz;
                if (dx * dx + dz * dz < rad * rad * 0.92f) return true;
            }
        }
        return false;
    }

    /** can a bullet fly from a to b? */
    public boolean lineOfSight(float ax, float az, float bx, float bz) {
        float dx = bx - ax, dz = bz - az, d = (float) Math.sqrt(dx * dx + dz * dz);
        int n = (int) (d / 0.25f) + 1;
        for (int i = 1; i < n; i++) {
            float t = i / (float) n;
            if (blocksShot((int) Math.floor(ax + dx * t), (int) Math.floor(az + dz * t))) return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ input
    /** a person's stick (only stored; applied in step) */
    public void input(Fighter f, float mx, float mz) {
        if (f == null) return;
        f.mx = Math.max(-1, Math.min(1, mx));
        f.mz = Math.max(-1, Math.min(1, mz));
    }

    /**
     * attack (0), super (1) or gadget (2) towards a direction; a tiny direction = at the nearest enemy.
     * In Brawl Ball the ball carrier kicks instead.
     */
    public boolean use(Fighter f, int what, float ax, float az) {
        if (f == null || !f.alive || f.stunUntil > time || f.dashLeft > 0 || over || resetIn > 0) return false;
        if (what == 3) { // hypercharge: faster, stronger, tougher for a while
            if (f.hyper < 1 || f.kit.hyperName.isEmpty()) return false;
            f.hyper = 0;
            f.hyperUntil = time + 5;
            events.add("hyper:" + f.id);
            fx.add(new Object[]{"hyper", f});
            return true;
        }
        float len = (float) Math.sqrt(ax * ax + az * az);
        Skill s = what == 0 ? f.kit.weapon : what == 1 ? (f.hyperUntil > time && f.kit.hyperUlti != null ? f.kit.hyperUlti : f.kit.ulti) : f.kit.gadget;
        if (s == null) return false;
        float angle;
        float aimDist = s.range;
        if (len < 0.15f) {
            Fighter t = nearestEnemy(f, s.range * 1.15f, true);
            if (t != null) {
                angle = (float) Math.atan2(t.x - f.x, t.z - f.z);
                aimDist = (float) Math.hypot(t.x - f.x, t.z - f.z);
            } else {
                angle = f.face;
            }
        } else {
            angle = (float) Math.atan2(ax, az);
            aimDist = s.range * Math.min(1, len);
        }
        // Brawl Ball: the carrier kicks the ball
        if (mode == Mode.BALL && ballCarrier == f.id && what != 2) {
            kick(f, angle, what == 1);
            if (what == 1) f.superCharge = 0;
            return true;
        }
        if (what == 0) {
            if (f.ammo < 1 || time - f.lastAttack < s.cooldown) {
                if (f.ammo < 1) events.add("empty:" + f.id);
                return false;
            }
            f.ammo -= 1;
        } else if (what == 1) {
            if (f.superCharge < 1) return false;
            f.superCharge = 0;
        } else {
            if (f.gadgets <= 0 || time - f.lastAttack < 0.5f) return false;
            f.gadgets--;
        }
        f.lastAttack = time;
        f.face = angle;
        f.action = what == 1 ? "ulti" : "attack";
        f.actionStart = time;
        if (f.invisUntil > time) f.invisUntil = time; // attacking shows you
        events.add((what == 0 ? "attack:" : what == 1 ? "ulti:" : "gadget:") + f.id);
        fx.add(new Object[]{"cast", f, s, angle, what});
        cast(f, s, angle, aimDist, what == 1);
        return true;
    }

    void cast(Fighter f, Skill s, float angle, float dist, boolean isUlti) {
        float dx = (float) Math.sin(angle), dz = (float) Math.cos(angle);
        int dmgBoost = f.nextAttackBoost > 0 ? 1 : 0;
        switch (s.kind) {
            case SHOT: {
                if (s.spread > 0 && s.bullets > 1) {
                    for (int i = 0; i < s.bullets; i++) {
                        float off = (float) Math.toRadians(s.spread) * (i / (float) (s.bullets - 1) - 0.5f);
                        shoot(f, s, angle + off, isUlti, 0);
                    }
                } else {
                    for (int i = 0; i < s.bullets; i++) shoot(f, s, angle, isUlti, i * s.between);
                }
                break;
            }
            case LOB: {
                float d = Math.max(1.5f, Math.min(s.range, dist));
                int n = Math.max(1, Math.min(s.bullets, 6));
                for (int i = 0; i < n; i++) {
                    float off = n > 1 ? (float) Math.toRadians(Math.max(s.spread, 20)) * (i / (float) (n - 1) - 0.5f) : 0;
                    lob(f, s, f.x + (float) Math.sin(angle + off) * d, f.z + (float) Math.cos(angle + off) * d, isUlti, i * s.between * 0.5f);
                }
                break;
            }
            case SUMMON: {
                float d = Math.max(1, Math.min(s.range, dist));
                float tx = f.x + dx * d, tz = f.z + dz * d;
                for (int k = 0; k < 10 && collides(tx, tz, 0.3f); k++) {
                    d -= 0.5f;
                    tx = f.x + dx * d;
                    tz = f.z + dz * d;
                }
                for (int i = 0; i < s.summonCount; i++) summon(f, s.summon, tx + i * 0.4f, tz);
                if (s.damage > 0) {
                    Area a = area(f, tx, tz, 1.2f, s.damage, 0, false);
                    a.left = 0.01f;
                }
                break;
            }
            case CHARGE: {
                float d = Math.max(1.5f, Math.min(s.range, isUlti ? s.range : dist));
                f.dashVx = dx * s.chargeSpeed;
                f.dashVz = dz * s.chargeSpeed;
                f.dashLeft = d;
                f.dashDamage = s.damage;
                f.dashHit.clear();
                if (s.breaksWalls || isUlti) f.nextAttackBoost = -1; // dash through walls breaks them
                break;
            }
            case JUMP: {
                float d = Math.max(1, Math.min(s.range, dist));
                float tx = f.x + dx * d, tz = f.z + dz * d;
                for (int k = 0; k < 20 && collides(tx, tz, f.kit.radius); k++) {
                    d -= 0.4f;
                    tx = f.x + dx * d;
                    tz = f.z + dz * d;
                }
                if (d > 0.3f) {
                    f.x = Math.max(0.5f, Math.min(width - 0.5f, tx));
                    f.z = Math.max(0.5f, Math.min(height - 0.5f, tz));
                }
                if (s.damage > 0) area(f, f.x, f.z, Math.max(1.2f, s.areaRadius), s.damage, 0, false).left = 0.01f;
                break;
            }
            case AREA: {
                float r = Math.max(1f, s.areaRadius);
                float cx = f.x + dx * Math.min(r * 0.8f, s.range * 0.5f), cz = f.z + dz * Math.min(r * 0.8f, s.range * 0.5f);
                Area a = area(f, cx, cz, r, s.areaDamage + dmgBoost * s.areaDamage / 2, 0, false);
                a.left = 0.01f;
                fx.add(new Object[]{"area", cx, cz, s.areaName, f, r});
                if (s.breaksWalls) breakAround(cx, cz, r * 0.6f);
                break;
            }
            case SPIN: {
                Area a = area(f, f.x, f.z, Math.max(1.5f, s.areaRadius), s.areaDamage > 0 ? s.areaDamage : s.damage, Math.max(1, s.areaTime > 0 ? s.areaTime : s.active), false);
                a.follow = true;
                a.tick = Math.max(0.25f, s.between);
                break;
            }
            case HEAL_AREA: {
                int heal = Math.abs(s.areaDamage > 0 ? s.areaDamage : s.damage > 0 ? s.damage : Math.round(f.maxHp * 0.3f));
                if (s.areaRadius <= 0.2f) {
                    healUnit(f, heal);
                } else {
                    Area a = area(f, f.x, f.z, Math.max(1.5f, s.areaRadius), heal, Math.max(1, s.areaTime), true);
                    a.tick = 0.5f;
                }
                break;
            }
            case SHIELD: f.shieldUntil = time + Math.max(2, s.active); break;
            case INVISIBLE: f.invisUntil = time + Math.max(3, s.active); break;
            case SPEED: f.speedUntil = time + Math.max(2.5f, s.active); healUnit(f, Math.round(f.maxHp * 0.1f)); break;
            case RELOAD: f.ammo = f.kit.weapon.maxCharge; f.nextAttackBoost = time + 5; break;
            default: break;
        }
        if (f.nextAttackBoost > 0 && f.nextAttackBoost < time) f.nextAttackBoost = 0;
    }

    final List<Object[]> queued = new ArrayList<>();

    void shoot(Fighter f, Skill s, float angle, boolean isUlti, float delay) {
        if (delay > 0) {
            queued.add(new Object[]{time + delay, f.id, s, angle, isUlti});
            return;
        }
        Shot sh = new Shot();
        sh.id = nextId++;
        sh.dx = (float) Math.sin(angle);
        sh.dz = (float) Math.cos(angle);
        sh.x = f.x + sh.dx * 0.3f;
        sh.z = f.z + sh.dz * 0.3f;
        sh.speed = s.speed;
        sh.left = s.range;
        sh.radius = s.radius;
        sh.damage = s.damage == 0 ? s.areaDamage : s.damage;
        if (f.nextAttackBoost > time) sh.damage = sh.damage * 3 / 2;
        sh.team = f.team;
        sh.owner = f.id;
        sh.ulti = isUlti;
        sh.pierceChars = s.pierceChars;
        sh.pierceEnv = s.pierceEnv;
        sh.breaksWalls = s.breaksWalls || (isUlti && s.pierceEnv);
        sh.skill = s;
        sh.angle = angle;
        sh.h = 0.6f;
        shots.add(sh);
    }

    void lob(Fighter f, Skill s, float tx, float tz, boolean isUlti, float delay) {
        Shot sh = new Shot();
        sh.id = nextId++;
        sh.lob = true;
        sh.x = f.x;
        sh.z = f.z;
        sh.tx = Math.max(0.3f, Math.min(width - 0.3f, tx));
        sh.tz = Math.max(0.3f, Math.min(height - 0.3f, tz));
        float d = (float) Math.hypot(sh.tx - sh.x, sh.tz - sh.z);
        sh.total = Math.max(0.35f, d / Math.max(4, s.speed));
        sh.flight = -delay;
        sh.dx = (sh.tx - sh.x);
        sh.dz = (sh.tz - sh.z);
        sh.team = f.team;
        sh.owner = f.id;
        sh.ulti = isUlti;
        sh.skill = s;
        sh.radius = s.areaRadius;
        sh.damage = s.areaDamage;
        if (f.nextAttackBoost > time) sh.damage = sh.damage * 3 / 2;
        sh.breaksWalls = s.breaksWalls;
        sh.angle = (float) Math.atan2(sh.dx, sh.dz);
        shots.add(sh);
    }

    Area area(Fighter f, float x, float z, float r, int damage, float time0, boolean heal) {
        Area a = new Area();
        a.x = x;
        a.z = z;
        a.radius = r;
        a.damage = damage;
        a.team = f.team;
        a.owner = f.id;
        a.heal = heal;
        a.left = time0;
        a.tick = 0.5f;
        a.next = 0;
        areas.add(a);
        return a;
    }

    void summon(Fighter owner, String code, float x, float z) {
        if (code == null) return;
        // one pet of a kind per owner (Nita's bear replaces the old one)
        for (Fighter o : fighters) if (o.pet && o.ownerId == owner.id && o.kit.code.equals(code)) o.alive = false;
        Fighter p = add(code, null, owner.team, "pet", owner.name);
        p.pet = true;
        p.bot = true;
        p.ownerId = owner.id;
        p.x = x;
        p.z = z;
        if (p.kit.autoDamage <= 0) p.kit.autoDamage = Math.round(400 * POWER);
        if (p.kit.hp <= 0) p.maxHp = p.hp = 3000;
        p.face = owner.face;
    }

    void kick(Fighter f, float angle, boolean hard) {
        ballCarrier = -1;
        ballX = f.x + (float) Math.sin(angle) * 0.5f;
        ballZ = f.z + (float) Math.cos(angle) * 0.5f;
        float sp = hard ? 17 : 12;
        ballVx = (float) Math.sin(angle) * sp;
        ballVz = (float) Math.cos(angle) * sp;
        ballH = hard ? 0.2f : 0.6f;
        ballNoPick = 0.35f;
        ballLastTouch = f.id;
        f.lastAttack = time;
        f.action = hard ? "ulti" : "attack";
        f.actionStart = time;
        events.add("kick:" + f.id);
        if (hard) superKick = 0.8f;
    }

    float superKick;

    void resetBall() {
        ballX = width / 2f;
        ballZ = height / 2f;
        ballVx = ballVz = 0;
        ballCarrier = -1;
        ballH = 0;
    }

    // ------------------------------------------------------------------ simulation
    public void step(float dt) {
        if (client) return;
        dt = Math.min(dt, 0.1f);
        time += dt;
        if (messageUntil > 0) messageUntil -= dt;
        for (Popup p : popups) p.age += dt;
        popups.removeIf(p -> p.age > 1.1f);
        if (over) return;
        if (resetIn > 0) {
            resetIn -= dt;
            if (resetIn <= 0) kickoff();
            return;
        }
        roundTime += dt;
        // queued bullets (bursts)
        for (int i = queued.size() - 1; i >= 0; i--) {
            Object[] q = queued.get(i);
            if ((float) q[0] > time) continue;
            queued.remove(i);
            Fighter f = byId((int) q[1]);
            if (f != null && f.alive) shoot(f, (Skill) q[2], (float) q[3] + (rnd.nextFloat() - 0.5f) * 0.05f, (boolean) q[4], 0);
        }
        for (Fighter f : new ArrayList<>(fighters)) {
            if (f.box) continue;
            if (!f.alive) {
                if (f.pet) continue;
                if (respawnTime >= 0) {
                    f.respawnIn -= dt;
                    if (f.respawnIn <= 0) respawn(f);
                }
                continue;
            }
            if (f.dummy) {
                dummy(f, dt);
                f.flash = Math.max(0, f.flash - dt);
                continue;
            }
            if (f.bot) think(f, dt);
            move(f, dt);
            regen(f, dt);
            if (f.pet) petAttack(f, dt);
            f.flash = Math.max(0, f.flash - dt);
        }
        fighters.removeIf(f -> f.pet && !f.alive);
        stepShots(dt);
        stepAreas(dt);
        stepItems(dt);
        stepMode(dt);
    }

    /** training dummies stand still; the shooting one fires at you when you come close */
    void dummy(Fighter d, float dt) {
        if (d.kit.autoDamage <= 0 || d.kit.autoProjectile.isEmpty()) return;
        d.autoCd -= dt;
        Fighter t = nearestEnemy(d, d.kit.autoRange, false);
        if (t == null) return;
        d.face = (float) Math.atan2(t.x - d.x, t.z - d.z);
        if (d.autoCd > 0) return;
        d.autoCd = Math.max(0.3f, d.kit.autoEvery);
        Skill s = new Skill();
        projectile(s, d.kit.autoProjectile);
        s.damage = d.kit.autoDamage;
        s.range = d.kit.autoRange + 1;
        shoot(d, s, d.face, false, 0);
        d.action = "attack";
        d.actionStart = time;
        events.add("enemyShot:" + d.id);
    }

    void respawn(Fighter f) {
        f.alive = true;
        f.hp = f.maxHp;
        f.x = f.spawnX;
        f.z = f.spawnZ;
        f.ammo = f.kit.weapon.maxCharge;
        f.action = "idle";
        f.actionStart = time;
        events.add("respawn:" + f.id);
        fx.add(new Object[]{"spawn", f});
    }

    void move(Fighter f, float dt) {
        float speed = f.kit.speed;
        if (f.speedUntil > time) speed *= 1.35f;
        if (f.hyperUntil > time) speed *= 1 + f.kit.hyperSpeed;
        if (f.slowUntil > time) speed *= 0.6f;
        if (mode == Mode.SHOWDOWN) speed *= 1 + Math.min(0.0f, 0);
        if (f.dashLeft > 0) {
            float sp = (float) Math.hypot(f.dashVx, f.dashVz);
            float d = Math.min(f.dashLeft, sp * dt);
            float nx = f.x + f.dashVx / sp * d, nz = f.z + f.dashVz / sp * d;
            boolean wallBreaker = f.nextAttackBoost < 0;
            if (collides(nx, nz, f.kit.radius)) {
                if (wallBreaker) {
                    breakAround(nx, nz, f.kit.radius + 0.3f);
                } else {
                    f.dashLeft = 0;
                }
            }
            if (!collides(nx, nz, f.kit.radius)) {
                f.x = nx;
                f.z = nz;
            }
            f.dashLeft -= d;
            for (Fighter o : fighters) {
                if (!o.alive || !enemies(f, o) || f.dashHit.contains(o.id)) continue;
                if (Math.hypot(o.x - f.x, o.z - f.z) < f.kit.radius + o.kit.radius + 0.2f) {
                    f.dashHit.add(o.id);
                    damage(f, o, f.dashDamage, true);
                }
            }
            if (f.dashLeft <= 0) {
                f.dashLeft = 0;
                if (f.nextAttackBoost < 0) f.nextAttackBoost = 0;
            }
            f.moving = true;
            return;
        }
        if (f.stunUntil > time) {
            f.moving = false;
            return;
        }
        float mx = f.mx, mz = f.mz;
        if (mode == Mode.BALL && ballCarrier == f.id) speed *= 1.0f;
        float len = (float) Math.sqrt(mx * mx + mz * mz);
        f.moving = len > 0.12f && speed > 0;
        if (f.moving) {
            float k = Math.min(1, len) / len * speed * dt;
            float nx = f.x + mx * k, nz = f.z + mz * k;
            if (!collides(nx, f.z, f.kit.radius)) f.x = nx;
            if (!collides(f.x, nz, f.kit.radius)) f.z = nz;
            if (time - f.lastAttack > 0.45f) f.face = (float) Math.atan2(mx, mz);
        }
        f.inBush = isBush((int) Math.floor(f.x), (int) Math.floor(f.z));
        if (!"idle".equals(f.action) && !"walk".equals(f.action) && time - f.actionStart > 0.55f) f.action = "idle";
        if ("idle".equals(f.action) || "walk".equals(f.action)) {
            String a = f.moving ? "walk" : "idle";
            if (!a.equals(f.action)) {
                f.action = a;
                f.actionStart = time;
            }
        }
        // ball pick up
        if (mode == Mode.BALL && ballCarrier < 0 && !f.pet && ballNoPick <= 0 && ballH < 0.8f
                && Math.hypot(ballX - f.x, ballZ - f.z) < f.kit.radius + 0.35f && !(ballLastTouch == f.id && ballNoPick > -0.2f)) {
            ballCarrier = f.id;
            ballLastTouch = f.id;
            events.add("ball:" + f.id);
        }
    }

    void regen(Fighter f, float dt) {
        if (f.pet) return;
        Skill w = f.kit.weapon;
        if (f.ammo < w.maxCharge) f.ammo = Math.min(w.maxCharge, f.ammo + dt / w.reload);
        if (time - f.lastHurt > 3 && time - f.lastAttack > 3 && f.hp < f.maxHp && !inPoison(f)) {
            f.hp = Math.min(f.maxHp, f.hp + f.maxHp * 0.13f * dt);
        }
        if (mode == Mode.SHOWDOWN || mode == Mode.KNOCKOUT) {
            if (inPoison(f)) {
                f.poisonTick -= dt;
                if (f.poisonTick <= 0) {
                    f.poisonTick = 1;
                    float d = 1000 + 300 * Math.max(0, poison - 3);
                    hurt(null, f, d, 0xFF73D23C);
                }
            }
        }
    }

    boolean inPoison(Fighter f) {
        return poison > 0 && (f.x < poison || f.z < poison || f.x > width - poison || f.z > height - poison);
    }

    void petAttack(Fighter p, float dt) {
        p.autoCd -= dt;
        if (p.autoCd > 0) return;
        Fighter t = nearestEnemy(p, Math.max(1.2f, p.kit.autoRange), false);
        if (t == null) return;
        p.autoCd = Math.max(0.3f, p.kit.autoEvery);
        p.face = (float) Math.atan2(t.x - p.x, t.z - p.z);
        p.action = "attack";
        p.actionStart = time;
        if (p.kit.autoRange > 2.5f) {
            Skill s = new Skill();
            s.damage = p.kit.autoDamage;
            s.range = p.kit.autoRange + 0.5f;
            s.speed = 12;
            s.radius = 0.2f;
            shoot(p, s, p.face, false, 0);
        } else {
            damage(p, t, p.kit.autoDamage, false);
        }
    }

    // ------------------------------------------------------------------ hits
    boolean enemies(Fighter a, Fighter b) {
        if (a == b) return false;
        if (b.box || a.box) return !a.box;
        return a.team != b.team;
    }

    void damage(Fighter from, Fighter to, int dmg, boolean ulti) {
        if (!to.alive || dmg <= 0) return;
        float d = dmg;
        if (to.shieldUntil > time) d *= 0.3f;
        if (to.hyperUntil > time) d *= 1 - to.kit.hyperShield;
        if (from != null && from.hyperUntil > time) d *= 1 + from.kit.hyperDamage;
        if (from != null && !from.pet && !to.box && from.hyperUntil <= time && from.kit.hyperMul > 0) {
            from.hyper = Math.min(1, from.hyper + dmg / POWER * from.kit.hyperMul / 100f / 4400f);
        }
        if (from != null && from.cubes > 0) d *= 1 + 0.1f * from.cubes;
        if (from != null && !ulti && !from.pet && !to.box) {
            float mul = ulti ? from.kit.ultiUltiMul : from.kit.ultiMul;
            from.superCharge = Math.min(1, from.superCharge + dmg / POWER * mul / 100f / 4400f);
        } else if (from != null && ulti && !to.box) {
            from.superCharge = Math.min(1, from.superCharge + dmg / POWER * from.kit.ultiUltiMul / 100f / 4400f);
        }
        if (from != null && !from.pet) from.damageDone += (int) d;
        else if (from != null) {
            Fighter o = byId(from.ownerId);
            if (o != null) o.damageDone += (int) d;
        }
        hurt(from, to, d, ulti ? 0xFFFFD84A : 0xFFFFFFFF);
    }

    void hurt(Fighter from, Fighter to, float d, int color) {
        to.hp -= d;
        to.flash = 0.12f;
        to.lastHurt = time;
        if (to.invisUntil > time && from != null) to.invisUntil = time;
        Popup p = new Popup();
        p.x = to.x + (rnd.nextFloat() - 0.5f) * 0.3f;
        p.z = to.z;
        p.text = String.valueOf(Math.round(d));
        p.color = color;
        popups.add(p);
        events.add("hit:" + to.id);
        fx.add(new Object[]{"hurt", to});
        if (to.hp <= 0) die(from, to);
    }

    void healUnit(Fighter f, int amount) {
        if (!f.alive || amount <= 0) return;
        f.hp = Math.min(f.maxHp, f.hp + amount);
        Popup p = new Popup();
        p.x = f.x;
        p.z = f.z;
        p.text = "+" + amount;
        p.color = 0xFF5BE35B;
        popups.add(p);
    }

    void die(Fighter killer, Fighter f) {
        f.hp = 0;
        f.alive = false;
        f.respawnIn = respawnTime;
        f.deaths++;
        f.dashLeft = 0;
        events.add("dead:" + f.id);
        fx.add(new Object[]{"dead", f});
        Fighter credit = killer != null && killer.pet ? byId(killer.ownerId) : killer;
        if (f.box) {
            dropItem(2, f.x, f.z);
            return;
        }
        if (credit != null && !f.pet) {
            credit.kills++;
            events.add("kill:" + credit.id);
        }
        if (f.pet) return;
        // pets die with their owner
        for (Fighter o : fighters) if (o.pet && o.ownerId == f.id) o.alive = false;
        if (mode == Mode.GEM && f.gems > 0) {
            for (int i = 0; i < f.gems; i++) dropItem(0, f.x, f.z);
            f.gems = 0;
        }
        if (mode == Mode.BALL && ballCarrier == f.id) {
            ballCarrier = -1;
            ballX = f.x;
            ballZ = f.z;
            ballVx = ballVz = 0;
        }
        if (mode == Mode.BOUNTY && credit != null && credit.team != f.team) {
            score[credit.team] += f.bounty;
            credit.bounty = Math.min(7, credit.bounty + 1);
            f.bounty = 2;
        }
        if (mode == Mode.SHOWDOWN) {
            for (int i = 0; i < Math.max(1, f.cubes); i++) dropItem(2, f.x, f.z);
        }
    }

    void dropItem(int type, float x, float z) {
        Item it = new Item();
        it.type = type;
        it.x = x;
        it.z = z;
        double a = rnd.nextDouble() * Math.PI * 2;
        float sp = 1.5f + rnd.nextFloat() * 2.5f;
        it.vx = (float) Math.cos(a) * sp;
        it.vz = (float) Math.sin(a) * sp;
        items.add(it);
    }

    void breakAround(float x, float z, float r) {
        for (int rr = (int) Math.floor(z - r); rr <= (int) Math.floor(z + r); rr++) {
            for (int c = (int) Math.floor(x - r); c <= (int) Math.floor(x + r); c++) {
                if (Math.hypot(c + 0.5f - x, rr + 0.5f - z) <= r + 0.5f) {
                    if (breakable(c, rr) && (blocksMove(c, rr) || isBush(c, rr))) {
                        breakCell(c, rr);
                        events.add("wall:0");
                    }
                }
            }
        }
    }

    void stepShots(float dt) {
        for (Shot s : shots) {
            if (s.lob) {
                s.flight += dt;
                if (s.flight < 0) continue;
                float t = Math.min(1, s.flight / s.total);
                float sx = s.tx - s.dx, sz = s.tz - s.dz;
                s.x = sx + s.dx * t;
                s.z = sz + s.dz * t;
                s.h = 0.6f + 4 * t * (1 - t) * Math.min(3.5f, s.total * 4);
                if (t >= 1) {
                    s.dead = true;
                    Fighter f = byId(s.owner);
                    Area a = new Area();
                    a.x = s.tx;
                    a.z = s.tz;
                    a.radius = Math.max(0.8f, s.radius);
                    a.damage = s.damage;
                    a.team = s.team;
                    a.owner = s.owner;
                    a.left = s.skill != null && s.skill.areaTime > 0.9f ? s.skill.areaTime : 0.01f;
                    a.tick = s.skill != null ? s.skill.areaTick : 0.5f;
                    areas.add(a);
                    if (s.breaksWalls) breakAround(s.tx, s.tz, a.radius * 0.8f);
                    fx.add(new Object[]{"area", s.tx, s.tz, s.skill != null ? s.skill.areaName : "", f, a.radius});
                    if (s.skill != null && s.skill.summon != null && f != null) summon(f, s.skill.summon, s.tx, s.tz);
                    events.add("boom:" + s.owner);
                }
                continue;
            }
            s.age += dt;
            float dist = s.speed * dt;
            while (dist > 0 && !s.dead) {
                float d = Math.min(0.1f, dist);
                dist -= d;
                s.x += s.dx * d;
                s.z += s.dz * d;
                s.left -= d;
                if (s.left <= 0) {
                    s.dead = true;
                    fx.add(new Object[]{"reach", s.x, s.z, s, null});
                    break;
                }
                int c = (int) Math.floor(s.x), r = (int) Math.floor(s.z);
                if (blocksShot(c, r)) {
                    if (s.breaksWalls && breakable(c, r)) {
                        fx.add(new Object[]{"wall", c, r, cell(c, r)});
                        breakCell(c, r);
                        events.add("wall:0");
                    } else {
                        s.dead = true;
                        fx.add(new Object[]{"hitEnv", s.x - s.dx * 0.1f, s.z - s.dz * 0.1f, s, null});
                        break;
                    }
                }
                if (s.breaksWalls && isBush(c, r) && breakable(c, r)) breakCell(c, r);
                for (Fighter o : fighters) {
                    if (!o.alive || s.hit.contains(o.id)) continue;
                    if (!o.box && o.team == s.team) continue;
                    float rr = o.kit.radius + s.radius;
                    if ((o.x - s.x) * (o.x - s.x) + (o.z - s.z) * (o.z - s.z) > rr * rr) continue;
                    s.hit.add(o.id);
                    Fighter from = byId(s.owner);
                    fx.add(new Object[]{"hitChar", s.x, s.z, s, o});
                    damage(from, o, s.damage, s.ulti);
                    if (s.skill != null && s.skill.areaRadius > 0 && s.skill.kind == Kind.SHOT && s.skill.areaDamage > 0 && !s.pierceChars) {
                        Area a = new Area();
                        a.x = s.x;
                        a.z = s.z;
                        a.radius = s.skill.areaRadius;
                        a.damage = s.skill.areaDamage;
                        a.team = s.team;
                        a.owner = s.owner;
                        a.left = 0.01f;
                        a.hitOnce = o.id;
                        areas.add(a);
                    }
                    if (!s.pierceChars) {
                        s.dead = true;
                        break;
                    }
                }
            }
        }
        shots.removeIf(s -> s.dead);
    }

    void stepAreas(float dt) {
        for (Area a : areas) {
            if (a.follow) {
                Fighter f = byId(a.owner);
                if (f != null && f.alive) {
                    a.x = f.x;
                    a.z = f.z;
                } else {
                    a.left = 0;
                }
            }
            a.next -= dt;
            if (a.next <= 0) {
                a.next = a.tick;
                Fighter from = byId(a.owner);
                for (Fighter o : fighters) {
                    if (!o.alive || o.id == a.hitOnce) continue;
                    if (Math.hypot(o.x - a.x, o.z - a.z) > a.radius + o.kit.radius * 0.5f) continue;
                    if (a.heal) {
                        if (!o.box && o.team == a.team) healUnit(o, a.damage);
                    } else if (o.box || o.team != a.team) {
                        if (from != null) damage(from, o, a.damage, false);
                        else hurt(null, o, a.damage, 0xFFFFFFFF);
                    }
                }
            }
            a.left -= dt;
        }
        areas.removeIf(a -> a.left <= 0);
    }

    void stepItems(float dt) {
        for (Item it : items) {
            it.age += dt;
            if (it.vx != 0 || it.vz != 0) {
                float nx = it.x + it.vx * dt, nz = it.z + it.vz * dt;
                if (!collides(nx, nz, 0.2f)) {
                    it.x = nx;
                    it.z = nz;
                }
                it.vx *= Math.max(0, 1 - 4 * dt);
                it.vz *= Math.max(0, 1 - 4 * dt);
                if (Math.abs(it.vx) + Math.abs(it.vz) < 0.05f) it.vx = it.vz = 0;
            }
            if (it.age < 0.4f) continue;
            for (Fighter f : fighters) {
                if (!f.alive || f.pet || f.box) continue;
                if (Math.hypot(f.x - it.x, f.z - it.z) > f.kit.radius + 0.35f) continue;
                if (it.type == 0) {
                    f.gems++;
                    events.add("gem:" + f.id);
                } else if (it.type == 2) {
                    f.cubes++;
                    f.maxHp += 400 * POWER / 2;
                    f.hp += 400 * POWER / 2;
                    events.add("cube:" + f.id);
                } else {
                    events.add("star:" + f.id);
                }
                it.age = -999;
                break;
            }
        }
        items.removeIf(i -> i.age < -100);
    }

    // ------------------------------------------------------------------ modes
    void stepMode(float dt) {
        switch (mode) {
            case GEM: gems(dt); break;
            case BALL: ball(dt); break;
            case BOUNTY: if (roundTime >= timeLimit) finishByScore(); break;
            case SHOWDOWN: showdown(dt); break;
            case KNOCKOUT: knockout(dt); break;
            default: break;
        }
    }

    void gems(float dt) {
        gemTimer -= dt;
        int onField = items.size();
        int carried = 0;
        for (Fighter f : fighters) carried += f.gems;
        if (gemTimer <= 0) {
            gemTimer = 7;
            if (onField + carried < 29) {
                dropItem(0, mineX, mineZ);
                events.add("gemspawn:0");
            }
        }
        int[] g = new int[2];
        for (Fighter f : fighters) if (!f.pet && !f.box && f.team >= 0 && f.team < 2) g[f.team] += f.gems;
        score[0] = g[0];
        score[1] = g[1];
        int lead = g[0] >= 10 && g[0] > g[1] ? 0 : g[1] >= 10 && g[1] > g[0] ? 1 : -1;
        if (lead < 0) {
            gemCountdown = -1;
            gemCountdownTeam = -1;
        } else {
            if (gemCountdownTeam != lead) {
                gemCountdownTeam = lead;
                gemCountdown = 15;
                events.add("countdown:" + lead);
            }
            gemCountdown -= dt;
            if (gemCountdown <= 0) end(lead);
        }
        if (roundTime >= timeLimit && gemCountdownTeam < 0) finishByScore();
    }

    void ball(float dt) {
        if (superKick > 0) superKick -= dt;
        ballNoPick -= dt;
        Fighter c = ballCarrier >= 0 ? byId(ballCarrier) : null;
        if (c != null && c.alive) {
            ballX = c.x + (float) Math.sin(c.face) * 0.35f;
            ballZ = c.z + (float) Math.cos(c.face) * 0.35f;
            ballH = 0.25f;
        } else {
            ballCarrier = -1;
            float sp = (float) Math.hypot(ballVx, ballVz);
            if (sp > 0) {
                float steps = Math.max(1, sp * dt / 0.1f);
                for (int i = 0; i < steps; i++) {
                    float nx = ballX + ballVx * dt / steps, nz = ballZ + ballVz * dt / steps;
                    int cx = (int) Math.floor(nx), cz = (int) Math.floor(nz);
                    boolean goalZone = cz < 0 || cz >= height;
                    if (!goalZone && blocksShot(cx, cz)) {
                        if (superKick > 0 && breakable(cx, cz)) {
                            breakCell(cx, cz);
                        } else {
                            if (blocksShot((int) Math.floor(nx), (int) Math.floor(ballZ))) ballVx = -ballVx * 0.6f;
                            else ballVz = -ballVz * 0.6f;
                            break;
                        }
                    }
                    ballX = nx;
                    ballZ = nz;
                }
                float fr = Math.max(0, 1 - 1.3f * dt);
                ballVx *= fr;
                ballVz *= fr;
                if (Math.hypot(ballVx, ballVz) < 0.3f) ballVx = ballVz = 0;
            }
            ballH = Math.max(0, ballH - dt * 1.5f);
        }
        // goals: team 0 scores at the top, team 1 at the bottom
        boolean inCols = ballX >= goalLeft && ballX <= goalRight + 1;
        if (inCols && ballZ < 0.45f) goal(0);
        else if (inCols && ballZ > height - 0.45f) goal(1);
        ballX = Math.max(0.3f, Math.min(width - 0.3f, ballX));
        ballZ = Math.max(0.2f, Math.min(height - 0.2f, ballZ));
        if (roundTime >= timeLimit) finishByScore();
    }

    void goal(int team) {
        score[team]++;
        events.add("goal:" + team);
        message = team == 0 ? "ГОЛ синих!" : "ГОЛ красных!";
        messageUntil = 2.5f;
        if (score[team] >= 2) {
            end(team);
            return;
        }
        resetIn = 3;
        resetBall();
    }

    /** after a goal / a knockout round: everybody back to their spawn */
    void kickoff() {
        resetBall();
        for (Fighter f : fighters) {
            if (f.box) continue;
            if (f.pet) {
                f.alive = false;
                continue;
            }
            f.alive = true;
            f.hp = f.maxHp;
            f.x = f.spawnX;
            f.z = f.spawnZ;
            f.ammo = f.kit.weapon.maxCharge;
            f.dashLeft = 0;
        }
        fighters.removeIf(f -> f.pet);
        shots.clear();
        areas.clear();
        if (mode == Mode.KNOCKOUT) {
            for (int r = 0; r < height; r++) cells[r] = startCells[r].clone();
            brokenCells.clear();
            mapVersion++;
            poison = 0;
            roundTime = 0;
        }
    }

    void showdown(float dt) {
        if (roundTime > 35) poison = Math.min(Math.min(width, height) / 2f - 2.5f, (roundTime - 35) / 7f);
        int alive = 0, last = -1;
        for (Fighter f : fighters) {
            if (f.alive && !f.pet && !f.box) {
                alive++;
                last = f.id;
            }
        }
        if (alive <= 1) {
            winner = last;
            over = true;
            Fighter w = byId(last);
            message = w != null ? "Победил: " + w.name : "Ничья";
            messageUntil = 999;
            events.add("end:" + last);
        }
    }

    void knockout(float dt) {
        if (roundTime > 45) poison = Math.min(Math.min(width, height) / 2f - 2.5f, (roundTime - 45) / 5f);
        int[] alive = new int[2];
        for (Fighter f : fighters) if (f.alive && !f.pet && !f.box && f.team >= 0 && f.team < 2) alive[f.team]++;
        int roundWinner = alive[0] == 0 && alive[1] == 0 ? -2 : alive[1] == 0 ? 0 : alive[0] == 0 ? 1 : -1;
        if (roundWinner == -1) return;
        if (roundWinner >= 0) {
            roundWins[roundWinner]++;
            score[roundWinner] = roundWins[roundWinner];
        }
        events.add("round:" + roundWinner);
        if (roundWinner >= 0 && roundWins[roundWinner] >= 2) {
            end(roundWinner);
            return;
        }
        round++;
        message = "Раунд " + round;
        messageUntil = 2.5f;
        resetIn = 3;
    }

    void finishByScore() {
        if (score[0] == score[1]) end(-2);
        else end(score[0] > score[1] ? 0 : 1);
    }

    void end(int team) {
        winner = team;
        over = true;
        message = team == -2 ? "Ничья" : team == 0 ? "Победа синих" : "Победа красных";
        messageUntil = 999;
        events.add("end:" + team);
    }

    // ------------------------------------------------------------------ bots
    /** nearest enemy the fighter could see (bushes hide unless close) */
    public Fighter nearestEnemy(Fighter f, float range, boolean includeBoxes) {
        Fighter best = null;
        float bd = range * range;
        for (Fighter o : fighters) {
            if (!o.alive || !enemies(f, o)) continue;
            if (o.box && !includeBoxes && mode != Mode.SHOWDOWN) continue;
            if (!visibleTo(o, f)) continue;
            float dx = o.x - f.x, dz = o.z - f.z, d = dx * dx + dz * dz;
            if (o.box) d += 4; // brawlers first
            if (d < bd) {
                bd = d;
                best = o;
            }
        }
        return best;
    }

    /** can {@code viewer} see {@code o}? (bushes and invisibility) */
    public boolean visibleTo(Fighter o, Fighter viewer) {
        if (viewer == null || o.box || !enemies(viewer, o)) return true;
        float d = (float) Math.hypot(o.x - viewer.x, o.z - viewer.z);
        if (o.invisUntil > time && d > 1.5f) return false;
        if (o.inBush && d > 2.2f && time - o.lastAttack > 1 && time - o.lastHurt > 1) return false;
        return true;
    }

    void think(Fighter f, float dt) {
        f.thinkIn -= dt;
        if (f.pet) {
            Fighter t = nearestEnemy(f, 12, false);
            Fighter owner = byId(f.ownerId);
            float gx, gz;
            if (t != null) {
                gx = t.x;
                gz = t.z;
            } else if (owner != null && owner.alive) {
                gx = owner.x + 1;
                gz = owner.z;
            } else {
                gx = f.x;
                gz = f.z;
            }
            steer(f, gx, gz, t != null ? Math.max(0.6f, f.kit.autoRange * 0.8f) : 1.2f);
            return;
        }
        if (f.thinkIn > 0) return;
        f.thinkIn = 0.15f + rnd.nextFloat() * 0.1f;
        Skill w = f.kit.weapon;
        Fighter enemy = nearestEnemy(f, 11, mode == Mode.SHOWDOWN);
        float hpPart = f.hp / f.maxHp;
        float gx = -1, gz = -1, keep = 0.5f;
        boolean fight = enemy != null;
        // mode goals
        switch (mode) {
            case GEM: {
                Item gem = nearestItem(f, 0);
                if (f.gems >= 4 || (gemCountdownTeam == f.team && f.gems > 0)) {
                    gx = f.spawnX;
                    gz = f.spawnZ;
                    if (enemy != null && Math.hypot(enemy.x - f.x, enemy.z - f.z) > w.range) fight = false;
                } else if (gem != null && (enemy == null || Math.hypot(gem.x - f.x, gem.z - f.z) < 4)) {
                    gx = gem.x;
                    gz = gem.z;
                    keep = 0;
                } else {
                    gx = mineX;
                    gz = mineZ + (f.team == 0 ? 2.5f : -2.5f);
                }
                break;
            }
            case BALL: {
                float goalX = (goalLeft + goalRight + 1) / 2f, goalZ = f.team == 0 ? 0 : height;
                if (ballCarrier == f.id) {
                    gx = goalX;
                    gz = goalZ;
                    keep = 0;
                    float d = (float) Math.hypot(goalX - f.x, goalZ - f.z);
                    if (d < 7 && lineOfSight(f.x, f.z, goalX, f.team == 0 ? 0.5f : height - 0.5f)) {
                        use(f, f.superCharge >= 1 ? 1 : 0, goalX - f.x, goalZ - f.z);
                        return;
                    }
                    fight = false;
                } else if (ballCarrier < 0) {
                    gx = ballX;
                    gz = ballZ;
                    keep = 0;
                } else {
                    Fighter c = byId(ballCarrier);
                    if (c != null && c.team != f.team) {
                        gx = c.x;
                        gz = c.z;
                        enemy = c;
                        fight = true;
                    } else if (c != null) {
                        gx = c.x + (c.team == 0 ? 0 : 0);
                        gz = c.z + (f.team == 0 ? -2.5f : 2.5f);
                    }
                }
                break;
            }
            case SHOWDOWN: {
                Item cube = nearestItem(f, 2);
                if (cube != null && Math.hypot(cube.x - f.x, cube.z - f.z) < 8) {
                    gx = cube.x;
                    gz = cube.z;
                    keep = 0;
                } else if (enemy == null) {
                    gx = width / 2f + (f.id % 5 - 2) * 2;
                    gz = height / 2f + (f.id % 3 - 1) * 2;
                }
                if (inPoison(f) || poison > 0 && (f.x < poison + 1.5f || f.z < poison + 1.5f || f.x > width - poison - 1.5f || f.z > height - poison - 1.5f)) {
                    gx = width / 2f;
                    gz = height / 2f;
                    keep = 0;
                }
                break;
            }
            default: {
                if (enemy == null) {
                    Fighter far = null;
                    float fd = Float.MAX_VALUE;
                    for (Fighter o : fighters) {
                        if (!o.alive || o.box || !enemies(f, o)) continue;
                        float dd = (o.x - f.x) * (o.x - f.x) + (o.z - f.z) * (o.z - f.z);
                        if (dd < fd) {
                            fd = dd;
                            far = o;
                        }
                    }
                    if (far != null) {
                        gx = far.x;
                        gz = far.z;
                    } else {
                        gx = width / 2f;
                        gz = height / 2f;
                    }
                }
                if (mode == Mode.KNOCKOUT && poison > 0 && (f.x < poison + 1.5f || f.z < poison + 1.5f || f.x > width - poison - 1.5f || f.z > height - poison - 1.5f)) {
                    gx = width / 2f;
                    gz = height / 2f;
                }
                break;
            }
        }
        // low health: back off and heal
        if (hpPart < 0.33f && enemy != null && mode != Mode.SHOWDOWN && ballCarrier != f.id) {
            float dx = f.x - enemy.x, dz = f.z - enemy.z, l = (float) Math.max(0.1, Math.hypot(dx, dz));
            gx = f.x + dx / l * 4;
            gz = f.z + dz / l * 4;
            keep = 0;
        }
        if (fight && enemy != null) {
            float d = (float) Math.hypot(enemy.x - f.x, enemy.z - f.z);
            boolean sees = lineOfSight(f.x, f.z, enemy.x, enemy.z) || w.kind == Kind.LOB;
            float want = w.kind == Kind.AREA || w.kind == Kind.CHARGE || w.range < 3.5f ? 0.5f : w.range * 0.75f;
            if (gx < 0 || hpPart >= 0.33f) {
                if (d > want + 0.5f || !sees) {
                    gx = enemy.x;
                    gz = enemy.z;
                    keep = sees ? want : 0.5f;
                } else if (d < want - 1.5f) {
                    float dx = f.x - enemy.x, dz = f.z - enemy.z;
                    gx = f.x + dx / d * 2;
                    gz = f.z + dz / d * 2;
                    keep = 0;
                } else { // strafe sideways
                    float dx = enemy.x - f.x, dz = enemy.z - f.z;
                    gx = f.x - dz / d * 2 * f.strafe;
                    gz = f.z + dx / d * 2 * f.strafe;
                    keep = 0;
                    if (rnd.nextFloat() < 0.05f) f.strafe = -f.strafe;
                }
            }
            // shoot
            float lead = d / Math.max(4, w.speed);
            float px = enemy.x + enemy.mx * enemy.kit.speed * lead * 0.6f, pz = enemy.z + enemy.mz * enemy.kit.speed * lead * 0.6f;
            float ang = (float) Math.atan2(px - f.x, pz - f.z) + (rnd.nextFloat() - 0.5f) * 2 * f.aimErr;
            float dist = (float) Math.hypot(px - f.x, pz - f.z);
            float ax = (float) Math.sin(ang) * Math.min(1, dist / w.range), az = (float) Math.cos(ang) * Math.min(1, dist / w.range);
            if (Math.abs(ax) + Math.abs(az) < 0.2f) {
                ax = (float) Math.sin(ang) * 0.25f;
                az = (float) Math.cos(ang) * 0.25f;
            }
            if (sees && f.superCharge >= 1 && d < f.kit.ulti.range * 0.95f && rnd.nextFloat() < 0.5f && ballCarrier != f.id) {
                use(f, 1, ax, az);
            } else if (sees && d < w.range * 0.95f && f.ammo >= 1 && rnd.nextFloat() < 0.55f && ballCarrier != f.id) {
                use(f, 0, ax, az);
            } else if (f.gadgets > 0 && hpPart < 0.5f && rnd.nextFloat() < 0.04f) {
                use(f, 2, ax, az);
            }
        }
        f.goalX = gx;
        f.goalZ = gz;
        f.keep = keep;
        steer(f, gx, gz, keep);
    }

    float keepOf(Fighter f) {
        return f.keep;
    }

    Item nearestItem(Fighter f, int type) {
        Item best = null;
        float bd = Float.MAX_VALUE;
        for (Item it : items) {
            if (it.type != type) continue;
            float d = (it.x - f.x) * (it.x - f.x) + (it.z - f.z) * (it.z - f.z);
            if (d < bd) {
                bd = d;
                best = it;
            }
        }
        return best;
    }

    /** sets the bot's stick towards a point, around walls (distance field over the tiles) */
    void steer(Fighter f, float gx, float gz, float keep) {
        if (gx < 0) {
            f.mx = f.mz = 0;
            return;
        }
        float dx = gx - f.x, dz = gz - f.z, d = (float) Math.hypot(dx, dz);
        if (d <= keep + 0.15f) {
            f.mx = f.mz = 0;
            return;
        }
        int tc = Math.max(0, Math.min(width - 1, (int) gx)), tr = Math.max(0, Math.min(height - 1, (int) gz));
        if (blocksMove(tc, tr)) { // aim at the nearest open tile instead
            int bestD = Integer.MAX_VALUE, bc0 = tc, br0 = tr;
            for (int rr = Math.max(0, tr - 4); rr <= Math.min(height - 1, tr + 4); rr++) {
                for (int cc = Math.max(0, tc - 4); cc <= Math.min(width - 1, tc + 4); cc++) {
                    if (blocksMove(cc, rr)) continue;
                    int dd = (cc - tc) * (cc - tc) + (rr - tr) * (rr - tr);
                    if (dd < bestD) {
                        bestD = dd;
                        bc0 = cc;
                        br0 = rr;
                    }
                }
            }
            tc = bc0;
            tr = br0;
        }
        int[] field = field(tc, tr);
        int fc = (int) f.x, fr = (int) f.z;
        int here = field[fr * width + fc];
        if (here <= 1 || here == Integer.MAX_VALUE) {
            f.mx = dx / Math.max(0.01f, d);
            f.mz = dz / Math.max(0.01f, d);
            return;
        }
        // look a few tiles ahead along the field and aim at the furthest tile we can walk straight to
        int bc = fc, br = fr, best = here;
        for (int k = 0; k < 4; k++) {
            int nc = bc, nr = br;
            for (int oy = -1; oy <= 1; oy++) {
                for (int ox = -1; ox <= 1; ox++) {
                    int c = bc + ox, r = br + oy;
                    if (c < 0 || r < 0 || c >= width || r >= height) continue;
                    if (ox != 0 && oy != 0 && (blocksMove(bc + ox, br) || blocksMove(bc, br + oy))) continue;
                    int v = field[r * width + c];
                    if (v < best) {
                        best = v;
                        nc = c;
                        nr = r;
                    }
                }
            }
            if (nc == bc && nr == br) break;
            if (k > 0 && !walkable(f.x, f.z, nc + 0.5f, nr + 0.5f, f.kit.radius)) break;
            bc = nc;
            br = nr;
        }
        float tx = bc + 0.5f - f.x, tz = br + 0.5f - f.z, tl = (float) Math.hypot(tx, tz);
        if (tl < 0.05f) {
            f.mx = dx / d;
            f.mz = dz / d;
        } else {
            f.mx = tx / tl;
            f.mz = tz / tl;
        }
    }

    /** can a circle walk straight from a to b? */
    boolean walkable(float ax, float az, float bx, float bz, float rad) {
        float dx = bx - ax, dz = bz - az, d = (float) Math.hypot(dx, dz);
        int n = (int) (d / 0.2f) + 1;
        for (int i = 1; i <= n; i++) {
            float t = i / (float) n;
            if (collides(ax + dx * t, az + dz * t, rad * 0.95f)) return false;
        }
        return true;
    }

    private final Map<Integer, int[]> fields = new HashMap<>();
    private int fieldsVersion = -1;

    int[] field(int tc, int tr) {
        if (fieldsVersion != mapVersion) {
            fields.clear();
            fieldsVersion = mapVersion;
        }
        int key = tr * width + tc;
        int[] f = fields.get(key);
        if (f != null) return f;
        f = new int[width * height];
        Arrays.fill(f, Integer.MAX_VALUE);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        f[key] = 0;
        q.add(key);
        while (!q.isEmpty()) {
            int k = q.poll();
            int c = k % width, r = k / width;
            for (int o = 0; o < 4; o++) {
                int nc = c + (o == 0 ? 1 : o == 1 ? -1 : 0), nr = r + (o == 2 ? 1 : o == 3 ? -1 : 0);
                if (nc < 0 || nr < 0 || nc >= width || nr >= height || blocksMove(nc, nr)) continue;
                int nk = nr * width + nc;
                if (f[nk] != Integer.MAX_VALUE) continue;
                f[nk] = f[k] + 1;
                q.add(nk);
            }
        }
        if (fields.size() > 200) fields.clear();
        fields.put(key, f);
        return f;
    }

    // ------------------------------------------------------------------ network snapshot
    /** everything a player's screen needs, as one compact line */
    public String snapshot() {
        StringBuilder sb = new StringBuilder(2048);
        sb.append(f1(time)).append(',').append(f1(roundTime)).append(',').append(score[0]).append(',').append(score[1]).append(',')
                .append(round).append(',').append(f1(gemCountdown)).append(',').append(gemCountdownTeam).append(',').append(f1(poison)).append(',')
                .append(winner).append(',').append(over ? 1 : 0).append(',').append(f1(resetIn)).append(',').append(f2(ballX)).append(',')
                .append(f2(ballZ)).append(',').append(f1(ballH)).append(',').append(ballCarrier).append(',').append(f1(messageUntil)).append(',')
                .append(esc(message)).append('|');
        for (Fighter f : fighters) {
            sb.append(f.id).append(',').append(f.team).append(',').append(esc(f.kit.code)).append(',').append(esc(f.kit.skin == null ? "" : f.kit.skin)).append(',')
                    .append(esc(f.owner)).append(',').append(esc(f.name)).append(',').append(f2(f.x)).append(',').append(f2(f.z)).append(',')
                    .append(f2(f.face)).append(',').append((int) f.hp).append(',').append((int) f.maxHp).append(',').append(f2(f.ammo)).append(',')
                    .append(f2(f.superCharge)).append(',').append(f.alive ? 1 : 0).append(',').append(actionCode(f.action)).append(',')
                    .append(f1(time - f.actionStart)).append(',').append(f.gems).append(',').append(f.bounty).append(',').append(f.cubes).append(',')
                    .append(f.flash > 0 ? 1 : 0).append(',').append(f.inBush ? 1 : 0).append(',').append(f1(Math.max(0, f.invisUntil - time))).append(',')
                    .append(f1(Math.max(0, f.respawnIn))).append(',').append(f.gadgets).append(',').append(f.box ? 1 : f.pet ? 2 : 0).append(',')
                    .append(f.kills).append(',').append(f1(Math.max(0, f.shieldUntil - time))).append(';');
        }
        sb.append('|');
        for (Shot s : shots) {
            if (s.lob && s.flight < 0) continue;
            sb.append(f2(s.x)).append(',').append(f2(s.z)).append(',').append(f1(s.h)).append(',').append(s.team).append(',')
                    .append(s.ulti ? 1 : 0).append(',').append(f2(s.radius)).append(';');
        }
        sb.append('|');
        for (Area a : areas) sb.append(f2(a.x)).append(',').append(f2(a.z)).append(',').append(f2(a.radius)).append(',').append(a.team).append(',').append(a.heal ? 1 : 0).append(';');
        sb.append('|');
        for (Item it : items) sb.append(it.type).append(',').append(f2(it.x)).append(',').append(f2(it.z)).append(';');
        sb.append('|');
        for (int[] c : brokenCells) sb.append(c[0]).append(',').append(c[1]).append(';');
        sb.append('|');
        for (Popup p : popups) if (p.age < 0.05f) sb.append(f2(p.x)).append(',').append(f2(p.z)).append(',').append(esc(p.text)).append(',').append(p.color).append(';');
        sb.append('|');
        for (String e : events) sb.append(esc(e)).append(';');
        return sb.toString();
    }

    /** applies a host snapshot (client side) */
    public void apply(String s) {
        String[] part = s.split("\\|", -1);
        if (part.length < 8) return;
        String[] h = part[0].split(",", -1);
        time = pf(h[0]);
        roundTime = pf(h[1]);
        score[0] = pi(h[2]);
        score[1] = pi(h[3]);
        round = pi(h[4]);
        gemCountdown = pf(h[5]);
        gemCountdownTeam = pi(h[6]);
        poison = pf(h[7]);
        winner = pi(h[8]);
        over = "1".equals(h[9]);
        resetIn = pf(h[10]);
        ballX = pf(h[11]);
        ballZ = pf(h[12]);
        ballH = pf(h[13]);
        ballCarrier = pi(h[14]);
        messageUntil = pf(h[15]);
        message = unesc(h[16]);
        Map<Integer, Fighter> old = new HashMap<>();
        for (Fighter f : fighters) old.put(f.id, f);
        fighters.clear();
        for (String e : part[1].split(";")) {
            if (e.isEmpty()) continue;
            String[] v = e.split(",", -1);
            if (v.length < 27) continue;
            int id = pi(v[0]);
            Fighter f = old.containsKey(id) ? old.get(id) : new Fighter();
            f.id = id;
            f.team = pi(v[1]);
            String code = unesc(v[2]), skin = unesc(v[3]);
            if (f.kit == null || !f.kit.code.equals(code) || !skin.equals(f.kit.skin)) {
                f.kit = copyKit(kit(code));
                f.kit.skin = skin;
            }
            f.owner = unesc(v[4]);
            f.name = unesc(v[5]);
            f.x = pf(v[6]);
            f.z = pf(v[7]);
            f.face = pf(v[8]);
            f.hp = pi(v[9]);
            f.maxHp = Math.max(1, pi(v[10]));
            f.ammo = pf(v[11]);
            f.superCharge = pf(v[12]);
            f.alive = "1".equals(v[13]);
            f.action = actionName(pi(v[14]));
            f.actionStart = time - pf(v[15]);
            f.gems = pi(v[16]);
            f.bounty = pi(v[17]);
            f.cubes = pi(v[18]);
            f.flash = "1".equals(v[19]) ? 0.1f : 0;
            f.inBush = "1".equals(v[20]);
            f.invisUntil = time + pf(v[21]);
            f.respawnIn = pf(v[22]);
            f.gadgets = pi(v[23]);
            int kind = pi(v[24]);
            f.box = kind == 1;
            f.pet = kind == 2;
            f.bot = "bot".equals(f.owner);
            f.kills = pi(v[25]);
            f.shieldUntil = time + pf(v[26]);
            fighters.add(f);
        }
        shots.clear();
        for (String e : part[2].split(";")) {
            if (e.isEmpty()) continue;
            String[] v = e.split(",", -1);
            Shot sh = new Shot();
            sh.x = pf(v[0]);
            sh.z = pf(v[1]);
            sh.h = pf(v[2]);
            sh.team = pi(v[3]);
            sh.ulti = "1".equals(v[4]);
            sh.radius = pf(v[5]);
            shots.add(sh);
        }
        areas.clear();
        for (String e : part[3].split(";")) {
            if (e.isEmpty()) continue;
            String[] v = e.split(",", -1);
            Area a = new Area();
            a.x = pf(v[0]);
            a.z = pf(v[1]);
            a.radius = pf(v[2]);
            a.team = pi(v[3]);
            a.heal = "1".equals(v[4]);
            areas.add(a);
        }
        items.clear();
        for (String e : part[4].split(";")) {
            if (e.isEmpty()) continue;
            String[] v = e.split(",", -1);
            Item it = new Item();
            it.type = pi(v[0]);
            it.x = pf(v[1]);
            it.z = pf(v[2]);
            items.add(it);
        }
        // map: start from the original and break what the host broke
        List<int[]> br = new ArrayList<>();
        for (String e : part[5].split(";")) {
            if (e.isEmpty()) continue;
            String[] v = e.split(",", -1);
            br.add(new int[]{pi(v[0]), pi(v[1])});
        }
        if (br.size() != brokenCells.size()) {
            for (int r = 0; r < height; r++) cells[r] = startCells[r].clone();
            for (int[] c : br) if (c[1] >= 0 && c[1] < height && c[0] >= 0 && c[0] < width) cells[c[1]][c[0]] = '.';
            brokenCells.clear();
            brokenCells.addAll(br);
            mapVersion++;
        }
        for (String e : part[6].split(";")) {
            if (e.isEmpty()) continue;
            String[] v = e.split(",", -1);
            if (v.length < 4) continue;
            Popup p = new Popup();
            p.x = pf(v[0]);
            p.z = pf(v[1]);
            p.text = unesc(v[2]);
            p.color = pi(v[3]);
            popups.add(p);
        }
        for (String e : part[7].split(";")) if (!e.isEmpty()) events.add(unesc(e));
    }

    /** client side: popups fade on their own between snapshots */
    public void clientTick(float dt) {
        time += dt;
        for (Popup p : popups) p.age += dt;
        popups.removeIf(p -> p.age > 1.1f);
        if (messageUntil > 0 && messageUntil < 900) messageUntil -= dt;
    }

    /** host: removes start tiles digits so a client battle has the same map (clients call it too) */
    public void prepareClientMap() {
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                char ch = cells[r][c];
                if (ch >= '0' && ch <= '9') cells[r][c] = startCells[r][c] = '.';
            }
        }
    }

    static int actionCode(String a) {
        switch (a) {
            case "walk": return 1;
            case "attack": return 2;
            case "ulti": return 3;
            default: return 0;
        }
    }

    static String actionName(int c) {
        switch (c) {
            case 1: return "walk";
            case 2: return "attack";
            case 3: return "ulti";
            default: return "idle";
        }
    }

    static String f1(float v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    static String f2(float v) {
        return String.format(Locale.ROOT, "%.2f", v);
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("%", "%25").replace(",", "%2C").replace(";", "%3B").replace("|", "%7C");
    }

    static String unesc(String s) {
        return s.replace("%7C", "|").replace("%3B", ";").replace("%2C", ",").replace("%25", "%");
    }

    static float pf(String s) {
        try {
            return Float.parseFloat(s);
        } catch (Exception e) {
            return 0;
        }
    }

    static int pi(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }
}
