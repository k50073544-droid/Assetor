package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Sc2;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Frame-by-frame viewer for one animated object, with selection and export of chosen frames. */
public final class FramesActivity extends Activity {

    /** Parsed file handed over from SpritesActivity (avoids parsing it twice). */
    static Sc2 holder;

    static final int REQ_SAVE = 1;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService big = Executors.newSingleThreadExecutor();
    private final ExecutorService small = Executors.newSingleThreadExecutor();
    private final LruCache<Integer, Bitmap> thumbs = new LruCache<Integer, Bitmap>(16 * 1024) {
        @Override
        protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount() / 1024; }
    };

    private Sc2 sc2;
    private String export;
    private float[] bounds;
    private int frames, fps;
    private int current;
    private int renderGen;
    private final TreeSet<Integer> selected = new TreeSet<>();

    private ZoomImageView view;
    private TextView label, markBtn, playBtn, saveBtn;
    private SeekBar seek;
    private Adapter adapter;
    private boolean playing;
    private int saveSize = 1024;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        sc2 = holder;
        export = getIntent().getStringExtra("export");
        if (sc2 == null || export == null) {
            finish();
            return;
        }
        frames = Math.max(1, sc2.frameCount(export));
        fps = sc2.fps(export);

        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, export, 17, Ui.TEXT));
        TextView hint = Ui.text(this, "Тап по кадру — показать. Долгое нажатие — отметить. Все кадры на одном холсте, чтобы их можно было склеить обратно.", 12, Ui.MUTED);
        hint.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 6));
        root.addView(hint);

        view = new ZoomImageView(this);
        root.addView(view, new LinearLayout.LayoutParams(-1, Ui.dp(this, 300)));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(0, Ui.dp(this, 6), 0, 0);
        TextView prev = Ui.button(this, "‹", false);
        TextView next = Ui.button(this, "›", false);
        prev.setOnClickListener(v -> show(current - 1));
        next.setOnClickListener(v -> show(current + 1));
        label = Ui.text(this, "", 13, Ui.TEXT);
        label.setGravity(Gravity.CENTER);
        nav.addView(prev);
        nav.addView(label, Ui.lp(0, -2, 1));
        nav.addView(next);
        root.addView(nav);

        seek = new SeekBar(this);
        seek.setMax(frames - 1);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) { if (user) show(v); }
            public void onStartTrackingTouch(SeekBar s) { stop(); }
            public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(seek);

        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 6));
        playBtn = Ui.button(this, "▶", false);
        playBtn.setOnClickListener(v -> {
            if (playing) stop();
            else play();
        });
        markBtn = Ui.button(this, "Отметить", false);
        markBtn.setOnClickListener(v -> toggle(current));
        TextView more = Ui.button(this, "Выбор…", false);
        more.setOnClickListener(v -> selectionMenu());
        saveBtn = Ui.button(this, "Сохранить", true);
        saveBtn.setOnClickListener(v -> saveMenu());
        LinearLayout.LayoutParams alp = Ui.lp(-2, -2, 0);
        alp.rightMargin = Ui.dp(this, 6);
        actions.addView(playBtn, alp);
        actions.addView(markBtn, new LinearLayout.LayoutParams(alp));
        actions.addView(more, new LinearLayout.LayoutParams(alp));
        actions.addView(saveBtn);
        root.addView(actions);

        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 72));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(Ui.dp(this, 4));
        grid.setVerticalSpacing(Ui.dp(this, 4));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        adapter = new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((pa, v, pos, id) -> {
            stop();
            show(pos);
        });
        grid.setOnItemLongClickListener((pa, v, pos, id) -> {
            toggle(pos);
            return true;
        });
        root.addView(grid, Ui.lp(-1, 0, 1));
        setContentView(root);

        big.execute(() -> {
            try {
                bounds = sc2.unionBounds(export);
                int rest = sc2.restFrame(export);
                main.post(() -> {
                    show(rest);
                    adapter.notifyDataSetChanged();
                });
            } catch (Exception e) {
                main.post(() -> label.setText("Ошибка: " + e.getMessage()));
            }
        });
    }

    // ------------------------------------------------------------------ viewing
    private void show(int f) {
        if (bounds == null) return;
        current = Math.floorMod(f, frames);
        seek.setProgress(current);
        updateLabel();
        final int gen = ++renderGen;
        final int frame = current;
        big.execute(() -> {
            if (gen != renderGen) return;
            try {
                Img im = sc2.renderFrame(export, frame, bounds, 768, 2);
                if (im == null) return;
                Bitmap bm = Decoders.toBitmap(im);
                main.post(() -> {
                    if (gen == renderGen) view.setBitmap(bm);
                });
            } catch (Exception ignored) {
                // keep previous frame
            }
        });
    }

    private void updateLabel() {
        double sec = current / (double) fps;
        label.setText(String.format(Locale.ROOT, "кадр %d / %d  ·  %.2f c%s", current + 1, frames, sec,
                selected.contains(current) ? "  ·  ✓" : ""));
        markBtn.setText(selected.contains(current) ? "Снять" : "Отметить");
        saveBtn.setText(selected.isEmpty() ? "Сохранить" : "Сохранить (" + selected.size() + ")");
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!playing) return;
            show(current + 1);
            main.postDelayed(this, Math.max(33, 1000 / Math.max(1, fps)));
        }
    };

    private void play() {
        playing = true;
        playBtn.setText("❚❚");
        main.post(tick);
    }

    private void stop() {
        playing = false;
        playBtn.setText("▶");
        main.removeCallbacks(tick);
    }

    // ------------------------------------------------------------------ selection
    private void toggle(int f) {
        if (!selected.remove(f)) selected.add(f);
        updateLabel();
        adapter.notifyDataSetChanged();
    }

    private void selectionMenu() {
        String[] items = {"Отметить все кадры", "Отметить каждый 2-й", "Отметить каждый 5-й", "Отметить диапазон…", "Снять все отметки"};
        new AlertDialog.Builder(this).setTitle("Выбор кадров").setItems(items, (d, w) -> {
            switch (w) {
                case 0: for (int i = 0; i < frames; i++) selected.add(i); break;
                case 1: for (int i = 0; i < frames; i += 2) selected.add(i); break;
                case 2: for (int i = 0; i < frames; i += 5) selected.add(i); break;
                case 3: rangeDialog(); return;
                default: selected.clear(); break;
            }
            updateLabel();
            adapter.notifyDataSetChanged();
        }).show();
    }

    private void rangeDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, p, p, 0);
        android.widget.EditText from = new android.widget.EditText(this);
        android.widget.EditText to = new android.widget.EditText(this);
        from.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        to.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        from.setHint("с кадра");
        to.setHint("по кадр");
        from.setText(String.valueOf(current + 1));
        to.setText(String.valueOf(frames));
        box.addView(from, Ui.lp(0, -2, 1));
        box.addView(to, Ui.lp(0, -2, 1));
        new AlertDialog.Builder(this).setTitle("Диапазон (1–" + frames + ")").setView(box)
                .setPositiveButton("Отметить", (d, w) -> {
                    try {
                        int a = Integer.parseInt(from.getText().toString().trim()) - 1;
                        int b = Integer.parseInt(to.getText().toString().trim()) - 1;
                        if (a > b) { int t = a; a = b; b = t; }
                        for (int i = Math.max(0, a); i <= Math.min(frames - 1, b); i++) selected.add(i);
                        updateLabel();
                        adapter.notifyDataSetChanged();
                    } catch (NumberFormatException ignored) {
                        Toast.makeText(this, "Введи номера кадров", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Отмена", null).show();
    }

    // ------------------------------------------------------------------ saving
    private void saveMenu() {
        stop();
        String what = selected.isEmpty() ? "текущий кадр (" + (current + 1) + ")" : "отмеченные кадры (" + selected.size() + ")";
        String[] sizes = {"512 px", "1024 px (рекомендую)", "2048 px"};
        int[] values = {512, 1024, 2048};
        new AlertDialog.Builder(this).setTitle("Сохранить " + what + " в PNG")
                .setItems(sizes, (d, w) -> {
                    saveSize = values[w];
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    startActivityForResult(i, REQ_SAVE);
                }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SAVE || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri tree = data.getData();
        List<Integer> list = new ArrayList<>(selected.isEmpty() ? java.util.Collections.singleton(current) : selected);
        int size = saveSize;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        TextView status = Ui.text(this, "Готовлю…", 13, 0xFF888888);
        int p = Ui.dp(this, 20);
        status.setPadding(p, p, p, p);
        boolean[] cancel = {false};
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Сохранение кадров").setView(status).setCancelable(false)
                .setNegativeButton("Отмена", (d, w) -> cancel[0] = true).show();
        big.execute(() -> {
            int done = 0;
            String err = null;
            try {
                Uri base = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
                Uri dir = base;
                if (list.size() > 1) {
                    dir = DocumentsContract.createDocument(getContentResolver(), base, DocumentsContract.Document.MIME_TYPE_DIR,
                            export + "_frames");
                    if (dir == null) throw new java.io.IOException("не удалось создать папку");
                }
                int digits = String.valueOf(frames).length();
                for (int f : list) {
                    if (cancel[0]) break;
                    Img im = sc2.renderFrame(export, f, bounds, size, 2);
                    if (im == null) continue;
                    String name = String.format(Locale.ROOT, "%s_%0" + digits + "d.png", export, f + 1);
                    Uri out = DocumentsContract.createDocument(getContentResolver(), dir, "image/png", name);
                    if (out == null) continue;
                    try (OutputStream o = getContentResolver().openOutputStream(out)) {
                        if (o == null) continue;
                        Bitmap bm = Decoders.toBitmap(im);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, o);
                        bm.recycle();
                    }
                    done++;
                    int fd = done;
                    main.post(() -> status.setText(fd + " / " + list.size()));
                }
            } catch (Throwable e) {
                err = e.getMessage();
            }
            String msg = err == null ? "Сохранено кадров: " + done : "Ошибка: " + err + " (успели: " + done + ")";
            main.post(() -> {
                dlg.dismiss();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("ОК", null).show();
            });
        });
    }

    // ------------------------------------------------------------------ frame strip
    final class Adapter extends BaseAdapter {
        public int getCount() { return frames; }

        public Object getItem(int i) { return i; }

        public long getItemId(int i) { return i; }

        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) {
                FrameLayout cell = new FrameLayout(FramesActivity.this);
                cell.setBackground(Ui.round(Ui.CARD, Ui.dp(FramesActivity.this, 8)));
                ImageView img = new ImageView(FramesActivity.this);
                img.setId(1);
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int pad = Ui.dp(FramesActivity.this, 3);
                img.setPadding(pad, pad, pad, pad);
                cell.addView(img, new FrameLayout.LayoutParams(-1, Ui.dp(FramesActivity.this, 72)));
                TextView num = Ui.bold(FramesActivity.this, "", 10, Ui.TEXT);
                num.setId(2);
                num.setPadding(pad * 2, pad, pad * 2, pad);
                cell.addView(num, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START));
                v = cell;
            }
            ImageView img = v.findViewById(1);
            TextView num = v.findViewById(2);
            boolean sel = selected.contains(pos);
            num.setText(sel ? "✓ " + (pos + 1) : String.valueOf(pos + 1));
            num.setTextColor(sel ? 0xFF16130A : Ui.TEXT);
            num.setBackground(Ui.round(sel ? Ui.ACCENT : 0x99000000, Ui.dp(FramesActivity.this, 6)));
            v.setBackground(Ui.round(pos == current ? Ui.CARD2 : Ui.CARD, Ui.dp(FramesActivity.this, 8)));
            img.setTag(pos);
            Bitmap c = thumbs.get(pos);
            if (c != null) {
                img.setImageBitmap(c);
            } else {
                img.setImageDrawable(null);
                small.execute(() -> {
                    if (bounds == null || !Integer.valueOf(pos).equals(img.getTag())) return;
                    try {
                        Img im = sc2.renderFrame(export, pos, bounds, 144, 1);
                        if (im == null) return;
                        Bitmap b = Decoders.toBitmap(im);
                        thumbs.put(pos, b);
                        main.post(() -> {
                            if (Integer.valueOf(pos).equals(img.getTag())) img.setImageBitmap(b);
                        });
                    } catch (Exception ignored) {
                        // leave empty
                    }
                });
            }
            return v;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stop();
        big.shutdownNow();
        small.shutdownNow();
    }
}
