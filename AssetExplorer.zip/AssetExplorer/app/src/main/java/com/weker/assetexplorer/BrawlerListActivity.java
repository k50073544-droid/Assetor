package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.GameDb;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The game's brawler list: blue screen, "N из N БОЙЦОВ", cards with the portrait on its rarity colour,
 * the name in the corner and the power column on the right. Taps open the brawler's screen.
 */
public final class BrawlerListActivity extends Activity {

    static final int BLUE = 0xFF1E6FE6;
    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private Typeface font = Typeface.DEFAULT_BOLD;
    private final List<GameDb.Brawler> all = new ArrayList<>();
    private final List<GameDb.Brawler> shown = new ArrayList<>();
    private TextView count;
    private GridView grid;
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(BLUE);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(new SkullBackground());
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // top bar: back slab, title, search, cosmetics / boxes
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(0xFF101A3A);
        View back = new BackButton(this);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 46)));
        count = Ui.bold(this, "", 18, 0xFFFFFFFF);
        count.setPadding(Ui.dp(this, 16), 0, 0, 0);
        top.addView(count, Ui.lp(0, -2, 1));
        EditText search = new EditText(this);
        search.setHint("ПОИСК");
        search.setHintTextColor(0xFFB8C4E0);
        search.setTextColor(0xFFFFFFFF);
        search.setSingleLine(true);
        search.setBackground(Ui.round(0xFF26304F, Ui.dp(this, 8)));
        search.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            @Override
            public void afterTextChanged(Editable e) {
                filter(e.toString());
            }
        });
        top.addView(search, new LinearLayout.LayoutParams(Ui.dp(this, 190), Ui.dp(this, 38)));
        GameButton cos = new GameButton(this, "Косметика", GameButton.PURPLE, font);
        cos.setTextSize(13);
        cos.setOnClickListener(v -> hub(1));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, Ui.dp(this, 42));
        bl.leftMargin = Ui.dp(this, 8);
        top.addView(cos, bl);
        GameButton boxes = new GameButton(this, "Боксы", GameButton.YELLOW, font);
        boxes.setTextSize(13);
        boxes.setOnClickListener(v -> hub(2));
        LinearLayout.LayoutParams bl2 = new LinearLayout.LayoutParams(-2, Ui.dp(this, 42));
        bl2.leftMargin = Ui.dp(this, 6);
        bl2.rightMargin = Ui.dp(this, 10);
        top.addView(boxes, bl2);
        col.addView(top, new LinearLayout.LayoutParams(-1, Ui.dp(this, 50)));

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setHorizontalSpacing(Ui.dp(this, 10));
        grid.setVerticalSpacing(Ui.dp(this, 10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        grid.setPadding(Ui.dp(this, 40), Ui.dp(this, 10), Ui.dp(this, 40), Ui.dp(this, 10));
        grid.setClipToPadding(false);
        adapter = new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, i, id) -> {
            Intent in = new Intent(this, BrawlerActivity.class);
            in.putExtra("vid", vid);
            in.putExtra("brawler", shown.get(i).code);
            startActivity(in);
        });
        col.addView(grid, Ui.lp(-1, 0, 1));
        setContentView(root);

        new Thread(() -> {
            Typeface f = GameUi.font(gd);
            List<GameDb.Brawler> l = gd.db.brawlers();
            main.post(() -> {
                font = f;
                count.setTypeface(f);
                search.setTypeface(f);
                cos.setTypeface(f);
                boxes.setTypeface(f);
                all.clear();
                // the game lists by rarity, then by release (Shelly, Nita, Colt…)
                List<GameDb.Brawler> sorted = new ArrayList<>(l);
                sorted.sort((x, y) -> Integer.compare(rarityRank(x.rarity), rarityRank(y.rarity)));
                all.addAll(sorted);
                filter("");
            });
        }).start();
    }

    private void hub(int tab) {
        Intent i = new Intent(this, HubActivity.class);
        i.putExtra("vid", vid);
        i.putExtra("tab", tab);
        startActivity(i);
    }

    static int rarityRank(String r) {
        switch (r.toLowerCase(Locale.ROOT)) {
            case "common": return 0;
            case "rare": return 1;
            case "super_rare": return 2;
            case "epic": return 3;
            case "mega_epic": return 4;
            case "legendary": return 5;
            case "ultra_legendary": return 6;
            default: return 7;
        }
    }

    /** card background of a rarity, as the brawler list shows it */
    static int rarityBg(String r) {
        switch (r.toLowerCase(Locale.ROOT)) {
            case "common": return 0xFF9BD3F5;
            case "rare": return 0xFF2FD52F;
            case "super_rare": return 0xFF2E8BF2;
            case "epic": return 0xFFB13DF2;
            case "mega_epic": return 0xFFF2353C;
            case "legendary": return 0xFFF5D323;
            case "ultra_legendary": return 0xFF35E9D8;
            default: return 0xFF7C8299;
        }
    }

    private void filter(String q) {
        String s = q.trim().toLowerCase(Locale.forLanguageTag("ru"));
        shown.clear();
        for (GameDb.Brawler b : all) if (s.isEmpty() || b.name.toLowerCase(Locale.forLanguageTag("ru")).contains(s)) shown.add(b);
        int real = 0;
        for (GameDb.Brawler b : all) if (!b.hidden) real++;
        count.setText(String.format(Locale.ROOT, "%d из %d БОЙЦОВ", shown.size(), real));
        adapter.notifyDataSetChanged();
    }

    final class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }

        @Override public Object getItem(int i) { return shown.get(i); }

        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            Card c = v instanceof Card ? (Card) v : new Card(BrawlerListActivity.this);
            c.set(shown.get(i));
            return c;
        }
    }

    /** one card: rarity colour, portrait, name in the corner, power column with the brawler's item icons */
    final class Card extends View {
        GameDb.Brawler br;
        Bitmap portrait;
        final Bitmap[] items = new Bitmap[3];
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);

        Card(Context c) {
            super(c);
            setLayoutParams(new android.widget.AbsListView.LayoutParams(-1, Ui.dp(c, 118)));
            t.setTextAlign(Paint.Align.RIGHT);
        }

        void set(GameDb.Brawler b) {
            if (br == b) return;
            br = b;
            portrait = null;
            items[0] = items[1] = items[2] = null;
            final GameDb.Brawler want = b;
            CardGrid.POOL.execute(() -> {
                Bitmap pt = gd.export(want.portraitFile, want.portraitExport, 300);
                Bitmap[] it = itemIcons(want);
                main.post(() -> {
                    if (br != want) return;
                    portrait = pt;
                    System.arraycopy(it, 0, items, 0, 3);
                    invalidate();
                });
            });
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            if (br == null) return;
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            float colW = w * 0.15f, bottom = h * 0.17f, r = 6 * d;
            RectF outer = new RectF(0, 0, w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF1C1440);
            c.drawRoundRect(outer, r, r, p);
            RectF pic = new RectF(3 * d, 3 * d, w - colW, h - bottom);
            p.setColor(rarityBg(br.rarity));
            c.drawRect(pic, p);
            if (portrait != null) { // fill the box, keep the face (the top) in view
                float s = Math.max(pic.width() / portrait.getWidth(), pic.height() / portrait.getHeight()) * 1.1f;
                float pw = portrait.getWidth() * s, ph = portrait.getHeight() * s;
                c.save();
                c.clipRect(pic);
                c.drawBitmap(portrait, null, new RectF(pic.left - (pw - pic.width()) * 0.3f, pic.top - ph * 0.05f,
                        pic.left - (pw - pic.width()) * 0.3f + pw, pic.top - ph * 0.05f + ph), p);
                c.restore();
            }
            t.setTypeface(font);
            t.setTextSize(h * 0.15f);
            GameUi.outlined(c, br.name.toUpperCase(Locale.forLanguageTag("ru")), pic.right - 6 * d, pic.bottom - 6 * d, t, 0xFFFFFFFF, 3.2f * d);
            // power column (purple for power 11)
            RectF pc = new RectF(w - colW, 3 * d, w - 3 * d, h - bottom);
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new LinearGradient(0, pc.top, 0, pc.bottom, 0xFFE070FF, 0xFF8E2BD8, Shader.TileMode.CLAMP));
            c.drawRect(pc, g);
            float cx = pc.centerX(), rr = colW * 0.42f;
            p.setColor(0xFF4B1C80);
            c.drawCircle(cx, pc.top + rr + 2 * d, rr, p);
            p.setColor(0xFFFFFFFF);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            c.drawCircle(cx, pc.top + rr + 2 * d, rr, p);
            p.setStyle(Paint.Style.FILL);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(rr * 1.15f);
            GameUi.outlined(c, "11", cx, pc.top + rr * 1.4f + 2 * d, t, 0xFFFFFFFF, 2 * d);
            float iy = pc.top + rr * 2 + 6 * d, is = Math.min(colW * 0.78f, (pc.bottom - iy) / 3.2f);
            for (int k = 0; k < 3; k++) {
                if (items[k] == null) continue;
                float y = iy + k * (is * 1.05f);
                c.drawBitmap(items[k], null, new RectF(cx - is / 2, y, cx + is / 2, y + is), p);
            }
            // bottom strip
            p.setColor(0xFF2A1E5C);
            c.drawRect(3 * d, h - bottom, w - 3 * d, h - 3 * d, p);
            t.setTextAlign(Paint.Align.LEFT);
            t.setTextSize(bottom * 0.62f);
            GameUi.outlined(c, br.rarityName.toUpperCase(Locale.forLanguageTag("ru")), 8 * d, h - bottom * 0.28f, t, 0xFFFFFFFF, 2 * d);
            t.setTextAlign(Paint.Align.RIGHT);
        }
    }

    /** gadget, star power and hypercharge icons from cards.csv */
    Bitmap[] itemIcons(GameDb.Brawler b) {
        Bitmap[] out = new Bitmap[3];
        GameDb.Table cards = gd.db.table("cards.csv");
        for (String[] r : cards.rows) {
            if (!b.code.equals(cards.get(r, "Target"))) continue;
            String meta = cards.get(r, "MetaType");
            int k = "5".equals(meta) ? 0 : "4".equals(meta) ? 1 : "6".equals(meta) ? 2 : -1;
            if (k < 0 || out[k] != null) continue;
            String ex = cards.get(r, "IconExportName");
            if (ex.isEmpty()) continue;
            String f = GameDb.fileName(cards.get(r, "IconSWF"));
            boolean ui = f.isEmpty() || f.equals("ui.sc");
            out[k] = ui ? GameUi.pic(gd, ex, 96) : gd.export(f, ex, 96);
        }
        return out;
    }

    /** the dark slab with a white arrow the game puts in the top-left corner */
    static final class BackButton extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        BackButton(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            Path slab = new Path();
            slab.moveTo(0, 0);
            slab.lineTo(w, 0);
            slab.lineTo(w * 0.86f, h);
            slab.lineTo(0, h);
            slab.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF3A3F52);
            c.drawPath(slab, p);
            Path arrow = new Path();
            arrow.moveTo(w * 0.52f, h * 0.2f);
            arrow.lineTo(w * 0.3f, h * 0.5f);
            arrow.lineTo(w * 0.52f, h * 0.8f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(h * 0.2f);
            p.setColor(0xFF000000);
            c.drawPath(arrow, p);
            p.setStrokeWidth(h * 0.12f);
            p.setColor(0xFFFFFFFF);
            c.drawPath(arrow, p);
        }
    }

    /** blue background with faint skulls, like the game's menus */
    static final class SkullBackground extends android.graphics.drawable.Drawable {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        @Override
        public void draw(Canvas c) {
            android.graphics.Rect b = getBounds();
            p.setShader(new android.graphics.RadialGradient(b.exactCenterX(), b.exactCenterY(), Math.max(b.width(), b.height()) * 0.7f,
                    0xFF2B8CFF, 0xFF1557D0, Shader.TileMode.CLAMP));
            c.drawRect(b, p);
            p.setShader(null);
            p.setColor(0x14FFFFFF);
            float s = b.height() / 7f;
            for (float y = s * 0.5f; y < b.height() + s; y += s * 1.3f) {
                for (float x = s * 0.5f + ((int) (y / s) % 2) * s * 0.65f; x < b.width() + s; x += s * 1.3f) skull(c, x, y, s * 0.32f);
            }
        }

        void skull(Canvas c, float x, float y, float r) {
            c.drawCircle(x, y, r, p);
            c.drawRect(x - r * 0.55f, y + r * 0.6f, x + r * 0.55f, y + r * 1.15f, p);
        }

        @Override public void setAlpha(int a) {}

        @Override public void setColorFilter(android.graphics.ColorFilter f) {}

        @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
    }
}
