package com.weker.assetexplorer.codec;

import java.util.HashMap;
import java.util.Map;

/**
 * What the training cave looks like: the theme's ground and surroundings, a model per wall / bush / water tile,
 * the dummies and the brawler, all placed from a {@link Cave}. {@link #build} makes a {@link Scene3d} for one frame.
 */
public final class CaveScene {

    /** character model units -> tiles */
    public static final float CHAR_SCALE = 0.1f;

    public final Cave cave;
    public final Assets assets;
    Model3d ground, env, wall, wallDestroyed, grass, indestructible, quad, disc;
    Map<String, Img> groundImg, envImg, wallImg, grassImg, indImg;
    public Assets.Actor player;
    final Map<String, Assets.Actor> dummies = new HashMap<>();
    public float camX, camZ;
    public float camHeight = 13.5f, camBack = 8.5f;

    public CaveScene(Cave cave, Assets a, String playerSkin) {
        this.cave = cave;
        this.assets = a;
        GameDb db = a.db;
        String theme = "OldTownTutorial";
        GameDb.MapData md = db.map("Training");
        if (md != null && md.theme != null) {
            GameDb.Table loc = db.table("locations.csv");
            for (String[] r : loc.rows) if ("Training".equals(loc.get(r, "Map"))) theme = loc.get(r, "LocationTheme");
        }
        ground = a.model(db.themeModel(theme, "GroundModel"));
        env = a.model(db.themeModel(theme, "EnvironmentModel"));
        Model3d w = a.model(db.themeModel(theme, "Wall1Model"));
        String sub = db.themeSubmesh(theme, "Wall1Submesh");
        if (w != null) {
            wall = sub != null && w.only(sub) != null ? w.only(sub) : w;
            wallDestroyed = sub != null ? w.only(sub + "_destroyed") : null;
        }
        grass = a.model(db.themeModel(theme, "Grass"));
        if (grass != null && grass.only("grass_1") != null) grass = grass.only("grass_1");
        indestructible = a.model(db.themeModel(theme, "IndestructibleModel"));
        groundImg = a.imagesFor(ground);
        envImg = a.imagesFor(env);
        wallImg = a.imagesFor(wall);
        grassImg = a.imagesFor(grass);
        indImg = a.imagesFor(indestructible);
        quad = Scene3d.quad();
        disc = Scene3d.disc(20);
        player = a.actor(playerSkin);
        GameDb.Table ch = db.table("characters.csv");
        for (Cave.Unit u : cave.dummies) {
            if (dummies.containsKey(u.code)) continue;
            String[] r = ch.row(u.code);
            String skin = r != null ? ch.get(r, "DefaultSkin") : "";
            dummies.put(u.code, a.actor(skin));
        }
        camX = cave.player.x;
        camZ = cave.player.z;
    }

    /** camera follows the brawler, a little behind it (south), like in a battle */
    public void follow(float dt) {
        float tx = Math.max(5.5f, Math.min(cave.width - 5.5f, cave.player.x));
        float tz = Math.max(4f, Math.min(cave.height - 2.5f, cave.player.z));
        float k = dt <= 0 ? 1 : Math.min(1, dt * 6);
        camX += (tx - camX) * k;
        camZ += (tz - camZ) * k;
    }

    public Scene3d build() {
        Scene3d s = new Scene3d();
        s.background = 0xFF2A3B2E;
        s.fovY = 36;
        s.near = 2f;
        s.far = 80f;
        s.view = Scene3d.lookAt(camX, camHeight, camZ + camBack, camX, 0, camZ - 0.6f);
        float[] zUp = Scene3d.zUp();
        if (ground != null) {
            Scene3d.Item g = s.add(ground, groundImg, zUp);
            g.still = true;
            g.background = true;
        }
        // the play field: the game draws it from flat tiles, a checkerboard of two sand tones
        if (floor == null) floor = floorModel();
        Scene3d.Item fl = s.add(floor, null, Scene3d.translate(0, 0.01f, 0));
        fl.still = true;
        fl.vertexColors = true;
        if (env != null) s.add(env, envImg, zUp).still = true;
        // tiles
        Cave.Unit p = cave.player;
        int pc = (int) Math.floor(p.x), pr = (int) Math.floor(p.z);
        for (int r = 0; r < cave.height; r++) {
            for (int c = 0; c < cave.width; c++) {
                char ch = cave.cells[r][c];
                float[] at = Scene3d.mul(Scene3d.translate(c + 0.5f, 0, r + 0.5f), zUp);
                if (ch == 'M' && wall != null) {
                    s.add(wall, wallImg, at).still = true;
                } else if (ch == 'I' && indestructible != null) {
                    s.add(indestructible, indImg, at).still = true;
                } else if (ch == 'F' && grass != null) {
                    Scene3d.Item it = s.add(grass, grassImg, at);
                    it.still = true;
                    if (p.alive && Math.abs(c - pc) <= 1 && Math.abs(r - pr) <= 1 && p.inBush) it.color = 0x88FFFFFF;
                } else if (ch == 'W') {
                    Scene3d.Item it = s.add(quad, null, Scene3d.translate(c, 0.03f, r));
                    it.color = 0xFF3C9FD8;
                    it.overlay = true;
                    it.still = true;
                }
            }
        }
        // dummies
        for (Cave.Unit u : cave.dummies) {
            if (!u.alive) continue;
            Assets.Actor a = dummies.get(u.code);
            shadow(s, u);
            if (a == null || a.model == null) continue;
            String act = "attack".equals(u.action) && a.clips.containsKey("attack") ? "attack" : "idle";
            Model3d m = a.posed(act, "idle".equals(act) ? cave.time : cave.time - u.actionStart, "idle".equals(act));
            Scene3d.Item it = s.add(m, a.images, place(u));
            it.override = a.override;
            if (u.flash > 0) it.flash = 0x707070;
        }
        // brawler
        if (p.alive) {
            shadow(s, p);
            if (player != null && player.model != null) {
                boolean loop = "idle".equals(p.action) || "walk".equals(p.action);
                Model3d m = player.posed(p.action, cave.time - p.actionStart, loop);
                Scene3d.Item it = s.add(m, player.images, place(p));
                it.override = player.override;
                if (p.inBush) it.color = 0x99FFFFFF;
                if (p.flash > 0) it.flash = 0x804040;
            }
        }
        // projectiles: glowing dots
        for (Cave.Shot sh : cave.shots) {
            float r = Math.max(0.13f, sh.radius * 0.8f);
            Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(sh.x, 0.55f, sh.z), Scene3d.scale(r, 1, r)));
            it.color = sh.enemy ? 0xFFFF5040 : sh.ulti ? 0xFFFFD040 : 0xFFFFF2A0;
            it.overlay = true;
        }
        return s;
    }

    Model3d floor;

    /** one flat part with a colour per corner: light and dark squares, slightly darker at the edges */
    Model3d floorModel() {
        int w = cave.width, h = cave.height;
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "floor";
        p.triangles = w * h * 2;
        p.pos = new float[p.triangles * 9];
        p.nrm = new float[p.triangles * 9];
        p.uv = new float[p.triangles * 6];
        p.colors = new int[p.triangles * 3];
        p.hasNormals = true;
        int t = 0;
        for (int r = 0; r < h; r++) {
            for (int c = 0; c < w; c++) {
                int col = ((r + c) & 1) == 0 ? 0xFFEBC596 : 0xFFE2B887;
                if (r == 0 || c == 0 || r == h - 1 || c == w - 1) col = ((r + c) & 1) == 0 ? 0xFFDDB282 : 0xFFD4A877;
                float[] q = {c, 0, r, c + 1, 0, r, c + 1, 0, r + 1, c, 0, r, c + 1, 0, r + 1, c, 0, r + 1};
                for (int k = 0; k < 6; k++) {
                    p.pos[t * 9 + k * 3] = q[k * 3];
                    p.pos[t * 9 + k * 3 + 1] = 0;
                    p.pos[t * 9 + k * 3 + 2] = q[k * 3 + 2];
                    p.nrm[t * 9 + k * 3 + 1] = 1;
                    p.colors[t * 3 + k] = col;
                }
                t += 2;
            }
        }
        m.parts.add(p);
        m.triangles = p.triangles;
        m.bounds = new float[]{0, 0, 0, w, 0, h};
        return m;
    }

    float[] place(Cave.Unit u) {
        float k = CHAR_SCALE * u.scale / 100f;
        return Scene3d.mul(Scene3d.translate(u.x, 0, u.z), Scene3d.mul(Scene3d.rotateY(u.face), Scene3d.scale(k)));
    }

    void shadow(Scene3d s, Cave.Unit u) {
        float r = Math.max(0.3f, u.radius * 1.15f);
        Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(u.x, 0.04f, u.z), Scene3d.scale(r, 1, r * 0.85f)));
        it.color = 0x50000000;
        it.overlay = true;
    }

    /** where a unit's head is, for health bars (world coordinates) */
    public float headHeight(Cave.Unit u) {
        Assets.Actor a = u == cave.player ? player : dummies.get(u.code);
        float h = a != null && a.model != null ? a.height() : 12;
        return h * CHAR_SCALE * u.scale / 100f + 0.25f;
    }
}
