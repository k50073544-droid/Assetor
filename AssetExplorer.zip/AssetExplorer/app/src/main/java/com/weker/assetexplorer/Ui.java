package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** Tiny helpers for building views in code. */
public final class Ui {

    private Ui() {}

    public static final int BG = 0xFF0F1117;
    public static final int CARD = 0xFF1A1D27;
    public static final int CARD2 = 0xFF252937;
    public static final int TEXT = 0xFFEDEFF5;
    public static final int MUTED = 0xFF9097A8;
    public static final int ACCENT = 0xFFFFC93C;
    public static final int NEW = 0xFF3DDC84;
    public static final int CHANGED = 0xFFFF9F43;

    public static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    public static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    public static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    public static TextView bold(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTextColor(primary ? 0xFF16130A : TEXT);
        b.setBackground(round(primary ? ACCENT : CARD2, dp(c, 10)));
        int p = dp(c, 12);
        b.setPadding(p, 0, p, 0);
        b.setMinHeight(dp(c, 40));
        b.setMinimumHeight(dp(c, 40));
        return b;
    }

    public static TextView chip(Context c, String s) {
        TextView t = text(c, s, 13, TEXT);
        int h = dp(c, 12), v = dp(c, 7);
        t.setPadding(h, v, h, v);
        t.setGravity(Gravity.CENTER);
        setChip(c, t, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(c, 6);
        t.setLayoutParams(lp);
        return t;
    }

    public static void setChip(Context c, TextView t, boolean on) {
        t.setBackground(round(on ? ACCENT : CARD2, dp(c, 16)));
        t.setTextColor(on ? 0xFF16130A : TEXT);
    }

    public static String size(long b) {
        if (b < 1024) return b + " Б";
        if (b < 1024 * 1024) return String.format(Locale.ROOT, "%.1f КБ", b / 1024f);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.ROOT, "%.1f МБ", b / 1048576f);
        return String.format(Locale.ROOT, "%.2f ГБ", b / 1073741824f);
    }

    public static LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }
}
