package com.weker.assetexplorer;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/** Imports a game zip (APK, XAPK contents or data dump) as a new version. */
public final class Importer {

    public interface Progress {
        void onProgress(int files, long bytes, String current);
    }

    public static final class Result {
        public long vid;
        public String version;
        public int files;
        public int added, changed;
    }

    private final Context ctx;
    private final Db db;
    private final File blobDir;
    private volatile boolean cancelled;

    public Importer(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.db = Db.get(ctx);
        this.blobDir = Blobs.dir(ctx);
    }

    public void cancel() { cancelled = true; }

    public Result run(Uri uri, String displayName, Progress progress) throws IOException {
        String fallbackName = displayName == null ? "версия" : displayName.replaceAll("(?i)\\.(zip|apk|xapk)$", "");
        long vid = createVersion(fallbackName + " (импорт…)");
        String[] detected = {null};
        int[] count = {0};
        long[] bytes = {0};
        SQLiteDatabase w = db.getWritableDatabase();
        w.beginTransaction();
        try {
            try {
                try (InputStream raw = ctx.getContentResolver().openInputStream(uri)) {
                    if (raw == null) throw new IOException("Не удалось открыть файл");
                    ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw, 1 << 16));
                    ZipEntry e;
                    while ((e = zin.getNextEntry()) != null) {
                        if (cancelled) throw new IOException("Отменено");
                        if (e.isDirectory()) continue;
                        handleEntry(w, vid, e.getName(), zin, detected, count, bytes, progress);
                    }
                }
            } catch (IOException | RuntimeException streamError) {
                if (cancelled) throw streamError;
                // Some zips (stored entries with data descriptors) can't be streamed: copy and use ZipFile.
                w.delete("files", "vid=?", new String[]{"" + vid});
                count[0] = 0;
                bytes[0] = 0;
                File tmp = new File(ctx.getCacheDir(), "import.zip");
                try (InputStream in = ctx.getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(tmp)) {
                    if (in == null) throw new IOException("Не удалось открыть файл");
                    copy(in, out, null);
                }
                try (ZipFile zf = new ZipFile(tmp)) {
                    Enumeration<? extends ZipEntry> en = zf.entries();
                    while (en.hasMoreElements()) {
                        if (cancelled) throw new IOException("Отменено");
                        ZipEntry e = en.nextElement();
                        if (e.isDirectory()) continue;
                        try (InputStream in = zf.getInputStream(e)) {
                            handleEntry(w, vid, e.getName(), in, detected, count, bytes, progress);
                        }
                    }
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            }
            if (count[0] == 0) throw new IOException("В архиве не найдено файлов");
            w.setTransactionSuccessful();
        } catch (IOException | RuntimeException ex) {
            w.endTransaction();
            db.getWritableDatabase().delete("versions", "id=?", new String[]{"" + vid});
            throw ex;
        }
        w.endTransaction();

        String name = detected[0] != null ? detected[0] : fallbackName;
        long existing = db.findVersion(name);
        if (existing >= 0 && existing != vid) db.deleteVersion(existing, blobDir);
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("files", count[0]);
        db.getWritableDatabase().update("versions", cv, "id=?", new String[]{"" + vid});
        db.recomputeStatuses();

        Result r = new Result();
        r.vid = vid;
        r.version = name;
        r.files = count[0];
        r.added = Db.count(db.getReadableDatabase(), "SELECT COUNT(*) FROM files WHERE vid=? AND status=1", vid);
        r.changed = Db.count(db.getReadableDatabase(), "SELECT COUNT(*) FROM files WHERE vid=? AND status=2", vid);
        return r;
    }

    private long createVersion(String name) {
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("imported", System.currentTimeMillis());
        cv.put("files", 0);
        return db.getWritableDatabase().insert("versions", null, cv);
    }

    private void handleEntry(SQLiteDatabase w, long vid, String entryName, InputStream in, String[] detected,
                             int[] count, long[] bytes, Progress progress) throws IOException {
        String le = entryName.toLowerCase(Locale.ROOT);
        if (le.endsWith(".apk") || le.endsWith(".xapk") || le.endsWith(".obb")) {
            // nested archive (XAPK = zip with APK inside): read it in place
            ZipInputStream nested = new ZipInputStream(new BufferedInputStream(in, 1 << 16));
            ZipEntry ne;
            while ((ne = nested.getNextEntry()) != null) {
                if (cancelled) throw new IOException("Отменено");
                if (ne.isDirectory()) continue;
                handleEntry(w, vid, ne.getName(), nested, detected, count, bytes, progress);
            }
            return;
        }
        String path = normalize(entryName);
        if (path == null) return;
        String lower = path.toLowerCase(Locale.ROOT);

        File tmp = new File(blobDir, "tmp_import");
        CRC32 crc = new CRC32();
        long size;
        ByteArrayOutputStream small = lower.endsWith("fingerprint.json") ? new ByteArrayOutputStream() : null;
        try (OutputStream out = new FileOutputStream(tmp)) {
            size = copy(in, out, crc, small);
        }
        if (small != null) {
            try {
                JSONObject j = new JSONObject(small.toString("UTF-8"));
                String v = j.optString("version", null);
                if (v != null && !v.isEmpty()) detected[0] = v;
            } catch (Exception ignored) {
                // not a json we understand
            }
        }
        String key = String.format(Locale.ROOT, "%08x%012x", crc.getValue(), size);
        File dst = Blobs.file(blobDir, key);
        if (dst.exists() && dst.length() == size) {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        } else {
            //noinspection ResultOfMethodCallIgnored
            dst.getParentFile().mkdirs();
            if (!tmp.renameTo(dst)) {
                try (InputStream i2 = new FileInputStream(tmp); OutputStream o2 = new FileOutputStream(dst)) {
                    copy(i2, o2, null);
                }
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }

        ContentValues cv = new ContentValues();
        cv.put("vid", vid);
        cv.put("path", path);
        cv.put("lpath", lower);
        cv.put("name", Categorizer.name(path));
        cv.put("ext", Categorizer.ext(path));
        cv.put("type", Categorizer.type(path));
        cv.put("tags", Categorizer.tags(path));
        cv.put("size", size);
        cv.put("blob", key);
        w.insert("files", null, cv);

        count[0]++;
        bytes[0] += size;
        if (progress != null && (count[0] % 25 == 0 || size > 1 << 20)) progress.onProgress(count[0], bytes[0], path);
    }

    /** Keeps the part after "assets/" when present; drops code and signatures. */
    static String normalize(String name) {
        String n = name.replace('\\', '/');
        while (n.startsWith("/")) n = n.substring(1);
        if (n.isEmpty() || n.contains("../")) return null;
        String l = n.toLowerCase(Locale.ROOT);
        int a = l.indexOf("assets/");
        if (a >= 0) return n.substring(a + 7).isEmpty() ? null : n.substring(a + 7);
        if (l.startsWith("meta-inf/") || l.endsWith(".dex") || l.startsWith("lib/") || l.equals("resources.arsc")
                || l.equals("androidmanifest.xml") || l.startsWith("kotlin/")) return null;
        return n;
    }

    static long copy(InputStream in, OutputStream out, CRC32 crc) throws IOException {
        return copy(in, out, crc, null);
    }

    static long copy(InputStream in, OutputStream out, CRC32 crc, ByteArrayOutputStream also) throws IOException {
        byte[] buf = new byte[1 << 16];
        long total = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (crc != null) crc.update(buf, 0, n);
            if (also != null && also.size() < (4 << 20)) also.write(buf, 0, n);
            total += n;
        }
        return total;
    }
}
