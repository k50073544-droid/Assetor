package com.weker.assetexplorer.codec;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The game's tables in one place: brawlers, skins, voice lines, pins, sprays, player icons, Starr Drops / boxes,
 * the training map and the numbers the training cave needs. Everything comes from the imported version, so a newer
 * game version brings its new brawlers automatically. Pure Java (a {@link Source} gives file bytes).
 */
public final class GameDb {

    /** gives the (decompressed) bytes of a game file by name, or null */
    public interface Source {
        byte[] read(String fileName);
    }

    /** one csv table with column access */
    public static final class Table {
        public final String[] header;
        public final List<String[]> rows = new ArrayList<>();
        final Map<String, Integer> col = new HashMap<>();
        final Map<String, String[]> byName = new HashMap<>();

        Table(List<String[]> raw) {
            header = raw.isEmpty() ? new String[0] : raw.get(0);
            for (int i = 0; i < header.length; i++) col.put(header[i].trim(), i);
            for (int i = 2; i < raw.size(); i++) {
                String[] r = raw.get(i);
                rows.add(r);
                if (r.length > 0 && !r[0].isEmpty() && !byName.containsKey(r[0])) byName.put(r[0], r);
            }
        }

        public String get(String[] r, String c) {
            Integer i = col.get(c);
            return i == null || r == null || i >= r.length ? "" : r[i].trim();
        }

        public int num(String[] r, String c, int def) {
            String s = get(r, c);
            try {
                return s.isEmpty() ? def : Integer.parseInt(s);
            } catch (NumberFormatException e) {
                return def;
            }
        }

        public boolean flag(String[] r, String c) {
            return get(r, c).equalsIgnoreCase("true");
        }

        public String[] row(String name) { return byName.get(name); }

        public boolean has(String c) { return col.containsKey(c); }
    }

    private final Source src;
    private final Map<String, Table> tables = new HashMap<>();
    public Map<String, String> ru = new HashMap<>();

    public GameDb(Source src) {
        this.src = src;
        byte[] loc = src.read("ru.csv");
        if (loc != null) {
            for (String[] r : parseCsv(new String(loc, StandardCharsets.UTF_8))) {
                if (r.length >= 2 && !r[0].isEmpty()) ru.put(r[0].trim(), r[1]);
            }
        }
    }

    public Table table(String name) {
        Table t = tables.get(name);
        if (t == null) {
            byte[] d = src.read(name);
            t = new Table(d == null ? new ArrayList<>() : parseCsv(new String(d, StandardCharsets.UTF_8)));
            tables.put(name, t);
        }
        return t;
    }

    /** Russian text of a TID, tags removed; null when missing */
    public String text(String tid) {
        if (tid == null || tid.isEmpty()) return null;
        String s = ru.get(tid);
        if (s == null) return null;
        s = s.replaceAll("<[^>]*>", "").replace("\\n", "\n").trim();
        return s.isEmpty() ? null : s;
    }

    /** CSV with quotes (Supercell tables) */
    public static List<String[]> parseCsv(String text) {
        List<String[]> rows = new ArrayList<>();
        List<String> cur = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        cell.append('"');
                        i++;
                    } else {
                        q = false;
                    }
                } else {
                    cell.append(c);
                }
            } else if (c == '"') {
                q = true;
            } else if (c == ',') {
                cur.add(cell.toString());
                cell.setLength(0);
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                cur.add(cell.toString());
                cell.setLength(0);
                rows.add(cur.toArray(new String[0]));
                cur.clear();
            } else {
                cell.append(c);
            }
        }
        if (cell.length() > 0 || !cur.isEmpty()) {
            cur.add(cell.toString());
            rows.add(cur.toArray(new String[0]));
        }
        return rows;
    }

    /** "ШЕЛЛИ" -> "Шелли" (game names are upper case) */
    public static String nice(String s) {
        if (s == null) return null;
        if (!s.equals(s.toUpperCase(Locale.ROOT))) return s;
        StringBuilder sb = new StringBuilder();
        boolean start = true;
        for (char c : s.toLowerCase(Locale.forLanguageTag("ru")).toCharArray()) {
            sb.append(start ? Character.toUpperCase(c) : c);
            start = c == ' ' || c == '-' || c == '.';
        }
        return sb.toString();
    }

    public static String fileName(String path) {
        int i = path.lastIndexOf('/');
        return i < 0 ? path : path.substring(i + 1);
    }

    // ------------------------------------------------------------------ brawlers
    public static final class Brawler {
        public String code, item, name, rarity = "", rarityName = "";
        public String portraitFile, portraitExport;
        public int hp, speed;
        public String weapon, ulti, defaultSkin;
        public final List<Skin> skins = new ArrayList<>();
        /** label -> sound name (voice lines of the default look) */
        public final Map<String, String> voice = new LinkedHashMap<>();
        public final List<String> gadgets = new ArrayList<>(), starPowers = new ArrayList<>();
        public String hypercharge;
        public String[] row;
        /** switched off / not in the brawler list of the game (forms, events) */
        public boolean hidden;
    }

    public static final class Skin {
        public String name, conf, title, rarity = "", brawler;
        public String model, texture;
        public int priceGems, priceBling, priceCoins;
        public boolean disabled;
        /** label -> sound name; skins with their own voice override the brawler's */
        public final Map<String, String> voice = new LinkedHashMap<>();
        public String iconFile, iconExport;
    }

    static final String[][] VOICE = {
            {"StartSoundVO", "Появление"}, {"AttackSoundVO", "Атака"}, {"UseUltiSoundVO", "Супер"},
            {"KillCelebrationSoundVO", "Победил врага"}, {"InLeadCelebrationSoundVO", "Лидирует"},
            {"TakeDamageSoundVO", "Получил урон"}, {"DeathSoundVO", "Поражение"}, {"UnlockVO", "Открытие бойца"}};

    private List<Brawler> brawlers;

    /** playable brawlers in table order (newest last) */
    public synchronized List<Brawler> brawlers() {
        if (brawlers != null) return brawlers;
        brawlers = new ArrayList<>();
        Table ch = table("characters.csv");
        Table cards = table("cards.csv");
        Map<String, Brawler> byCode = new HashMap<>();
        for (String[] r : ch.rows) {
            if (!"Hero".equals(ch.get(r, "Type"))) continue;
            boolean hidden = ch.flag(r, "Disabled") || ch.get(r, "ItemName").isEmpty();
            if (hidden) {
                // content switched off in the tables: transformed forms, event brawlers… (not the hashed placeholder copies)
                if (ch.flag(r, "Disabled") || r[0].matches("[0-9a-f]{20,}") || ch.get(r, "DefaultSkin").isEmpty() || ch.get(r, "WeaponSkill").isEmpty()) continue;
            }
            Brawler b = new Brawler();
            b.row = r;
            b.code = r[0];
            b.hidden = hidden;
            b.item = ch.get(r, "ItemName").isEmpty() ? r[0].toLowerCase(Locale.ROOT) : ch.get(r, "ItemName");
            String n = nice(text(ch.get(r, "TID")));
            b.name = (n != null ? n : spaced(r[0])) + (hidden ? " (скрыт)" : "");
            b.hp = ch.num(r, "Hitpoints", 3000);
            b.speed = ch.num(r, "Speed", 720);
            b.weapon = ch.get(r, "WeaponSkill");
            b.ulti = ch.get(r, "UltimateSkill");
            b.defaultSkin = ch.get(r, "DefaultSkin");
            b.portraitFile = fileName(ch.get(r, "IconSWF"));
            b.portraitExport = ch.get(r, "IconExportName");
            for (String[] v : VOICE) {
                String s = ch.get(r, v[0]);
                if (!s.isEmpty() && !b.voice.containsValue(s)) b.voice.put(v[1], s);
            }
            brawlers.add(b);
            byCode.put(b.code, b);
        }
        for (String[] r : cards.rows) {
            Brawler b = byCode.get(cards.get(r, "Target"));
            if (b == null || cards.flag(r, "Disabled")) continue;
            String meta = cards.get(r, "MetaType");
            String n = text(cards.get(r, "TID"));
            if ("0".equals(meta) || "unlock".equals(cards.get(r, "Type"))) {
                b.rarity = cards.get(r, "Rarity");
                b.rarityName = rarityName(b.rarity);
            } else if (n != null) {
                if ("5".equals(meta)) b.gadgets.add(nice(n));
                else if ("4".equals(meta)) b.starPowers.add(nice(n));
                else if ("6".equals(meta)) b.hypercharge = nice(n);
            }
        }
        // skins
        Table skins = table("skins.csv");
        Table confs = table("skin_confs.csv");
        for (String[] r : skins.rows) {
            String[] conf = confs.row(skins.get(r, "Conf"));
            if (conf == null) continue;
            Brawler b = byCode.get(confs.get(conf, "Character"));
            if (b == null) continue;
            boolean dup = false;
            for (Skin x : b.skins) if (x.name.equals(r[0])) dup = true;
            if (dup) continue;
            Skin s = new Skin();
            s.name = r[0];
            s.conf = conf[0];
            s.brawler = b.code;
            s.disabled = skins.flag(r, "Disabled");
            String t = text(skins.get(r, "TID"));
            s.title = t != null ? nice(t) : s.name.equals(b.defaultSkin) ? "Стандартный" : spaced(s.name);
            s.rarity = skins.get(r, "Rarity");
            s.model = fileName(confs.get(conf, "Model"));
            s.texture = skins.get(r, "DiffuseTexture");
            s.priceGems = skins.num(r, "PriceGems", 0);
            s.priceBling = skins.num(r, "PriceBling", 0);
            s.priceCoins = skins.num(r, "PriceCoins", 0);
            s.iconFile = fileName(skins.get(r, "IconOverrideSWF"));
            s.iconExport = skins.get(r, "IconOverrideExportName");
            for (String[] v : VOICE) {
                String snd = confs.get(conf, v[0]);
                if (!snd.isEmpty() && !s.voice.containsValue(snd)) s.voice.put(v[1], snd);
            }
            if (s.voice.isEmpty()) s.voice.putAll(b.voice);
            if (s.name.equals(b.defaultSkin)) b.skins.add(0, s);
            else b.skins.add(s);
        }
        return brawlers;
    }

    public Brawler brawler(String code) {
        for (Brawler b : brawlers()) if (b.code.equals(code)) return b;
        return null;
    }

    public static String rarityName(String r) {
        switch (r.toLowerCase(Locale.ROOT)) {
            case "common": case "default": return "Обычный";
            case "rare": return "Редкий";
            case "super_rare": return "Сверхредкий";
            case "epic": return "Эпический";
            case "mega_epic": case "mythic": return "Мифический";
            case "legendary": return "Легендарный";
            case "ultra_legendary": return "Ультралегендарный";
            case "chromatic": return "Хроматический";
            case "collectors": return "Коллекционный";
            case "hypercharge": return "Гиперзаряд";
            case "": return "";
            default: return r;
        }
    }

    /** ARGB colour the game uses for a rarity */
    public static int rarityColor(String r) {
        switch (r.toLowerCase(Locale.ROOT)) {
            case "rare": case "1": return 0xFF68FD58;
            case "super_rare": case "2": return 0xFF5AB3FF;
            case "epic": case "3": return 0xFFD850FF;
            case "mega_epic": case "mythic": case "4": return 0xFFFE5E72;
            case "legendary": case "5": return 0xFFFFF11E;
            case "ultra_legendary": return 0xFF3BFFE4;
            case "chromatic": return 0xFFFF9F2E;
            case "collectors": return 0xFFE6B84A;
            default: return 0xFFB9C2D6;
        }
    }

    // ------------------------------------------------------------------ sounds
    /** files (sfx/xxx.ogg) of a sound name from sounds.csv */
    public List<String> soundFiles(String sound) {
        List<String> out = new ArrayList<>();
        Table t = table("sounds.csv");
        String[] r = t.row(sound);
        if (r == null) return out;
        for (String f : t.get(r, "FileNames").split("[,;]")) if (!f.trim().isEmpty()) out.add(fileName(f.trim()));
        return out;
    }

    // ------------------------------------------------------------------ cosmetics
    public static final class Item2d {
        public String name, title, file, export, rarity = "", character, sound;
        public int priceGems, priceBling;
    }

    /** pins (emotes.csv), sprays (sprays.csv) or player icons (player_thumbnails.csv) */
    public List<Item2d> items(String kind) {
        List<Item2d> out = new ArrayList<>();
        Table t;
        String fileCol, exportCol;
        switch (kind) {
            case "pins": t = table("emotes.csv"); fileCol = "IconSWF"; exportCol = "IconExportName"; break;
            case "sprays": t = table("sprays.csv"); fileCol = "FileName"; exportCol = "ExportName"; break;
            default: t = table("player_thumbnails.csv"); fileCol = "IconSWF"; exportCol = "IconExportName"; break;
        }
        for (String[] r : t.rows) {
            if (r.length == 0 || r[0].isEmpty()) continue;
            String file = t.get(r, fileCol), export = t.get(r, exportCol);
            if (file.isEmpty() || export.isEmpty()) continue;
            Item2d it = new Item2d();
            it.name = r[0];
            it.title = r[0];
            it.file = fileName(file);
            it.export = export;
            it.rarity = t.get(r, "Rarity");
            it.character = t.get(r, kind.equals("icons") ? "RequiredHero" : "Character");
            it.sound = t.get(r, "SoundEffect");
            it.priceGems = t.num(r, "PriceGems", 0);
            it.priceBling = t.num(r, "PriceBling", 0);
            out.add(it);
        }
        return out;
    }

    /** all skins of all brawlers */
    public List<Skin> allSkins() {
        List<Skin> out = new ArrayList<>();
        for (Brawler b : brawlers()) for (Skin s : b.skins) if (!s.disabled) out.add(s);
        return out;
    }

    // ------------------------------------------------------------------ boxes
    public static final class Container {
        public String name, title, model, faceFile, faceIdle, faceUpgrade, faceOpen, visual = "";
        public int rarity;
        /** frame ranges of the 3D model's own animation */
        public int[] intro, idle, miss, upgrade, open;
        public String soundMiss, soundUpgrade, soundReady, soundReady2, soundOpen;
        public boolean starr;
        public String[] row;
    }

    public static final class RewardType {
        public String name, type, value;
        public int min, max, priceMin, priceMax, tier;
        public String fallback;
        public int fallbackAmount;
        public final Map<String, Integer> tickets = new HashMap<>();
    }

    private List<Container> containers;
    private List<RewardType> rewards;

    /** every reward container that has rewards in random_rewards.csv */
    public synchronized List<Container> containers() {
        if (containers != null) return containers;
        containers = new ArrayList<>();
        Table t = table("random_reward_containers.csv");
        List<RewardType> rw = rewardTypes();
        for (String[] r : t.rows) {
            if (r.length == 0 || r[0].isEmpty()) continue;
            Container c = new Container();
            c.row = r;
            c.name = r[0];
            String tt = text(t.get(r, "TID"));
            c.title = tt != null ? nice(tt) : spaced(c.name);
            c.rarity = t.num(r, "Rarity", 0);
            c.model = fileName(t.get(r, "SCW"));
            c.visual = t.get(r, "VisualType");
            c.faceFile = fileName(t.get(r, "FaceFileName"));
            c.faceIdle = t.get(r, "FaceIdleExportName");
            c.faceUpgrade = t.get(r, "FaceUpgradeExportName");
            c.faceOpen = t.get(r, "FaceOpenExportName");
            c.intro = range(t, r, "Intro3D");
            c.idle = range(t, r, "Idle3D");
            c.miss = range(t, r, "Miss3D");
            c.upgrade = range(t, r, "Upgrade3D");
            c.open = range(t, r, "Open3D");
            c.soundMiss = t.get(r, "SoundMiss");
            c.soundUpgrade = t.get(r, "SoundUpgrade");
            c.soundReady = t.get(r, "SoundReadyToOpen");
            c.soundReady2 = t.get(r, "SoundReadyToOpen2");
            c.soundOpen = t.get(r, "SoundOpen");
            c.starr = c.name.endsWith("Star") && t.num(r, "TicketsInWinGamesDraw", 0) > 0;
            boolean any = false;
            for (RewardType x : rw) if (x.tickets.getOrDefault(c.name, 0) > 0) any = true;
            if (any) containers.add(c);
        }
        return containers;
    }

    static int[] range(Table t, String[] r, String prefix) {
        String a = t.get(r, prefix + "AnimStart"), b = t.get(r, prefix + "AnimEnd");
        if (a.isEmpty() || b.isEmpty()) return null;
        try {
            return new int[]{Integer.parseInt(a), Integer.parseInt(b)};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** "SuperRareCollabDrop" -> "Super Rare Collab Drop" */
    static String spaced(String s) {
        return s.replaceAll("([a-z])([A-Z0-9])", "$1 $2");
    }

    public synchronized List<RewardType> rewardTypes() {
        if (rewards != null) return rewards;
        rewards = new ArrayList<>();
        Table t = table("random_rewards.csv");
        for (String[] r : t.rows) {
            if (r.length == 0 || r[0].isEmpty()) continue;
            RewardType x = new RewardType();
            x.name = r[0];
            x.type = t.get(r, "TypeName");
            x.value = t.get(r, "TypeValue");
            x.min = t.num(r, "AmountMin", 1);
            x.max = Math.max(x.min, t.num(r, "AmountMax", x.min));
            x.priceMin = t.num(r, "TypePriceMin", 0);
            x.priceMax = t.num(r, "TypePriceMax", 99999);
            x.tier = t.num(r, "TierForVisualization", 0);
            x.fallback = t.get(r, "FallbackTypeName");
            x.fallbackAmount = t.num(r, "FallbackAmount", 0);
            for (int i = 0; i < t.header.length; i++) {
                String h = t.header[i];
                if (h.startsWith("TicketsIn") && i < r.length && !r[i].isEmpty()) {
                    try {
                        x.tickets.put(h.substring(9), Integer.parseInt(r[i].trim()));
                    } catch (NumberFormatException ignored) {
                        // not a number
                    }
                }
            }
            rewards.add(x);
        }
        return rewards;
    }

    /**
     * Rarities of one Starr Drop family and their chance of being drawn (TicketsInWinGamesDraw):
     * family "" = normal Starr Drops (RareStar…LegendaryStar), "Splitting" = Chaos drops.
     */
    public List<Container> starrRarities(String family) {
        List<Container> out = new ArrayList<>();
        for (Container c : containers()) {
            if (!c.starr) continue;
            String core = c.name.substring(0, c.name.length() - 4); // without "Star"
            boolean split = core.endsWith("Splitting");
            if (family.equals("Splitting") ? split : !split && core.matches("(Rare|SuperRare|Epic|Mythic|Legendary|Ultra)")) out.add(c);
        }
        out.sort((a, b) -> Integer.compare(a.rarity, b.rarity));
        return out;
    }

    public int drawTickets(Container c) {
        return table("random_reward_containers.csv").num(c.row, "TicketsInWinGamesDraw", 0);
    }

    // ------------------------------------------------------------------ training cave
    public static final class MapData {
        public int width, height;
        public char[][] cells; // [row][col]
        public String theme;
    }

    /** a map from maps.csv by name ("Training") */
    public MapData map(String name) {
        Table t = table("maps.csv");
        List<String> lines = new ArrayList<>();
        boolean on = false;
        for (String[] r : t.rows) {
            String m = t.get(r, "Map");
            if (!m.isEmpty()) on = m.equals(name);
            if (on) lines.add(t.get(r, "Data"));
        }
        if (lines.isEmpty()) return null;
        MapData d = new MapData();
        d.height = lines.size();
        d.width = 0;
        for (String l : lines) d.width = Math.max(d.width, l.length());
        d.cells = new char[d.height][d.width];
        for (int y = 0; y < d.height; y++) {
            String l = lines.get(y);
            for (int x = 0; x < d.width; x++) d.cells[y][x] = x < l.length() ? l.charAt(x) : '.';
        }
        Table loc = table("locations.csv");
        for (String[] r : loc.rows) if (name.equals(loc.get(r, "Map"))) d.theme = loc.get(r, "LocationTheme");
        return d;
    }

    /** row of a location theme (models for ground, walls, bushes…) */
    public String[] theme(String name) {
        return table("location_themes.csv").row(name);
    }

    public String themeModel(String theme, String column) {
        Table t = table("location_themes.csv");
        String[] r = t.row(theme);
        String v = r == null ? "" : t.get(r, column);
        if (v.isEmpty()) {
            String[] d = t.row("Default");
            v = d == null ? "" : t.get(d, column);
        }
        return v.isEmpty() ? null : fileName(v);
    }

    public String themeSubmesh(String theme, String column) {
        Table t = table("location_themes.csv");
        String[] r = t.row(theme);
        String v = r == null ? "" : t.get(r, column);
        return v.isEmpty() ? null : v;
    }

    /** tile code -> tile row of tiles.csv */
    public Map<Character, String[]> tiles() {
        Map<Character, String[]> m = new HashMap<>();
        Table t = table("tiles.csv");
        for (String[] r : t.rows) {
            String c = t.get(r, "TileCode");
            if (c.length() == 1 && !m.containsKey(c.charAt(0))) m.put(c.charAt(0), r);
        }
        return m;
    }
}
