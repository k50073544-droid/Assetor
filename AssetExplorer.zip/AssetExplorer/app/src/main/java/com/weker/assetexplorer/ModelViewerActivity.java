package com.weker.assetexplorer;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import io.github.sceneview.SceneView;
import io.github.sceneview.math.Position;
import io.github.sceneview.math.Rotation;
import io.github.sceneview.node.ModelNode;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.FloatBuffer;

public class ModelViewerActivity extends AppCompatActivity {

    private SceneView sceneView;
    private ModelNode modelNode;

    private float previousX;
    private float previousY;
    private float currentYAngle = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_model_viewer);

        sceneView = findViewById(R.id.sceneView);
        Button btnExport3d = findViewById(R.id.btnExport3d);
        Button btnRender2d = findViewById(R.id.btnRender2d);

        // Получаем путь к 3D файлу (GLB/glTF/SC) из Intent
        String modelPath = getIntent().getStringExtra("MODEL_PATH");
        if (modelPath != null) {
            loadModel(modelPath);
        }

        // Интерактивное вращение 3D-модели пальцем
        sceneView.setOnTouchListener((v, event) -> {
            float x = event.getX();
            float y = event.getY();

            if (event.getAction() == MotionEvent.ACTION_MOVE && modelNode != null) {
                float dx = x - previousX;
                currentYAngle += dx * 0.5f;
                modelNode.setRotation(new Rotation(0f, currentYAngle, 0f));
            }

            previousX = x;
            previousY = y;
            return true;
        });

        // Экспорт модели в 3D (формат .OBJ)
        btnExport3d.setOnClickListener(v -> exportToObj());

        // Рендер 2D-спрайтшита со всех 8 сторон
        btnRender2d.setOnClickListener(v -> render2dViews());
    }

    private void loadModel(String filePath) {
        // Загрузка GLB/glTF модели на сцену
        modelNode = sceneView.loadModel(filePath, true, 1.0f, new Position(0f, 0f, -2f));
    }

    /**
     * Сохранение геометрии персонажа в файл .OBJ
     */
    private void exportToObj() {
        if (modelNode == null) {
            Toast.makeText(this, "Модель не загружена", Toast.LENGTH_SHORT).show();
            return;
        }

        File exportDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "AssetExplorer/3D");
        if (!exportDir.exists()) exportDir.mkdirs();

        File objFile = new File(exportDir, "brawler_model.obj");

        try (FileWriter writer = new FileWriter(objFile)) {
            writer.write("# Exported by AssetExplorer\n");
            writer.write("o BrawlerCharacter\n\n");

            // Извлечение вершин меша
            FloatBuffer vertices = modelNode.getBufferData("a_position");
            if (vertices != null) {
                vertices.rewind();
                while (vertices.hasRemaining()) {
                    float x = vertices.get();
                    float y = vertices.get();
                    float z = vertices.get();
                    writer.write(String.format("v %.4f %.4f %.4f\n", x, y, z));
                }
            }

            // Извлечение UV-координат
            FloatBuffer uvs = modelNode.getBufferData("a_texcoord");
            if (uvs != null) {
                uvs.rewind();
                while (uvs.hasRemaining()) {
                    float u = uvs.get();
                    float v = uvs.get();
                    writer.write(String.format("vt %.4f %.4f\n", u, v));
                }
            }

            writer.flush();
            Toast.makeText(this, "3D модель сохранена: " + objFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка экспорта 3D", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Поворот модели на 8 углов обзора и сборка кругового 2D спрайтшита
     */
    private void render2dViews() {
        if (modelNode == null) return;

        int views = 8;
        int frameWidth = 512;
        int frameHeight = 512;

        Bitmap spriteSheet = Bitmap.createBitmap(frameWidth * views, frameHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(spriteSheet);

        float originalAngle = currentYAngle;

        for (int i = 0; i < views; i++) {
            float angle = i * (360f / views);
            modelNode.setRotation(new Rotation(0f, angle, 0f));

            Bitmap frame = captureSceneView();
            if (frame != null) {
                Bitmap resizedFrame = Bitmap.createScaledBitmap(frame, frameWidth, frameHeight, false);
                canvas.drawBitmap(resizedFrame, i * frameWidth, 0, null);
            }
        }

        modelNode.setRotation(new Rotation(0f, originalAngle, 0f));

        saveBitmapToGallery(spriteSheet, "brawler_8way_view.png");
    }

    private Bitmap captureSceneView() {
        sceneView.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(sceneView.getDrawingCache());
        sceneView.setDrawingCacheEnabled(false);
        return bitmap;
    }

    private void saveBitmapToGallery(Bitmap bitmap, String fileName) {
        File exportDir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AssetExplorer/2D");
        if (!exportDir.exists()) exportDir.mkdirs();

        File imageFile = new File(exportDir, fileName);
        try (FileOutputStream out = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            Toast.makeText(this, "2D спрайтшит сохранен: " + imageFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка сохранения 2D", Toast.LENGTH_SHORT).show();
        }
    }
}
