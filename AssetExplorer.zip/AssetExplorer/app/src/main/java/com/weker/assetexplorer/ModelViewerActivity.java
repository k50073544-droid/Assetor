package com.weker.assetexplorer;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public final class ModelViewerActivity extends Activity {

    private GLSurfaceView glView;
    private ModelRenderer renderer;
    private float previousX, previousY;
    private String modelPath;
    private String texturePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        modelPath = getIntent().getStringExtra("MODEL_PATH");
        texturePath = getIntent().getStringExtra("TEXTURE_PATH");

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);

        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        renderer = new ModelRenderer(modelPath, texturePath);
        glView.setRenderer(renderer);
        glView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        root.addView(glView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Touch listener for rotation
        glView.setOnTouchListener((v, event) -> {
            float x = event.getX();
            float y = event.getY();
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                float dx = x - previousX;
                float dy = y - previousY;
                renderer.angleY += dx * 0.5f;
                renderer.angleX += dy * 0.5f;
            }
            previousX = x;
            previousY = y;
            return true;
        });

        // Controls overlay
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        int pad = Ui.dp(this, 12);
        controls.setPadding(pad, pad, pad, pad);

        Button btnExport3d = new Button(this);
        btnExport3d.setText("Сохранить 3D (.OBJ)");
        btnExport3d.setTextColor(Color.WHITE);
        btnExport3d.setBackgroundColor(0xFF2196F3);
        btnExport3d.setOnClickListener(v -> export3D());

        Button btnRender2d = new Button(this);
        btnRender2d.setText("Сохранить 2D (8 сторон)");
        btnRender2d.setTextColor(Color.WHITE);
        btnRender2d.setBackgroundColor(0xFF4CAF50);
        btnRender2d.setOnClickListener(v -> render2D());

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        btnParams.setMargins(pad / 2, 0, pad / 2, 0);

        controls.addView(btnExport3d, btnParams);
        controls.addView(btnRender2d, btnParams);

        FrameLayout.LayoutParams ctrlParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        ctrlParams.gravity = Gravity.BOTTOM;
        root.addView(controls, ctrlParams);

        setContentView(root);
    }

    private void export3D() {
        if (renderer.modelData == null) {
            Toast.makeText(this, "Модель не загружена", Toast.LENGTH_SHORT).show();
            return;
        }

        File exportDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "AssetExplorer/3D");
        if (!exportDir.exists()) exportDir.mkdirs();

        File file = new File(exportDir, "brawler_export.obj");
        try (FileWriter fw = new FileWriter(file)) {
            fw.write("# Exported by AssetExplorer\n");
            fw.write("o BrawlerModel\n\n");

            float[] v = renderer.modelData.vertices;
            for (int i = 0; i < v.length; i += 3) {
                fw.write(String.format("v %.4f %.4f %.4f\n", v[i], v[i+1], v[i+2]));
            }
            float[] vt = renderer.modelData.uvs;
            if (vt != null) {
                for (int i = 0; i < vt.length; i += 2) {
                    fw.write(String.format("vt %.4f %.4f\n", vt[i], vt[i+1]));
                }
            }
            int count = v.length / 3;
            for (int i = 1; i <= count; i += 3) {
                if (vt != null) {
                    fw.write(String.format("f %d/%d %d/%d %d/%d\n", i, i, i+1, i+1, i+2, i+2));
                } else {
                    fw.write(String.format("f %d %d %d\n", i, i+1, i+2));
                }
            }
            Toast.makeText(this, "3D модель сохранена в " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка экспорта 3D: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void render2D() {
        new Thread(() -> {
            int views = 8;
            int frameW = 512;
            int frameH = 512;
            Bitmap spriteSheet = Bitmap.createBitmap(frameW * views, frameH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(spriteSheet);

            float savedAngle = renderer.angleY;
            for (int i = 0; i < views; i++) {
                renderer.angleY = i * (360f / views);
                try { Thread.sleep(60); } catch (InterruptedException ignored) {}
                Bitmap frame = captureGL();
                if (frame != null) {
                    Bitmap scaled = Bitmap.createScaledBitmap(frame, frameW, frameH, true);
                    canvas.drawBitmap(scaled, i * frameW, 0, null);
                }
            }
            renderer.angleY = savedAngle;

            File exportDir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AssetExplorer/2D");
            if (!exportDir.exists()) exportDir.mkdirs();
            File imageFile = new File(exportDir, "brawler_8views.png");
            try (FileOutputStream out = new FileOutputStream(imageFile)) {
                spriteSheet.compress(Bitmap.CompressFormat.PNG, 100, out);
                runOnUiThread(() -> Toast.makeText(this, "2D спрайтшит сохранен: " + imageFile.getAbsolutePath(), Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Ошибка сохранения 2D", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private Bitmap captureGL() {
        int w = glView.getWidth();
        int h = glView.getHeight();
        if (w <= 0 || h <= 0) return null;

        int[] pixelData = new int[w * h];
        IntBuffer buffer = IntBuffer.wrap(pixelData);
        buffer.position(0);

        GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buffer);

        int[] pixels = new int[w * h];
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                int pix = pixelData[i * w + j];
                int pb = (pix >> 16) & 0xff;
                int pr = (pix << 16) & 0x00ff0000;
                int pix1 = (pix & 0xff00ff00) | pr | pb;
                pixels[(h - i - 1) * w + j] = pix1;
            }
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888);
    }

    // OpenGL Renderer Class
    private static class ModelRenderer implements GLSurfaceView.Renderer {

        public float angleX = 0f;
        public float angleY = 0f;
        public ModelData modelData;

        private final String mPath;
        private final String tPath;

        private int program;
        private int textureId = -1;
        private FloatBuffer vertexBuffer;
        private FloatBuffer uvBuffer;

        private final float[] projectionMatrix = new float[16];
        private final float[] viewMatrix = new float[16];
        private final float[] modelMatrix = new float[16];
        private final float[] mvpMatrix = new float[16];

        private static final String VERTEX_SHADER =
                "uniform mat4 uMVPMatrix;\n" +
                "attribute vec4 aPosition;\n" +
                "attribute vec2 aTexCoord;\n" +
                "varying vec2 vTexCoord;\n" +
                "void main() {\n" +
                "  gl_Position = uMVPMatrix * aPosition;\n" +
                "  vTexCoord = aTexCoord;\n" +
                "}\n";

        private static final String FRAGMENT_SHADER =
                "precision mediump float;\n" +
                "varying vec2 vTexCoord;\n" +
                "uniform sampler2D uTexture;\n" +
                "uniform int uHasTexture;\n" +
                "void main() {\n" +
                "  if (uHasTexture == 1) {\n" +
                "    gl_FragColor = texture2D(uTexture, vTexCoord);\n" +
                "  } else {\n" +
                "    gl_FragColor = vec4(0.8, 0.4, 0.2, 1.0);\n" +
                "  }\n" +
                "}\n";

        public ModelRenderer(String mPath, String tPath) {
            this.mPath = mPath;
            this.tPath = tPath;
        }

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glClearColor(0.12f, 0.12f, 0.14f, 1.0f);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);

            int vShader = loadShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER);
            int fShader = loadShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER);
            program = GLES20.glCreateProgram();
            GLES20.glAttachShader(program, vShader);
            GLES20.glAttachShader(program, fShader);
            GLES20.glLinkProgram(program);

            // Load model data
            if (mPath != null && new File(mPath).exists()) {
                modelData = parseObj(mPath);
            }
            if (modelData == null) {
                modelData = createDefaultCube();
            }

            ByteBuffer vbb = ByteBuffer.allocateDirect(modelData.vertices.length * 4);
            vbb.order(ByteOrder.nativeOrder());
            vertexBuffer = vbb.asFloatBuffer();
            vertexBuffer.put(modelData.vertices);
            vertexBuffer.position(0);

            if (modelData.uvs != null) {
                ByteBuffer ubb = ByteBuffer.allocateDirect(modelData.uvs.length * 4);
                ubb.order(ByteOrder.nativeOrder());
                uvBuffer = ubb.asFloatBuffer();
                uvBuffer.put(modelData.uvs);
                uvBuffer.position(0);
            }

            // Load texture if available
            if (tPath != null && new File(tPath).exists()) {
                Bitmap bmp = android.graphics.BitmapFactory.decodeFile(tPath);
                if (bmp != null) {
                    int[] texs = new int[1];
                    GLES20.glGenTextures(1, texs, 0);
                    textureId = texs[0];
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0);
                    bmp.recycle();
                }
            }
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
            float ratio = (float) width / height;
            Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1, 1, 2, 100);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

            GLES20.glUseProgram(program);

            Matrix.setLookAtM(viewMatrix, 0, 0, 0, 4, 0, 0, 0, 0, 1, 0);
            Matrix.setIdentityM(modelMatrix, 0);
            Matrix.rotateM(modelMatrix, 0, angleX, 1, 0, 0);
            Matrix.rotateM(modelMatrix, 0, angleY, 0, 1, 0);

            Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, modelMatrix, 0);
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0);

            int mvpHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix");
            GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0);

            int posHandle = GLES20.glGetAttribLocation(program, "aPosition");
            GLES20.glEnableVertexAttribArray(posHandle);
            GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 12, vertexBuffer);

            int texHandle = GLES20.glGetAttribLocation(program, "aTexCoord");
            int hasTexHandle = GLES20.glGetUniformLocation(program, "uHasTexture");

            if (uvBuffer != null && textureId != -1) {
                GLES20.glEnableVertexAttribArray(texHandle);
                GLES20.glVertexAttribPointer(texHandle, 2, GLES20.GL_FLOAT, false, 8, uvBuffer);

                GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
                GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTexture"), 0);
                GLES20.glUniform1i(hasTexHandle, 1);
            } else {
                GLES20.glUniform1i(hasTexHandle, 0);
            }

            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, modelData.vertices.length / 3);

            GLES20.glDisableVertexAttribArray(posHandle);
            if (uvBuffer != null) GLES20.glDisableVertexAttribArray(texHandle);
        }

        private int loadShader(int type, String code) {
            int shader = GLES20.glCreateShader(type);
            GLES20.glShaderSource(shader, code);
            GLES20.glCompileShader(shader);
            return shader;
        }

        private ModelData parseObj(String path) {
            List<Float> rawV = new ArrayList<>();
            List<Float> rawVT = new ArrayList<>();
            List<Float> outV = new ArrayList<>();
            List<Float> outVT = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("v ")) {
                        String[] p = line.split("\\s+");
                        rawV.add(Float.parseFloat(p[1]));
                        rawV.add(Float.parseFloat(p[2]));
                        rawV.add(Float.parseFloat(p[3]));
                    } else if (line.startsWith("vt ")) {
                        String[] p = line.split("\\s+");
                        rawVT.add(Float.parseFloat(p[1]));
                        rawVT.add(Float.parseFloat(p[2]));
                    } else if (line.startsWith("f ")) {
                        String[] parts = line.split("\\s+");
                        for (int i = 1; i <= 3; i++) {
                            String[] idxs = parts[i].split("/");
                            int vi = (Integer.parseInt(idxs[0]) - 1) * 3;
                            outV.add(rawV.get(vi));
                            outV.add(rawV.get(vi + 1));
                            outV.add(rawV.get(vi + 2));

                            if (idxs.length > 1 && !idxs[1].isEmpty() && !rawVT.isEmpty()) {
                                int vti = (Integer.parseInt(idxs[1]) - 1) * 2;
                                outVT.add(rawVT.get(vti));
                                outVT.add(1.0f - rawVT.get(vti + 1));
                            }
                        }
                    }
                }
                ModelData md = new ModelData();
                md.vertices = new float[outV.size()];
                for (int i = 0; i < outV.size(); i++) md.vertices[i] = outV.get(i);
                if (!outVT.isEmpty()) {
                    md.uvs = new float[outVT.size()];
                    for (int i = 0; i < outVT.size(); i++) md.uvs[i] = outVT.get(i);
                }
                return md;
            } catch (Exception e) {
                return null;
            }
        }

        private ModelData createDefaultCube() {
            ModelData md = new ModelData();
            md.vertices = new float[] {
                -0.5f, -0.5f,  0.5f,  0.5f, -0.5f,  0.5f,  0.5f,  0.5f,  0.5f,
                -0.5f, -0.5f,  0.5f,  0.5f,  0.5f,  0.5f, -0.5f,  0.5f,  0.5f,
                -0.5f, -0.5f, -0.5f,  0.5f, -0.5f, -0.5f,  0.5f,  0.5f, -0.5f,
                -0.5f, -0.5f, -0.5f,  0.5f,  0.5f, -0.5f, -0.5f,  0.5f, -0.5f
            };
            md.uvs = new float[] {
                0f, 0f, 1f, 0f, 1f, 1f,
                0f, 0f, 1f, 1f, 0f, 1f,
                1f, 0f, 0f, 0f, 0f, 1f,
                1f, 0f, 0f, 1f, 1f, 1f
            };
            return md;
        }
    }

    private static class ModelData {
        float[] vertices;
        float[] uvs;
    }
}
