package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.Battle;
import com.weker.assetexplorer.codec.GameDb;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * A brawler's screen as in the game: name banner and class on the left with the description, the brawler in 3D
 * in the middle on its glow, gadget / star power / hypercharge icons and the power panel with health, attack and
 * super on the right; "ВЫБРАТЬ" picks a skin, "ИСПЫТАТЬ" opens the training cave. The small buttons open
 * the animations, the voice lines and the skins.
 */
public final class BrawlerActivity extends Activity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private GameDb.Brawler br;
    private GameDb.Skin skin;
    private Sfx sfx;
    private Typeface font = Typeface.DEFAULT_BOLD;
    private GlModelView hero;
    private int heroLoad;
    private Screen screen;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        br = gd.db.brawler(getIntent().getStringExtra("brawler"));
        if (br == null) {
            finish();
            return;
        }
        skin = br.skins.isEmpty() ? null : br.skins.get(0);
        font = GameUi.font(gd);

        FrameLayout root = new FrameLayout(this);
        root.setBackground(new BrawlerListActivity.SkullBackground());
        screen = new Screen(this);
        root.addView(screen, new FrameLayout.LayoutParams(-1, -1));
        // the brawler in 3D, middle of the screen
        hero = new GlModelView(this, true);
        hero.settings().pitch = 0.08f;
        hero.settings().yaw = 0.3f;
        hero.settings().zoom = 0.95f;
        hero.onFailed = () -> root.removeView(hero.view());
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(-1, -1);
        root.addView(hero, hl);
        root.addView(new Buttons(this), new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> placeHero(r - l, bt - t));
        selectSkin(skin);
        new Thread(() -> screen.load()).start();
    }

    /** the 3D view covers the middle third, like the game's stage */
    private void placeHero(int w, int h) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) hero.getLayoutParams();
        int nw = (int) (w * 0.36f), nh = (int) (h * 0.84f);
        if (lp.width == nw && lp.height == nh) return;
        lp.width = nw;
        lp.height = nh;
        lp.leftMargin = (int) (w * 0.315f);
        lp.topMargin = (int) (h * 0.12f);
        hero.setLayoutParams(lp);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sfx.stopAll();
        if (hero != null) hero.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (hero != null) hero.onResume();
    }

    private void selectSkin(GameDb.Skin s) {
        skin = s;
        if (s == null) return;
        final int ticket = ++heroLoad;
        new Thread(() -> {
            try {
                Db.Row r = gd.row(s.model);
                if (r == null) return;
                Model3dActivity.Loaded l = Model3dActivity.load(this, r, s.texture);
                // the hero screen pose when the skin has one, else standing
                SkinTables t = SkinTables.get(this, vid);
                for (SkinTables.Anim a : t.animations(t.conf(s.model, s.texture))) {
                    if (a.label.equals("Экран бойца")) {
                        try {
                            l.anim = Model3dActivity.loadAnim(this, r, l.model, a);
                            l.animInfo = a;
                        } catch (Throwable ignored) {
                            // keep idle
                        }
                    }
                }
                main.post(() -> {
                    if (ticket != heroLoad || isFinishing()) return;
                    hero.setModel(l.model, l.images, l.override);
                    hero.setAnimation(l.anim, l.animInfo == null ? 0 : l.animInfo.start, l.animInfo == null ? -1 : l.animInfo.end);
                });
            } catch (Throwable ignored) {
                // no model in the archive
            }
        }).start();
        if (screen != null) screen.invalidate();
    }

    // ------------------------------------------------------------------ actions
    private void openCave() {
        Intent i = new Intent(this, CaveActivity.class);
        i.putExtra("vid", vid);
        i.putExtra("brawler", br.code);
        if (skin != null) i.putExtra("skin", skin.name);
        startActivity(i);
    }

    private void pickSkin() {
        List<String> names = new ArrayList<>();
        for (GameDb.Skin s : br.skins) {
            names.add((s == skin ? "✓ " : "") + s.title + (s.priceGems > 0 ? "  ·  " + s.priceGems + " 💎" : "") + (s.disabled && !s.name.equals(br.defaultSkin) ? "  (скрыт)" : ""));
        }
        new AlertDialog.Builder(this).setTitle("Скины · " + br.name).setItems(names.toArray(new String[0]), (d, w) -> selectSkin(br.skins.get(w))).show();
    }

    private void animations() {
        if (skin == null) return;
        new Thread(() -> {
            SkinTables t = SkinTables.get(this, vid);
            List<SkinTables.Anim> anims = t.animations(t.conf(skin.model, skin.texture));
            main.post(() -> {
                if (anims.isEmpty()) {
                    Toast.makeText(this, "Анимаций нет в таблицах", Toast.LENGTH_SHORT).show();
                    return;
                }
                String[] n = new String[anims.size()];
                for (int i = 0; i < n.length; i++) n[i] = "▶  " + anims.get(i).label;
                new AlertDialog.Builder(this).setTitle("Анимации · " + skin.title).setItems(n, (d, w) -> {
                    Db.Row r = gd.row(skin.model);
                    if (r == null) return;
                    Intent in = new Intent(this, Model3dActivity.class);
                    in.putExtra("id", r.id);
                    in.putExtra("texture", skin.texture);
                    in.putExtra("title", skin.title + " · " + br.name);
                    in.putExtra("anim", anims.get(w).label);
                    startActivity(in);
                }).show();
            });
        }).start();
    }

    private void voiceLines() {
        Map<String, String> voice = skin != null && !skin.voice.isEmpty() ? skin.voice : br.voice;
        if (voice.isEmpty()) {
            Toast.makeText(this, "Реплик нет в characters.csv", Toast.LENGTH_SHORT).show();
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 14);
        box.setPadding(p, p, p, p);
        for (Map.Entry<String, String> e : voice.entrySet()) {
            int n = gd.db.soundFiles(e.getValue()).size();
            GameButton b = new GameButton(this, e.getKey() + (n > 1 ? "  ×" + n : ""), GameButton.BLUE, font);
            b.setTextSize(14);
            b.setOnClickListener(v -> {
                if (sfx.play(e.getValue()) == null) Toast.makeText(this, "Нет звука в архиве", Toast.LENGTH_SHORT).show();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 48));
            lp.bottomMargin = Ui.dp(this, 6);
            box.addView(b, lp);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this).setTitle("Реплики · " + br.name).setView(sv).setPositiveButton("Закрыть", null).show();
    }

    // ------------------------------------------------------------------ drawing
    /** everything that is painted: banner, description, icons, power panel (layout measured from the game) */
    final class Screen extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap glow, portrait;
        final Bitmap[] items = new Bitmap[3];
        final String[] itemNames = new String[3];
        String cls = "", desc = "", ultiName = "", attack = "";
        int hp;

        Screen(Context c) {
            super(c);
        }

        void load() {
            Bitmap g = GameUi.pic(gd, "hero_screen_center", 512);
            Bitmap pt = gd.export(br.portraitFile, br.portraitExport, 200);
            GameDb db = gd.db;
            GameDb.Table ch = db.table("characters.csv");
            String[] row = ch.row(br.code);
            String c = "", ds = "";
            if (row != null) {
                GameDb.Table ca = db.table("class_archetypes.csv");
                String[] ar = ca.row(ch.get(row, "ClassArchetype"));
                String ct = ar == null ? null : db.text(ca.get(ar, "TID"));
                c = ct != null ? ct : "";
                String dt = db.text(ch.get(row, "TID") + "_DESC");
                ds = dt != null ? dt : "";
            }
            GameDb.Table cards = db.table("cards.csv");
            String un = "";
            Bitmap[] it = new Bitmap[3];
            String[] itn = new String[3];
            for (String[] r : cards.rows) {
                if (!br.code.equals(cards.get(r, "Target"))) continue;
                String meta = cards.get(r, "MetaType");
                if ("3".equals(meta)) {
                    String n = db.text(cards.get(r, "TID"));
                    if (n != null) un = n;
                }
                int k = "5".equals(meta) ? 0 : "4".equals(meta) ? 1 : "6".equals(meta) ? 2 : -1;
                if (k < 0 || it[k] != null) continue;
                String ex = cards.get(r, "IconExportName"), f = GameDb.fileName(cards.get(r, "IconSWF"));
                if (ex.isEmpty()) continue;
                boolean ui = f.isEmpty() || f.equals("ui.sc");
                it[k] = ui ? GameUi.pic(gd, ex, 160) : gd.export(f, ex, 160);
                String n = db.text(cards.get(r, "TID"));
                itn[k] = n != null ? GameDb.nice(n) : "";
            }
            String atk;
            try {
                Battle bt = new Battle(db, Battle.Mode.TRAINING, null, 1);
                Battle.Kit k = bt.kit(br.code);
                atk = k.weapon.bullets > 1 ? k.weapon.bullets + " x " + k.weapon.damage : String.valueOf(k.weapon.damage);
                hp = k.hp;
            } catch (Throwable e) {
                atk = "—";
                hp = br.hp * 2;
            }
            gd.forget("ui.sc");
            final String fc = c, fd = ds, fu = un, fa = atk;
            main.post(() -> {
                glow = g;
                portrait = pt;
                System.arraycopy(it, 0, items, 0, 3);
                System.arraycopy(itn, 0, itemNames, 0, 3);
                cls = fc;
                desc = fd;
                ultiName = fu;
                attack = fa;
                invalidate();
            });
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            t.setTypeface(font);
            Locale ru = Locale.forLanguageTag("ru");
            // glow behind the brawler
            if (glow != null) {
                float gs = h * 0.95f;
                c.drawBitmap(glow, null, new RectF(w * 0.5f - gs / 2, h * 0.47f - gs / 2, w * 0.5f + gs / 2, h * 0.47f + gs / 2), p);
            }
            // name banner: light slanted strip, big outlined name, class under it
            Path ban = new Path();
            ban.moveTo(0, h * 0.21f);
            ban.lineTo(w * 0.275f, h * 0.195f);
            ban.lineTo(w * 0.26f, h * 0.335f);
            ban.lineTo(0, h * 0.35f);
            ban.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF9FDFFF);
            c.drawPath(ban, p);
            Path ban2 = new Path();
            ban2.moveTo(0, h * 0.265f);
            ban2.lineTo(w * 0.27f, h * 0.25f);
            ban2.lineTo(w * 0.26f, h * 0.335f);
            ban2.lineTo(0, h * 0.35f);
            ban2.close();
            p.setColor(0xFF6FC8F2);
            c.drawPath(ban2, p);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(h * 0.075f);
            GameUi.outlined(c, br.name.toUpperCase(ru), w * 0.18f, h * 0.27f, t, 0xFFFFFFFF, h * 0.012f);
            t.setTextSize(h * 0.036f);
            if (!cls.isEmpty()) GameUi.outlined(c, cls.toUpperCase(ru), w * 0.17f, h * 0.315f, t, 0xFFFFFFFF, h * 0.007f);
            t.setTextSize(h * 0.03f);
            GameUi.outlined(c, br.rarityName.toUpperCase(ru), w * 0.19f, h * 0.355f, t, GameDb.rarityColor(br.rarity.isEmpty() ? "common" : br.rarity) | 0xFF000000, h * 0.006f);
            // portrait in the level badge place
            if (portrait != null) {
                float ps = h * 0.11f;
                p.setColor(0xFF3B2A7A);
                c.drawRoundRect(new RectF(w * 0.07f, h * 0.37f, w * 0.07f + ps, h * 0.37f + ps), h * 0.015f, h * 0.015f, p);
                c.drawBitmap(portrait, null, new RectF(w * 0.07f + 3, h * 0.37f + 3, w * 0.07f + ps - 3, h * 0.37f + ps - 3), p);
            }
            if (skin != null) {
                t.setTextAlign(Paint.Align.LEFT);
                t.setTextSize(h * 0.032f);
                GameUi.outlined(c, skin.title, w * 0.07f + h * 0.13f, h * 0.43f, t, 0xFFFFFFFF, h * 0.006f);
            }
            // description, wrapped
            t.setTextAlign(Paint.Align.LEFT);
            t.setTextSize(h * 0.029f);
            float y = h * 0.53f;
            for (String line : wrap(desc, w * 0.2f)) {
                if (y > h * 0.73f) break;
                GameUi.outlined(c, line, w * 0.072f, y, t, 0xFFFFFFFF, h * 0.005f);
                y += h * 0.036f;
            }
            // items: gadget, star power, hypercharge
            float is = h * 0.13f;
            for (int k = 0; k < 3; k++) {
                if (items[k] == null) continue;
                float cx = w * (0.8f + k * 0.072f), cy = h * 0.31f;
                c.drawBitmap(items[k], null, new RectF(cx - is / 2, cy - is / 2, cx + is / 2, cy + is / 2), p);
            }
            // power panel
            RectF pan = new RectF(w * 0.775f, h * 0.49f, w * 0.98f, h * 0.885f);
            p.setColor(0xCC10235A);
            c.drawRoundRect(pan, h * 0.02f, h * 0.02f, p);
            p.setColor(0xFFD62AD6);
            c.drawCircle(w * 0.782f, h * 0.52f, h * 0.045f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(h * 0.006f);
            p.setColor(0xFF000000);
            c.drawCircle(w * 0.782f, h * 0.52f, h * 0.045f, p);
            p.setStyle(Paint.Style.FILL);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(h * 0.045f);
            GameUi.outlined(c, "11", w * 0.782f, h * 0.537f, t, 0xFFFFFFFF, h * 0.007f);
            t.setTextAlign(Paint.Align.LEFT);
            t.setTextSize(h * 0.04f);
            GameUi.outlined(c, "СИЛА", w * 0.81f, h * 0.53f, t, 0xFFFFFFFF, h * 0.007f);
            t.setTextAlign(Paint.Align.RIGHT);
            t.setTextSize(h * 0.028f);
            GameUi.outlined(c, "МАКС. 11", w * 0.973f, h * 0.53f, t, 0xFFFF5BE4, h * 0.005f);
            float sx = w * 0.81f, sw = (w * 0.973f - sx) / 11f;
            p.setColor(0xFFFF5BE4);
            for (int i = 0; i < 11; i++) c.drawRect(sx + i * sw + 2, h * 0.548f, sx + (i + 1) * sw - 2, h * 0.562f, p);
            stat(c, w, h, 0, 0xFF3BD24A, "ЗДОРОВЬЕ", String.valueOf(hp), 0xFF9DFF8F);
            stat(c, w, h, 1, 0xFFEF3B4D, "АТАКА", attack, 0xFFFF8C9A);
            stat(c, w, h, 2, 0xFFF7B22B, "СУПЕР", ultiName.toUpperCase(ru), 0xFFFFD36B);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(h * 0.06f);
            GameUi.outlined(c, "МАКС. УР.", w * 0.875f, h * 0.95f, t, 0xFFFFD02A, h * 0.009f);
        }

        void stat(Canvas c, float w, float h, int i, int color, String label, String value, int labelColor) {
            float top = h * (0.585f + i * 0.098f), bh = h * 0.085f;
            p.setColor(0xFF0E1A44);
            c.drawRect(w * 0.785f, top, w * 0.97f, top + bh, p);
            p.setColor(color);
            c.drawRect(w * 0.785f, top, w * 0.785f + bh, top + bh, p);
            t.setTextAlign(Paint.Align.LEFT);
            t.setTextSize(h * 0.03f);
            GameUi.outlined(c, label, w * 0.785f + bh * 1.2f, top + bh * 0.42f, t, labelColor, h * 0.005f);
            t.setTextSize(h * 0.036f);
            GameUi.outlined(c, value, w * 0.785f + bh * 1.2f, top + bh * 0.88f, t, 0xFFFFFFFF, h * 0.006f);
        }

        List<String> wrap(String s, float width) {
            List<String> out = new ArrayList<>();
            if (s == null || s.isEmpty()) return out;
            StringBuilder line = new StringBuilder();
            for (String word : s.replace("\\n", " ").split("\\s+")) {
                String test = line.length() == 0 ? word : line + " " + word;
                if (t.measureText(test) > width && line.length() > 0) {
                    out.add(line.toString());
                    line = new StringBuilder(word);
                } else {
                    line = new StringBuilder(test);
                }
            }
            if (line.length() > 0) out.add(line.toString());
            return out;
        }
    }

    /** the tappable parts: back, the small square buttons, ВЫБРАТЬ and ИСПЫТАТЬ */
    final class Buttons extends FrameLayout {
        Buttons(Context c) {
            super(c);
            View back = new BrawlerListActivity.BackButton(c);
            back.setOnClickListener(v -> finish());
            addView(back, new LayoutParams(Ui.dp(c, 84), Ui.dp(c, 46)));
        }

        boolean built;

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            if (built || w == 0 || h == 0) return;
            built = true;
            post(() -> build(w, h));
        }

        void build(int w, int h) {
            Context c = getContext();
            String[] icons = {"👤", "💬", "👕"};
            Runnable[] acts = {BrawlerActivity.this::animations, BrawlerActivity.this::voiceLines, BrawlerActivity.this::pickSkin};
            for (int i = 0; i < 3; i++) {
                TextView sq = new TextView(c);
                sq.setText(icons[i]);
                sq.setTextSize(20);
                sq.setGravity(Gravity.CENTER);
                sq.setBackground(Ui.round(0xFF3A3F52, Ui.dp(c, 8)));
                final Runnable a = acts[i];
                sq.setOnClickListener(v -> a.run());
                LayoutParams lp = new LayoutParams((int) (w * 0.06f), (int) (h * 0.085f));
                lp.leftMargin = (int) (w * (0.075f + i * 0.068f));
                lp.topMargin = (int) (h * 0.755f);
                addView(sq, lp);
            }
            GameButton pick = new GameButton(c, "Выбрать", GameButton.YELLOW, font);
            pick.setTextSize(20);
            pick.setOnClickListener(v -> pickSkin());
            LayoutParams pl = new LayoutParams((int) (w * 0.195f), (int) (h * 0.115f));
            pl.leftMargin = (int) (w * 0.068f);
            pl.topMargin = (int) (h * 0.855f);
            addView(pick, pl);
            GameButton tryIt = new GameButton(c, "Испытать", GameButton.BLUE, font);
            tryIt.setTextSize(15);
            tryIt.setOnClickListener(v -> openCave());
            LayoutParams tl = new LayoutParams((int) (w * 0.07f), (int) (h * 0.1f));
            tl.leftMargin = (int) (w * 0.278f);
            tl.topMargin = (int) (h * 0.865f);
            tl.width = (int) (w * 0.075f);
            addView(tryIt, tl);
        }
    }
}
