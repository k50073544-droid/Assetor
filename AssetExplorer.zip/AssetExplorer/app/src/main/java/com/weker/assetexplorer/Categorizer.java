package com.weker.assetexplorer;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Sorts game files into types (by format) and themes (by name keywords). */
public final class Categorizer {

    private Categorizer() {}

    // ---- types (one per file)
    public static final String T_3D = "3d";
    public static final String T_TEX = "tex";
    public static final String T_SC = "sc";
    public static final String T_IMG = "img";
    public static final String T_MUSIC = "music";
    public static final String T_SFX = "sfx";
    public static final String T_VIDEO = "video";
    public static final String T_CSV = "csv";
    public static final String T_DATA = "data";
    public static final String T_FONT = "font";
    public static final String T_SHADER = "shader";
    public static final String T_OTHER = "other";

    public static final Map<String, String> TYPE_NAMES = new LinkedHashMap<>();
    public static final Map<String, String> TAG_NAMES = new LinkedHashMap<>();
    static final Map<String, String[]> TAG_KEYWORDS = new LinkedHashMap<>();

    static {
        TYPE_NAMES.put(T_3D, "3D модели");
        TYPE_NAMES.put(T_TEX, "Текстуры");
        TYPE_NAMES.put(T_SC, "2D графика (.sc)");
        TYPE_NAMES.put(T_IMG, "Картинки");
        TYPE_NAMES.put(T_SFX, "Звуки");
        TYPE_NAMES.put(T_MUSIC, "Музыка");
        TYPE_NAMES.put(T_VIDEO, "Видео");
        TYPE_NAMES.put(T_CSV, "Таблицы (csv)");
        TYPE_NAMES.put(T_DATA, "Данные");
        TYPE_NAMES.put(T_FONT, "Шрифты");
        TYPE_NAMES.put(T_SHADER, "Шейдеры");
        TYPE_NAMES.put(T_OTHER, "Прочее");

        // keywords match whole name parts (split by _ . / -); "word*" = part starts with word
        tag("pins", "Пины/эмодзи", "pin", "pins", "emoji*", "emote*", "emoticon*");
        tag("icons", "Иконки", "icon*", "thumbnail*", "portrait*", "avatar*", "profile*");
        tag("skins", "Скины", "skin*");
        tag("heroes", "Бравлеры", "hero*", "brawler*", "character*");
        tag("sprays", "Спреи", "spray*");
        tag("gear", "Гаджеты/пассивки", "gadget*", "gear*", "starpower*", "hypercharge*", "ability*");
        tag("maps", "Карты/окружение", "map*", "tile", "tiles", "tileset*", "environment*", "env", "level*", "arena*", "background*", "bg");
        tag("fx", "Эффекты", "effect*", "fx", "vfx", "particle*");
        tag("ui", "Интерфейс", "ui", "hud", "button*", "popup*", "menu*", "loading*");
        tag("anim", "Анимации", "anim*", "idle*", "walk*", "attack*", "win", "lose", "run", "pose*");
        tag("pets", "Питомцы", "pet", "pets");
        tag("text", "Локализация", "localization", "texts", "lang*");
    }

    static void tag(String id, String name, String... kw) {
        TAG_NAMES.put(id, name);
        TAG_KEYWORDS.put(id, kw);
    }

    public static String ext(String path) {
        String n = name(path);
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    public static String name(String path) {
        int i = path.lastIndexOf('/');
        return i < 0 ? path : path.substring(i + 1);
    }

    public static String type(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        String e = ext(p);
        switch (e) {
            case "glb": case "gltf": case "scw": case "dae": case "fbx": case "obj":
                return T_3D;
            case "sctx": case "ktx": case "zktx": case "pvr": case "astc": case "ktx2":
                return T_TEX;
            case "sc":
                return p.endsWith("_tex.sc") ? T_TEX : T_SC;
            case "png": case "jpg": case "jpeg": case "webp": case "gif": case "bmp":
                return T_IMG;
            case "ogg": case "mp3": case "wav": case "opus": case "m4a": case "aac": case "flac":
                return (p.contains("music") || p.contains("/mus/")) ? T_MUSIC : T_SFX;
            case "mp4": case "webm": case "mkv": case "3gp":
                return T_VIDEO;
            case "csv":
                return T_CSV;
            case "json": case "txt": case "xml": case "ini": case "yaml": case "yml": case "plist": case "cfg": case "bytes":
                return T_DATA;
            case "ttf": case "otf":
                return T_FONT;
            case "glsl": case "vert": case "frag": case "shader": case "vsh": case "fsh": case "metal": case "spv":
                return T_SHADER;
            default:
                if (p.contains("sc3d/")) return T_3D;
                return T_OTHER;
        }
    }

    /** returns ",tag1,tag2," or "" */
    public static String tags(String path) {
        String[] parts = path.toLowerCase(Locale.ROOT).split("[^a-z0-9]+");
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String[]> e : TAG_KEYWORDS.entrySet()) {
            boolean hit = false;
            for (String k : e.getValue()) {
                boolean prefix = k.endsWith("*");
                String w = prefix ? k.substring(0, k.length() - 1) : k;
                for (String part : parts) {
                    if (prefix ? part.startsWith(w) : part.equals(w)) {
                        hit = true;
                        break;
                    }
                }
                if (hit) break;
            }
            if (hit) {
                if (sb.length() == 0) sb.append(',');
                sb.append(e.getKey()).append(',');
            }
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- search
    /** Russian words people will type, mapped to type/tag filters. */
    static final String[][] ALIASES = {
            {"пин", "tag:pins"}, {"эмодз", "tag:pins"}, {"эмоц", "tag:pins"},
            {"иконк", "tag:icons"}, {"аватар", "tag:icons"}, {"значок", "tag:icons"},
            {"скин", "tag:skins"}, {"облик", "tag:skins"},
            {"бравлер", "tag:heroes"}, {"персонаж", "tag:heroes"}, {"герой", "tag:heroes"}, {"боец", "tag:heroes"},
            {"спрей", "tag:sprays"},
            {"гаджет", "tag:gear"}, {"пассивк", "tag:gear"}, {"звездн", "tag:gear"}, {"гиперзаряд", "tag:gear"},
            {"карта", "tag:maps"}, {"карты", "tag:maps"}, {"окружен", "tag:maps"}, {"фон", "tag:maps"},
            {"эффект", "tag:fx"}, {"частиц", "tag:fx"},
            {"интерфейс", "tag:ui"}, {"кнопк", "tag:ui"},
            {"анимац", "tag:anim"},
            {"питом", "tag:pets"},
            {"перевод", "tag:text"}, {"локализ", "tag:text"},
            {"модел", "type:3d"}, {"3д", "type:3d"}, {"3d", "type:3d"},
            {"текстур", "type:tex"},
            {"картинк", "type:img"}, {"изображ", "type:img"}, {"png", "type:img"},
            {"звук", "type:sfx"}, {"музык", "type:music"}, {"видео", "type:video"},
            {"таблиц", "type:csv"}, {"шрифт", "type:font"}, {"шейдер", "type:shader"},
    };

    public static final class Query {
        public final List<String> words = new ArrayList<>();
        public final List<String> types = new ArrayList<>();
        public final List<String> tags = new ArrayList<>();
    }

    public static Query parseQuery(String text) {
        Query q = new Query();
        if (text == null) return q;
        for (String raw : text.toLowerCase(Locale.ROOT).trim().split("\\s+")) {
            if (raw.isEmpty()) continue;
            String alias = null;
            for (String[] a : ALIASES) {
                if (raw.startsWith(a[0])) {
                    alias = a[1];
                    break;
                }
            }
            if (alias == null) {
                q.words.add(raw);
            } else if (alias.startsWith("type:")) {
                q.types.add(alias.substring(5));
            } else {
                q.tags.add(alias.substring(4));
            }
        }
        return q;
    }

    // ---------------------------------------------------------------- versions
    /** Natural compare: "62.10.1" > "62.9". */
    public static int compareVersions(String a, String b) {
        String[] x = a.split("[^0-9]+"), y = b.split("[^0-9]+");
        int n = Math.max(x.length, y.length);
        for (int i = 0; i < n; i++) {
            long u = i < x.length && !x[i].isEmpty() ? parse(x[i]) : 0;
            long v = i < y.length && !y[i].isEmpty() ? parse(y[i]) : 0;
            if (u != v) return Long.compare(u, v);
        }
        return a.compareTo(b);
    }

    static long parse(String s) {
        try {
            return Long.parseLong(s.length() > 15 ? s.substring(0, 15) : s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
