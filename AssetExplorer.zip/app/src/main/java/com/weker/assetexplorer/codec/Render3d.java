package com.weker.assetexplorer.codec;

import java.util.Map;

/**
 * Small software renderer for {@link Model3d}: perspective camera orbiting the model, z-buffer,
 * perspective-correct texturing. Shading uses the game's own "lightmaps" when available — matcap images
 * sampled by the view-space normal (diffuse multiplies, specular adds) — otherwise a soft directional light.
 * Pure Java so it works the same everywhere.
 */
public final class Render3d {

    public float yaw = 0.5f, pitch = 0.2f, zoom = 1f;
    /** screen-space pan in fractions of the view */
    public float panX, panY;
    public boolean lighting = true, textured = true, flipV = false;
    public int background = 0xFF20232F;

    /** Single texture for every part (old behaviour / manual choice). */
    public Img render(Model3d m, Img texture, int w, int h, int ss) {
        return render(m, null, texture, w, h, ss);
    }

    /**
     * @param images   texture file name -> picture (material textures and lightmaps), may be null
     * @param override when not null, used instead of the material textures on every part
     */
    public Img render(Model3d m, Map<String, Img> images, Img override, int w, int h, int ss) {
        ss = Math.max(1, ss);
        int W = w * ss, H = h * ss;
        int[] px = new int[W * H];
        float[] zb = new float[W * H];
        java.util.Arrays.fill(px, background);
        java.util.Arrays.fill(zb, Float.MAX_VALUE);

        float[] b = m.bounds;
        float cx = (b[0] + b[3]) / 2, cy = (b[1] + b[4]) / 2, cz = (b[2] + b[5]) / 2;
        float dx = b[3] - b[0], dy = b[4] - b[1], dz = b[5] - b[2];
        float radius = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) / 2f;
        if (radius <= 0) radius = 1;
        double fov = Math.toRadians(30);
        double aspect = W / (double) H;
        double fit = Math.min(1, aspect);
        float dist = (float) (radius / Math.sin(fov / 2) / fit / zoom);
        float near = Math.max(dist - radius * 4, dist * 0.02f);
        double f = (H / 2.0) / Math.tan(fov / 2);
        double ox = W / 2.0 + panX * W, oy = H / 2.0 + panY * H;

        // rotation: yaw around Y, then pitch around X
        float cyw = (float) Math.cos(yaw), syw = (float) Math.sin(yaw);
        float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        float[] r = {cyw, 0, -syw, syw * sp, cp, cyw * sp, syw * cp, -sp, cyw * cp};

        Tri t3 = new Tri();
        for (Model3d.Part p : m.parts) {
            if (!p.visible) continue;
            Img tex = null;
            if (textured && p.hasUv) {
                tex = override != null ? override : images != null && p.diffuseTex != null ? images.get(p.diffuseTex) : null;
            }
            Img lmD = lighting && images != null && p.lightmapDiffuse != null ? images.get(p.lightmapDiffuse) : null;
            Img lmS = lighting && images != null && p.lightmapSpecular != null ? images.get(p.lightmapSpecular) : null;
            t3.tex = tex;
            t3.lmD = lmD;
            t3.lmS = lmS;
            t3.lambert = lighting && lmD == null;
            for (int t = 0; t < p.triangles; t++) {
                boolean skip = false;
                for (int k = 0; k < 3; k++) {
                    int i = (t * 3 + k) * 3;
                    float x = p.pos[i] - cx, y = p.pos[i + 1] - cy, z = p.pos[i + 2] - cz;
                    float X = r[0] * x + r[1] * y + r[2] * z;
                    float Y = r[3] * x + r[4] * y + r[5] * z;
                    float Z = r[6] * x + r[7] * y + r[8] * z;
                    float depth = dist - Z; // camera looks at -Z from +Z
                    if (depth <= near) { skip = true; break; }
                    t3.sx[k] = (float) (ox + X * f / depth);
                    t3.sy[k] = (float) (oy - Y * f / depth);
                    t3.sw[k] = 1f / depth;
                }
                if (skip) continue;
                if (lighting) {
                    float fnx = 0, fny = 0, fnz = 0;
                    if (!p.hasNormals) {
                        int i0 = t * 9;
                        float ax = p.pos[i0 + 3] - p.pos[i0], ay = p.pos[i0 + 4] - p.pos[i0 + 1], az = p.pos[i0 + 5] - p.pos[i0 + 2];
                        float bx = p.pos[i0 + 6] - p.pos[i0], by = p.pos[i0 + 7] - p.pos[i0 + 1], bz = p.pos[i0 + 8] - p.pos[i0 + 2];
                        fnx = ay * bz - az * by;
                        fny = az * bx - ax * bz;
                        fnz = ax * by - ay * bx;
                    }
                    for (int k = 0; k < 3; k++) {
                        int i = (t * 3 + k) * 3;
                        float nx = p.hasNormals ? p.nrm[i] : fnx, ny = p.hasNormals ? p.nrm[i + 1] : fny, nz = p.hasNormals ? p.nrm[i + 2] : fnz;
                        float NX = r[0] * nx + r[1] * ny + r[2] * nz;
                        float NY = r[3] * nx + r[4] * ny + r[5] * nz;
                        float NZ = r[6] * nx + r[7] * ny + r[8] * nz;
                        float nl = (float) Math.sqrt(NX * NX + NY * NY + NZ * NZ);
                        if (nl == 0) { NX = 0; NY = 0; NZ = 1; nl = 1; }
                        t3.nx[k] = NX / nl;
                        t3.ny[k] = NY / nl;
                        t3.nz[k] = NZ / nl;
                    }
                }
                int ui = t * 6;
                for (int k = 0; k < 3; k++) {
                    t3.u[k] = p.uv[ui + k * 2];
                    t3.v[k] = flipV ? 1 - p.uv[ui + k * 2 + 1] : p.uv[ui + k * 2 + 1];
                }
                raster(px, zb, W, H, t3);
            }
        }
        if (ss == 1) return new Img(W, H, px);
        int[] out = new int[w * h];
        int n = ss * ss;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int a = 0, rr = 0, g = 0, bb = 0;
                for (int j = 0; j < ss; j++) {
                    for (int i = 0; i < ss; i++) {
                        int c = px[(y * ss + j) * W + x * ss + i];
                        a += c >>> 24;
                        rr += (c >> 16) & 255;
                        g += (c >> 8) & 255;
                        bb += c & 255;
                    }
                }
                out[y * w + x] = ((a / n) << 24) | ((rr / n) << 16) | ((g / n) << 8) | (bb / n);
            }
        }
        return new Img(w, h, out);
    }

    /** one triangle's screen data */
    static final class Tri {
        final float[] sx = new float[3], sy = new float[3], sw = new float[3];
        final float[] nx = new float[3], ny = new float[3], nz = new float[3];
        final float[] u = new float[3], v = new float[3];
        Img tex, lmD, lmS;
        boolean lambert;
    }

    // light for models without lightmaps: upper left, towards the viewer
    static final float LX = -0.45f, LY = 0.62f, LZ = 0.64f;

    private void raster(int[] px, float[] zb, int W, int H, Tri t) {
        float x0 = t.sx[0], y0 = t.sy[0], x1 = t.sx[1], y1 = t.sy[1], x2 = t.sx[2], y2 = t.sy[2];
        float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (Math.abs(area) < 1e-9f) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int maxX = Math.min(W - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int maxY = Math.min(H - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        float inv = 1f / area;
        boolean shade = t.lambert || t.lmD != null;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5f;
            for (int x = minX; x <= maxX; x++) {
                float pxf = x + 0.5f;
                float a = ((x1 - pxf) * (y2 - py) - (x2 - pxf) * (y1 - py)) * inv;
                float b = ((x2 - pxf) * (y0 - py) - (x0 - pxf) * (y2 - py)) * inv;
                float c = 1 - a - b;
                if (a < 0 || b < 0 || c < 0) continue;
                float wa = a * t.sw[0], wb = b * t.sw[1], wc = c * t.sw[2];
                float w = wa + wb + wc;
                float depth = 1f / w;
                int o = y * W + x;
                if (depth >= zb[o]) continue;
                wa /= w;
                wb /= w;
                wc /= w;
                int col;
                if (t.tex != null) {
                    col = sample(t.tex, wa * t.u[0] + wb * t.u[1] + wc * t.u[2], wa * t.v[0] + wb * t.v[1] + wc * t.v[2]);
                    if ((col >>> 24) < 100) continue; // cut-out (hair, lashes)
                } else {
                    col = 0xFFC4C9D4;
                }
                int rr = (col >> 16) & 255, gg = (col >> 8) & 255, bb = col & 255;
                if (shade) {
                    float nx = wa * t.nx[0] + wb * t.nx[1] + wc * t.nx[2];
                    float ny = wa * t.ny[0] + wb * t.ny[1] + wc * t.ny[2];
                    float nz = wa * t.nz[0] + wb * t.nz[1] + wc * t.nz[2];
                    float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                    if (nl > 0) { nx /= nl; ny /= nl; nz /= nl; }
                    if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; } // inside of a double-sided surface
                    if (t.lmD != null) {
                        float mu = nx * 0.48f + 0.5f, mv = 0.5f - ny * 0.48f;
                        int d = sampleClamp(t.lmD, mu, mv);
                        rr = rr * ((d >> 16) & 255) / 255;
                        gg = gg * ((d >> 8) & 255) / 255;
                        bb = bb * (d & 255) / 255;
                        if (t.lmS != null) {
                            int s = sampleClamp(t.lmS, mu, mv);
                            rr += (s >> 16) & 255;
                            gg += (s >> 8) & 255;
                            bb += s & 255;
                        }
                    } else {
                        float l = 0.52f + 0.58f * Math.max(0, nx * LX + ny * LY + nz * LZ);
                        rr = (int) (rr * l);
                        gg = (int) (gg * l);
                        bb = (int) (bb * l);
                    }
                    rr = Math.min(255, rr);
                    gg = Math.min(255, gg);
                    bb = Math.min(255, bb);
                }
                px[o] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
                zb[o] = depth;
            }
        }
    }

    /** bilinear, repeating */
    static int sample(Img im, float u, float v) {
        float x = (u - (float) Math.floor(u)) * im.width - 0.5f;
        float y = (v - (float) Math.floor(v)) * im.height - 0.5f;
        return bilinear(im, x, y, true);
    }

    /** bilinear, clamped (matcaps) */
    static int sampleClamp(Img im, float u, float v) {
        return bilinear(im, u * im.width - 0.5f, v * im.height - 0.5f, false);
    }

    static int bilinear(Img im, float x, float y, boolean wrap) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        float fx = x - x0, fy = y - y0;
        int c00 = px(im, x0, y0, wrap), c10 = px(im, x0 + 1, y0, wrap), c01 = px(im, x0, y0 + 1, wrap), c11 = px(im, x0 + 1, y0 + 1, wrap);
        int out = 0;
        for (int sh = 0; sh <= 24; sh += 8) {
            float top = ((c00 >>> sh) & 255) * (1 - fx) + ((c10 >>> sh) & 255) * fx;
            float bot = ((c01 >>> sh) & 255) * (1 - fx) + ((c11 >>> sh) & 255) * fx;
            out |= (Math.round(top * (1 - fy) + bot * fy) & 255) << sh;
        }
        return out;
    }

    static int px(Img im, int x, int y, boolean wrap) {
        if (wrap) {
            x = Math.floorMod(x, im.width);
            y = Math.floorMod(y, im.height);
        } else {
            x = Math.max(0, Math.min(im.width - 1, x));
            y = Math.max(0, Math.min(im.height - 1, y));
        }
        return im.argb[y * im.width + x];
    }
}
