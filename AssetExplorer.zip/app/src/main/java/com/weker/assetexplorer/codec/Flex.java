package com.weker.assetexplorer.codec;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal FlexBuffers reader (schemaless binary JSON used for glTF extensions in Supercell files).
 * Produces Map / List / Long / Double / Boolean / String / byte[].
 */
public final class Flex {

    private Flex() {}

    static final int NULL = 0, INT = 1, UINT = 2, FLOAT = 3, KEY = 4, STRING = 5, INDIRECT_INT = 6, INDIRECT_UINT = 7,
            INDIRECT_FLOAT = 8, MAP = 9, VECTOR = 10, VECTOR_INT = 11, VECTOR_UINT = 12, VECTOR_FLOAT = 13, VECTOR_KEY = 14,
            VECTOR_STRING_DEPRECATED = 15, VECTOR_INT2 = 16, VECTOR_FLOAT4 = 24, BLOB = 25, BOOL = 26, VECTOR_BOOL = 36;

    /** Reads the root value of a flexbuffer stored in d[start, end). */
    public static Object read(byte[] d, int start, int end) {
        if (end - start < 3) return null;
        int rootWidth = d[end - 1] & 0xFF;
        int packed = d[end - 2] & 0xFF;
        int pos = end - 2 - rootWidth;
        return value(d, pos, rootWidth, packed, 0);
    }

    static Object value(byte[] d, int pos, int parentWidth, int packed, int depth) {
        if (depth > 64) return null;
        int type = packed >> 2;
        int width = 1 << (packed & 3);
        switch (type) {
            case NULL: return null;
            case INT: return readInt(d, pos, parentWidth);
            case UINT: return readUInt(d, pos, parentWidth);
            case FLOAT: return readFloat(d, pos, parentWidth);
            case BOOL: return readUInt(d, pos, parentWidth) != 0;
            default: break;
        }
        int target = (int) (pos - readUInt(d, pos, parentWidth));
        switch (type) {
            case KEY: return key(d, target);
            case STRING: {
                int len = (int) readUInt(d, target - width, width);
                return new String(d, target, len, StandardCharsets.UTF_8);
            }
            case INDIRECT_INT: return readInt(d, target, width);
            case INDIRECT_UINT: return readUInt(d, target, width);
            case INDIRECT_FLOAT: return readFloat(d, target, width);
            case BLOB: {
                int len = (int) readUInt(d, target - width, width);
                return java.util.Arrays.copyOfRange(d, target, target + len);
            }
            case MAP: {
                int size = (int) readUInt(d, target - width, width);
                int keysPos = target - 3 * width;
                int keys = (int) (keysPos - readUInt(d, keysPos, width));
                int keyWidth = (int) readUInt(d, target - 2 * width, width);
                Map<String, Object> m = new LinkedHashMap<>();
                for (int i = 0; i < size; i++) {
                    int kp = keys + i * keyWidth;
                    String k = key(d, (int) (kp - readUInt(d, kp, keyWidth)));
                    int vt = d[target + size * width + i] & 0xFF;
                    m.put(k, value(d, target + i * width, width, vt, depth + 1));
                }
                return m;
            }
            case VECTOR: {
                int size = (int) readUInt(d, target - width, width);
                List<Object> l = new ArrayList<>(size);
                for (int i = 0; i < size; i++) {
                    int vt = d[target + size * width + i] & 0xFF;
                    l.add(value(d, target + i * width, width, vt, depth + 1));
                }
                return l;
            }
            default: break;
        }
        if (type >= VECTOR_INT && type <= VECTOR_STRING_DEPRECATED || type == VECTOR_BOOL) {
            int size = (int) readUInt(d, target - width, width);
            int et = type == VECTOR_BOOL ? BOOL : type - VECTOR_INT + INT;
            return typed(d, target, width, size, et, depth);
        }
        if (type >= VECTOR_INT2 && type <= VECTOR_FLOAT4) {
            int n = (type - VECTOR_INT2) / 3 + 2;
            int et = (type - VECTOR_INT2) % 3 + INT;
            return typed(d, target, width, n, et, depth);
        }
        return null;
    }

    static List<Object> typed(byte[] d, int target, int width, int size, int et, int depth) {
        List<Object> l = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            int p = target + i * width;
            switch (et) {
                case INT: l.add(readInt(d, p, width)); break;
                case UINT: l.add(readUInt(d, p, width)); break;
                case FLOAT: l.add(readFloat(d, p, width)); break;
                case BOOL: l.add(readUInt(d, p, width) != 0); break;
                case KEY: l.add(key(d, (int) (p - readUInt(d, p, width)))); break;
                default: l.add(value(d, p, width, (STRING << 2) | Integer.numberOfTrailingZeros(width), depth + 1)); break;
            }
        }
        return l;
    }

    static String key(byte[] d, int p) {
        int e = p;
        while (e < d.length && d[e] != 0) e++;
        return new String(d, p, e - p, StandardCharsets.UTF_8);
    }

    static long readUInt(byte[] d, int p, int w) {
        long v = 0;
        for (int i = w - 1; i >= 0; i--) v = (v << 8) | (d[p + i] & 0xFF);
        return v;
    }

    static long readInt(byte[] d, int p, int w) {
        long v = readUInt(d, p, w);
        int bits = w * 8;
        return bits >= 64 ? v : (v << (64 - bits)) >> (64 - bits);
    }

    static double readFloat(byte[] d, int p, int w) {
        if (w == 8) return Double.longBitsToDouble(readUInt(d, p, 8));
        return Float.intBitsToFloat((int) readUInt(d, p, 4));
    }
}
