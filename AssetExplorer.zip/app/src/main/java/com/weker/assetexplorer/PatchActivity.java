package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.PatchNotes;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * "Что нового": patch notes between two imported versions, written from the game tables —
 * new brawlers with their kit, balance changes (▲ buff / ▼ nerf), new gadgets / star powers / hypercharges,
 * skins with prices, modes, maps, pins / sprays / icons, music and texts.
 */
public final class PatchActivity extends Activity {

    static final int RED = 0xFFFF5D5D;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final ExecutorService icons = Executors.newSingleThreadExecutor();
    private List<Db.Version> versions;
    private Db.Version oldV, newV;
    private TextView oldBtn, newBtn, info;
    private LinearLayout list;
    private PatchNotes notes;
    private int gen;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(Ui.bold(this, "Что нового в обновлении", 19, Ui.TEXT), Ui.lp(0, -2, 1));
        TextView share = Ui.button(this, "Поделиться", false);
        share.setOnClickListener(v -> share());
        top.addView(share);
        root.addView(top);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(this, 8), 0, 0);
        oldBtn = Ui.button(this, "Было: —", false);
        oldBtn.setOnClickListener(v -> pick(true));
        row.addView(oldBtn, Ui.lp(0, -2, 1));
        TextView arrow = Ui.bold(this, "  →  ", 16, Ui.MUTED);
        row.addView(arrow);
        newBtn = Ui.button(this, "Стало: —", true);
        newBtn.setOnClickListener(v -> pick(false));
        row.addView(newBtn, Ui.lp(0, -2, 1));
        root.addView(row);
        info = Ui.text(this, "", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        root.addView(info);
        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 0, 0, Ui.dp(this, 24));
        sv.addView(list);
        root.addView(sv, Ui.lp(-1, 0, 1));
        setContentView(root);

        long want = getIntent().getLongExtra("vid", -1);
        bg.execute(() -> {
            List<Db.Version> vs = Db.get(this).versions();
            main.post(() -> {
                versions = vs;
                if (vs.size() < 2) {
                    info.setText("Нужно минимум две версии. Импортируй ZIP другой версии игры (старой или новой) — "
                            + "и здесь появится список всего, что поменялось между ними.");
                    return;
                }
                int i = 0;
                for (int k = 0; k < vs.size(); k++) if (vs.get(k).id == want) i = k;
                if (i == vs.size() - 1) i = vs.size() - 2;
                newV = vs.get(i);
                oldV = vs.get(i + 1);
                compute();
            });
        });
    }

    private void pick(boolean old) {
        if (versions == null || versions.size() < 2) return;
        String[] names = new String[versions.size()];
        for (int i = 0; i < names.length; i++) names[i] = versions.get(i).name;
        new AlertDialog.Builder(this).setTitle(old ? "Старая версия" : "Новая версия").setItems(names, (d, w) -> {
            if (old) oldV = versions.get(w);
            else newV = versions.get(w);
            compute();
        }).show();
    }

    private void compute() {
        if (oldV == null || newV == null) return;
        oldBtn.setText("Было: " + oldV.name);
        newBtn.setText("Стало: " + newV.name);
        list.removeAllViews();
        if (oldV.id == newV.id) {
            info.setText("Выбери две разные версии.");
            return;
        }
        info.setText("Сравниваю таблицы игры…");
        ProgressBar pb = new ProgressBar(this);
        list.addView(pb, Ui.lp(-1, Ui.dp(this, 60), 0));
        final int g = ++gen;
        final Db.Version a = oldV, b = newV;
        bg.execute(() -> {
            PatchNotes n;
            String err = null;
            try {
                GameDb da = GameData.of(this, a.id).db, db = GameData.get(this, b.id).db;
                n = PatchNotes.diff(da, db);
            } catch (Throwable e) {
                n = null;
                err = e.toString();
            }
            PatchNotes res = n;
            String e2 = err;
            main.post(() -> {
                if (g != gen) return;
                list.removeAllViews();
                if (res == null) {
                    info.setText("Ошибка: " + e2);
                    return;
                }
                notes = res;
                show(res, b.id);
            });
        });
    }

    private void show(PatchNotes n, long newVid) {
        int count = 0;
        for (PatchNotes.Section s : n.sections) count += s.entries.size();
        info.setText(count == 0 ? "В таблицах игры нет отличий." : "Изменений: " + count + " · нажми на раздел, чтобы свернуть");
        GameData gd = GameData.get(this, newVid);
        for (PatchNotes.Section s : n.sections) {
            TextView head = Ui.bold(this, s.icon + "  " + s.title.toUpperCase(java.util.Locale.ROOT) + "  (" + s.entries.size() + ")", 15, Ui.ACCENT);
            head.setPadding(Ui.dp(this, 4), Ui.dp(this, 16), 0, Ui.dp(this, 6));
            list.addView(head);
            LinearLayout body = new LinearLayout(this);
            body.setOrientation(LinearLayout.VERTICAL);
            list.addView(body);
            head.setOnClickListener(v -> body.setVisibility(body.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
            for (PatchNotes.Entry e : s.entries) body.addView(card(e, gd));
        }
    }

    private View card(PatchNotes.Entry e, GameData gd) {
        LinearLayout row = new LinearLayout(this);
        row.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        int p = Ui.dp(this, 10);
        row.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2, 0);
        lp.bottomMargin = Ui.dp(this, 6);
        row.setLayoutParams(lp);
        if (e.brawler != null) {
            ImageView iv = new ImageView(this);
            int sz = Ui.dp(this, 44);
            LinearLayout.LayoutParams il = Ui.lp(sz, sz, 0);
            il.rightMargin = Ui.dp(this, 10);
            row.addView(iv, il);
            GameDb.Brawler br = gd.db.brawler(e.brawler);
            if (br != null) {
                icons.execute(() -> {
                    Bitmap bm = gd.export(br.portraitFile, br.portraitExport, 128);
                    if (bm != null) main.post(() -> iv.setImageBitmap(bm));
                });
            }
        }
        SpannableStringBuilder sb = new SpannableStringBuilder();
        int color = e.kind == PatchNotes.NEW ? Ui.NEW : e.kind == PatchNotes.REMOVED ? RED : Ui.TEXT;
        String mark = e.kind == PatchNotes.NEW ? "＋ " : e.kind == PatchNotes.REMOVED ? "− " : "";
        span(sb, mark + e.title, color, 1.08f, true);
        for (String d : e.details) {
            char m = d.charAt(0);
            sb.append('\n');
            if (m == '+') span(sb, "▲ ", Ui.NEW, 1f, true);
            else if (m == '-') span(sb, "▼ ", RED, 1f, true);
            else span(sb, "• ", Ui.MUTED, 1f, false);
            span(sb, d.substring(1), m == '~' ? 0xFFC5CAD6 : Ui.TEXT, 0.95f, false);
        }
        TextView t = Ui.text(this, "", 14, Ui.TEXT);
        t.setText(sb);
        t.setLineSpacing(Ui.dp(this, 2), 1f);
        t.setTextIsSelectable(true);
        row.addView(t, Ui.lp(0, -2, 1));
        return row;
    }

    static void span(SpannableStringBuilder sb, String s, int color, float size, boolean bold) {
        int a = sb.length();
        sb.append(s);
        sb.setSpan(new ForegroundColorSpan(color), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (size != 1f) sb.setSpan(new RelativeSizeSpan(size), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (bold) sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void share() {
        if (notes == null || oldV == null || newV == null) return;
        String text = notes.toText("Brawl Stars " + oldV.name + " → " + newV.name);
        String[] how = {"Отправить", "Скопировать"};
        new AlertDialog.Builder(this).setItems(how, (d, w) -> {
            if (w == 0) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                try {
                    startActivity(Intent.createChooser(i, "Что нового"));
                } catch (Exception e) {
                    Toast.makeText(this, "Нечем отправить", Toast.LENGTH_SHORT).show();
                }
            } else {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Что нового", text));
                Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
            }
        }).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bg.shutdownNow();
        icons.shutdownNow();
    }
}
