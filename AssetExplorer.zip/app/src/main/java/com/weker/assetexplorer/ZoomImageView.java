package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Image view with pinch-zoom, pan, double-tap and a checkerboard behind transparency. */
public final class ZoomImageView extends View {

    private Bitmap bitmap;
    private final Matrix matrix = new Matrix();
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint checkA = new Paint(), checkB = new Paint();
    private float scale = 1f, tx, ty;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestures;

    public ZoomImageView(Context c) {
        super(c);
        checkA.setColor(0xFF2A2D3A);
        checkB.setColor(0xFF343848);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                float ns = Math.max(0.05f, Math.min(scale * f, 64f));
                f = ns / scale;
                tx = d.getFocusX() - (d.getFocusX() - tx) * f;
                ty = d.getFocusY() - (d.getFocusY() - ty) * f;
                scale = ns;
                invalidate();
                return true;
            }
        });
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                tx -= dx;
                ty -= dy;
                invalidate();
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (scale > fitScale() * 1.5f) {
                    fit();
                } else {
                    float ns = fitScale() * 3f;
                    float f = ns / scale;
                    tx = e.getX() - (e.getX() - tx) * f;
                    ty = e.getY() - (e.getY() - ty) * f;
                    scale = ns;
                }
                invalidate();
                return true;
            }
        });
    }

    public void setBitmap(Bitmap b) {
        bitmap = b;
        paint.setFilterBitmap(true);
        fit();
        invalidate();
    }

    /** Next animation frame: keeps the user's zoom and position when the size doesn't change. */
    public void setFrame(Bitmap b) {
        boolean same = bitmap != null && b != null && bitmap.getWidth() == b.getWidth() && bitmap.getHeight() == b.getHeight();
        bitmap = b;
        paint.setFilterBitmap(true);
        if (!same) fit();
        invalidate();
    }

    public Bitmap getBitmap() { return bitmap; }

    float fitScale() {
        if (bitmap == null || getWidth() == 0) return 1f;
        return Math.min((float) getWidth() / bitmap.getWidth(), (float) getHeight() / bitmap.getHeight());
    }

    void fit() {
        if (bitmap == null || getWidth() == 0) return;
        scale = fitScale();
        tx = (getWidth() - bitmap.getWidth() * scale) / 2f;
        ty = (getHeight() - bitmap.getHeight() * scale) / 2f;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        getParent().requestDisallowInterceptTouchEvent(true);
        scaleDetector.onTouchEvent(e);
        gestures.onTouchEvent(e);
        return true;
    }

    @Override
    protected void onDraw(Canvas c) {
        int cs = 24;
        for (int y = 0; y < getHeight(); y += cs) {
            for (int x = 0; x < getWidth(); x += cs) {
                c.drawRect(x, y, x + cs, y + cs, ((x / cs + y / cs) & 1) == 0 ? checkA : checkB);
            }
        }
        if (bitmap == null) return;
        paint.setFilterBitmap(true);
        matrix.reset();
        matrix.postScale(scale, scale);
        matrix.postTranslate(tx, ty);
        c.drawBitmap(bitmap, matrix, paint);
    }
}
