package com.weker.assetexplorer.codec;

/**
 * A brawler's numbers at power 11, as the game shows them (base health and damage ×2), read straight from
 * characters.csv and skills.csv. Ranges are in tiles, times in seconds.
 */
public final class BrawlerStats {

    /** power 11 = level 1 × 2 */
    public static final float POWER = 2f;

    public String code;
    public int hp, speed;
    public Attack attack = new Attack(), sup = new Attack();

    public static final class Attack {
        public String skill = "", projectile = "", area = "", behavior = "", effect = "";
        public int damage, bullets = 1, ammo, spread;
        public float range, reload, between;

        /** "5 x 320" or "1200" */
        public String damageText() {
            if (damage <= 0) return "—";
            return bullets > 1 ? bullets + " x " + damage : String.valueOf(damage);
        }
    }

    public static BrawlerStats of(GameDb db, String code) {
        BrawlerStats s = new BrawlerStats();
        s.code = code;
        GameDb.Table ch = db.table("characters.csv");
        String[] r = ch.row(code);
        if (r == null) return s;
        s.hp = Math.round(ch.num(r, "Hitpoints", 0) * POWER);
        s.speed = ch.num(r, "Speed", 0);
        s.attack = attack(db, ch.get(r, "WeaponSkill"));
        s.sup = attack(db, ch.get(r, "UltimateSkill"));
        return s;
    }

    public static Attack attack(GameDb db, String skill) {
        Attack a = new Attack();
        a.skill = skill == null ? "" : skill;
        GameDb.Table t = db.table("skills.csv");
        String[] r = skill == null || skill.isEmpty() ? null : t.row(skill);
        if (r == null) return a;
        a.behavior = t.get(r, "BehaviorType");
        a.effect = t.get(r, "AttackEffect");
        a.projectile = t.get(r, "Projectiles");
        a.area = t.get(r, "AreaEffectObject");
        a.damage = Math.round(t.num(r, "Damage", 0) * POWER);
        a.bullets = Math.max(1, t.num(r, "NumBulletsInOneAttack", 1));
        a.spread = t.num(r, "Spread", 0);
        a.ammo = t.num(r, "MaxCharge", 0);
        a.range = t.num(r, "CastingRange", 0) / 3f;
        a.reload = t.num(r, "RechargeTime", 0) / 1000f;
        a.between = t.num(r, "MsBetweenAttacks", 0) / 1000f;
        if (a.damage == 0 && !a.area.isEmpty()) {
            GameDb.Table ar = db.table("area_effects_logic.csv");
            String[] x = ar.row(a.area);
            if (x != null) a.damage = Math.round(ar.num(x, "Damage", 0) * POWER);
        }
        return a;
    }
}
