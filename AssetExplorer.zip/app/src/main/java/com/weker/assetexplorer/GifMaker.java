package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.ScSprites;
import com.weker.assetexplorer.codec.Showcase;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * "GIF" on the hero screen: the chosen skin does its attack or super with the game's effects,
 * rendered frame by frame (no screen recording needed), shown here and saved as a .gif.
 */
public final class GifMaker {

    private GifMaker() {}

    static final int REQ_SAVE = 4711;
    /** the last GIF made, waiting for the "save as" answer */
    static File pending;

    public static void open(Activity a, GameData gd, GameDb.Brawler br, GameDb.Skin skin, Typeface font) {
        String[] what = {"Атака", "Супер"};
        new AlertDialog.Builder(a).setTitle("GIF · " + skin.title)
                .setItems(what, (d, w) -> askSize(a, gd, br, skin, w == 1 ? "ulti" : "attack"))
                .setNegativeButton("Отмена", null).show();
    }

    static void askSize(Activity a, GameData gd, GameDb.Brawler br, GameDb.Skin skin, String action) {
        String[] sizes = {"480 × 270 — быстро", "640 × 360 (рекомендую)", "960 × 540 — долго"};
        int[][] wh = {{480, 270}, {640, 360}, {960, 540}};
        new AlertDialog.Builder(a).setTitle("Размер")
                .setItems(sizes, (d, w) -> make(a, gd, br, skin, action, wh[w][0], wh[w][1]))
                .setNegativeButton("Отмена", null).show();
    }

    static void make(Activity a, GameData gd, GameDb.Brawler br, GameDb.Skin skin, String action, int w, int h) {
        Handler main = new Handler(Looper.getMainLooper());
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 20);
        box.setPadding(p, p, p, p);
        TextView label = Ui.text(a, "Готовлю эффекты…", 14, 0xFF222222);
        box.addView(label);
        ProgressBar bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        box.addView(bar, Ui.lp(-1, -2, 0));
        final boolean[] stop = {false};
        AlertDialog wait = new AlertDialog.Builder(a).setTitle("Делаю GIF").setView(box).setCancelable(false)
                .setNegativeButton("Стоп", (d, x) -> stop[0] = true).show();
        new Thread(() -> {
            File out = new File(gd.cacheDir(), "gif_" + skin.name + "_" + action + ".gif");
            String err = null;
            try {
                Showcase sc = new Showcase(gd.db, gd.assets, gd::read, new ScSprites(gd::sc), br.code, skin.name, action);
                if (!sc.hasModel()) throw new IllegalStateException("в архиве нет 3D-модели этого скина");
                try (OutputStream o = new BufferedOutputStream(new FileOutputStream(out))) {
                    sc.writeGif(o, w, h, 15, (done, total) -> {
                        int pc = done * 100 / Math.max(1, total);
                        main.post(() -> {
                            bar.setProgress(pc);
                            label.setText(done * 2 <= total ? "Рисую кадры… " + pc + "%" : "Собираю GIF… " + pc + "%");
                        });
                        return !stop[0];
                    });
                }
                if (stop[0]) err = "";
            } catch (Throwable e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            String e2 = err;
            main.post(() -> {
                wait.dismiss();
                if (e2 != null) {
                    if (!e2.isEmpty()) Toast.makeText(a, "Не получилось: " + e2, Toast.LENGTH_LONG).show();
                    return;
                }
                show(a, out, br.name + " · " + skin.title, w, h);
            });
        }, "gif").start();
    }

    /** the result playing, with "Сохранить" */
    static void show(Activity a, File gif, String title, int w, int h) {
        GifView v = new GifView(a, gif, w, h);
        new AlertDialog.Builder(a).setTitle(title).setView(v)
                .setPositiveButton("Сохранить", (d, x) -> {
                    pending = gif;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/gif");
                    i.putExtra(Intent.EXTRA_TITLE, gif.getName());
                    try {
                        a.startActivityForResult(i, REQ_SAVE);
                    } catch (Exception e) {
                        Toast.makeText(a, "Нет приложения для сохранения файлов", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Закрыть", null).show();
    }

    /** call from the activity's onActivityResult; true when it was ours */
    public static boolean onResult(Activity a, int req, int res, Intent data) {
        if (req != REQ_SAVE) return false;
        File f = pending;
        pending = null;
        if (res != Activity.RESULT_OK || data == null || data.getData() == null || f == null) return true;
        Uri uri = data.getData();
        new Thread(() -> {
            String msg;
            try (InputStream in = new FileInputStream(f); OutputStream o = a.getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new java.io.IOException("нет доступа");
                Importer.copy(in, o, null);
                msg = "GIF сохранён";
            } catch (Exception e) {
                msg = "Ошибка: " + e.getMessage();
            }
            String m = msg;
            a.runOnUiThread(() -> Toast.makeText(a, m, Toast.LENGTH_SHORT).show());
        }).start();
        return true;
    }

    /** plays a GIF file (android.graphics.Movie works on every Android version the app supports) */
    static final class GifView extends View {
        final Movie movie;
        final int w, h;
        final long start = SystemClock.uptimeMillis();

        @SuppressWarnings("deprecation")
        GifView(Context c, File f, int w, int h) {
            super(c);
            this.w = w;
            this.h = h;
            movie = Movie.decodeFile(f.getAbsolutePath());
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int width = MeasureSpec.getSize(ws);
            setMeasuredDimension(width, width * h / Math.max(1, w));
        }

        @Override
        @SuppressWarnings("deprecation")
        protected void onDraw(Canvas c) {
            if (movie == null) return;
            int dur = Math.max(1, movie.duration());
            movie.setTime((int) ((SystemClock.uptimeMillis() - start) % dur));
            float k = getWidth() / (float) Math.max(1, movie.width());
            c.save();
            c.scale(k, k);
            movie.draw(c, 0, 0);
            c.restore();
            postInvalidateOnAnimation();
        }
    }
}
