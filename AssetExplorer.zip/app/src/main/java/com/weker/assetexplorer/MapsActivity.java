package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.MapPlan;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** "Карты": every map of every mode from maps.csv / locations.csv, drawn from above as in the map maker. */
public final class MapsActivity extends Activity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private Map<String, List<MapPlan.Entry>> byMode = new LinkedHashMap<>();
    private String mode;
    private String query = "";
    private boolean hidden;
    private CardGrid grid;
    private TextView info, modeBtn, hiddenBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, "Карты", 19, Ui.TEXT));
        info = Ui.text(this, "Читаю карты…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(info);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        modeBtn = Ui.button(this, "Все режимы", true);
        modeBtn.setOnClickListener(v -> pickMode());
        row.addView(modeBtn, Ui.lp(0, -2, 1));
        hiddenBtn = Ui.chip(this, "Скрытые");
        hiddenBtn.setOnClickListener(v -> {
            hidden = !hidden;
            Ui.setChip(this, hiddenBtn, hidden);
            refresh();
        });
        LinearLayout.LayoutParams hl = Ui.lp(-2, -2, 0);
        hl.leftMargin = Ui.dp(this, 8);
        row.addView(hiddenBtn, hl);
        root.addView(row);
        EditText search = new EditText(this);
        search.setHint("Поиск карты");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        search.setPadding(p, Ui.dp(this, 9), p, Ui.dp(this, 9));
        LinearLayout.LayoutParams sl = Ui.lp(-1, -2, 0);
        sl.topMargin = Ui.dp(this, 8);
        sl.bottomMargin = Ui.dp(this, 8);
        root.addView(search, sl);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                query = e.toString().trim().toLowerCase(Locale.ROOT);
                refresh();
            }
        });
        grid = new CardGrid(this, 150, 150);
        root.addView(grid, Ui.lp(-1, 0, 1));
        setContentView(root);
        new Thread(() -> {
            try {
                CardGrid.font = GameUi.font(gd);
                Map<String, List<MapPlan.Entry>> m = MapPlan.byMode(gd.db);
                main.post(() -> {
                    byMode = m;
                    refresh();
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Ошибка чтения карт: " + e.getMessage()));
            }
        }).start();
    }

    private void pickMode() {
        List<String> names = new ArrayList<>();
        names.add("Все режимы");
        for (Map.Entry<String, List<MapPlan.Entry>> e : byMode.entrySet()) names.add(e.getKey() + "  (" + e.getValue().size() + ")");
        List<String> keys = new ArrayList<>(byMode.keySet());
        new AlertDialog.Builder(this).setTitle("Режим").setItems(names.toArray(new String[0]), (d, w) -> {
            mode = w == 0 ? null : keys.get(w - 1);
            modeBtn.setText(mode == null ? "Все режимы" : mode);
            refresh();
        }).show();
    }

    private void refresh() {
        List<CardGrid.Card> cards = new ArrayList<>();
        int total = 0;
        for (Map.Entry<String, List<MapPlan.Entry>> e : byMode.entrySet()) {
            if (mode != null && !mode.equals(e.getKey())) continue;
            for (MapPlan.Entry m : e.getValue()) {
                if (m.disabled && !hidden) continue;
                total++;
                if (!query.isEmpty() && !m.title.toLowerCase(Locale.ROOT).contains(query) && !m.location.toLowerCase(Locale.ROOT).contains(query)
                        && !m.modeTitle.toLowerCase(Locale.ROOT).contains(query)) continue;
                CardGrid.Card c = new CardGrid.Card();
                c.key = vid + "/map/" + m.location;
                c.title = m.title + (m.disabled ? " (скрыта)" : "");
                c.subtitle = m.modeTitle;
                c.color = 0xFF2A3346;
                c.glyph = "🗺";
                c.picture = () -> plan(gd, m, 260);
                c.click = () -> {
                    Intent i = new Intent(this, MapViewActivity.class);
                    i.putExtra("vid", vid);
                    i.putExtra("location", m.location);
                    startActivity(i);
                };
                cards.add(c);
            }
        }
        grid.setCards(cards);
        info.setText("Версия: " + Db.get(this).versionName(vid) + " · карт: " + cards.size() + (cards.size() != total ? " из " + total : "")
                + (hidden ? "" : " · скрытые выключены"));
    }

    /** the map from above, at most {@code max} pixels on the long side */
    static Bitmap plan(GameData gd, MapPlan.Entry m, int max) {
        GameDb.MapData d = gd.db.map(m.map);
        if (d == null) return null;
        int px = Math.max(2, max / Math.max(d.width, d.height));
        int[] argb = MapPlan.render(d, px, m.mode);
        return Decoders.toBitmap(new Img(d.width * px, d.height * px, argb));
    }
}
