package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.GameDb;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * "Бойцы, косметика, боксы": everything from the game tables of the chosen version —
 * all brawlers (newest included), all skins / pins / sprays / icons, and every box / Starr Drop to open.
 */
public final class HubActivity extends Activity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private TextView info;
    private FrameLayout content;
    private final TextView[] tabs = new TextView[3];
    private int tab;
    // cosmetics
    private String kind = "skins";
    private String query = "";
    private CardGrid cosGrid;
    private TextView cosCount;
    private final TextView[] kinds = new TextView[4];
    private Sfx sfx;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, "Бойцы · Косметика · Боксы", 19, Ui.TEXT));
        info = Ui.text(this, "Читаю таблицы игры…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(info);
        LinearLayout tabRow = new LinearLayout(this);
        String[] names = {"Бойцы", "Косметика", "Боксы"};
        for (int i = 0; i < 3; i++) {
            TextView t = Ui.chip(this, names[i]);
            final int k = i;
            t.setOnClickListener(v -> showTab(k));
            tabs[i] = t;
            tabRow.addView(t);
        }
        root.addView(tabRow);
        content = new FrameLayout(this);
        content.setPadding(0, Ui.dp(this, 10), 0, 0);
        root.addView(content, Ui.lp(-1, 0, 1));
        setContentView(root);

        new Thread(() -> {
            try {
                GameDb db = gd.db;
                CardGrid.font = GameUi.font(gd);
                List<GameDb.Brawler> bs = db.brawlers();
                int skins = db.allSkins().size();
                int boxes = db.containers().size();
                main.post(() -> {
                    if (bs.isEmpty()) {
                        info.setText("В этой версии не найдены таблицы игры (characters.csv, skins.csv…). Импортируй полный архив игры.");
                    } else {
                        info.setText(String.format(Locale.ROOT, "Версия: %s · бойцов: %d · скинов: %d · боксов: %d",
                                Db.get(this).versionName(vid), bs.size(), skins, boxes));
                    }
                    showTab(0);
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Ошибка чтения таблиц: " + e.getMessage()));
            }
        }).start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sfx.stopAll();
    }

    private void showTab(int k) {
        tab = k;
        for (int i = 0; i < 3; i++) Ui.setChip(this, tabs[i], i == k);
        content.removeAllViews();
        if (k == 0) content.addView(brawlersView());
        else if (k == 1) content.addView(cosmeticsView());
        else content.addView(boxesView());
    }

    // ------------------------------------------------------------------ brawlers
    private android.view.View brawlersView() {
        CardGrid g = new CardGrid(this, 104, 92);
        List<CardGrid.Card> cards = new ArrayList<>();
        List<GameDb.Brawler> bs = new ArrayList<>(gd.db.brawlers());
        java.util.Collections.reverse(bs); // newest first, as the game lists new brawlers
        for (GameDb.Brawler br : bs) {
            CardGrid.Card c = new CardGrid.Card();
            c.key = vid + "/portrait/" + br.code;
            c.title = br.name;
            c.subtitle = br.rarityName;
            c.color = dim(GameDb.rarityColor(br.rarity));
            c.glyph = br.name.isEmpty() ? "?" : br.name.substring(0, 1);
            c.picture = () -> gd.export(br.portraitFile, br.portraitExport, 256);
            c.click = () -> {
                Intent i = new Intent(this, BrawlerActivity.class);
                i.putExtra("vid", vid);
                i.putExtra("brawler", br.code);
                startActivity(i);
            };
            cards.add(c);
        }
        g.setCards(cards);
        return g;
    }

    static int dim(int c) {
        return 0xFF000000 | ((((c >> 16) & 255) * 45 / 100) << 16) | ((((c >> 8) & 255) * 45 / 100) << 8) | ((c & 255) * 45 / 100);
    }

    // ------------------------------------------------------------------ cosmetics
    private android.view.View cosmeticsView() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        String[][] ks = {{"skins", "Скины"}, {"pins", "Пины"}, {"sprays", "Спреи"}, {"icons", "Иконки"}};
        for (int i = 0; i < ks.length; i++) {
            TextView t = Ui.chip(this, ks[i][1]);
            final String k = ks[i][0];
            t.setOnClickListener(v -> {
                kind = k;
                fillCosmetics();
            });
            kinds[i] = t;
            row.addView(t);
        }
        hs.addView(row);
        box.addView(hs);
        EditText search = new EditText(this);
        search.setHint("Поиск: имя бойца, скина, пина…");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        int p = Ui.dp(this, 10);
        search.setPadding(p, p, p, p);
        search.setText(query);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override
            public void afterTextChanged(Editable e) {
                query = e.toString().trim().toLowerCase(Locale.ROOT);
                fillCosmetics();
            }
        });
        LinearLayout.LayoutParams sl = Ui.lp(-1, -2, 0);
        sl.topMargin = Ui.dp(this, 8);
        box.addView(search, sl);
        cosCount = Ui.text(this, "", 12, Ui.MUTED);
        cosCount.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        box.addView(cosCount);
        cosGrid = new CardGrid(this, 104, 92);
        box.addView(cosGrid, Ui.lp(-1, 0, 1));
        fillCosmetics();
        return box;
    }

    private void fillCosmetics() {
        String[] order = {"skins", "pins", "sprays", "icons"};
        for (int i = 0; i < 4; i++) Ui.setChip(this, kinds[i], order[i].equals(kind));
        List<CardGrid.Card> cards = new ArrayList<>();
        GameDb db = gd.db;
        if (kind.equals("skins")) {
            for (GameDb.Brawler br : db.brawlers()) {
                for (GameDb.Skin s : br.skins) {
                    String hay = (s.title + " " + s.name + " " + br.name).toLowerCase(Locale.ROOT);
                    if (!query.isEmpty() && !hay.contains(query)) continue;
                    CardGrid.Card c = new CardGrid.Card();
                    c.title = s.title + (s.disabled && !s.name.equals(br.defaultSkin) ? " (скрыт)" : "");
                    c.subtitle = br.name + (s.priceGems > 0 ? " · " + s.priceGems + " 💎" : s.priceBling > 0 ? " · " + s.priceBling + " блингов" : "");
                    c.color = dim(GameDb.rarityColor(s.rarity.isEmpty() ? "common" : s.rarity));
                    boolean ownIcon = s.iconFile != null && !s.iconFile.isEmpty() && s.iconExport != null && !s.iconExport.isEmpty();
                    c.key = vid + (ownIcon ? "/skinicon/" + s.name : "/portrait/" + br.code);
                    c.picture = ownIcon ? () -> gd.export(s.iconFile, s.iconExport, 256) : () -> gd.export(br.portraitFile, br.portraitExport, 256);
                    c.click = () -> openSkin(this, gd, br, s);
                    cards.add(c);
                }
            }
        } else {
            for (GameDb.Item2d it : db.items(kind)) {
                String hay = (it.name + " " + it.character).toLowerCase(Locale.ROOT);
                if (!query.isEmpty() && !hay.contains(query)) continue;
                CardGrid.Card c = new CardGrid.Card();
                c.title = it.name.replaceAll("^(emoji|spray|icon|thumbnail)_", "").replace('_', ' ');
                c.subtitle = GameDb.rarityName(it.rarity) + (it.priceGems > 0 ? " · " + it.priceGems + " 💎" : it.priceBling > 0 ? " · " + it.priceBling + " блингов" : "");
                c.color = it.rarity.isEmpty() ? Ui.CARD2 : dim(GameDb.rarityColor(it.rarity));
                c.key = vid + "/" + kind + "/" + it.file + "/" + it.export;
                c.picture = () -> gd.export(it.file, it.export, 220);
                c.click = () -> showItem(it);
                cards.add(c);
            }
        }
        cosCount.setText(cards.size() + " шт." + (kind.equals("skins") ? " · нажми, чтобы открыть в 3D" : kind.equals("pins") ? " · нажми — покажет и озвучит" : ""));
        cosGrid.setCards(cards);
    }

    private void showItem(GameDb.Item2d it) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, p, p, p);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        box.addView(iv, new LinearLayout.LayoutParams(-1, Ui.dp(this, 260)));
        TextView t = Ui.text(this, it.name + "\nФайл: " + it.file + " · " + it.export, 12, Ui.MUTED);
        t.setTextIsSelectable(true);
        box.addView(t);
        AlertDialog.Builder bld = new AlertDialog.Builder(this).setView(box).setPositiveButton("Закрыть", null);
        if (it.sound != null && !it.sound.isEmpty()) bld.setNeutralButton("▶ Звук", null);
        AlertDialog d = bld.show();
        if (it.sound != null && !it.sound.isEmpty()) {
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                if (sfx.play(it.sound) == null) Toast.makeText(this, "Звук не найден в архиве", Toast.LENGTH_SHORT).show();
            });
            sfx.play(it.sound);
        }
        new Thread(() -> {
            Bitmap bm = gd.export(it.file, it.export, 640);
            main.post(() -> {
                if (bm != null) iv.setImageBitmap(bm);
                else t.setText(it.name + "\nКартинка не найдена (нет файла " + it.file + ")");
            });
        }).start();
    }

    /** opens a skin's 3D model with its texture, idle animation and face */
    static void openSkin(Activity a, GameData gd, GameDb.Brawler br, GameDb.Skin s) {
        Db.Row row = gd.row(s.model);
        if (row == null) {
            Toast.makeText(a, "В архиве нет модели " + s.model, Toast.LENGTH_LONG).show();
            return;
        }
        Intent i = new Intent(a, Model3dActivity.class);
        i.putExtra("id", row.id);
        i.putExtra("texture", s.texture);
        i.putExtra("title", s.title + " · " + br.name);
        a.startActivity(i);
    }

    // ------------------------------------------------------------------ boxes
    private android.view.View boxesView() {
        CardGrid g = new CardGrid(this, 150, 70);
        List<CardGrid.Card> cards = new ArrayList<>();
        GameDb db = gd.db;
        if (!db.starrRarities("").isEmpty()) cards.add(boxCard("Старр-дроп", "редкость выпадает с шансами игры", 0xFFFFC21F, "starr:", "★"));
        if (!db.starrRarities("Splitting").isEmpty()) cards.add(boxCard("Хаос-дроп", "делящийся Старр-дроп", 0xFFD850FF, "starr:Splitting", "✦"));
        for (GameDb.Container c : db.containers()) {
            String sub = (c.model == null || c.model.isEmpty() ? "без 3D-модели" : c.model.replace(".glb", "")) + (c.visual.isEmpty() ? "" : " · " + c.visual.toLowerCase(Locale.ROOT));
            cards.add(boxCard(c.title, sub, GameDb.rarityColor(String.valueOf(Math.max(1, Math.min(5, c.rarity)))), "box:" + c.name, "▣"));
        }
        g.setCards(cards);
        return g;
    }

    private CardGrid.Card boxCard(String title, String sub, int color, String what, String glyph) {
        CardGrid.Card c = new CardGrid.Card();
        c.title = title;
        c.subtitle = sub;
        c.color = dim(color);
        c.glyph = glyph;
        c.click = () -> {
            Intent i = new Intent(this, BoxActivity.class);
            i.putExtra("vid", vid);
            i.putExtra("what", what);
            startActivity(i);
        };
        return c;
    }
}
