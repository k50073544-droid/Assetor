package com.weker.assetexplorer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.weker.assetexplorer.codec.Assets;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Sc2;
import com.weker.assetexplorer.codec.SupercellFiles;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The game's tables and files of one imported version, for the brawlers / cosmetics / boxes / cave screens.
 * Files are found by name among the version's imported files.
 */
public final class GameData {

    private static GameData cached;

    public final long vid;
    public final GameDb db;
    public final Assets assets;
    private final Context app;
    private final Map<String, Sc2> scs = new LinkedHashMap<>();

    private GameData(Context c, long vid) {
        this.app = c.getApplicationContext();
        this.vid = vid;
        GameDb.Source src = this::read;
        db = new GameDb(src);
        assets = new Assets(db, src);
        assets.images = GameData::decodeImage;
    }

    public static synchronized GameData get(Context c, long vid) {
        if (cached == null || cached.vid != vid) cached = new GameData(c, vid);
        return cached;
    }

    /** the version's file with this name, or null */
    public Db.Row row(String name) {
        if (name == null || name.isEmpty()) return null;
        List<String> one = new ArrayList<>();
        one.add(name);
        List<Db.Row> r = Db.get(app).byPaths(vid, one);
        return r.isEmpty() ? null : r.get(0);
    }

    /** file bytes by name: tables unpacked, everything else as stored */
    public byte[] read(String name) {
        try {
            Db.Row r = row(name);
            if (r == null) return null;
            File f = Blobs.file(app, r.blob);
            return name.toLowerCase(Locale.ROOT).endsWith(".csv") ? Decoders.content(f) : Decoders.readAll(f);
        } catch (Throwable e) {
            return null;
        }
    }

    public File file(String name) {
        Db.Row r = row(name);
        return r == null ? null : Blobs.file(app, r.blob);
    }

    static Img decodeImage(byte[] d) {
        Bitmap b = BitmapFactory.decodeByteArray(d, 0, d.length);
        if (b == null) return null;
        int[] px = new int[b.getWidth() * b.getHeight()];
        b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
        Img im = new Img(b.getWidth(), b.getHeight(), px);
        b.recycle();
        return im;
    }

    /** a 2D .sc file with its outside textures resolved; a few kept in memory */
    public Sc2 sc(String file) {
        synchronized (scs) {
            if (scs.containsKey(file)) {
                Sc2 s = scs.remove(file);
                scs.put(file, s);
                return s;
            }
        }
        Sc2 s = null;
        try {
            byte[] d = read(file);
            if (d != null) {
                s = Sc2.parse(d);
                for (int i = 0; i < s.textures.size(); i++) {
                    Sc2.Tex t = s.textures.get(i);
                    if ((t.data != null && t.data.length > 0) || t.external == null) continue;
                    byte[] td = read(t.external);
                    if (td == null) continue;
                    SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(td, t.external);
                    if (!ts.images.isEmpty()) s.setExternalTexture(i, ts.images.get(0));
                }
            }
        } catch (Throwable ignored) {
            s = null;
        }
        synchronized (scs) {
            scs.put(file, s);
            while (scs.size() > 4) scs.remove(scs.keySet().iterator().next());
        }
        return s;
    }

    /** the export, or its _big / _small version (portraits are stored that way) */
    static String pick(Sc2 s, String export) {
        for (String e : new String[]{export, export + "_big", export + "_small", export + "_1"}) if (s.exportIds.containsKey(e)) return e;
        return null;
    }

    /** a picture of an export (portrait, pin, spray, icon), or null */
    public Bitmap export(String file, String export, int size) {
        if (file == null || export == null || file.isEmpty() || export.isEmpty()) return null;
        try {
            Sc2 s = sc(file);
            if (s == null) return null;
            export = pick(s, export);
            if (export == null) return null;
            Img im;
            synchronized (s) {
                im = s.renderExport(export, size);
            }
            return im == null ? null : Decoders.toBitmap(im);
        } catch (Throwable e) {
            return null;
        }
    }
}
