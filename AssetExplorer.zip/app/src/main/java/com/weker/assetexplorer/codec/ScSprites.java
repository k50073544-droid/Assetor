package com.weker.assetexplorer.codec;

/** {@link Fx.Sprites} from .sc files: frames are rendered when first needed and kept in a small cache. */
public final class ScSprites implements Fx.Sprites {

    public interface ScSource {
        Sc2 sc(String file);
    }

    final ScSource src;
    final Fx.FrameCache cache = new Fx.FrameCache(500);
    /** pixels per .sc unit */
    public float pixels = 1.3f;
    /** frames kept per clip at most (long clips skip frames) */
    public int maxFrames = 16;

    public ScSprites(ScSource src) {
        this.src = src;
    }

    /**
     * In a battle: never render on the drawing thread. A frame that isn't ready yet is drawn by a background
     * thread and shows up a moment later (until then the clip's first frame, if ready), so the game doesn't stutter.
     */
    public volatile boolean async;
    private final java.util.concurrent.ExecutorService worker = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "sprites");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY + 1);
        return t;
    });
    private final java.util.Set<String> pending = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final java.util.Map<String, int[]> meta = new java.util.concurrent.ConcurrentHashMap<>();

    /** {frames, fps} of a clip */
    int[] meta(String file, String export) {
        String key = file + "/" + export;
        int[] m = meta.get(key);
        if (m != null) return m;
        if (async) {
            if (pending.add("m:" + key)) worker.execute(() -> {
                computeMeta(file, export);
                pending.remove("m:" + key);
            });
            return new int[]{1, 30};
        }
        return computeMeta(file, export);
    }

    int[] computeMeta(String file, String export) {
        Sc2 s = src.sc(file);
        int[] m = s == null || !s.exportIds.containsKey(export) ? new int[]{1, 30} : new int[]{Math.max(1, s.frameCount(export)), s.fps(export)};
        meta.put(file + "/" + export, m);
        return m;
    }

    @Override
    public int frames(String file, String export) {
        return meta(file, export)[0];
    }

    @Override
    public int fps(String file, String export) {
        return meta(file, export)[1];
    }

    @Override
    public Fx.Sprite get(String file, String export, int frame) {
        int[] m = meta(file, export);
        int n = m[0];
        int step = Math.max(1, (n + maxFrames - 1) / maxFrames);
        int f = Math.max(0, Math.min(n - 1, frame / step * step));
        String key = file + "/" + export + "/" + f;
        synchronized (cache) {
            if (cache.containsKey(key)) return cache.get(key);
        }
        if (!async) return render(file, export, f, key);
        if (pending.add(key)) worker.execute(() -> {
            render(file, export, f, key);
            pending.remove(key);
        });
        synchronized (cache) {
            return cache.get(file + "/" + export + "/0");
        }
    }

    Fx.Sprite render(String file, String export, int f, String key) {
        Sc2 s = src.sc(file);
        Fx.Sprite sp = null;
        if (s != null && s.exportIds.containsKey(export)) {
            try {
                synchronized (s) {
                    float[] b = s.bounds(export, f);
                    if (b != null && b[2] > b[0] && b[3] > b[1]) {
                        float w = b[2] - b[0], h = b[3] - b[1];
                        int size = Math.max(8, Math.min(160, Math.round(Math.max(w, h) * pixels)));
                        Img im = s.renderFrame(export, f, b, size, 1);
                        if (im != null) {
                            sp = new Fx.Sprite();
                            sp.img = im;
                            sp.x0 = b[0];
                            sp.y0 = b[1];
                            sp.x1 = b[2];
                            sp.y1 = b[3];
                        }
                    }
                }
            } catch (Throwable ignored) {
                sp = null;
            }
        }
        synchronized (cache) {
            cache.put(key, sp);
        }
        return sp;
    }
}
