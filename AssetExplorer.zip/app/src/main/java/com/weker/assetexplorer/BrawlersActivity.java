package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.BrawlerIndex;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Sc2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** All brawlers found in the effects files of a version, with their portraits. */
public final class BrawlersActivity extends Activity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Map<String, Bitmap> icons = new HashMap<>();
    private long vid;
    private BrawlerData data;
    private Sc2 portraits;
    private List<BrawlerIndex.Brawler> all = new ArrayList<>();
    private List<BrawlerIndex.Brawler> shown = new ArrayList<>();
    private TextView status;
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, "Бойцы", 20, Ui.TEXT));
        TextView hint = Ui.text(this, "2D-эффекты каждого бойца, разложенные по атаке, суперу, гаджетам, звёздным силам и гиперзаряду. "
                + "Внутри — кнопка «Собрать вместе»: все куски способности играют одной сценой, как в бою.", 12, Ui.MUTED);
        hint.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(hint);

        EditText search = new EditText(this);
        search.setHint("Найти бойца…");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        search.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        root.addView(search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(Editable e) { filter(e.toString()); }
        });

        status = Ui.text(this, "Собираю список бойцов… (первый раз долго: читаются все файлы эффектов)", 12, Ui.MUTED);
        status.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 6));
        root.addView(status);

        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 92));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(Ui.dp(this, 6));
        grid.setVerticalSpacing(Ui.dp(this, 6));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        adapter = new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((pa, v, pos, id) -> {
            Intent i = new Intent(this, BrawlerActivity.class);
            i.putExtra("vid", vid);
            i.putExtra("key", shown.get(pos).key);
            startActivity(i);
        });
        root.addView(grid, Ui.lp(-1, 0, 1));
        setContentView(root);

        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        bg.execute(() -> {
            try {
                BrawlerData d = BrawlerData.load(this, vid, t -> main.post(() -> status.setText(t)));
                Sc2 pt = null;
                if (d.portraits != null) {
                    try {
                        pt = Sc2.parse(Decoders.readAll(Blobs.file(this, d.portraits.blob)));
                    } catch (Throwable ignored) {
                        // no portraits
                    }
                }
                Sc2 fp = pt;
                main.post(() -> {
                    getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    data = d;
                    portraits = fp;
                    all = d.index.sorted();
                    filter(search.getText().toString());
                });
            } catch (Throwable e) {
                main.post(() -> {
                    getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    status.setText("Не получилось: " + e.getMessage());
                });
            }
        });
    }

    private void filter(String q) {
        if (data == null) return;
        String l = q.toLowerCase(Locale.ROOT).trim();
        List<BrawlerIndex.Brawler> r = new ArrayList<>();
        int known = 0;
        for (BrawlerIndex.Brawler b : all) {
            if (!l.isEmpty() && !b.name.toLowerCase(Locale.ROOT).contains(l) && !b.key.contains(l)) continue;
            r.add(b);
            if (b.known) known++;
        }
        shown = r;
        String s = "Бойцов: " + known + (r.size() > known ? " · ещё " + (r.size() - known) + " (боссы, события) в конце" : "");
        if (!data.note.isEmpty()) s += "\n" + data.note;
        status.setText(s);
        adapter.notifyDataSetChanged();
    }

    final class Adapter extends BaseAdapter {
        public int getCount() { return shown.size(); }

        public Object getItem(int i) { return shown.get(i); }

        public long getItemId(int i) { return i; }

        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) {
                LinearLayout cell = new LinearLayout(BrawlersActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setBackground(Ui.round(Ui.CARD, Ui.dp(BrawlersActivity.this, 10)));
                int pad = Ui.dp(BrawlersActivity.this, 6);
                cell.setPadding(pad, pad, pad, pad);
                FrameLayout box = new FrameLayout(BrawlersActivity.this);
                box.setBackground(Ui.round(0xFF252937, Ui.dp(BrawlersActivity.this, 8)));
                ImageView img = new ImageView(BrawlersActivity.this);
                img.setId(1);
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                box.addView(img, new FrameLayout.LayoutParams(-1, -1));
                TextView letter = Ui.bold(BrawlersActivity.this, "", 26, Ui.MUTED);
                letter.setId(3);
                letter.setGravity(Gravity.CENTER);
                box.addView(letter, new FrameLayout.LayoutParams(-1, -1));
                cell.addView(box, new LinearLayout.LayoutParams(-1, Ui.dp(BrawlersActivity.this, 72)));
                TextView name = Ui.bold(BrawlersActivity.this, "", 12, Ui.TEXT);
                name.setId(2);
                name.setGravity(Gravity.CENTER);
                name.setSingleLine(true);
                name.setPadding(0, pad / 2, 0, 0);
                cell.addView(name);
                TextView cnt = Ui.text(BrawlersActivity.this, "", 10, Ui.MUTED);
                cnt.setId(4);
                cnt.setGravity(Gravity.CENTER);
                cell.addView(cnt);
                v = cell;
            }
            BrawlerIndex.Brawler b = shown.get(pos);
            ImageView img = v.findViewById(1);
            TextView name = v.findViewById(2);
            TextView letter = v.findViewById(3);
            TextView cnt = v.findViewById(4);
            name.setText(b.name);
            name.setTextColor(b.known ? Ui.TEXT : Ui.MUTED);
            cnt.setText(b.count + " частей · " + b.skins.size() + " вид.");
            img.setTag(b.key);
            Bitmap c = icons.get(b.key);
            img.setImageBitmap(c);
            letter.setText(c == null ? b.name.substring(0, 1) : "");
            if (c == null && portraits != null && !icons.containsKey(b.key)) {
                icons.put(b.key, null); // requested once
                bg.execute(() -> {
                    Bitmap bm = null;
                    try {
                        String ex = BrawlerData.portraitExport(portraits, b);
                        Img im = ex == null ? null : portraits.renderExport(ex, 160);
                        if (im != null) bm = Decoders.toBitmap(im);
                    } catch (Throwable ignored) {
                        // no portrait
                    }
                    Bitmap fb = bm;
                    main.post(() -> {
                        icons.put(b.key, fb);
                        if (b.key.equals(img.getTag()) && fb != null) {
                            img.setImageBitmap(fb);
                            letter.setText("");
                        }
                    });
                });
            }
            return v;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bg.shutdownNow();
    }
}
