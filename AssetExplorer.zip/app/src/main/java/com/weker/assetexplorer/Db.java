package com.weker.assetexplorer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** SQLite index of all imported versions and their files. */
public final class Db extends SQLiteOpenHelper {

    public static final int ST_SAME = 0, ST_NEW = 1, ST_CHANGED = 2;

    private static Db instance;

    public static synchronized Db get(Context c) {
        if (instance == null) instance = new Db(c.getApplicationContext());
        return instance;
    }

    private Db(Context c) {
        super(c, "assets.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE versions(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, imported INTEGER, files INTEGER)");
        db.execSQL("CREATE TABLE files(id INTEGER PRIMARY KEY AUTOINCREMENT, vid INTEGER, path TEXT, lpath TEXT, name TEXT,"
                + " ext TEXT, type TEXT, tags TEXT, size INTEGER, blob TEXT, status INTEGER DEFAULT 0)");
        db.execSQL("CREATE INDEX f_vid_path ON files(vid, path)");
        db.execSQL("CREATE INDEX f_vid_status ON files(vid, status)");
        db.execSQL("CREATE INDEX f_blob ON files(blob)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {}

    // ------------------------------------------------------------------ versions
    public static final class Version {
        public long id;
        public String name;
        public long imported;
        public int files;
        public int added, changed, removed;
    }

    /** All versions sorted from newest to oldest (by version number). */
    public List<Version> versions() {
        List<Version> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id, name, imported, files FROM versions", null)) {
            while (c.moveToNext()) {
                Version v = new Version();
                v.id = c.getLong(0);
                v.name = c.getString(1);
                v.imported = c.getLong(2);
                v.files = c.getInt(3);
                list.add(v);
            }
        }
        Collections.sort(list, (a, b) -> Categorizer.compareVersions(b.name, a.name));
        return list;
    }

    public void fillStats(List<Version> list) {
        SQLiteDatabase db = getReadableDatabase();
        for (int i = 0; i < list.size(); i++) {
            Version v = list.get(i);
            v.added = count(db, "SELECT COUNT(*) FROM files WHERE vid=? AND status=1", v.id);
            v.changed = count(db, "SELECT COUNT(*) FROM files WHERE vid=? AND status=2", v.id);
            if (i + 1 < list.size()) {
                long prev = list.get(i + 1).id;
                try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM files p WHERE p.vid=? AND NOT EXISTS"
                        + " (SELECT 1 FROM files f WHERE f.vid=? AND f.path=p.path)",
                        new String[]{"" + prev, "" + v.id})) {
                    v.removed = c.moveToFirst() ? c.getInt(0) : 0;
                }
            }
        }
    }

    static int count(SQLiteDatabase db, String sql, long id) {
        try (Cursor c = db.rawQuery(sql, new String[]{"" + id})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public long findVersion(String name) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id FROM versions WHERE name=?", new String[]{name})) {
            return c.moveToFirst() ? c.getLong(0) : -1;
        }
    }

    public void renameVersion(long id, String name) {
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        getWritableDatabase().update("versions", cv, "id=?", new String[]{"" + id});
        recomputeStatuses();
    }

    public void deleteVersion(long id, File blobDir) {
        SQLiteDatabase db = getWritableDatabase();
        Set<String> blobs = new HashSet<>();
        try (Cursor c = db.rawQuery("SELECT DISTINCT blob FROM files WHERE vid=?", new String[]{"" + id})) {
            while (c.moveToNext()) blobs.add(c.getString(0));
        }
        db.delete("files", "vid=?", new String[]{"" + id});
        db.delete("versions", "id=?", new String[]{"" + id});
        for (String b : blobs) {
            try (Cursor c = db.rawQuery("SELECT 1 FROM files WHERE blob=? LIMIT 1", new String[]{b})) {
                if (!c.moveToFirst()) {
                    //noinspection ResultOfMethodCallIgnored
                    Blobs.file(blobDir, b).delete();
                }
            }
        }
        recomputeStatuses();
    }

    /** Marks each file NEW / CHANGED / SAME relative to the previous version number. */
    public void recomputeStatuses() {
        List<Version> vs = versions();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < vs.size(); i++) {
                long v = vs.get(i).id;
                if (i + 1 >= vs.size()) {
                    db.execSQL("UPDATE files SET status=0 WHERE vid=?", new Object[]{v});
                } else {
                    long p = vs.get(i + 1).id;
                    db.execSQL("UPDATE files SET status = CASE"
                            + " WHEN NOT EXISTS (SELECT 1 FROM files o WHERE o.vid=? AND o.path=files.path) THEN 1"
                            + " WHEN EXISTS (SELECT 1 FROM files o WHERE o.vid=? AND o.path=files.path AND o.blob=files.blob) THEN 0"
                            + " ELSE 2 END WHERE vid=?", new Object[]{p, p, v});
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    // ------------------------------------------------------------------ files
    public static final class Row {
        public long id, vid, size;
        public String path, name, ext, type, tags, blob;
        public int status;
    }

    static final String COLS = "id, vid, path, name, ext, type, tags, size, blob, status";

    static Row row(Cursor c) {
        Row r = new Row();
        r.id = c.getLong(0);
        r.vid = c.getLong(1);
        r.path = c.getString(2);
        r.name = c.getString(3);
        r.ext = c.getString(4);
        r.type = c.getString(5);
        r.tags = c.getString(6);
        r.size = c.getLong(7);
        r.blob = c.getString(8);
        r.status = c.getInt(9);
        return r;
    }

    public Row file(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM files WHERE id=?", new String[]{"" + id})) {
            return c.moveToFirst() ? row(c) : null;
        }
    }

    public static final class Filter {
        public long vid = -1;
        public boolean onlyChanged;
        public String type; // null = all
        public String tag;  // null = all
        public String text = "";
        public int sort; // 0 new first, 1 name, 2 size desc, 3 path
    }

    public List<Row> search(Filter f, int limit) {
        Categorizer.Query q = Categorizer.parseQuery(f.text);
        StringBuilder sql = new StringBuilder("SELECT " + COLS + " FROM files WHERE vid=?");
        List<String> args = new ArrayList<>();
        args.add("" + f.vid);
        if (f.onlyChanged) sql.append(" AND status>0");
        if (f.type != null) {
            sql.append(" AND type=?");
            args.add(f.type);
        }
        if (f.tag != null) {
            sql.append(" AND tags LIKE ?");
            args.add("%," + f.tag + ",%");
        }
        for (String t : q.types) {
            sql.append(" AND type=?");
            args.add(t);
        }
        for (String t : q.tags) {
            sql.append(" AND tags LIKE ?");
            args.add("%," + t + ",%");
        }
        for (String w : q.words) {
            sql.append(" AND lpath LIKE ? ESCAPE '\\'");
            args.add("%" + w.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%");
        }
        switch (f.sort) {
            case 1: sql.append(" ORDER BY name COLLATE NOCASE"); break;
            case 2: sql.append(" ORDER BY size DESC"); break;
            case 3: sql.append(" ORDER BY lpath"); break;
            default: sql.append(" ORDER BY status DESC, lpath"); break;
        }
        if (limit > 0) sql.append(" LIMIT ").append(limit);
        List<Row> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(sql.toString(), args.toArray(new String[0]))) {
            while (c.moveToNext()) out.add(row(c));
        }
        return out;
    }

    public int countAll(Filter f) {
        return search(f, 0).size();
    }

    /** Same path across all versions (newest first). */
    public List<Row> history(String path) {
        List<Row> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM files WHERE path=?", new String[]{path})) {
            while (c.moveToNext()) out.add(row(c));
        }
        return out;
    }

    /** Textures that probably belong to an .sc file (same folder, name starting with the base name). */
    public List<Row> related(Row r) {
        String base = r.path.substring(0, r.path.length() - r.ext.length() - (r.ext.isEmpty() ? 0 : 1));
        List<Row> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM files WHERE vid=? AND path LIKE ? AND id<>? AND type='tex' ORDER BY path LIMIT 50",
                new String[]{"" + r.vid, base.replace("%", "") + "%", "" + r.id})) {
            while (c.moveToNext()) out.add(row(c));
        }
        return out;
    }

    public List<Row> byPaths(long vid, List<String> paths) {
        List<Row> out = new ArrayList<>();
        for (String p : paths) {
            String n = Categorizer.name(p);
            try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM files WHERE vid=? AND name=? LIMIT 1",
                    new String[]{"" + vid, n})) {
                if (c.moveToFirst()) out.add(row(c));
            }
        }
        return out;
    }

    /** Textures and images in the same folder as r whose name contains text (all when text is empty). */
    public List<Row> texturesNear(Row r, String text, int limit) {
        int slash = r.path.lastIndexOf('/');
        String folder = slash < 0 ? "" : r.path.substring(0, slash + 1).toLowerCase(java.util.Locale.ROOT);
        List<Row> out = new ArrayList<>();
        String like = "%" + text.toLowerCase(java.util.Locale.ROOT).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%";
        try (Cursor c = getReadableDatabase().rawQuery("SELECT " + COLS + " FROM files WHERE vid=? AND (type='tex' OR type='img')"
                        + " AND lpath LIKE ? ESCAPE '\\' AND lower(name) LIKE ? ESCAPE '\\' ORDER BY name LIMIT " + limit,
                new String[]{"" + r.vid, folder.replace("%", "") + "%", like})) {
            while (c.moveToNext()) out.add(row(c));
        }
        return out;
    }

    public String versionName(long vid) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT name FROM versions WHERE id=?", new String[]{"" + vid})) {
            return c.moveToFirst() ? c.getString(0) : "?";
        }
    }

    public int typeCount(long vid, String type, boolean onlyChanged) {
        String sql = "SELECT COUNT(*) FROM files WHERE vid=? AND type=?" + (onlyChanged ? " AND status>0" : "");
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{"" + vid, type})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }
}
