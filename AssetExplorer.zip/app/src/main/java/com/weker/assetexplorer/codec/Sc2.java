package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Reader for Supercell SC2 (.sc version 5/6) files: atlases, export names and shapes,
 * plus a renderer that cuts each shape (sprite) out of its atlas.
 */
public final class Sc2 {

    public int version;
    public final List<String> strings = new ArrayList<>();
    public final List<String> exportNames = new ArrayList<>();
    public final List<Tex> textures = new ArrayList<>();
    public final List<ShapeDef> shapes = new ArrayList<>();
    byte[] points;
    int scalePrecision, translationPrecision;
    public final List<Bank> banks = new ArrayList<>();
    public final Map<Integer, Clip> clips = new HashMap<>();
    public final Map<Integer, ShapeDef> shapeById = new HashMap<>();
    public final Map<Integer, Integer> modifiers = new HashMap<>();
    /** export name -> display object id (in file order) */
    public final List<String> exportOrder = new ArrayList<>();
    public final Map<String, Integer> exportIds = new HashMap<>();
    int[] storageElements;

    public static final class Bank {
        public float[] m = new float[0]; // 6 floats per matrix: a b c d tx ty
        public int[] ct = new int[0];    // 7 ints per color transform: rMul gMul bMul alpha rAdd gAdd bAdd
        public byte[] clipData;
        public int matrixCount() { return m.length / 6; }
        public int colorCount() { return ct.length / 7; }
    }

    public static final class Clip {
        public int id, bank, frameCount, fps = 30;
        public int[] children = new int[0];
        public int[] blend = new int[0];
        /** per frame: flat triples (childIndex, matrixIndex, colorIndex) */
        public final List<int[]> frames = new ArrayList<>();
    }

    public static final class Tex {
        public int format, pixelType, width, height;
        public byte[] data;        // KTX or raw pixels (may be null)
        public String external;    // external texture file name (may be null)
        Img decoded;
    }

    public static final class Cmd {
        public int texture, count, offset;
    }

    public static final class ShapeDef {
        public int id;
        public String name = "";
        public final List<Cmd> cmds = new ArrayList<>();
    }

    public static boolean isSc2(byte[] d) {
        if (d.length < 12 || d[0] != 'S' || d[1] != 'C') return false;
        int v = le32(d, 2);
        return v >= 5 && v <= 32;
    }

    public static Sc2 parse(byte[] d) throws IOException {
        if (!isSc2(d)) throw new IOException("Не SC2");
        Sc2 s = new Sc2();
        s.version = le32(d, 2);
        int p = 6;
        if (s.version == 6) p += 2;
        int descSize = le32(d, p);
        p += 4;
        int desc = p;
        if (descSize <= 0 || desc + descSize > d.length) throw new IOException("Повреждённый заголовок SC2");
        Fb header = Fb.root(d, desc);
        s.translationPrecision = header.u32(0, 0);
        s.scalePrecision = header.u32(1, 0);
        int resourcesOffset = header.u32(8, 0);
        int externalBankSize = header.u32(12, 0);
        int compressedSize = header.u32(11, 0);
        p = desc + descSize;
        int end = compressedSize > 0 ? Math.min(d.length, p + compressedSize) : d.length;
        byte[] m = Zstd.isZstd(d, p) ? Zstd.decompress(d, p, end) : java.util.Arrays.copyOfRange(d, p, end);
        if (externalBankSize > 0 && compressedSize > 0 && end + externalBankSize <= d.length) {
            try {
                s.loadExternalBanks(d, end);
            } catch (RuntimeException | IOException e) {
                s.banks.clear();
            }
        }

        // metadata names (export names are also stored here)
        int meta = header.vec(10);
        if (meta > 0) {
            int n = le32(d, meta - 4);
            for (int i = 0; i < n && i < 100000; i++) {
                Fb e = Fb.at(d, meta + i * 4);
                String nm = e.str(0);
                if (nm != null) s.exportNames.add(nm);
            }
        }

        // data storage
        Fb storage = Fb.root(m, 4);
        int sv = storage.vec(0);
        if (sv > 0) {
            int n = le32(m, sv - 4);
            for (int i = 0; i < n; i++) {
                int sp = sv + i * 4;
                sp += le32(m, sp);
                int len = le32(m, sp);
                s.strings.add(new String(m, sp + 4, len, StandardCharsets.UTF_8));
            }
        }
        int pv = storage.vec(5);
        if (pv > 0) {
            int n = le32(m, pv - 4);
            s.points = java.util.Arrays.copyOfRange(m, pv, pv + n);
        }

        int ev = storage.vec(4);
        if (ev > 0) {
            int n = le32(m, ev - 4);
            s.storageElements = new int[n];
            for (int i = 0; i < n; i++) s.storageElements[i] = le16(m, ev + i * 2);
        }
        if (s.banks.isEmpty()) {
            int bv = storage.vec(6);
            int bn = bv > 0 ? le32(m, bv - 4) : 0;
            float sm = precision(s.scalePrecision), tm = precision(s.translationPrecision);
            for (int i = 0; i < bn; i++) {
                Fb b = Fb.at(m, bv + i * 4);
                Bank bank = new Bank();
                int mv = b.vec(0), hv = b.vec(2), cv = b.vec(1);
                if (mv > 0) {
                    int n = le32(m, mv - 4);
                    bank.m = new float[n * 6];
                    for (int k = 0; k < n * 6; k++) bank.m[k] = Float.intBitsToFloat(le32(m, mv + k * 4));
                } else if (hv > 0) {
                    int n = le32(m, hv - 4);
                    bank.m = new float[n * 6];
                    for (int k = 0; k < n; k++) {
                        for (int j = 0; j < 6; j++) {
                            short v = (short) le16(m, hv + k * 12 + j * 2);
                            bank.m[k * 6 + j] = v / (j < 4 ? sm : tm);
                        }
                    }
                }
                if (cv > 0) {
                    int n = le32(m, cv - 4);
                    bank.ct = new int[n * 7];
                    for (int k = 0; k < n; k++) {
                        int o = cv + k * 7;
                        bank.ct[k * 7] = m[o] & 0xFF;          // r_mul
                        bank.ct[k * 7 + 1] = m[o + 1] & 0xFF;  // g_mul
                        bank.ct[k * 7 + 2] = m[o + 2] & 0xFF;  // b_mul
                        bank.ct[k * 7 + 3] = m[o + 3] & 0xFF;  // alpha
                        bank.ct[k * 7 + 4] = m[o + 4] & 0xFF;  // r_add
                        bank.ct[k * 7 + 5] = m[o + 5] & 0xFF;  // g_add
                        bank.ct[k * 7 + 6] = m[o + 6] & 0xFF;  // b_add
                    }
                }
                s.banks.add(bank);
            }
        }

        // chunks: exports, textfields, shapes, movieclips, modifiers, textures
        int[] chunk = new int[6];
        int q = resourcesOffset;
        for (int i = 0; i < 6 && q + 4 <= m.length; i++) {
            int size = le32(m, q);
            chunk[i] = q + 4;
            q += 4 + size;
        }

        Map<Integer, String> exportById = new HashMap<>();
        if (chunk[0] > 0) {
            Fb ex = Fb.root(m, chunk[0]);
            int ids = ex.vec(0), refs = ex.vec(1);
            if (ids > 0 && refs > 0) {
                int n = Math.min(le32(m, ids - 4), le32(m, refs - 4));
                List<String> names = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    int id = le16(m, ids + i * 2);
                    int ref = le32(m, refs + i * 4);
                    String nm = ref >= 0 && ref < s.strings.size() ? s.strings.get(ref) : ("export_" + id);
                    exportById.put(id, nm);
                    names.add(nm);
                    if (!s.exportIds.containsKey(nm)) {
                        s.exportIds.put(nm, id);
                        s.exportOrder.add(nm);
                    }
                }
                if (!names.isEmpty()) {
                    s.exportNames.clear();
                    s.exportNames.addAll(names);
                }
            }
        }

        if (chunk[2] > 0) {
            Fb sh = Fb.root(m, chunk[2]);
            int v = sh.vec(0);
            int n = v > 0 ? le32(m, v - 4) : 0;
            for (int i = 0; i < n; i++) {
                Fb t = Fb.at(m, v + i * 4);
                ShapeDef def = new ShapeDef();
                def.id = t.u16(0, 0);
                int cv = t.vec(1);
                int cn = cv > 0 ? le32(m, cv - 4) : 0;
                for (int c = 0; c < cn; c++) {
                    int o = cv + c * 16;
                    Cmd cmd = new Cmd();
                    cmd.texture = le32(m, o + 4);
                    cmd.count = le32(m, o + 8);
                    cmd.offset = le32(m, o + 12);
                    def.cmds.add(cmd);
                }
                s.shapes.add(def);
            }
        }

        // movieclips: map export -> shapes it uses (to give sprites readable names)
        for (ShapeDef sd : s.shapes) s.shapeById.put(sd.id, sd);
        if (chunk[4] > 0) {
            try {
                Fb mo = Fb.root(m, chunk[4]);
                int v = mo.vec(0);
                int n = v > 0 ? le32(m, v - 4) : 0;
                for (int i = 0; i < n; i++) s.modifiers.put(le16(m, v + i * 4), m[v + i * 4 + 2] & 0xFF);
            } catch (RuntimeException ignored) {
                // no masks
            }
        }
        if (chunk[3] > 0) {
            Fb mc = Fb.root(m, chunk[3]);
            int v = mc.vec(0);
            int n = v > 0 ? le32(m, v - 4) : 0;
            Map<Integer, int[]> children = new HashMap<>();
            for (int i = 0; i < n; i++) {
                Fb t = Fb.at(m, v + i * 4);
                Clip clip = s.readClip(m, t);
                children.put(clip.id, clip.children);
                s.clips.put(clip.id, clip);
            }
            Map<Integer, ShapeDef> shapeById = s.shapeById;
            for (Map.Entry<Integer, String> e : exportById.entrySet()) {
                List<ShapeDef> found = new ArrayList<>();
                collect(e.getKey(), children, shapeById, found, new HashSet<>());
                int k = 0;
                for (ShapeDef sd : found) {
                    if (!sd.name.isEmpty()) continue;
                    sd.name = found.size() == 1 ? e.getValue() : e.getValue() + "_" + (++k);
                }
            }
        }
        for (ShapeDef sd : s.shapes) if (sd.name.isEmpty()) sd.name = "shape_" + sd.id;

        if (chunk[5] > 0) {
            Fb tx = Fb.root(m, chunk[5]);
            int v = tx.vec(0);
            int n = v > 0 ? le32(m, v - 4) : 0;
            for (int i = 0; i < n; i++) {
                Fb set = Fb.at(m, v + i * 4);
                Fb td = set.table(1);
                if (td == null) td = set.table(0);
                Tex t = new Tex();
                if (td != null) {
                    t.format = td.u8(0, 0);
                    t.pixelType = td.u8(1, 0);
                    t.width = td.u16(2, 0);
                    t.height = td.u16(3, 0);
                    int dv = td.vec(4);
                    if (dv > 0) t.data = java.util.Arrays.copyOfRange(m, dv, dv + le32(m, dv - 4));
                    t.external = td.str(5);
                }
                s.textures.add(t);
            }
        }
        return s;
    }

    static void collect(int id, Map<Integer, int[]> children, Map<Integer, ShapeDef> shapes, List<ShapeDef> out, Set<Integer> seen) {
        if (!seen.add(id) || seen.size() > 5000) return;
        ShapeDef sd = shapes.get(id);
        if (sd != null) {
            if (!out.contains(sd)) out.add(sd);
            return;
        }
        int[] ch = children.get(id);
        if (ch == null) return;
        for (int c : ch) collect(c, children, shapes, out, seen);
    }

    private final List<Integer> decodedOrder = new ArrayList<>();

    /** Decodes atlas i (embedded KTX or raw). Returns null for external textures. Keeps at most 2 in memory. */
    public synchronized Img texture(int i, List<String> info) throws IOException {
        Tex t = textures.get(i);
        if (t.decoded != null) return t.decoded;
        while (decodedOrder.size() >= 2) {
            Tex old = textures.get(decodedOrder.remove(0));
            if (old.data != null) old.decoded = null;
        }
        decodedOrder.add(i);
        if (t.data == null || t.data.length == 0) return null;
        byte[] data = t.data;
        if (Zstd.isZstd(data, 0)) data = Zstd.decompress(data);
        if (SupercellFiles.startsWith(data, SupercellFiles.KTX_ID, 0)) {
            t.decoded = SupercellFiles.readKtx(data, 0, info);
        } else if (SupercellFiles.isSctx(data)) {
            t.decoded = SupercellFiles.readSctx(data, info);
        } else {
            t.decoded = PixelFormats.raw(data, 0, t.width, t.height, SupercellFiles.sc1Raw(t.pixelType));
        }
        return t.decoded;
    }

    public synchronized void setExternalTexture(int i, Img img) {
        textures.get(i).decoded = img;
    }

    // ------------------------------------------------------------------ sprite rendering
    /** Renders a shape: each bitmap command's triangle strip is mapped from its atlas. */
    public synchronized Img renderShape(ShapeDef sd, int maxSize) throws IOException {
        if (points == null || sd.cmds.isEmpty()) return null;
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        double scale = 0;
        for (Cmd c : sd.cmds) {
            Img atlas = texture(c.texture, new ArrayList<>());
            if (atlas == null) continue;
            for (int i = 0; i < c.count; i++) {
                float x = vx(c, i), y = vy(c, i);
                minX = Math.min(minX, x);
                minY = Math.min(minY, y);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
            }
            for (int i = 0; i + 2 < c.count && scale == 0; i++) {
                double ax = vx(c, i + 1) - vx(c, i), ay = vy(c, i + 1) - vy(c, i);
                double bx = vx(c, i + 2) - vx(c, i), by = vy(c, i + 2) - vy(c, i);
                double au = (vu(c, i + 1) - vu(c, i)) * atlas.width, av = (vv(c, i + 1) - vv(c, i)) * atlas.height;
                double bu = (vu(c, i + 2) - vu(c, i)) * atlas.width, bv = (vv(c, i + 2) - vv(c, i)) * atlas.height;
                double areaXY = Math.abs(ax * by - ay * bx);
                double areaUV = Math.abs(au * bv - av * bu);
                if (areaXY > 1e-6 && areaUV > 1e-6) scale = Math.sqrt(areaUV / areaXY);
            }
        }
        if (minX > maxX) return null;
        if (scale == 0) scale = 1; // solid-colour shape: every vertex samples the same texel
        int w = (int) Math.ceil((maxX - minX) * scale);
        int h = (int) Math.ceil((maxY - minY) * scale);
        if (w <= 0 || h <= 0) return null;
        double fit = Math.min(1.0, (double) maxSize / Math.max(w, h));
        scale *= fit;
        w = Math.max(1, (int) Math.ceil((maxX - minX) * scale));
        h = Math.max(1, (int) Math.ceil((maxY - minY) * scale));
        int[] out = new int[w * h];
        for (Cmd c : sd.cmds) {
            Img atlas = texture(c.texture, new ArrayList<>());
            if (atlas == null) continue;
            for (int i = 0; i + 2 < c.count; i++) {
                rasterTri(out, w, h, atlas, c, i, i + 1, i + 2, minX, minY, scale);
            }
        }
        return new Img(w, h, out);
    }

    private void rasterTri(int[] out, int w, int h, Img atlas, Cmd c, int i0, int i1, int i2,
                           float minX, float minY, double scale) {
        double x0 = (vx(c, i0) - minX) * scale, y0 = (vy(c, i0) - minY) * scale;
        double x1 = (vx(c, i1) - minX) * scale, y1 = (vy(c, i1) - minY) * scale;
        double x2 = (vx(c, i2) - minX) * scale, y2 = (vy(c, i2) - minY) * scale;
        double det = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (Math.abs(det) < 1e-12) return;
        double u0 = vu(c, i0) * atlas.width, v0 = vv(c, i0) * atlas.height;
        double u1 = vu(c, i1) * atlas.width, v1 = vv(c, i1) * atlas.height;
        double u2 = vu(c, i2) * atlas.width, v2 = vv(c, i2) * atlas.height;
        int bx0 = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int by0 = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int bx1 = Math.min(w - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int by1 = Math.min(h - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        final double eps = 1e-4;
        for (int py = by0; py <= by1; py++) {
            for (int px = bx0; px <= bx1; px++) {
                double cx = px + 0.5, cy = py + 0.5;
                double a = ((x1 - cx) * (y2 - cy) - (x2 - cx) * (y1 - cy)) / det;
                double b = ((x2 - cx) * (y0 - cy) - (x0 - cx) * (y2 - cy)) / det;
                double g = 1 - a - b;
                if (a < -eps || b < -eps || g < -eps) continue;
                double u = a * u0 + b * u1 + g * u2;
                double v = a * v0 + b * v1 + g * v2;
                int iu = (int) Math.floor(u), iv = (int) Math.floor(v);
                if (iu < 0) iu = 0;
                if (iv < 0) iv = 0;
                if (iu >= atlas.width) iu = atlas.width - 1;
                if (iv >= atlas.height) iv = atlas.height - 1;
                out[py * w + px] = atlas.argb[iv * atlas.width + iu];
            }
        }
    }

    float vx(Cmd c, int i) { return Float.intBitsToFloat(le32(points, (c.offset + i) * 12)); }

    float vy(Cmd c, int i) { return Float.intBitsToFloat(le32(points, (c.offset + i) * 12 + 4)); }

    float vu(Cmd c, int i) { return le16(points, (c.offset + i) * 12 + 8) / 65535f; }

    float vv(Cmd c, int i) { return le16(points, (c.offset + i) * 12 + 10) / 65535f; }

    // ------------------------------------------------------------------ movieclips & banks
    // Matrix-bank and compressed frame decoding follow the logic of SupercellFlash
    // (MIT License, Copyright (c) 2025 SC Workshop), reimplemented in Java.

    static float precision(int p) {
        switch (p) {
            case 2: return 20f;
            case 3: return 1024f;
            default: return 1f;
        }
    }

    Clip readClip(byte[] m, Fb t) {
        Clip c = new Clip();
        c.id = t.u16(0, 0);
        c.frameCount = t.u16(3, 0);
        int fr = t.u8(2, 0);
        if (fr > 0) c.fps = fr;
        int cv = t.vec(5);
        int cn = cv > 0 ? le32(m, cv - 4) : 0;
        c.children = new int[cn];
        for (int i = 0; i < cn; i++) c.children[i] = le16(m, cv + i * 2);
        int bl = t.vec(7);
        if (bl > 0) {
            int n = le32(m, bl - 4);
            c.blend = new int[n];
            for (int i = 0; i < n; i++) c.blend[i] = m[bl + i] & 0xFF;
        }
        c.bank = t.u32(10, 0);
        // frame element counts
        List<Integer> counts = new ArrayList<>();
        int fv = t.vec(8);
        if (fv > 0) {
            int n = le32(m, fv - 4);
            for (int i = 0; i < n; i++) counts.add(le32(m, fv + i * 8));
        } else if (version == 5) {
            int sv = t.vec(12);
            if (sv > 0) {
                int n = le32(m, sv - 4);
                for (int i = 0; i < n; i++) counts.add(le16(m, sv + i * 2));
            }
        }
        int feo = t.field(9) != 0 ? le32(m, t.field(9)) : -1;
        try {
            if (feo >= 0 && storageElements != null) {
                int off = feo;
                for (int cnt : counts) {
                    int[] el = new int[cnt * 3];
                    for (int k = 0; k < el.length && off < storageElements.length; k++) el[k] = storageElements[off++];
                    c.frames.add(el);
                }
            } else if (version >= 6 && c.bank < banks.size() && banks.get(c.bank).clipData != null) {
                int cdo = t.u32(12, 0);
                byte[] clip = banks.get(c.bank).clipData;
                int nFrames = Math.max(counts.size(), c.frameCount);
                for (int f = 0; f < nFrames; f++) {
                    c.frames.add(decodeFrame(clip, cdo, f));
                }
            }
        } catch (RuntimeException e) {
            // keep whatever frames were decoded
        }
        return c;
    }

    void loadExternalBanks(byte[] d, int start) throws IOException {
        int descSize = le32(d, start);
        int descPos = start + 4;
        Fb root = Fb.root(d, descPos);
        int dataBase = descPos + descSize;
        int bv = root.vec(0);
        int bn = bv > 0 ? le32(d, bv - 4) : 0;
        Bank[] arr = new Bank[bn];
        for (int i = 0; i < bn; i++) {
            Fb b = Fb.at(d, bv + i * 4);
            int index = b.u32(0, i);
            int cOff = b.u32(1, 0), cSize = b.u32(2, 0);
            int cmBlocks = b.u32(4, 0), shortDataSize = b.u32(5, 0);
            int shortCount = b.u32(6, 0), floatCount = b.u32(7, 0), colorCount = b.u32(8, 0);
            int clipOff = b.u32(9, 0), clipSize = b.u32(10, 0);
            byte[] buf = Zstd.decompress(d, dataBase + cOff, dataBase + cOff + cSize);
            Bank bank = new Bank();

            int uncompressed = shortCount + floatCount;
            int total = Math.min(Math.max(uncompressed, cmBlocks * 16), 0xFFFF);
            uncompressed = Math.min(uncompressed, 0xFFFF);
            bank.m = new float[total * 6];
            for (int k = 0; k < floatCount && k < total; k++) {
                for (int j = 0; j < 6; j++) bank.m[k * 6 + j] = Float.intBitsToFloat(le32(buf, k * 24 + j * 4));
            }
            int floatSize = floatCount * 24;
            int cmdOff = floatSize + cmBlocks * 4; // byte offset of the u16 matrix data
            for (int i2 = uncompressed; i2 < total; i2 += 16) {
                int blockIndex = i2 >> 4;
                int enc = le32(buf, floatSize + blockIndex * 4);
                int dataOffset = enc >> 13;
                int base = enc & 0x1FFF;
                int a = u16(buf, cmdOff, base * 6), bb = u16(buf, cmdOff, base * 6 + 1);
                int cc = u16(buf, cmdOff, base * 6 + 2), dd = u16(buf, cmdOff, base * 6 + 3);
                int tx = u16(buf, cmdOff, base * 6 + 4), ty = u16(buf, cmdOff, base * 6 + 5);
                for (int sub = 0; sub < 16 && i2 + sub < total; sub++) {
                    int flags = u16(buf, cmdOff, dataOffset);
                    if ((flags & 3) != 0) {
                        int low = u16(buf, cmdOff, dataOffset + 1);
                        int high = u16(buf, cmdOff, dataOffset + 2);
                        long packed = pack(flags, low, high);
                        switch (flags & 0xF) {
                            case 1:
                                tx += bits(packed, 14, 4);
                                ty += bits(packed, 14, 18);
                                dataOffset += 2;
                                break;
                            case 2:
                                a += bits(packed, 7, 4);
                                dd += bits(packed, 7, 11);
                                tx += bits(packed, 7, 18);
                                ty += bits(packed, 7, 25);
                                dataOffset += 2;
                                break;
                            case 3:
                                a += bits(packed, 11, 4);
                                dd += bits(packed, 11, 15);
                                tx += bits(packed, 11, 26);
                                ty += bits(packed, 11, 37);
                                dataOffset += 3;
                                break;
                            case 5:
                                a += bits(packed, 7, 4);
                                bb += bits(packed, 7, 11);
                                cc += bits(packed, 7, 18);
                                dd += bits(packed, 7, 25);
                                tx += bits(packed, 8, 32);
                                ty += bits(packed, 8, 40);
                                dataOffset += 3;
                                break;
                            case 6: {
                                int mid = u16(buf, cmdOff, dataOffset + 3);
                                long tr = pack(low, high, mid);
                                a += bits(packed, 10, 4);
                                bb += bits(packed, 10, 14);
                                cc += bits(packed, 10, 24);
                                dd += bits(packed, 10, 34);
                                tx += bits(tr, 10, 28);
                                ty += bits(tr, 10, 38);
                                dataOffset += 4;
                                break;
                            }
                            case 7: {
                                int mid = u16(buf, cmdOff, dataOffset + 3);
                                int highest = u16(buf, cmdOff, dataOffset + 4);
                                long tr = pack(high, mid, highest);
                                a += bits(packed, 12, 4);
                                bb += bits(packed, 12, 16);
                                cc += bits(packed, 12, 28);
                                dd += bits(tr, 12, 8);
                                tx += bits(tr, 14, 20);
                                ty += bits(tr, 14, 34);
                                dataOffset += 5;
                                break;
                            }
                            case 0xF:
                                a += low;
                                bb += high;
                                cc += u16(buf, cmdOff, dataOffset + 3);
                                dd += u16(buf, cmdOff, dataOffset + 4);
                                tx += u16(buf, cmdOff, dataOffset + 5);
                                ty += u16(buf, cmdOff, dataOffset + 6);
                                dataOffset += 7;
                                break;
                            default:
                                throw new IOException("Неизвестное сжатие матриц");
                        }
                    } else {
                        tx += bits(flags, 7, 2);
                        ty += bits(flags, 7, 9);
                        dataOffset++;
                    }
                    int mi = (i2 + sub) * 6;
                    bank.m[mi] = (short) a / 1024f;
                    bank.m[mi + 1] = (short) bb / 1024f;
                    bank.m[mi + 2] = (short) cc / 1024f;
                    bank.m[mi + 3] = (short) dd / 1024f;
                    bank.m[mi + 4] = (short) tx / 20f;
                    bank.m[mi + 5] = (short) ty / 20f;
                }
            }
            int q = cmdOff;
            for (int k = floatCount; k < uncompressed; k++) {
                for (int j = 0; j < 6; j++) {
                    short v = (short) le16(buf, q);
                    q += 2;
                    bank.m[k * 6 + j] = v / (j < 4 ? 1024f : 20f);
                }
            }
            int co = floatSize + cmBlocks * 4 + shortDataSize * 2;
            bank.ct = new int[colorCount * 7];
            for (int k = 0; k < colorCount * 7 && co + k < buf.length; k++) bank.ct[k] = buf[co + k] & 0xFF;
            if (clipSize > 0 && clipOff + clipSize <= buf.length) {
                bank.clipData = java.util.Arrays.copyOfRange(buf, clipOff, clipOff + clipSize);
            }
            if (index >= 0 && index < bn) arr[index] = bank;
            else arr[i] = bank;
        }
        for (Bank b : arr) banks.add(b == null ? new Bank() : b);
    }

    static int u16(byte[] b, int base, int index) {
        int p = base + index * 2;
        if (p < 0 || p + 1 >= b.length) return 0;
        return le16(b, p);
    }

    static long pack(int low, int mid, int high) {
        return ((long) (high & 0xFFFF) << 32) | ((long) (mid & 0xFFFF) << 16) | (low & 0xFFFF);
    }

    /** sign-extended bit field */
    static int bits(long packed, int count, int shift) {
        return (int) ((packed << (64 - count - shift)) >> (64 - count));
    }

    static int sx(int v, int count, int shift) {
        return (v << (32 - count - shift)) >> (32 - count);
    }

    /** Decodes frame f of a compressed clip (v6). Returns flat triples. */
    static int[] decodeFrame(byte[] clip, int cdo, int f) {
        int hdr = cdo + f * 8 + 8;
        int frameOff = le32(clip, hdr);
        int ed = cdo + frameOff;                    // byte position of element data
        int start = ed + 2 * le16(clip, hdr + 4);   // byte position
        int end = ed + 2 * le16(clip, hdr + 6);
        int[] out = new int[4096];
        int n = 0;
        if (start == ed) {
            for (int p = start; p < end && n < out.length; p += 2) out[n++] = le16(clip, p);
            return java.util.Arrays.copyOf(out, n - n % 3);
        }
        if (start == end) return new int[0];
        int v6 = 0;
        int guard = 0;
        while (start != end && out.length - n >= 6 && guard++ < 100000) {
            if (start > end) break;
            int v17 = le16(clip, start);
            int v13 = le16(clip, ed), v14 = le16(clip, ed + 2), v16 = le16(clip, ed + 4);
            if ((v6 & 1) != 0) {
                out[n++] = v13;
                out[n++] = v14;
                out[n++] = v16;
                ed += 6;
                v6 >>= 1;
                continue;
            }
            v6 >>= 1;
            if ((v17 & 3) != 0) {
                switch (v17 & 7) {
                    case 1:
                        out[n++] = v13;
                        out[n++] = (sx(v17, 13, 3) + v14) & 0xFFFF;
                        out[n++] = v16;
                        ed += 6;
                        start += 2;
                        break;
                    case 2:
                        out[n++] = v13;
                        out[n++] = (sx(v17, 4, 3) + v14) & 0xFFFF;
                        out[n++] = (sx(v17, 9, 7) + v16) & 0xFFFF;
                        ed += 6;
                        start += 2;
                        break;
                    case 3:
                        out[n++] = v13;
                        out[n++] = (le16(clip, start + 2) + v14) & 0xFFFF;
                        out[n++] = (sx(v17, 13, 3) + v16) & 0xFFFF;
                        ed += 6;
                        start += 4;
                        break;
                    case 5:
                        out[n++] = v13;
                        out[n++] = v14;
                        out[n++] = v16;
                        ed += 6;
                        start += 2;
                        v6 = v17 >> 3;
                        break;
                    case 6:
                        ed += 6 * sx(v17, 13, 3);
                        start += 2;
                        break;
                    case 7:
                        out[n++] = sx(v17, 12, 3) & 0xFFFF;
                        out[n++] = le16(clip, start + 2);
                        out[n++] = le16(clip, start + 4);
                        start += 6;
                        if ((v17 & 0x8000) != 0) ed += 6;
                        break;
                    default:
                        return java.util.Arrays.copyOf(out, n - n % 3);
                }
            } else {
                out[n++] = v13;
                out[n++] = (sx(v17, 7, 2) + v14) & 0xFFFF;
                out[n++] = v16;
                out[n++] = le16(clip, ed + 6);
                out[n++] = (sx(v17, 7, 9) + le16(clip, ed + 8)) & 0xFFFF;
                out[n++] = le16(clip, ed + 10);
                ed += 12;
                start += 2;
                v6 >>= 1;
            }
        }
        if (start == end) {
            while (v6 != 0 && out.length - n >= 3) {
                if ((v6 & 1) == 0) break;
                out[n++] = le16(clip, ed);
                out[n++] = le16(clip, ed + 2);
                out[n++] = le16(clip, ed + 4);
                ed += 6;
                v6 >>= 1;
            }
        }
        return java.util.Arrays.copyOf(out, n - n % 3);
    }

    // ------------------------------------------------------------------ scene rendering
    /** 2x3 affine: x' = a*x + c*y + tx ; y' = b*x + d*y + ty */
    static float[] mul(float[] p, float[] c) {
        return new float[]{
                p[0] * c[0] + p[2] * c[1], p[1] * c[0] + p[3] * c[1],
                p[0] * c[2] + p[2] * c[3], p[1] * c[2] + p[3] * c[3],
                p[0] * c[4] + p[2] * c[5] + p[4], p[1] * c[4] + p[3] * c[5] + p[5]};
    }

    static final float[] IDENTITY = {1, 0, 0, 1, 0, 0};
    static final List<String> NO_INFO = new ArrayList<String>() {
        @Override
        public boolean add(String x) { return false; }
    };
    static final float[] NO_COLOR = {1, 1, 1, 1, 0, 0, 0}; // rMul gMul bMul aMul rAdd gAdd bAdd

    static final int MOD_MASK = 38, MOD_MASKED = 39, MOD_UNMASKED = 40;
    static final int DRAW_NORMAL = 0, DRAW_TO_MASK = 1, DRAW_MASKED = 2;

    interface DrawSink {
        void shape(ShapeDef sd, float[] m, float[] ct, int blend, int maskMode) throws IOException;

        default void clearMask() {}
    }

    /** Walks the display tree. maskMode is shared state, like a stencil buffer in the game. */
    void walk(int id, int frame, float[] m, float[] ct, int blend, DrawSink sink, int depth, int[] maskMode) throws IOException {
        if (depth > 24) return;
        ShapeDef sd = shapeById.get(id);
        if (sd != null) {
            sink.shape(sd, m, ct, blend, maskMode[0]);
            return;
        }
        Clip c = clips.get(id);
        if (c == null || c.frames.isEmpty()) return;
        int entryMode = maskMode[0];
        int[] el = c.frames.get(Math.floorMod(frame, c.frames.size()));
        Bank bank = c.bank < banks.size() ? banks.get(c.bank) : null;
        for (int i = 0; i + 2 < el.length; i += 3) {
            int child = el[i], mi = el[i + 1], ci = el[i + 2];
            if (child >= c.children.length) continue;
            int cid = c.children[child];
            Integer mod = modifiers.get(cid);
            if (mod != null) {
                if (mod == MOD_MASK) {
                    sink.clearMask();
                    maskMode[0] = DRAW_TO_MASK;
                } else if (mod == MOD_MASKED) {
                    maskMode[0] = DRAW_MASKED;
                } else if (mod == MOD_UNMASKED) {
                    maskMode[0] = DRAW_NORMAL;
                }
                continue;
            }
            float[] cm = m;
            if (mi != 0xFFFF && bank != null && mi < bank.matrixCount()) {
                float[] lm = java.util.Arrays.copyOfRange(bank.m, mi * 6, mi * 6 + 6);
                cm = mul(m, lm);
            }
            float[] cc = ct;
            if (ci != 0xFFFF && bank != null && ci < bank.colorCount()) {
                int o = ci * 7;
                float rm = bank.ct[o] / 255f, gm = bank.ct[o + 1] / 255f, bm = bank.ct[o + 2] / 255f, am = bank.ct[o + 3] / 255f;
                float ra = bank.ct[o + 4], ga = bank.ct[o + 5], ba = bank.ct[o + 6];
                // the child's transform is applied first, then the parent's
                cc = new float[]{rm * ct[0], gm * ct[1], bm * ct[2], am * ct[3],
                        ra * ct[0] + ct[4], ga * ct[1] + ct[5], ba * ct[2] + ct[6]};
            }
            if (cc[3] <= 0.001f && maskMode[0] != DRAW_TO_MASK) continue;
            int cb = blend;
            if (child < c.blend.length && c.blend[child] > 1) cb = c.blend[child];
            walk(cid, frame, cm, cc, cb, sink, depth + 1, maskMode);
        }
        if (maskMode[0] != entryMode) {
            maskMode[0] = entryMode;
            if (entryMode == DRAW_NORMAL) sink.clearMask();
        }
    }

    public Clip clipOf(String export) {
        Integer id = exportIds.get(export);
        return id == null ? null : clips.get(id);
    }

    public int frameCount(String export) {
        Integer id = exportIds.get(export);
        if (id == null) return 0;
        Clip c = clips.get(id);
        return c == null ? (shapeById.containsKey(id) ? 1 : 0) : c.frames.size();
    }

    public int fps(String export) {
        Clip c = clipOf(export);
        return c == null ? 30 : Math.max(1, Math.min(60, c.fps));
    }

    /** Bounding box (minX,minY,maxX,maxY) of an export at a frame; null if nothing is drawn. */
    public float[] bounds(String export, int frame) throws IOException {
        Integer id = exportIds.get(export);
        if (id == null) return null;
        float[] bb = {Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        walk(id, frame, IDENTITY, NO_COLOR, 0, (sd, m, ct, blend, mode) -> {
            if (mode == DRAW_TO_MASK) return;
            for (Cmd c : sd.cmds) {
                for (int i = 0; i < c.count; i++) {
                    float x = vx(c, i), y = vy(c, i);
                    float X = m[0] * x + m[2] * y + m[4], Y = m[1] * x + m[3] * y + m[5];
                    bb[0] = Math.min(bb[0], X);
                    bb[1] = Math.min(bb[1], Y);
                    bb[2] = Math.max(bb[2], X);
                    bb[3] = Math.max(bb[3], Y);
                }
            }
        }, 0, new int[1]);
        return bb[0] > bb[2] ? null : bb;
    }

    /** Union of bounds over all frames (stable canvas for animation). */
    public float[] unionBounds(String export) throws IOException {
        int n = Math.max(1, frameCount(export));
        float[] u = null;
        for (int f = 0; f < n; f++) {
            float[] b = bounds(export, f);
            if (b == null) continue;
            if (u == null) u = b.clone();
            else {
                u[0] = Math.min(u[0], b[0]);
                u[1] = Math.min(u[1], b[1]);
                u[2] = Math.max(u[2], b[2]);
                u[3] = Math.max(u[3], b[3]);
            }
        }
        return u;
    }

    private final Map<String, Integer> restCache = new HashMap<>();

    /**
     * Frame where the object stands still at full size: among frames whose drawn area is close to the maximum,
     * pick the one that differs least from its neighbours.
     */
    public synchronized int restFrame(String export) throws IOException {
        Integer cached = restCache.get(export);
        if (cached != null) return cached;
        Integer id = exportIds.get(export);
        int n = frameCount(export);
        int result = 0;
        if (id != null && n > 1) {
            float[][] sig = new float[n][];
            double[] area = new double[n];
            double maxArea = 0;
            for (int f = 0; f < n; f++) {
                List<Float> v = new ArrayList<>();
                float[] bb = {Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
                walk(id, f, IDENTITY, NO_COLOR, 0, (sd, m, ct, blend, mode) -> {
                    v.add((float) sd.id);
                    for (int k = 0; k < 6; k++) v.add(m[k]);
                    v.add(ct[3] * 100f);
                    if (mode == DRAW_TO_MASK) return;
                    for (Cmd c : sd.cmds) {
                        for (int i = 0; i < c.count; i++) {
                            float x = vx(c, i), y = vy(c, i);
                            float X = m[0] * x + m[2] * y + m[4], Y = m[1] * x + m[3] * y + m[5];
                            bb[0] = Math.min(bb[0], X);
                            bb[1] = Math.min(bb[1], Y);
                            bb[2] = Math.max(bb[2], X);
                            bb[3] = Math.max(bb[3], Y);
                        }
                    }
                }, 0, new int[1]);
                sig[f] = new float[v.size()];
                for (int k = 0; k < v.size(); k++) sig[f][k] = v.get(k);
                area[f] = bb[0] > bb[2] ? 0 : (double) (bb[2] - bb[0]) * (bb[3] - bb[1]);
                maxArea = Math.max(maxArea, area[f]);
            }
            double best = Double.MAX_VALUE;
            for (int f = 0; f < n; f++) {
                if (area[f] < maxArea * 0.85) continue;
                double d = 0;
                if (f > 0) d += sigDiff(sig[f], sig[f - 1]);
                if (f + 1 < n) d += sigDiff(sig[f], sig[f + 1]);
                if (d < best) {
                    best = d;
                    result = f;
                }
            }
        }
        restCache.put(export, result);
        return result;
    }

    static double sigDiff(float[] a, float[] b) {
        if (a.length != b.length) return 1e9;
        double d = 0;
        for (int i = 0; i < a.length; i++) d += Math.abs(a[i] - b[i]);
        return d;
    }

    static long diff(int[] a, int[] b) {
        if (a.length != b.length) return Long.MAX_VALUE / 4;
        long d = 0;
        for (int i = 0; i < a.length; i++) {
            int x = a[i], y = b[i];
            d += Math.abs((x >>> 24) - (y >>> 24)) + Math.abs(((x >> 16) & 255) - ((y >> 16) & 255))
                    + Math.abs(((x >> 8) & 255) - ((y >> 8) & 255)) + Math.abs((x & 255) - (y & 255));
        }
        return d;
    }

    /** Static picture of a whole object: resting frame, tight crop, longest side = size. */
    public synchronized Img renderExport(String export, int size) throws IOException {
        int f = restFrame(export);
        float[] bb = bounds(export, f);
        if (bb == null) return null;
        return renderFrame(export, f, bb, size, 2);
    }

    /** Renders one frame into the given bounds (minX,minY,maxX,maxY) with supersampling ss. */
    public synchronized Img renderFrame(String export, int frame, float[] bb, int size, int ss) throws IOException {
        Integer id = exportIds.get(export);
        if (id == null || bb == null) return null;
        double bw = Math.max(1e-3, bb[2] - bb[0]), bh = Math.max(1e-3, bb[3] - bb[1]);
        double scale = size / Math.max(bw, bh);
        int w = Math.max(1, (int) Math.ceil(bw * scale));
        int h = Math.max(1, (int) Math.ceil(bh * scale));
        if ((long) w * h > 16L * 1024 * 1024) return null;
        ss = Math.max(1, Math.min(ss, (int) Math.floor(Math.sqrt(16.0 * 1024 * 1024 / ((double) w * h)))));
        int W = w * ss, H = h * ss;
        final double sc = scale * ss;
        float[] buf = new float[W * H * 4]; // premultiplied RGBA 0..1
        float[][] mask = {null};
        walk(id, frame, IDENTITY, NO_COLOR, 0, new DrawSink() {
            @Override
            public void shape(ShapeDef sd, float[] m, float[] ct, int blend, int mode) throws IOException {
                if (mode == DRAW_TO_MASK && mask[0] == null) mask[0] = new float[W * H];
                for (Cmd c : sd.cmds) {
                    Img atlas = texture(c.texture, NO_INFO);
                    if (atlas == null) continue;
                    for (int i = 0; i + 2 < c.count; i++) {
                        drawTri(buf, mask[0], mode, blend, W, H, atlas, c, m, ct, i, i + 1, i + 2, bb[0], bb[1], sc);
                    }
                }
            }

            @Override
            public void clearMask() {
                if (mask[0] != null) java.util.Arrays.fill(mask[0], 0f);
            }
        }, 0, new int[1]);
        int[] out = new int[w * h];
        float inv = 1f / (ss * ss);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float r = 0, g = 0, b = 0, a = 0;
                for (int j = 0; j < ss; j++) {
                    int o = ((y * ss + j) * W + x * ss) * 4;
                    for (int i = 0; i < ss; i++, o += 4) {
                        r += buf[o];
                        g += buf[o + 1];
                        b += buf[o + 2];
                        a += buf[o + 3];
                    }
                }
                r *= inv;
                g *= inv;
                b *= inv;
                a *= inv;
                if (a <= 0.002f) continue;
                out[y * w + x] = (clamp255(a) << 24) | (clamp255(r / a) << 16) | (clamp255(g / a) << 8) | clamp255(b / a);
            }
        }
        return new Img(w, h, out);
    }

    static int clamp255(float v) {
        int x = Math.round(v * 255f);
        return x < 0 ? 0 : (x > 255 ? 255 : x);
    }

    static double[] tr(float[] m, float x, float y) {
        return new double[]{m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]};
    }

    private void drawTri(float[] buf, float[] mask, int mode, int blend, int w, int h, Img atlas, Cmd c, float[] m, float[] ct,
                         int i0, int i1, int i2, float ox, float oy, double scale) {
        float px0 = vx(c, i0), py0 = vy(c, i0), px1 = vx(c, i1), py1 = vy(c, i1), px2 = vx(c, i2), py2 = vy(c, i2);
        double x0 = (m[0] * px0 + m[2] * py0 + m[4] - ox) * scale, y0 = (m[1] * px0 + m[3] * py0 + m[5] - oy) * scale;
        double x1 = (m[0] * px1 + m[2] * py1 + m[4] - ox) * scale, y1 = (m[1] * px1 + m[3] * py1 + m[5] - oy) * scale;
        double x2 = (m[0] * px2 + m[2] * py2 + m[4] - ox) * scale, y2 = (m[1] * px2 + m[3] * py2 + m[5] - oy) * scale;
        double det = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (Math.abs(det) < 1e-12) return;
        double u0 = vu(c, i0) * atlas.width, v0 = vv(c, i0) * atlas.height;
        double u1 = vu(c, i1) * atlas.width, v1 = vv(c, i1) * atlas.height;
        double u2 = vu(c, i2) * atlas.width, v2 = vv(c, i2) * atlas.height;
        // barycentrics as linear functions of the pixel centre
        double aC = (x1 * y2 - x2 * y1) / det, aX = (y1 - y2) / det, aY = (x2 - x1) / det;
        double bC = (x2 * y0 - x0 * y2) / det, bX = (y2 - y0) / det, bY = (x0 - x2) / det;
        int bx0 = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2))));
        int by0 = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2))));
        int bx1 = Math.min(w - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int by1 = Math.min(h - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        final double eps = -1e-6;
        float r0 = ct[0] / 255f, g0 = ct[1] / 255f, b0 = ct[2] / 255f, am = ct[3];
        float ra = ct[4] / 255f, ga = ct[5] / 255f, ba = ct[6] / 255f;
        for (int py = by0; py <= by1; py++) {
            double cy = py + 0.5, cx = bx0 + 0.5;
            double a = aC + aX * cx + aY * cy;
            double b = bC + bX * cx + bY * cy;
            for (int px = bx0; px <= bx1; px++, a += aX, b += bX) {
                double g = 1 - a - b;
                if (a < eps || b < eps || g < eps) continue;
                int col = sample(atlas, a * u0 + b * u1 + g * u2, a * v0 + b * v1 + g * v2);
                int pi = py * w + px;
                float texA = (col >>> 24) / 255f;
                if (mode == DRAW_TO_MASK) {
                    if (mask != null && texA > mask[pi]) mask[pi] = texA;
                    continue;
                }
                float sa = texA * am;
                if (mode == DRAW_MASKED) sa *= mask == null ? 0f : mask[pi];
                if (sa <= 0) continue;
                float sr = Math.min(1f, ((col >> 16) & 0xFF) * r0 + ra);
                float sg = Math.min(1f, ((col >> 8) & 0xFF) * g0 + ga);
                float sb = Math.min(1f, (col & 0xFF) * b0 + ba);
                int o = pi * 4;
                float dr = buf[o], dg = buf[o + 1], db = buf[o + 2], da = buf[o + 3];
                switch (blend) {
                    case 8: // add
                        buf[o] = Math.min(1f, dr + sr * sa);
                        buf[o + 1] = Math.min(1f, dg + sg * sa);
                        buf[o + 2] = Math.min(1f, db + sb * sa);
                        buf[o + 3] = Math.min(1f, da + sa * (1 - da));
                        break;
                    case 4: { // screen
                        float pr = sr * sa, pg = sg * sa, pb = sb * sa;
                        buf[o] = pr + dr - pr * dr;
                        buf[o + 1] = pg + dg - pg * dg;
                        buf[o + 2] = pb + db - pb * db;
                        buf[o + 3] = sa + da - sa * da;
                        break;
                    }
                    case 3: { // multiply
                        float inv = 1 - sa;
                        buf[o] = sr * sa * dr + sr * sa * (1 - da) + dr * inv;
                        buf[o + 1] = sg * sa * dg + sg * sa * (1 - da) + dg * inv;
                        buf[o + 2] = sb * sa * db + sb * sa * (1 - da) + db * inv;
                        buf[o + 3] = sa + da * inv;
                        break;
                    }
                    default: {
                        float inv = 1 - sa;
                        buf[o] = sr * sa + dr * inv;
                        buf[o + 1] = sg * sa + dg * inv;
                        buf[o + 2] = sb * sa + db * inv;
                        buf[o + 3] = sa + da * inv;
                        break;
                    }
                }
            }
        }
    }

    /** bilinear sample, non-premultiplied ARGB out */
    static int sample(Img im, double u, double v) {
        double x = u - 0.5, y = v - 0.5;
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        double fx = x - x0, fy = y - y0;
        float r = 0, g = 0, b = 0, a = 0;
        for (int j = 0; j < 2; j++) {
            for (int i = 0; i < 2; i++) {
                int xx = Math.min(im.width - 1, Math.max(0, x0 + i));
                int yy = Math.min(im.height - 1, Math.max(0, y0 + j));
                double wgt = (i == 0 ? 1 - fx : fx) * (j == 0 ? 1 - fy : fy);
                int p = im.argb[yy * im.width + xx];
                float pa = (p >>> 24) / 255f * (float) wgt;
                a += pa;
                r += ((p >> 16) & 0xFF) * pa;
                g += ((p >> 8) & 0xFF) * pa;
                b += (p & 0xFF) * pa;
            }
        }
        if (a <= 0) return 0;
        return (Math.round(a * 255) << 24) | (Math.round(r / a) << 16) | (Math.round(g / a) << 8) | Math.round(b / a);
    }

    // ------------------------------------------------------------------ helpers
    static int le32(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
    }

    static int le16(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
    }

    /** Minimal FlatBuffers table accessor. */
    static final class Fb {
        final byte[] d;
        final int pos, vt, vtSize;

        Fb(byte[] d, int pos) {
            this.d = d;
            this.pos = pos;
            this.vt = pos - le32(d, pos);
            this.vtSize = le16(d, vt);
        }

        static Fb root(byte[] d, int base) { return new Fb(d, base + le32(d, base)); }

        /** table referenced by a uoffset stored at p */
        static Fb at(byte[] d, int p) { return new Fb(d, p + le32(d, p)); }

        int field(int id) {
            int o = 4 + id * 2;
            if (o + 2 > vtSize) return 0;
            int off = le16(d, vt + o);
            return off == 0 ? 0 : pos + off;
        }

        int u8(int id, int def) { int f = field(id); return f == 0 ? def : d[f] & 0xFF; }

        int u16(int id, int def) { int f = field(id); return f == 0 ? def : le16(d, f); }

        int u32(int id, int def) { int f = field(id); return f == 0 ? def : le32(d, f); }

        /** start of vector elements (after length), or 0 */
        int vec(int id) {
            int f = field(id);
            if (f == 0) return 0;
            int v = f + le32(d, f);
            return v + 4;
        }

        String str(int id) {
            int f = field(id);
            if (f == 0) return null;
            int s = f + le32(d, f);
            int len = le32(d, s);
            return new String(d, s + 4, len, StandardCharsets.UTF_8);
        }

        Fb table(int id) {
            int f = field(id);
            return f == 0 ? null : new Fb(d, f + le32(d, f));
        }
    }
}
