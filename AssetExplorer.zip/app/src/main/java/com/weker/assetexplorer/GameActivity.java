package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.Battle;
import com.weker.assetexplorer.codec.BattleFx;
import com.weker.assetexplorer.codec.BattleScene;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Scene3d;
import com.weker.assetexplorer.codec.Specials;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * A battle against bots on any map, in any of the playable modes and dressed in any location theme, as one of the
 * newest (or hidden) brawlers with the gadget and star power picked before. Controls and look come from the game's
 * own ui.sc and font.
 */
public final class GameActivity extends Activity implements GLSurfaceView.Renderer {

    private final Handler main = new Handler(Looper.getMainLooper());
    private GameData gd;
    private Sfx sfx;
    private GLSurfaceView gl;
    private Hud hud;
    private TextView status;
    private final GlScene glScene = new GlScene();
    private final Object lock = new Object();
    private Battle battle;
    private BattleScene scene;
    private Battle.Fighter me;
    private Scene3d lastScene;
    private long lastNanos;
    private volatile float moveX, moveZ;
    /** {what, dx, dz}: 0 attack, 1 super, 2 gadget */
    private final ConcurrentLinkedQueue<float[]> fire = new ConcurrentLinkedQueue<>();
    private String skin, brawler, mapName, themeName;
    private Battle.Mode mode;
    private int gadgetPick, starPick, quality = 2;
    /** 0 easy, 1 normal, 2 hard bots; aim help 0 off, 1 light, 2 strong; shoot by itself */
    private int difficulty, assist = 2;
    private boolean autoFire;
    private long lastFrameNanos;
    private com.weker.assetexplorer.codec.ScLoader scLoader;
    /** an error the battle can't go on after: shown instead of a silent close */
    private volatile String fatal;
    private int errorStreak, errorTotal;
    private long lastErrorLog;
    /** the game's own control pictures (cut once from ui.sc), by name */
    private java.util.Map<String, Bitmap> pics = new java.util.HashMap<>();
    private boolean contextSeen;
    private GameDb.Brawler info;
    // game pictures
    private Bitmap gadgetIcon, hyperIcon;
    private BattleFx effects;
    /** damage of the last second, shown as "Урон в секунду" */
    private volatile int dps;
    private final java.util.ArrayDeque<long[]> dmgLog = new java.util.ArrayDeque<>();
    private int lastDamage;
    private Typeface font = Typeface.DEFAULT_BOLD;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        CrashLog.install(this);
        CrashLog.stage("бой: запуск");
        long vid = getIntent().getLongExtra("vid", -1);
        brawler = getIntent().getStringExtra("brawler");
        skin = getIntent().getStringExtra("skin");
        mapName = getIntent().getStringExtra("map");
        themeName = getIntent().getStringExtra("theme");
        gadgetPick = getIntent().getIntExtra("gadget", 1);
        quality = getIntent().getIntExtra("quality", 2);
        difficulty = Math.max(0, Math.min(2, getIntent().getIntExtra("difficulty", 0)));
        assist = Math.max(0, Math.min(2, getIntent().getIntExtra("assist", 2)));
        autoFire = getIntent().getBooleanExtra("autofire", false);
        starPick = getIntent().getIntExtra("star", 1);
        try {
            mode = Battle.Mode.valueOf(getIntent().getStringExtra("mode"));
        } catch (Exception e) {
            mode = Battle.Mode.GEM;
        }
        gd = GameData.get(this, vid);
        // the game's pictures stay packed (ASTC) all the way to the video card: nothing is unpacked into memory
        gd.assets.gpuTextures = true;
        sfx = new Sfx(gd);
        sfx.maxAtOnce = 10;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1E2230);
        gl = new GLSurfaceView(this);
        renderScale(gl, quality == 0 ? 600 : quality == 1 ? 900 : 1440);
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(new GlModelView.Chooser(quality == 2));
        gl.setRenderer(this);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        hud = new Hud(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        status = Ui.bold(this, "Загружаю карту…", 18, Ui.TEXT);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0xEE0F1A3A);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        new Thread(() -> {
            try {
                font = GameUi.font(gd);
                main.post(() -> status.setTypeface(font));
                // the game's own sticks and buttons, cut once out of ui.sc before anything else takes memory
                if (!UiPictures.done(gd)) {
                    main.post(() -> status.setText("Достаю картинки управления из игры…\n(один раз)"));
                    CrashLog.stage("бой: картинки интерфейса");
                    UiPictures.prepare(gd);
                }
                pics = UiPictures.load(gd, 320);
                CrashLog.stage("бой: таблицы и карта");
                main.post(() -> status.setText("Загружаю карту…"));
                GameDb db = gd.db;
                info = db.brawler(brawler);
                if (skin == null && info != null) skin = info.defaultSkin;
                Battle bt = new Battle(db, mode, mapName, themeName, System.nanoTime());
                bt.difficulty = difficulty;
                bt.onError = e -> CrashLog.survived("бой (кадр пропущен, игра идёт дальше)", e);
                bt.assist = assist == 0 ? 0 : (float) Math.toRadians(assist == 1 ? 8 : 16);
                Battle.Fighter f = bt.add(brawler, skin, 0, "me", info != null ? info.name.replace(" (скрыт)", "") : brawler, gadgetPick, starPick);
                bt.start();
                CrashLog.stage("бой: модели и текстуры");
                main.post(() -> status.setText("Загружаю бойцов…"));
                BattleScene sc = new BattleScene(bt, gd.assets);
                sc.gpu = true;
                sc.viewer = f;
                sc.preload();
                gd.forgetAll(); // characters.sc (faces) is big once parsed and isn't needed after this
                CrashLog.stage("бой: эффекты");
                // the effects are the game's own: its .sc files give the pictures (on the video card, as packed textures)
                // and the clips; a file is read from the disk by a background thread and its parts only when a clip needs them
                com.weker.assetexplorer.codec.ScLoader loader = new com.weker.assetexplorer.codec.ScLoader(name -> {
                    java.io.File fl = gd.file(name);
                    return fl == null ? null : com.weker.assetexplorer.codec.Sc2.parse(fl);
                });
                scLoader = loader;
                glScene.files = gd::read;
                BattleFx bfx = new BattleFx(bt, db, gd::read, null);
                bfx.fx.files = gd::file;
                bfx.fx.scFiles = loader;
                bfx.fx.maxParticles = quality == 0 ? 300 : quality == 1 ? 600 : 1000;
                bfx.dust = quality > 0;
                sc.effects = bfx;
                main.post(() -> status.setText("Готовлю эффекты…"));
                loader.blocking = true;
                try {
                    java.util.Set<String> seen = new java.util.HashSet<>();
                    for (Battle.Fighter x : bt.fighters) {
                        if (x.box || x.kit == null || !seen.add(x.kit.code)) continue;
                        try {
                            bfx.prewarm(x);
                        } catch (Throwable e) {
                            CrashLog.survived("эффекты бойца " + x.kit.code, e);
                        }
                    }
                } finally {
                    loader.blocking = false;
                }
                for (Battle.Fighter x : bt.fighters) if (!x.box) bt.fx.add(new Object[]{"spawn", x}); // everybody appears with the game's effect
                effects = bfx;
                sc.camX = f.x;
                sc.camZ = f.z;
                loadPictures();
                CrashLog.stage("бой");
                synchronized (lock) {
                    battle = bt;
                    scene = sc;
                    me = f;
                    lastNanos = 0;
                }
                main.post(() -> {
                    status.setVisibility(View.GONE);
                    if (info != null) sfx.play(info.voice.get("Появление"));
                    if (sc.actor(f.kit.skin) == null || sc.actor(f.kit.skin).model == null) {
                        android.widget.Toast.makeText(this, "Модели бойца нет в архиве — он показан тенью", android.widget.Toast.LENGTH_LONG).show();
                    }
                    if (loader.outOfMemory > 0) {
                        android.widget.Toast.makeText(this, "Не хватило памяти на часть эффектов — они не покажутся", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Throwable e) {
                CrashLog.survived("загрузка боя", e);
                final String why = e instanceof OutOfMemoryError ? "не хватило памяти" : String.valueOf(e.getMessage());
                main.post(() -> status.setText("Не удалось начать бой: " + why
                        + "\nНужны таблицы игры (maps.csv, characters.csv, skills.csv…) и 3D-модели в импортированном архиве.\nПодробности откроются при следующем запуске приложения."));
            }
        }, "cave-load").start();
    }

    /**
     * Draws the 3D at most 720 pixels high and lets the screen stretch it: on big phone screens that is most of the
     * speed (the interface on top stays sharp).
     */
    static void renderScale(GLSurfaceView v, int maxHeight) {
        android.util.DisplayMetrics dm = v.getResources().getDisplayMetrics();
        int w = Math.max(dm.widthPixels, dm.heightPixels), h = Math.min(dm.widthPixels, dm.heightPixels);
        if (h <= maxHeight + 40) return;
        float k = maxHeight / (float) h;
        v.getHolder().setFixedSize(Math.round(w * k), Math.round(h * k));
    }

    /**
     * The sticks are drawn by the game screen itself; only the gadget and hypercharge icons are pictures, taken from a
     * small PNG cache (ui.sc itself is far too big to open in a battle: then a drawn gear is shown instead).
     */
    private void loadPictures() {
        GameDb.Table cards = gd.db.table("cards.csv");
        int gadgets = 0;
        int size = Ui.dp(this, 96);
        for (String[] c : cards.rows) {
            if (!brawler.equals(cards.get(c, "Target"))) continue;
            String meta = cards.get(c, "MetaType");
            String file = GameDb.fileName(cards.get(c, "IconSWF")), ex = cards.get(c, "IconExportName");
            if (ex.isEmpty()) continue;
            if ("5".equals(meta) && ++gadgets == gadgetPick) gadgetIcon = icon(file.isEmpty() ? "ui.sc" : file, ex, size);
            if ("6".equals(meta)) hyperIcon = icon(file.isEmpty() ? "ui.sc" : file, ex, size);
        }
    }

    /** a card icon from the disk cache, cut out of its .sc file only the first time (not on low graphics) */
    private Bitmap icon(String file, String export, int size) {
        java.io.File dir = new java.io.File(gd.cacheDir(), "icons");
        java.io.File f = new java.io.File(dir, gd.vid + "_" + export.replaceAll("[^A-Za-z0-9_]", "_") + ".png");
        try {
            if (f.exists()) return android.graphics.BitmapFactory.decodeFile(f.getPath());
            // ui.sc takes about 220 MB once opened: in a battle it is never opened, the button is drawn instead
            java.io.File src = gd.file(file);
            if (src == null || src.length() > (quality == 2 ? 8_000_000L : 6_000_000L)) return null;
            Bitmap b = gd.export(file, export, size);
            if (b != null) {
                dir.mkdirs();
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) {
                    b.compress(Bitmap.CompressFormat.PNG, 100, o);
                }
            }
            return b;
        } catch (Throwable e) {
            gd.forget(file);
            return null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // the rest of the app sees files unpacked again, and the battle's memory is given back
        CrashLog.stage("меню");
        if (scLoader != null) {
            scLoader.shutdown();
            scLoader.forget();
        }
        gd.assets.gpuTextures = false;
        gd.assets.forgetTextures();
        gd.forgetAll();
        for (Bitmap b : pics.values()) if (b != null && !b.isRecycled()) b.recycle();
        pics.clear();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
        sfx.stopAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
        lastNanos = 0;
    }

    // ------------------------------------------------------------------ GL thread: step + draw
    @Override
    public void onSurfaceCreated(GL10 g, EGLConfig config) {
        try {
            glScene.init(); // a new GL context (also after the app was away): everything is sent to the video card again
            glScene.files = gd::read;
            contextSeen = true;
        } catch (RuntimeException e) {
            CrashLog.survived("OpenGL", e);
            main.post(() -> {
                status.setVisibility(View.VISIBLE);
                status.setText("OpenGL ES 2.0 недоступен: " + e.getMessage());
            });
        }
    }

    @Override
    public void onSurfaceChanged(GL10 g, int w, int h) {
        glScene.resize(w, h);
        if (Build.VERSION.SDK_INT >= 30) { // 60 frames a second even on a 120 Hz screen: steady, cool, and the game's own speed
            main.post(() -> {
                try {
                    gl.getHolder().getSurface().setFrameRate(quality == 0 ? 30f : 60f, android.view.Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
                } catch (Throwable ignored) {
                    // the limiter below does it
                }
            });
        }
    }

    @Override
    public void onDrawFrame(GL10 g) {
        // at most 60 (30 on low graphics) frames a second
        long period = quality == 0 ? 33_000_000L : 16_000_000L;
        long wait = period - (System.nanoTime() - lastFrameNanos);
        if (wait > 1_500_000L) {
            try {
                Thread.sleep(wait / 1_000_000L);
            } catch (InterruptedException ignored) {
                // draw now
            }
        }
        lastFrameNanos = System.nanoTime();
        Scene3d s = null;
        List<String> events = new ArrayList<>();
        synchronized (lock) {
            if (battle != null && fatal == null) {
                try {
                    long now = System.nanoTime();
                    // a long pause (the app was away, a slow frame) must not make the world jump: at most a tenth of a second
                    float dt = lastNanos == 0 ? 0 : Math.min(0.1f, (now - lastNanos) / 1e9f);
                    lastNanos = now;
                    float[] f;
                    while ((f = fire.poll()) != null) battle.use(me, (int) f[0], f[1], f[2]);
                    if (autoFire && me.alive && !hud.holding) {
                        Battle.Skill w = me.kit.weapon;
                        if (me.ammo >= 1 && battle.time - me.lastAttack >= w.cooldown && battle.nearestEnemy(me, w.range * 0.95f, false) != null) {
                            battle.use(me, 0, 0, 0);
                        }
                    }
                    battle.input(me, moveX, moveZ);
                    battle.step(dt);
                    if (effects != null) {
                        effects.consume();
                        effects.step(dt);
                        events.addAll(effects.fx.takeSounds());
                    }
                    scene.follow(dt);
                    events.addAll(battle.events);
                    battle.events.clear();
                    long ms = System.currentTimeMillis();
                    if (me.damageDone != lastDamage) {
                        dmgLog.add(new long[]{ms, me.damageDone - lastDamage});
                        lastDamage = me.damageDone;
                    }
                    while (!dmgLog.isEmpty() && ms - dmgLog.peekFirst()[0] > 1000) dmgLog.pollFirst();
                    int sum = 0;
                    for (long[] x : dmgLog) sum += x[1];
                    dps = sum;
                    s = scene.build();
                    lastScene = s;
                    errorStreak = 0;
                } catch (Throwable e) {
                    frameError("кадр боя", e);
                    s = lastScene; // the last good picture is shown again
                    battle.events.clear();
                }
            }
        }
        try {
            glScene.draw(s != null ? s : new Scene3d());
        } catch (Throwable e) {
            synchronized (lock) {
                frameError("рисование", e);
            }
        }
        if (!events.isEmpty()) main.post(() -> sounds(events));
        hud.postInvalidate();
    }

    /**
     * A frame that went wrong is skipped instead of closing the game; the reason is written down (rarely: not sixty
     * times a second). Out of memory first drops what can be read again, then lowers the effects.
     */
    private void frameError(String what, Throwable e) {
        errorStreak++;
        errorTotal++;
        long now = System.currentTimeMillis();
        if (now - lastErrorLog > 3000) {
            lastErrorLog = now;
            CrashLog.survived(what, e);
        }
        if (e instanceof OutOfMemoryError) {
            if (scLoader != null) scLoader.forget();
            gd.forgetAll();
            if (effects != null) effects.fx.maxParticles = Math.max(100, effects.fx.maxParticles / 2);
            System.gc();
        }
        if (errorStreak >= 30 || errorTotal >= 400) {
            fatal = "В бою произошла ошибка, продолжить нельзя.\nНажми «Выйти» — подробности откроются при следующем запуске приложения.";
            main.post(() -> {
                status.setText(fatal);
                status.setBackgroundColor(0xCC0F1A3A);
                status.setVisibility(View.VISIBLE);
            });
        }
    }

    private long lastVoice;

    private void sounds(List<String> events) {
        if (info == null || me == null) return;
        long now = System.currentTimeMillis();
        String mine = ":" + me.id;
        for (String e : events) {
            if (!e.contains(":")) { // an effect's own sound (shots, hits, explosions)
                sfx.effect(e);
                continue;
            }
            String voice = null;
            if (e.equals("ulti" + mine)) voice = info.voice.get("Супер");
            else if (e.equals("kill" + mine)) voice = info.voice.get("Победил врага");
            else if (e.equals("hit" + mine) && now - lastVoice > 2500) voice = info.voice.get("Получил урон");
            else if (e.equals("dead" + mine)) voice = info.voice.get("Поражение");
            else if (e.equals("respawn" + mine)) voice = info.voice.get("Появление");
            else if (e.equals("attack" + mine) && now - lastVoice > 4000 && Math.random() < 0.25) voice = info.voice.get("Атака");
            else if (e.startsWith("end:")) voice = battle.winner == me.team || battle.winner == me.id ? info.voice.get("Лидирует") : null;
            if (voice != null && sfx.play(voice) != null) lastVoice = now;
        }
    }

    // ------------------------------------------------------------------ HUD
    /**
     * The game's battle screen: sticks where the game puts them (measured from its screenshots, as parts of the
     * screen size), the super button with its skull, the gadget and hypercharge buttons, thin health bars with the
     * number above, ammo / super / hypercharge bars under yours, "Урон в секунду" and "Выйти".
     */
    final class Hud extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint grey = new Paint(Paint.FILTER_BITMAP_FLAG);
        int movePtr = -1;
        float moveCx, moveCy, moveX0, moveY0;
        int aimPtr = -1, aimWhat;
        /** a finger is on an attack / super / gadget stick (read by the battle thread) */
        volatile boolean holding;
        final RectF tmp = new RectF();
        final Path clip = new Path();
        boolean aimMoved;
        float aimCx, aimCy, aimDx, aimDy;
        long aimStart;

        Hud(Context c) {
            super(c);
            text.setTextAlign(Paint.Align.CENTER);
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(0);
            grey.setColorFilter(new ColorMatrixColorFilter(cm));
            grey.setAlpha(170);
        }

        /** ring radius of a stick: 14% of the screen height, like the game */
        float ring() { return getHeight() * 0.14f; }

        float moveHomeX() { return getWidth() * 0.1475f; }

        float moveHomeY() { return getHeight() * 0.77f; }

        float attackX() { return getWidth() * 0.8425f; }

        float attackY() { return getHeight() * 0.63f; }

        float ultiX() { return getWidth() * 0.715f; }

        float ultiY() { return getHeight() * 0.74f; }

        float itemX() { return getWidth() * 0.795f; }

        float itemY() { return getHeight() * 0.88f; }

        float hyperX() { return getWidth() * 0.65f; }

        float hyperY() { return getHeight() * 0.88f; }

        RectF exitRect() {
            float w = getWidth(), h = getHeight();
            return new RectF(w * 0.565f, h * 0.885f, w * 0.62f, h * 0.96f);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            int idx = e.getActionIndex();
            float R = ring();
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    float x = e.getX(idx), y = e.getY(idx);
                    int id = e.getPointerId(idx);
                    if (exitRect().contains(x, y)) {
                        finish();
                        return true;
                    }
                    if (me != null && !me.kit.hyperName.isEmpty() && Math.hypot(x - hyperX(), y - hyperY()) < R * 0.5f) {
                        fire.add(new float[]{3, 0, 0});
                        return true;
                    }
                    if (x < getWidth() * 0.45f && movePtr < 0) {
                        movePtr = id;
                        moveCx = moveX0 = x;
                        moveCy = moveY0 = y;
                    } else if (aimPtr < 0) {
                        int what = 0;
                        float cx = attackX(), cy = attackY();
                        if (Math.hypot(x - ultiX(), y - ultiY()) < R * 0.75f) {
                            what = 1;
                            cx = ultiX();
                            cy = ultiY();
                        } else if (me != null && me.kit.gadget != null && Math.hypot(x - itemX(), y - itemY()) < R * 0.6f) {
                            what = 2;
                            cx = itemX();
                            cy = itemY();
                        } else if (Math.hypot(x - cx, y - cy) > R * 1.4f) {
                            cx = x;
                            cy = y;
                        }
                        aimPtr = id;
                        aimStart = System.currentTimeMillis();
                        aimWhat = what;
                        aimCx = cx;
                        aimCy = cy;
                        aimDx = aimDy = 0;
                        aimMoved = false;
                    }
                    break;
                }
                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        int id = e.getPointerId(i);
                        float x = e.getX(i), y = e.getY(i);
                        if (id == movePtr) {
                            moveX0 = x;
                            moveY0 = y;
                            float dx = (x - moveCx) / R, dy = (y - moveCy) / R;
                            float l = (float) Math.sqrt(dx * dx + dy * dy);
                            if (l > 1) { // as in the game, the stick follows the finger when it goes past the ring
                                dx /= l;
                                dy /= l;
                                moveCx = x - dx * R;
                                moveCy = y - dy * R;
                            }
                            if (l < 0.12f) { // a small dead zone: a resting thumb doesn't walk
                                moveX = moveZ = 0;
                            } else {
                                moveX = dx;
                                moveZ = dy;
                            }
                        } else if (id == aimPtr) {
                            aimDx = (x - aimCx) / R;
                            aimDy = (y - aimCy) / R;
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (l > 0.2f) aimMoved = true;
                            if (l > 1) {
                                aimDx /= l;
                                aimDy /= l;
                            }
                        }
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL: {
                    int id = e.getPointerId(idx);
                    if (id == movePtr) {
                        movePtr = -1;
                        moveX = moveZ = 0;
                    } else if (id == aimPtr) {
                        aimPtr = -1;
                        if (a != MotionEvent.ACTION_CANCEL) {
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            Battle bt = battle;
                            if (bt != null && me != null && bt.mode == Battle.Mode.HOCKEY && bt.ballCarrier == me.id && aimWhat == 0) {
                                // the puck: aim gives the way, holding gives the strength
                                float ch = Math.max(0.2f, Math.min(1, (System.currentTimeMillis() - aimStart) / 1000f));
                                float dx = aimMoved && l > 0.05f ? aimDx / l : 0, dy = aimMoved && l > 0.05f ? aimDy / l : -1;
                                if (me.team == 0 && !aimMoved) dy = -1;
                                fire.add(new float[]{0, dx * ch, dy * ch});
                            } else if (!aimMoved || l > 0.2f) fire.add(new float[]{aimWhat, aimMoved ? aimDx : 0, aimMoved ? aimDy : 0});
                        }
                        aimDx = aimDy = 0;
                    }
                    break;
                }
                default:
                    break;
            }
            holding = aimPtr >= 0;
            invalidate();
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            text.setTypeface(font);
            synchronized (lock) {
                if (battle == null || lastScene == null) return;
                drawWorld(c, battle, scene, lastScene);
                drawControls(c, battle, me);
            }
        }

        private void drawWorld(Canvas c, Battle b, BattleScene sc, Scene3d s) {
            int w = getWidth(), h = getHeight();
            // aim guide: a light cone (or a circle where a throw lands), yellow for the super
            if (aimPtr >= 0 && aimMoved && me.alive && aimWhat <= 2) {
                Battle.Skill sk = aimWhat == 0 ? me.kit.weapon : aimWhat == 1 ? me.kit.ulti : me.kit.gadget;
                if (sk != null) {
                    float ang = (float) Math.atan2(aimDx, aimDy);
                    float len = (float) Math.min(1, Math.hypot(aimDx, aimDy));
                    Path path = new Path();
                    if (sk.kind == Battle.Kind.LOB || sk.kind == Battle.Kind.SUMMON || sk.kind == Battle.Kind.JUMP) {
                        float tx = me.x + (float) Math.sin(ang) * sk.range * len, tz = me.z + (float) Math.cos(ang) * sk.range * len;
                        float rad = Math.max(0.8f, sk.areaRadius);
                        for (int i = 0; i <= 24; i++) {
                            double t = Math.PI * 2 * i / 24;
                            float[] q = s.project(tx + (float) Math.cos(t) * rad, 0.05f, tz + (float) Math.sin(t) * rad, w, h);
                            if (i == 0) path.moveTo(q[0], q[1]);
                            else path.lineTo(q[0], q[1]);
                        }
                    } else {
                        float half = (float) Math.toRadians(Math.max(4, Math.min(170, sk.spread / 2f + 2)));
                        float[] a0 = s.project(me.x, 0.05f, me.z, w, h);
                        path.moveTo(a0[0], a0[1]);
                        for (int i = 0; i <= 12; i++) {
                            float t = ang - half + 2 * half * i / 12f;
                            float[] q = s.project(me.x + (float) Math.sin(t) * sk.range, 0.05f, me.z + (float) Math.cos(t) * sk.range, w, h);
                            path.lineTo(q[0], q[1]);
                        }
                    }
                    path.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(aimWhat == 1 ? 0x66FFD23A : aimWhat == 2 ? 0x6668E05A : 0x66FFFFFF);
                    c.drawPath(path, p);
                }
            }
            for (Battle.Fighter f : b.fighters) {
                if (!f.alive || f.critter || (f != me && !b.visibleTo(f, me))) continue;
                bar(c, s, sc, f, w, h);
            }
            // Duo's question: the answers over their circles
            if (b.quizAnswers != null) {
                text.setTextSize(h * 0.04f);
                for (int i = 0; i < 3; i++) {
                    float[] q = s.project(b.quizX[i], 0.1f, b.quizZ[i], w, h);
                    boolean here = me.alive && com.weker.assetexplorer.codec.Quiz.zoneAt(b, me.x, me.z) == i;
                    GameUi.outlined(c, b.quizAnswers[i], q[0], q[1], text, here ? 0xFF7CFF4A : 0xFFFFFFFF, h * 0.008f);
                }
            }
            float th = h * 0.032f;
            text.setTextSize(th);
            for (Battle.Popup pp : b.popups) {
                float[] q = s.project(pp.x, 2.0f + pp.age * 0.9f, pp.z, w, h);
                text.setAlpha((int) (255 * Math.max(0, 1 - pp.age / 1.1f)));
                GameUi.outlined(c, pp.text, q[0], q[1], text, pp.color, th * 0.22f);
            }
            text.setAlpha(255);
            if (!me.alive) {
                text.setTextSize(h * 0.05f);
                String t = b.respawnTime < 0 || b.over ? (b.over ? "" : "ТЫ ВЫБЫЛ — смотришь за другими")
                        : String.format(Locale.ROOT, "ВОЗРОЖДЕНИЕ ЧЕРЕЗ %d", (int) Math.ceil(Math.max(0, me.respawnIn)));
                if (!t.isEmpty()) GameUi.outlined(c, t, w / 2f, h * 0.4f, text, 0xFFFFFFFF, h * 0.009f);
            }
        }

        /** as in the game: number above a thin bar; for you also the name, ammo, super and hypercharge bars */
        private void bar(Canvas c, Scene3d s, BattleScene sc, Battle.Fighter f, int w, int h) {
            float[] q = s.project(f.x, sc.headHeight(f), f.z, w, h);
            boolean mine = f == me;
            float bw = h * (mine ? 0.1f : f.maxHp >= 50000 ? 0.1f : 0.085f), bh = h * 0.012f, o = h * 0.0035f;
            // everything sits above the head: under the bar only your ammo / super / hypercharge strips
            float below = mine ? h * (0.011f + 0.008f + (f.kit.hyperName.isEmpty() ? 0 : 0.008f)) + o * 8 : 0;
            float x = q[0] - bw / 2, y = q[1] - bh - below;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF22223A);
            c.drawRoundRect(new RectF(x - o, y - o, x + bw + o, y + bh + o), bh, bh, p);
            float part = Math.max(0, Math.min(1, f.hp / f.maxHp));
            p.setColor(mine ? 0xFF5BE04B : f.team == me.team ? 0xFF3D9BFF : 0xFFE5333B);
            c.drawRoundRect(new RectF(x, y, x + Math.max(bh, bw * part), y + bh), bh / 2, bh / 2, p);
            p.setColor(mine ? 0x66FFFFFF : 0x44FFFFFF);
            c.drawRoundRect(new RectF(x + bh * 0.3f, y + bh * 0.15f, x + Math.max(bh, bw * part) - bh * 0.3f, y + bh * 0.45f), bh / 4, bh / 4, p);
            float th = h * 0.022f;
            text.setTextSize(th);
            GameUi.outlined(c, String.valueOf((int) Math.ceil(f.hp)), q[0], y - o * 1.5f, text, 0xFFFFFFFF, th * 0.2f);
            if (!mine) return;
            text.setTextSize(h * 0.025f);
            GameUi.outlined(c, f.name, q[0], y - th - o * 2, text, 0xFF63E356, h * 0.005f);
            float yy = y + bh + o * 2.5f;
            int max = f.kit.weapon.maxCharge;
            float gap = h * 0.003f, sw = (bw - gap * (max - 1)) / max, ah = h * 0.011f;
            for (int i = 0; i < max; i++) {
                float fill = Math.max(0, Math.min(1, f.ammo - i));
                float ax = x + i * (sw + gap);
                p.setColor(0xFF22223A);
                c.drawRoundRect(new RectF(ax - o * 0.6f, yy - o * 0.6f, ax + sw + o * 0.6f, yy + ah + o * 0.6f), ah / 3, ah / 3, p);
                p.setColor(fill >= 1 ? 0xFFFF8A1C : 0xFF8C4E1A);
                if (fill > 0) c.drawRoundRect(new RectF(ax, yy, ax + sw * fill, yy + ah), ah / 3, ah / 3, p);
            }
            yy += ah + o * 2.2f;
            float sh = h * 0.008f;
            p.setColor(0xFF22223A);
            c.drawRoundRect(new RectF(x - o * 0.6f, yy - o * 0.6f, x + bw + o * 0.6f, yy + sh + o * 0.6f), sh, sh, p);
            p.setColor(0xFFFFD02A);
            if (f.superCharge > 0) c.drawRoundRect(new RectF(x, yy, x + bw * Math.min(1, f.superCharge), yy + sh), sh / 2, sh / 2, p);
            if (!f.kit.hyperName.isEmpty()) {
                yy += sh + o * 1.8f;
                p.setColor(0xFF22223A);
                c.drawRoundRect(new RectF(x - o * 0.6f, yy - o * 0.6f, x + bw + o * 0.6f, yy + sh + o * 0.6f), sh, sh, p);
                p.setColor(f.hyperUntil > b().time ? 0xFFFF4FD8 : 0xFFE0337A);
                float hp = f.hyperUntil > b().time ? (f.hyperUntil - b().time) / 5f : f.hyper;
                if (hp > 0) c.drawRoundRect(new RectF(x, yy, x + bw * Math.min(1, hp), yy + sh), sh / 2, sh / 2, p);
            }
        }

        Battle b() {
            return battle;
        }

        private void drawControls(Canvas c, Battle b, Battle.Fighter f) {
            int w = getWidth(), h = getHeight();
            float R = ring();
            modePanel(c, b, f, w, h);
            // movement stick: home place when idle, under the finger when held
            float mcx = movePtr >= 0 ? moveCx : moveHomeX(), mcy = movePtr >= 0 ? moveCy : moveHomeY();
            float mdx = 0, mdy = 0;
            if (movePtr >= 0) {
                mdx = moveX0 - moveCx;
                mdy = moveY0 - moveCy;
                float l = (float) Math.hypot(mdx, mdy);
                if (l > R) {
                    mdx = mdx / l * R;
                    mdy = mdy / l * R;
                }
            }
            stick(c, mcx, mcy, mdx, mdy, R, R * 0.46f, movePtr >= 0, 0xFF3D8BFF, false, false, "virtuastick_move_bg", "virtuastick_move_stick");
            // attack: tap shoots at the nearest enemy, drag aims, back to the middle cancels
            boolean aA = aimPtr >= 0 && aimWhat == 0;
            boolean cancel = aimPtr >= 0 && aimMoved && Math.hypot(aimDx, aimDy) < 0.2f;
            stick(c, aA ? aimCx : attackX(), aA ? aimCy : attackY(), aA ? aimDx * R : 0, aA ? aimDy * R : 0,
                    R, R * 0.46f, aA, 0xFFFF4B3E, f.ammo < 1, aA && cancel, "virtuastick_attack_bg", "virtuastick_attack_stick");
            // super: the yellow skull button, grey with a filling ring while it charges
            boolean ready = f.superCharge >= 1;
            boolean aU = aimPtr >= 0 && aimWhat == 1;
            float ub = R * 0.5f;
            float ux = ultiX() + (aU ? aimDx * (R * 0.95f - ub * 0.2f) : 0), uy = ultiY() + (aU ? aimDy * (R * 0.95f - ub * 0.2f) : 0);
            Bitmap uBlue = bmp("ulti_stick_0"), uYellow = bmp("ulti_stick_1"), uBall = bmp("ulti_stick_2"), uSkull = bmp("button_ulti_skull_0");
            if (uBlue != null && uYellow != null) {
                // the game's super button: blue with its skull while it charges, yellow when ready, a glowing ball on its ring while aimed
                Bitmap uBg = bmp("virtuastick_ulti_bg_" + (aU ? 1 : 0));
                if (uBg != null && (aU || ready)) put(c, uBg, ultiX(), ultiY(), R * 0.95f, p);
                if (aU && uBall != null) {
                    put(c, uBall, ux, uy, ub * 0.9f, p);
                    if (cancel) cross(c, ux, uy, ub * 0.9f);
                } else {
                    put(c, ready ? uYellow : uBlue, ultiX(), ultiY(), ub * 1.05f, p);
                    if (ready && uSkull != null) putRound(c, uSkull, ultiX(), ultiY(), ub * 0.8f, p);
                }
            } else {
                if (aU) ring(c, ultiX(), ultiY(), R * 0.95f, 0xFFFFC21F, true);
                knob(c, ux, uy, ub, ready ? 0xFFFFC21F : 0xFF8A8A92, aU || ready, aU && cancel);
                skull(c, ux, uy, ub * 0.62f, ready ? 0xFFFFC21F : 0xFF8A8A92, ready ? 0xFF4A2A06 : 0xFF505058);
            }
            if (!ready) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(h * 0.011f);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setColor(0xFFFFC21F);
                c.drawArc(new RectF(ultiX() - ub * 1.18f, ultiY() - ub * 1.18f, ultiX() + ub * 1.18f, ultiY() + ub * 1.18f), -90, 360 * f.superCharge, false, p);
                p.setStyle(Paint.Style.FILL);
            }
            // gadget: green button with this brawler's gadget icon and how many are left
            if (f.kit.gadget != null) {
                boolean aG = aimPtr >= 0 && aimWhat == 2;
                float gb = R * 0.34f;
                float gx = itemX() + (aG ? aimDx * R * 0.6f : 0), gy = itemY() + (aG ? aimDy * R * 0.6f : 0);
                boolean has = f.gadgets > 0;
                Bitmap gBase = bmp("item_base_stick_" + (has ? 1 : 0)), gBall = bmp("item_base_stick_2"), gBg = bmp("virtuastick_item_bg_" + (aG ? 1 : 0));
                if (gBase != null) {
                    // the game's green gadget button (dark when there is none left), its ring and ball while aimed
                    gb = R * 0.4f;
                    gx = itemX() + (aG ? aimDx * R * 0.6f : 0);
                    gy = itemY() + (aG ? aimDy * R * 0.6f : 0);
                    if (aG && gBg != null) put(c, gBg, itemX(), itemY(), R * 0.72f, p);
                    put(c, aG && gBall != null ? gBall : gBase, gx, gy, gb * 1.05f, p);
                    if (aG && cancel) cross(c, gx, gy, gb);
                    if (gadgetIcon != null && !(aG && gBall != null)) {
                        float gi = gb * 0.62f;
                        c.drawBitmap(gadgetIcon, null, new RectF(gx - gi, gy - gi, gx + gi, gy + gi), has ? p : grey);
                    }
                } else {
                    if (aG) ring(c, itemX(), itemY(), R * 0.6f + gb * 0.4f, 0xFF5BE04B, true);
                    knob(c, gx, gy, gb, has ? 0xFF4CC93E : 0xFF7A7A82, has, aG && cancel);
                    if (gadgetIcon != null) {
                        float gi = gb * 0.78f;
                        c.drawBitmap(gadgetIcon, null, new RectF(gx - gi, gy - gi, gx + gi, gy + gi), has ? p : grey);
                    } else {
                        gear(c, gx, gy, gb * 0.55f, has ? 0xFFFFFFFF : 0xFFCCCCCC);
                    }
                }
                text.setTextSize(h * 0.028f);
                GameUi.outlined(c, String.valueOf(f.gadgets), gx + gb * 0.85f, gy + gb * 1.0f, text, 0xFFFFFFFF, h * 0.005f);
            }
            // hypercharge
            if (!f.kit.hyperName.isEmpty()) {
                boolean on = f.hyper >= 1 || f.hyperUntil > b.time;
                float hb = R * 0.5f;
                Bitmap oc = bmp("overcharge_button_0");
                float hi = hb * 0.7f;
                if (oc != null) {
                    // the game's glowing purple button; the brawler's own hypercharge picture on it
                    put(c, oc, hyperX(), hyperY(), hb * 1.25f, on ? p : grey);
                    if (hyperIcon != null) put(c, hyperIcon, hyperX(), hyperY(), hi * 0.8f, on ? p : grey);
                } else {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(on ? 0xFF7A1FD0 : 0xFF55505E);
                    c.drawCircle(hyperX(), hyperY(), hb * 0.92f, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(h * 0.006f);
                    p.setColor(on ? 0xFFE7B8FF : 0xFF999999);
                    c.drawCircle(hyperX(), hyperY(), hb * 0.92f, p);
                    p.setStyle(Paint.Style.FILL);
                    if (hyperIcon != null) c.drawBitmap(hyperIcon, null, new RectF(hyperX() - hi, hyperY() - hi, hyperX() + hi, hyperY() + hi), on ? p : grey);
                    else {
                        p.setColor(on ? 0xFFB040FF : 0xFF666666);
                        c.drawCircle(hyperX(), hyperY(), hb * 0.8f, p);
                    }
                }
                if (f.hyper < 1 && f.hyperUntil <= b.time) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(h * 0.01f);
                    p.setColor(0xFFD050FF);
                    c.drawArc(new RectF(hyperX() - hb, hyperY() - hb, hyperX() + hb, hyperY() + hb), -90, 360 * f.hyper, false, p);
                    p.setStyle(Paint.Style.FILL);
                }
            }
            // "Выйти", like the game's translucent box
            RectF ex = exitRect();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x88555570);
            c.drawRoundRect(ex, h * 0.01f, h * 0.01f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(h * 0.003f);
            p.setColor(0xCCFFFFFF);
            c.drawRoundRect(ex, h * 0.01f, h * 0.01f, p);
            p.setStyle(Paint.Style.FILL);
            text.setTextSize(h * 0.03f);
            GameUi.outlined(c, "Выйти", ex.centerX(), ex.centerY() + h * 0.011f, text, 0xFFFFFFFF, h * 0.005f);
        }

        /** the top of the screen: time, score of the mode, the boss's health, the round, messages */
        private void modePanel(Canvas c, Battle b, Battle.Fighter f, int w, int h) {
            float th = h * 0.045f;
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(th);
            float left = b.timeLimit - b.roundTime;
            if (b.timeLimit < 9000 && !b.over) {
                int sec = Math.max(0, (int) Math.ceil(left));
                GameUi.outlined(c, String.format(Locale.ROOT, "%d:%02d", sec / 60, sec % 60), w / 2f, h * 0.07f, text, 0xFFFFFFFF, h * 0.007f);
            }
            String line = null;
            if (b.mode == Battle.Mode.TRAINING) { // the cave: damage per second, top right, as in the game
                text.setTextAlign(Paint.Align.RIGHT);
                text.setTextSize(h * 0.03f);
                GameUi.outlined(c, String.valueOf(dps), w * 0.985f, h * 0.1f, text, 0xFF56B4FF, h * 0.006f);
                float vw = text.measureText(String.valueOf(dps));
                GameUi.outlined(c, "Урон в секунду:", w * 0.985f - vw - h * 0.05f, h * 0.1f, text, 0xFFFFFFFF, h * 0.006f);
                text.setTextAlign(Paint.Align.CENTER);
            }
            switch (b.mode) {
                case GEM:
                    line = b.score[0] + "  💎  " + b.score[1];
                    if (b.gemCountdownTeam >= 0) line += String.format(Locale.ROOT, "   (%d)", (int) Math.ceil(Math.max(0, b.gemCountdown)));
                    break;
                case BALL: case HOCKEY: case BOUNTY: case KNOCKOUT:
                    line = b.score[0] + "  :  " + b.score[1];
                    break;
                case SHOWDOWN: {
                    int n = 0;
                    for (Battle.Fighter o : b.fighters) if (o.alive && !o.pet && !o.box) n++;
                    line = "Осталось бойцов: " + n;
                    break;
                }
                case HIDE:
                    line = "Раунд " + b.round + " · " + (f.hunter ? "ТЫ ВОДИШЬ" : "ПРЯЧЬСЯ") + " · очки: " + f.points;
                    break;
                case BOSS: {
                    Battle.Fighter boss = null;
                    for (Battle.Fighter o : b.fighters) if (o.boss) boss = o;
                    line = "Этап " + b.stage;
                    if (boss != null && boss.alive) {
                        float bw = w * 0.4f, bh = h * 0.028f, x = (w - bw) / 2, y = h * 0.13f;
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(0xFF22223A);
                        c.drawRoundRect(new RectF(x - 4, y - 4, x + bw + 4, y + bh + 4), bh, bh, p);
                        p.setColor(0xFFE5333B);
                        c.drawRoundRect(new RectF(x, y, x + bw * Math.max(0, boss.hp / boss.maxHp), y + bh), bh / 2, bh / 2, p);
                        text.setTextSize(h * 0.026f);
                        GameUi.outlined(c, boss.name + "  " + (int) Math.ceil(boss.hp), w / 2f, y + bh * 0.85f, text, 0xFFFFFFFF, h * 0.004f);
                        text.setTextSize(th);
                    }
                    break;
                }
                default:
                    break;
            }
            if (b.quizQuestion != null) {
                float y = h * 0.27f;
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xCC1E2A10);
                c.drawRoundRect(new RectF(w * 0.12f, y - h * 0.06f, w * 0.88f, y + h * 0.05f), h * 0.02f, h * 0.02f, p);
                text.setTextSize(h * 0.036f);
                GameUi.outlined(c, b.quizQuestion, w / 2f, y, text, 0xFF9BFF4A, h * 0.006f);
                text.setTextSize(h * 0.028f);
                GameUi.outlined(c, String.format(Locale.ROOT, "Встань в круг с верным ответом · %d", (int) Math.ceil(Math.max(0, b.quizUntil - b.time))),
                        w / 2f, y + h * 0.04f, text, 0xFFFFFFFF, h * 0.005f);
            }
            if (line != null) {
                text.setTextSize(h * 0.035f);
                GameUi.outlined(c, line, w / 2f, h * 0.115f + (b.mode == Battle.Mode.BOSS ? h * 0.07f : 0), text, 0xFFFFE14D, h * 0.006f);
            }
            if (Specials.isVinceCode(f.kit.code)) {
                text.setTextAlign(Paint.Align.LEFT);
                text.setTextSize(h * 0.035f);
                GameUi.outlined(c, "Мотыльки: " + f.moths, w * 0.02f, h * 0.08f, text, 0xFFB8F05A, h * 0.006f);
                text.setTextAlign(Paint.Align.CENTER);
            }
            if (b.messageUntil > 0 && b.message != null && !b.message.isEmpty()) {
                text.setTextSize(b.over ? h * 0.07f : h * 0.045f);
                GameUi.outlined(c, b.message, w / 2f, h * (b.over ? 0.42f : 0.3f), text, 0xFFFFFFFF, h * 0.009f);
                if (b.over) {
                    text.setTextSize(h * 0.032f);
                    GameUi.outlined(c, "Нажми «Выйти», чтобы вернуться", w / 2f, h * 0.5f, text, 0xFFDDDDDD, h * 0.006f);
                }
            }
            // Super Hockey: the charge while holding the attack with the puck
            if (aimPtr >= 0 && aimWhat == 0 && b.mode == Battle.Mode.HOCKEY && b.ballCarrier == f.id) {
                float ch = Math.min(1, (System.currentTimeMillis() - aimStart) / 1000f);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(h * 0.014f);
                p.setColor(ch >= 0.95f ? 0xFFFF4040 : 0xFFFFD02A);
                float R = ring() * 1.1f;
                c.drawArc(new RectF(aimCx - R, aimCy - R, aimCx + R, aimCy + R), -90, 360 * ch, false, p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        /** one of the game's pictures (cut from ui.sc), or null */
        private Bitmap bmp(String key) {
            return pics.get(key);
        }

        /** a picture drawn into a box of half-size r around (cx, cy) */
        private void put(Canvas c, Bitmap b, float cx, float cy, float r, Paint paint) {
            tmp.set(cx - r, cy - r, cx + r, cy + r);
            c.drawBitmap(b, null, tmp, paint);
        }

        /** the same, cut to a circle (the super's skull is a square picture) */
        private void putRound(Canvas c, Bitmap b, float cx, float cy, float r, Paint paint) {
            c.save();
            clip.reset();
            clip.addCircle(cx, cy, r * 0.98f, Path.Direction.CW);
            c.clipPath(clip);
            put(c, b, cx, cy, r, paint);
            c.restore();
        }

        /** one of the game's sticks: its picture (dim at rest, bright under the finger), else a drawn ring and knob */
        private void stick(Canvas c, float cx, float cy, float dx, float dy, float rb, float rk, boolean active, int color, boolean off, boolean cancel,
                           String bg, String knob) {
            Bitmap b = bmp(bg + (active ? "_1" : "_0")), k = bmp(knob + (active ? "_1" : "_0"));
            if (b != null && k != null) {
                put(c, b, cx, cy, rb, p);
                put(c, k, cx + dx, cy + dy, rk * 1.1f, off ? grey : p);
                if (cancel) cross(c, cx + dx, cy + dy, rk);
                return;
            }
            ring(c, cx, cy, rb, off ? 0xFF8A8A92 : color, active);
            knob(c, cx + dx, cy + dy, rk, off ? 0xFF8A8A92 : color, active, cancel);
        }

        /** the red cross over a knob that, let go, would cancel */
        private void cross(Canvas c, float x, float y, float r) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(r * 0.18f);
            p.setColor(0xFFFF3B3B);
            float k = r * 0.38f;
            c.drawLine(x - k, y - k, x + k, y + k, p);
            c.drawLine(x - k, y + k, x + k, y - k, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void ring(Canvas c, float cx, float cy, float r, int color, boolean active) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(active ? 0x40000000 : 0x26000000);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(r * 0.05f);
            p.setColor((color & 0x00FFFFFF) | (active ? 0xD0000000 : 0x80000000));
            c.drawCircle(cx, cy, r - r * 0.025f, p);
            p.setStyle(Paint.Style.FILL);
        }

        /** a round game button: dark edge underneath, the colour, a light shine on top; a red cross when it would cancel */
        private void knob(Canvas c, float x, float y, float r, int color, boolean active, boolean cancel) {
            int a = active ? 0xFF000000 : 0xC8000000;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x55000000);
            c.drawCircle(x, y + r * 0.12f, r * 1.04f, p);
            p.setColor(shade(color, 0.55f) & 0x00FFFFFF | a);
            c.drawCircle(x, y, r, p);
            p.setColor(color & 0x00FFFFFF | a);
            c.drawCircle(x, y - r * 0.06f, r * 0.86f, p);
            p.setColor(active ? 0x55FFFFFF : 0x33FFFFFF);
            c.drawOval(new RectF(x - r * 0.55f, y - r * 0.78f, x + r * 0.55f, y - r * 0.28f), p);
            if (cancel) cross(c, x, y, r);
        }

        private int shade(int c, float k) {
            return 0xFF000000 | ((int) (((c >> 16) & 255) * k) << 16) | ((int) (((c >> 8) & 255) * k) << 8) | (int) ((c & 255) * k);
        }

        /** the super's skull: round head, jaw, two eyes and a nose (dark: eyes and teeth, light: the skull) */
        private void skull(Canvas c, float x, float y, float r, int dark, int light) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(light);
            c.drawCircle(x, y - r * 0.12f, r * 0.78f, p);
            c.drawRoundRect(new RectF(x - r * 0.48f, y + r * 0.2f, x + r * 0.48f, y + r * 0.82f), r * 0.18f, r * 0.18f, p);
            p.setColor(dark);
            c.drawCircle(x - r * 0.3f, y - r * 0.08f, r * 0.22f, p);
            c.drawCircle(x + r * 0.3f, y - r * 0.08f, r * 0.22f, p);
            Path nose = new Path();
            nose.moveTo(x, y + r * 0.14f);
            nose.lineTo(x - r * 0.1f, y + r * 0.32f);
            nose.lineTo(x + r * 0.1f, y + r * 0.32f);
            nose.close();
            c.drawPath(nose, p);
            p.setStrokeWidth(r * 0.07f);
            p.setStyle(Paint.Style.STROKE);
            for (int i = -1; i <= 1; i++) c.drawLine(x + i * r * 0.16f, y + r * 0.52f, x + i * r * 0.16f, y + r * 0.8f, p);
            p.setStyle(Paint.Style.FILL);
        }

        /** a simple gear, when the gadget's own icon isn't available */
        private void gear(Canvas c, float x, float y, float r, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            for (int i = 0; i < 8; i++) {
                double t = Math.PI * 2 * i / 8;
                c.drawCircle(x + (float) Math.cos(t) * r * 0.82f, y + (float) Math.sin(t) * r * 0.82f, r * 0.2f, p);
            }
            c.drawCircle(x, y, r * 0.78f, p);
            p.setColor(0xFF2E7D25);
            c.drawCircle(x, y, r * 0.3f, p);
        }
    }
}
