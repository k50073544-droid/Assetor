package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A map seen from above, the way the game's map maker draws it: one coloured square per tile of maps.csv.
 * Pure pixels (ARGB) so it works both on the phone and in desktop tests.
 */
public final class MapPlan {

    /** one map of one location: what the list shows */
    public static final class Entry {
        public String location, title, map, mode, modeTitle, theme;
        public boolean disabled;
        public int width, height;
    }

    /** every location that has a map, grouped by game mode in table order */
    public static Map<String, List<Entry>> byMode(GameDb db) {
        Map<String, List<Entry>> out = new LinkedHashMap<>();
        GameDb.Table loc = db.table("locations.csv");
        java.util.Set<String> maps = mapNames(db);
        for (String[] r : loc.rows) {
            String map = loc.get(r, "Map");
            if (map.isEmpty() || !maps.contains(map)) continue;
            Entry e = new Entry();
            e.location = r[0];
            e.map = map;
            e.mode = loc.get(r, "GameModeVariation");
            e.modeTitle = PatchNotes.modeName(db, e.mode);
            e.theme = loc.get(r, "LocationTheme");
            e.disabled = loc.flag(r, "Disabled");
            String tid = loc.get(r, "TID");
            String t = tid.isEmpty() ? "" : db.text(tid);
            e.title = t == null || t.isEmpty() || t.equals(tid) ? GameDb.nice(r[0]) : t;
            out.computeIfAbsent(e.modeTitle, k -> new ArrayList<>()).add(e);
        }
        return out;
    }

    static java.util.Set<String> mapNames(GameDb db) {
        java.util.Set<String> s = new java.util.HashSet<>();
        GameDb.Table t = db.table("maps.csv");
        for (String[] r : t.rows) {
            String m = t.get(r, "Map");
            if (!m.isEmpty()) s.add(m);
        }
        return s;
    }

    // ------------------------------------------------------------------ colours (map maker palette)
    static final int OPEN_A = 0xFFEBC596, OPEN_B = 0xFFE2B887;

    /** colour of a tile code; 0 = draw the floor */
    public static int tileColor(char c) {
        switch (c) {
            case 'M': return 0xFFB5651D;       // wall 1
            case 'X': return 0xFF8E4E17;       // wall 2
            case 'Y': return 0xFFC98B3C;       // crate
            case 'C': return 0xFFA0602A;       // barrel
            case 'T': return 0xFF9A7A4F;       // themed wall
            case 'B': return 0xFFD9A066;       // fragile
            case 'D': return 0xFF7FA35B;       // decoration (breaks on touch)
            case 'N': return 0xFF8C6239;       // fence
            case 'a': return 0xFFB79062;       // rope fence
            case 'I': case 'E': return 0xFF6E6E78; // unbreakable
            case 'J': return 0xFF2E2E36;       // out of the field
            case 'F': case 'R': return 0xFF4CAF50; // bush
            case 'W': case 'V': return 0xFF34A6EC; // water
            case 'x': return 0xFFE05050;       // damage
            case 'z': return 0xFF9C7BD6;       // slow
            case 'w': return 0xFF6FD0FF;       // fast
            case 'v': return 0xFFE07A3A;       // damage over time
            case 'o': return 0xFFFFC107;       // bouncer
            case 'S': return 0xFFF4F7FB;       // snow
            case 'q': return 0xFFBFE6FF;       // ice
            case '=': return 0xFF2E2E36;       // empty
            default:
                if (c >= 'À' && c <= 'Ë') return 0xFF7D7D86;
                return 0;
        }
    }

    /** circle drawn over a tile: spawns, goals, objectives */
    public static int markColor(char c) {
        switch (c) {
            case '1': return 0xFF2F8CFF;   // blue team spawn
            case '2': return 0xFFFF3B3B;   // red team spawn
            case '3': return 0xFF9C5CFF;   // extra spawns (duo / trio)
            case '4': return 0xFFFFD54F;   // power cube box
            case '6': return 0xFF66B2FF;   // blue goal
            case '7': return 0xFFFF7A7A;   // red goal
            case '8': return 0xFFE040FB;   // objective (safe, zone, mine…)
            case 'y': return 0xFF00E5A0;   // jump pad
            case 'L': case 'K': case 'O': case 'U': case 'P': case 'Z': case 'G': case 'H':
            case 'c': case 'd': case 'e': case 'f':
                return 0xFF00BCD4;          // teleports and other pairs
            default: return 0;
        }
    }

    /** a square under the tile (floor effects shown as pads in 3D) */
    public static int padColor(char c) {
        switch (c) {
            case 'x': case 'z': case 'w': case 'v': case 'S': case 'q': case 'o': return tileColor(c);
            default: return 0;
        }
    }

    /** what each colour means, for the legend under the plan */
    public static final String[][] LEGEND = {
            {"M", "Стена"}, {"Y", "Ящик"}, {"C", "Бочка"}, {"N", "Забор"}, {"I", "Неразрушаемое"},
            {"F", "Куст"}, {"W", "Вода"}, {"1", "Синие"}, {"2", "Красные"}, {"4", "Ящик с силой"},
            {"8", "Цель режима"}, {"6", "Ворота"}, {"y", "Прыжок"}, {"L", "Телепорт"},
            {"x", "Урон"}, {"z", "Замедление"}, {"w", "Ускорение"},
    };

    /** the mode's object in the middle when the map itself has none (gem mine, ball) */
    public static int centerMark(GameDb.MapData m, String mode) {
        String md = mode == null ? "" : mode.toLowerCase(java.util.Locale.ROOT);
        if (!md.contains("gem") && !md.contains("ball") && !md.contains("hockey")) return 0;
        for (char[] row : m.cells) for (char c : row) if (c == '8') return 0;
        return md.contains("gem") ? 0xFFE040FB : 0xFFFFFFFF;
    }

    public static int[] render(GameDb.MapData m, int px, String mode) {
        int[] out = render(m, px);
        int mark = centerMark(m, mode);
        if (mark != 0) {
            int w = m.width * px;
            float cx = m.width * px / 2f, cy = m.height * px / 2f, rr = px * 0.7f;
            for (int y = (int) (cy - rr - 1); y <= cy + rr + 1; y++) {
                for (int x = (int) (cx - rr - 1); x <= cx + rr + 1; x++) {
                    if (x < 0 || y < 0 || x >= w || y >= m.height * px) continue;
                    float d = (float) Math.hypot(x + 0.5f - cx, y + 0.5f - cy);
                    if (d <= rr) out[y * w + x] = d > rr - Math.max(1, px / 6f) ? 0xFF222222 : mark;
                }
            }
        }
        return out;
    }

    /** a picture of the map: {@code px} pixels per tile, ARGB, row by row */
    public static int[] render(GameDb.MapData m, int px) {
        int w = m.width * px, h = m.height * px;
        int[] out = new int[w * h];
        for (int r = 0; r < m.height; r++) {
            for (int c = 0; c < m.width; c++) {
                char code = m.cells[r][c];
                int floor = ((r + c) & 1) == 0 ? OPEN_A : OPEN_B;
                int col = tileColor(code);
                int mark = markColor(code);
                boolean block = col != 0 && code != 'F' && code != 'R' && code != 'W' && code != 'V' && padColor(code) == 0
                        && code != 'J' && code != '=';
                for (int y = 0; y < px; y++) {
                    int row = (r * px + y) * w + c * px;
                    for (int x = 0; x < px; x++) {
                        int v = col != 0 ? col : floor;
                        if (block && px >= 6 && (y == 0 || x == px - 1)) v = shade(v, 1.18f);
                        if (block && px >= 6 && (y == px - 1 || x == 0)) v = shade(v, 0.72f);
                        if ((code == 'F' || code == 'R') && px >= 6 && ((x + y * 3) % 5 == 0)) v = shade(v, 0.82f);
                        if (mark != 0) {
                            float dx = x + 0.5f - px / 2f, dy = y + 0.5f - px / 2f, rr = px * 0.42f;
                            float d = (float) Math.sqrt(dx * dx + dy * dy);
                            if (d <= rr) v = d > rr - Math.max(1, px / 8f) ? 0xFFFFFFFF : mark;
                        }
                        out[row + x] = v;
                    }
                }
            }
        }
        return out;
    }

    static int shade(int c, float k) {
        int r = Math.min(255, (int) (((c >> 16) & 255) * k));
        int g = Math.min(255, (int) (((c >> 8) & 255) * k));
        int b = Math.min(255, (int) ((c & 255) * k));
        return (c & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
