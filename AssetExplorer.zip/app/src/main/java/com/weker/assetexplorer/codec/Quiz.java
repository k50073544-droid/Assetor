package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.List;

/**
 * Mega Boss Duo's question (skill MegaBossDuoQuiz): the boss asks one of the game's own questions
 * (TID_QUIZ_DUO_n with TID_QUIZ_DUO_n_ANSWER_1..3, the first answer is right), three answer circles appear
 * around it, and when the time is up whoever stands outside the right one is hit (boss_duo_answer_right / _wrong /
 * _outside). If most of the team answered right, the boss is dazed for a moment.
 */
public final class Quiz {

    private Quiz() {}

    public static final float TIME = 7, RADIUS = 2.2f;

    /** the questions of this version's texts: {question, right, wrong, wrong} */
    static List<String[]> questions(GameDb db) {
        List<String[]> l = new ArrayList<>();
        for (int n = 1; n < 400; n++) {
            String q = db.text(String.format(java.util.Locale.ROOT, "TID_QUIZ_DUO_%02d", n));
            if (q == null) q = db.text("TID_QUIZ_DUO_" + n);
            if (q == null) {
                if (n > 20) break;
                continue;
            }
            String a1 = db.text("TID_QUIZ_DUO_" + n + "_ANSWER_1"), a2 = db.text("TID_QUIZ_DUO_" + n + "_ANSWER_2"), a3 = db.text("TID_QUIZ_DUO_" + n + "_ANSWER_3");
            if (a1 != null && a2 != null && a3 != null) l.add(new String[]{q, a1, a2, a3});
        }
        return l;
    }

    /** the boss starts a question (false when the texts have none) */
    static boolean start(Battle b, Battle.Fighter boss) {
        if (b.quizUntil > b.time) return false;
        if (b.quizBank == null) b.quizBank = questions(b.db);
        if (b.quizBank.isEmpty()) return false;
        String[] q = b.quizBank.get(b.rnd.nextInt(b.quizBank.size()));
        int[] order = {0, 1, 2};
        for (int i = 2; i > 0; i--) {
            int j = b.rnd.nextInt(i + 1);
            int t = order[i];
            order[i] = order[j];
            order[j] = t;
        }
        b.quizQuestion = q[0];
        b.quizAnswers = new String[3];
        b.quizX = new float[3];
        b.quizZ = new float[3];
        float base = (float) Math.atan2(b.width / 2f - boss.x, b.height / 2f - boss.z);
        for (int i = 0; i < 3; i++) {
            b.quizAnswers[i] = q[1 + order[i]];
            if (order[i] == 0) b.quizRight = i;
            // three circles in front of the boss, spread out, inside the field
            float a = base + (float) Math.toRadians(-55 + 55 * i);
            float x = boss.x + (float) Math.sin(a) * 5.5f, z = boss.z + (float) Math.cos(a) * 5.5f;
            float[] p = open(b, x, z);
            b.quizX[i] = p[0];
            b.quizZ[i] = p[1];
        }
        b.quizUntil = b.time + TIME;
        b.events.add("quiz:" + boss.id);
        b.message = "Вопрос от Duo!";
        b.messageUntil = 1.5f;
        // bots pick an answer: mostly the right one
        for (Battle.Fighter f : b.fighters) f.quizPick = b.rnd.nextFloat() < 0.75f ? b.quizRight : b.rnd.nextInt(3);
        return true;
    }

    static float[] open(Battle b, float x, float z) {
        x = Math.max(RADIUS, Math.min(b.width - RADIUS, x));
        z = Math.max(RADIUS, Math.min(b.height - RADIUS, z));
        for (int k = 0; k < 30 && b.collides(x, z, 0.5f); k++) {
            x += (b.width / 2f - x) * 0.15f;
            z += (b.height / 2f - z) * 0.15f;
        }
        return new float[]{x, z};
    }

    /** which circle a point is in, or -1 */
    public static int zoneAt(Battle b, float x, float z) {
        if (b.quizAnswers == null) return -1;
        for (int i = 0; i < 3; i++) if (Math.hypot(x - b.quizX[i], z - b.quizZ[i]) <= RADIUS) return i;
        return -1;
    }

    static void step(Battle b, float dt) {
        if (b.quizAnswers == null || b.quizUntil > b.time) return;
        // time is up
        Battle.Fighter boss = null;
        for (Battle.Fighter f : b.fighters) if (f.boss && f.alive) boss = f;
        int right = 0, all = 0;
        for (Battle.Fighter f : new ArrayList<>(b.fighters)) {
            if (!f.alive || f.boss || f.pet || f.box || f.team != 0) continue;
            all++;
            int z = zoneAt(b, f.x, f.z);
            if (z == b.quizRight) {
                right++;
                b.fx.add(new Object[]{"effect", "boss_duo_answer_right", f.x, f.z});
                continue;
            }
            b.fx.add(new Object[]{"effect", z < 0 ? "boss_duo_answer_outside" : "boss_duo_answer_wrong", f.x, f.z});
            int dmg = Math.round(1500 * Battle.POWER * b.bossDamage);
            if (boss != null) b.damage(boss, f, dmg, true);
            else b.hurt(null, f, dmg, 0xFFFF5050);
        }
        if (boss != null && all > 0 && right * 2 > all) {
            boss.stunUntil = b.time + 3;
            b.message = "Верно: " + b.quizAnswers[b.quizRight] + "! Duo в замешательстве";
        } else {
            b.message = "Правильный ответ: " + (b.quizAnswers[b.quizRight]);
        }
        b.messageUntil = 2.5f;
        b.events.add("quizEnd:" + right);
        b.quizAnswers = null;
        b.quizQuestion = null;
    }

    /** a teammate bot during a question walks to the circle it picked */
    static boolean thinkAlly(Battle b, Battle.Fighter f) {
        if (b.quizAnswers == null || f.team != 0 || f.boss || f.pet) return false;
        int i = Math.max(0, Math.min(2, f.quizPick));
        b.steer(f, b.quizX[i], b.quizZ[i], 0.6f);
        return true;
    }
}
