package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * "What changed in the update": compares the game tables of two versions and writes it the way patch notes
 * read — new brawlers, gadgets, star powers, hypercharges, skins, modes, maps, pins, music, and balance changes
 * (health, damage, range, reload… at power 11, with the card descriptions showing old → new values).
 */
public final class PatchNotes {

    public static final int NEW = 0, REMOVED = 1, CHANGED = 2;

    public static final class Entry {
        public int kind;
        public String title;
        /** detail lines; the first character is '+' (better), '-' (worse) or '~' (neither) */
        public final List<String> details = new ArrayList<>();
        /** the brawler it is about (for the portrait), may be null */
        public String brawler;
    }

    public static final class Section {
        public String title, icon;
        public final List<Entry> entries = new ArrayList<>();
    }

    public final List<Section> sections = new ArrayList<>();
    final GameDb a, b;

    PatchNotes(GameDb oldDb, GameDb newDb) {
        a = oldDb;
        b = newDb;
    }

    /** {@code oldDb} → {@code newDb} */
    public static PatchNotes diff(GameDb oldDb, GameDb newDb) {
        PatchNotes p = new PatchNotes(oldDb, newDb);
        p.brawlers();
        p.balance();
        p.cards();
        p.skins();
        p.modes();
        p.maps();
        p.cosmetics();
        p.music();
        p.texts();
        p.sections.removeIf(s -> s.entries.isEmpty());
        return p;
    }

    Section section(String title, String icon) {
        Section s = new Section();
        s.title = title;
        s.icon = icon;
        sections.add(s);
        return s;
    }

    static Entry entry(Section s, int kind, String title, String brawler) {
        Entry e = new Entry();
        e.kind = kind;
        e.title = title;
        e.brawler = brawler;
        s.entries.add(e);
        return e;
    }

    // ------------------------------------------------------------------ brawlers
    Map<String, GameDb.Brawler> byCode(GameDb db) {
        Map<String, GameDb.Brawler> m = new LinkedHashMap<>();
        for (GameDb.Brawler x : db.brawlers()) m.put(x.code, x);
        return m;
    }

    String brawlerName(String code) {
        GameDb.Brawler x = b.brawler(code);
        if (x == null) x = a.brawler(code);
        return x == null ? GameDb.nice(code) : x.name;
    }

    void brawlers() {
        Section s = section("Бойцы", "⭐");
        Map<String, GameDb.Brawler> o = byCode(a), n = byCode(b);
        for (GameDb.Brawler x : n.values()) {
            GameDb.Brawler old = o.get(x.code);
            if (old == null) {
                Entry e = entry(s, NEW, "Новый боец: " + x.name, x.code);
                if (!x.rarityName.isEmpty()) e.details.add("~Редкость: " + x.rarityName);
                BrawlerStats st = BrawlerStats.of(b, x.code);
                e.details.add("~Здоровье: " + st.hp);
                e.details.add("~Атака: " + st.attack.damageText() + ", дальность " + num(st.attack.range) + ", патронов " + st.attack.ammo);
                if (st.sup.damage > 0) e.details.add("~Супер: " + st.sup.damageText());
                for (String g : x.gadgets) e.details.add("~Гаджет: " + g);
                for (String g : x.starPowers) e.details.add("~Звёздная сила: " + g);
                if (x.hypercharge != null) e.details.add("~Гиперзаряд: " + x.hypercharge);
                if (x.skins.size() > 1) e.details.add("~Скинов сразу: " + (x.skins.size() - 1));
            } else if (old.hidden && !x.hidden) {
                entry(s, CHANGED, "Бойца открыли: " + x.name, x.code);
            } else if (!old.hidden && x.hidden) {
                entry(s, CHANGED, "Бойца скрыли: " + x.name, x.code);
            }
        }
        for (GameDb.Brawler x : o.values()) if (!n.containsKey(x.code)) entry(s, REMOVED, "Убран: " + x.name, null);
    }

    // ------------------------------------------------------------------ balance
    /** column → {label, how to show: 2 = ×2 (power 11), 3 = tiles, 1000 = seconds, 1 = as is, better: +1 higher / -1 lower / 0} */
    static final Object[][] CHAR_COLS = {
            {"Hitpoints", "Здоровье", 2, 1}, {"Speed", "Скорость", 1, 1}, {"AutoAttackDamage", "Урон автоатаки", 2, 1},
            {"UltiChargeMul", "Заряд супера от атак, %", 1, 1}, {"UltiChargeUltiMul", "Заряд супера от супера, %", 1, 1},
            {"OverchargeChargeMul", "Заряд гиперзаряда, %", 1, 1}, {"OverchargeSpeedPercent", "Гиперзаряд: скорость, %", 1, 1},
            {"OverchargeDamagePercent", "Гиперзаряд: урон, %", 1, 1}, {"OverchargeShieldPercent", "Гиперзаряд: щит, %", 1, 1},
            {"CollisionRadius", "Размер хитбокса", 1, 0}};
    static final Object[][] SKILL_COLS = {
            {"Damage", "урон", 2, 1}, {"NumBulletsInOneAttack", "снарядов", 1, 1}, {"CastingRange", "дальность", 3, 1},
            {"RechargeTime", "перезарядка, с", 1000, -1}, {"MaxCharge", "патронов", 1, 1}, {"Spread", "разброс", 1, 0},
            {"Cooldown", "задержка, с", 1000, -1}, {"MsBetweenAttacks", "между выстрелами, с", 1000, 0},
            {"ActiveTime", "длительность, с", 1000, 1}, {"ChargeSpeed", "скорость рывка", 1, 1}};
    static final Object[][] PROJ_COLS = {
            {"Speed", "скорость снаряда", 1, 1}, {"Radius", "ширина снаряда", 1, 1}};
    static final Object[][] AREA_COLS = {
            {"Damage", "урон по площади", 2, 1}, {"Radius", "радиус", 1, 1}, {"TimeMs", "время действия, с", 1000, 0}};

    void balance() {
        Section s = section("Баланс", "⚖");
        Map<String, GameDb.Brawler> o = byCode(a);
        for (GameDb.Brawler x : b.brawlers()) {
            if (!o.containsKey(x.code)) continue;
            Entry e = new Entry();
            e.kind = CHANGED;
            e.title = x.name;
            e.brawler = x.code;
            GameDb.Table ca = a.table("characters.csv"), cb = b.table("characters.csv");
            String[] ra = ca.row(x.code), rb = cb.row(x.code);
            if (ra == null || rb == null) continue;
            cols(e, "", ca, ra, cb, rb, CHAR_COLS);
            skill(e, "Атака", ca.get(ra, "WeaponSkill"), cb.get(rb, "WeaponSkill"));
            skill(e, "Супер", ca.get(ra, "UltimateSkill"), cb.get(rb, "UltimateSkill"));
            String ha = ca.get(ra, "OverchargedUltimateSkill"), hb = cb.get(rb, "OverchargedUltimateSkill");
            if (!hb.isEmpty()) skill(e, "Гиперсупер", ha.isEmpty() ? hb : ha, hb);
            // gadget / star power / hypercharge numbers (shown inside their descriptions)
            cardValues(e, x.code);
            if (!e.details.isEmpty()) s.entries.add(e);
        }
    }

    void skill(Entry e, String label, String na, String nb) {
        GameDb.Table ta = a.table("skills.csv"), tb = b.table("skills.csv");
        String[] ra = ta.row(na), rb = tb.row(nb);
        if (ra == null || rb == null) return;
        cols(e, label + ": ", ta, ra, tb, rb, SKILL_COLS);
        String pa = ta.get(ra, "Projectiles"), pb = tb.get(rb, "Projectiles");
        if (!pb.isEmpty()) {
            GameDb.Table qa = a.table("projectiles_logic.csv"), qb = b.table("projectiles_logic.csv");
            String[] xa = qa.row(pa.isEmpty() ? pb : pa), xb = qb.row(pb);
            if (xa != null && xb != null) {
                cols(e, label + ": ", qa, xa, qb, xb, PROJ_COLS);
                if (qb.has("Damage")) cols(e, label + ": ", qa, xa, qb, xb, new Object[][]{{"Damage", "урон снаряда", 2, 1}});
            }
        }
        String aa = ta.get(ra, "AreaEffectObject"), ab = tb.get(rb, "AreaEffectObject");
        if (!ab.isEmpty()) {
            GameDb.Table qa = a.table("area_effects_logic.csv"), qb = b.table("area_effects_logic.csv");
            String[] xa = qa.row(aa.isEmpty() ? ab : aa), xb = qb.row(ab);
            if (xa != null && xb != null) cols(e, label + ": ", qa, xa, qb, xb, AREA_COLS);
        }
    }

    void cols(Entry e, String prefix, GameDb.Table ta, String[] ra, GameDb.Table tb, String[] rb, Object[][] cols) {
        for (Object[] c : cols) {
            String col = (String) c[0];
            if (!ta.has(col) || !tb.has(col)) continue;
            String va = ta.get(ra, col), vb = tb.get(rb, col);
            if (va.equals(vb)) continue;
            Double da = parse(va), db = parse(vb);
            if (da == null && db == null) continue;
            double x = da == null ? 0 : da, y = db == null ? 0 : db;
            int how = (int) c[2], better = (int) c[3];
            String fa = show(x, how), fb = show(y, how);
            if (fa.equals(fb)) continue;
            char mark = better == 0 ? '~' : (y > x) == (better > 0) ? '+' : '-';
            String label = prefix.isEmpty() ? (String) c[1] : prefix + c[1];
            e.details.add(mark + cap(label) + ": " + fa + " → " + fb);
        }
    }

    static Double parse(String s) {
        if (s == null || s.isEmpty()) return null;
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    static String show(double v, int how) {
        switch (how) {
            case 2: return String.valueOf(Math.round(v * BrawlerStats.POWER));
            case 3: return num((float) (v / 3));
            case 1000: return num((float) (v / 1000));
            default: return num((float) v);
        }
    }

    static String num(float v) {
        if (Math.abs(v - Math.round(v)) < 0.001f) return String.valueOf(Math.round(v));
        String s = String.format(Locale.ROOT, "%.2f", v);
        while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s.replace('.', ',');
    }

    static String cap(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    static final String[] VALUE_COLS = {"Value", "Value2", "Value3", "Value4", "Value5", "Value6"};

    void cardValues(Entry e, String code) {
        GameDb.Table ta = a.table("cards.csv"), tb = b.table("cards.csv");
        for (String[] rb : tb.rows) {
            if (!code.equals(tb.get(rb, "Target"))) continue;
            String meta = tb.get(rb, "MetaType");
            if (!"4".equals(meta) && !"5".equals(meta) && !"6".equals(meta)) continue;
            String[] ra = ta.row(rb[0]);
            if (ra == null) continue;
            String[] va = new String[6], vb = new String[6];
            boolean changed = false;
            for (int i = 0; i < 6; i++) {
                va[i] = ta.has(VALUE_COLS[i]) ? ta.get(ra, VALUE_COLS[i]) : "";
                vb[i] = tb.has(VALUE_COLS[i]) ? tb.get(rb, VALUE_COLS[i]) : "";
                // a value that just disappeared was moved elsewhere by the developers, not a balance change
                if (vb[i].isEmpty()) va[i] = "";
                if (!va[i].equals(vb[i])) changed = true;
            }
            // gadget cooldown and uses live in accessories.csv
            String accDetail = null;
            if ("5".equals(meta)) {
                GameDb.Table aa = a.table("accessories.csv"), ab = b.table("accessories.csv");
                String[] xa = aa.row(ta.get(ra, "Skill")), xb = ab.row(tb.get(rb, "Skill"));
                if (xa != null && xb != null && !aa.get(xa, "Cooldown").equals(ab.get(xb, "Cooldown"))) {
                    Double ca = parse(aa.get(xa, "Cooldown")), cb = parse(ab.get(xb, "Cooldown"));
                    if (ca != null && cb != null) accDetail = (cb < ca ? '+' : '-') + "Перезарядка гаджета: " + num(ca.floatValue()) + " → " + num(cb.floatValue());
                }
            }
            if (!changed && accDetail == null) continue;
            String kind = "5".equals(meta) ? "Гаджет" : "4".equals(meta) ? "Звёздная сила" : "Гиперзаряд";
            String name = b.text(tb.get(rb, "TID"));
            String head = kind + " «" + (name != null ? GameDb.nice(name) : rb[0]) + "»";
            if (changed) {
                String desc = description(tb.get(rb, "TID"), va, vb);
                e.details.add("~" + head + ": " + (desc != null ? desc : valuesText(va, vb)));
            }
            if (accDetail != null) e.details.add(accDetail.charAt(0) + head + " — " + accDetail.substring(1));
        }
    }

    static String valuesText(String[] va, String[] vb) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            if (va[i].equals(vb[i])) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append("значение ").append(i + 1).append(": ").append(va[i].isEmpty() ? "—" : va[i]).append(" → ").append(vb[i].isEmpty() ? "—" : vb[i]);
        }
        return sb.toString();
    }

    /** the card's description with &lt;VALUEn&gt; filled in, changed numbers written as "old → new" */
    String description(String tid, String[] va, String[] vb) {
        if (tid == null || tid.isEmpty()) return null;
        String raw = b.ru.get(tid + "_DESC");
        if (raw == null) return null;
        String s = raw;
        for (int i = 6; i >= 1; i--) {
            String key = i == 1 ? "(<VALUE1>|<VALUE>)" : "<VALUE" + i + ">";
            String v = va[i - 1].equals(vb[i - 1]) ? vb[i - 1] : (va[i - 1].isEmpty() ? "—" : va[i - 1]) + " → " + vb[i - 1];
            s = s.replaceAll(key, java.util.regex.Matcher.quoteReplacement(v));
        }
        s = s.replaceAll("<[^>]*>", "").replace("\\n", " ").replace(' ', ' ').trim();
        if (!s.contains("→")) return null;
        return s;
    }

    // ------------------------------------------------------------------ new cards
    void cards() {
        Section s = section("Новые гаджеты, звёздные силы и гиперзаряды", "🔧");
        GameDb.Table ta = a.table("cards.csv"), tb = b.table("cards.csv");
        Map<String, GameDb.Brawler> o = byCode(a);
        for (String[] rb : tb.rows) {
            String meta = tb.get(rb, "MetaType");
            if (!"4".equals(meta) && !"5".equals(meta) && !"6".equals(meta)) continue;
            if (ta.row(rb[0]) != null) continue;
            String code = tb.get(rb, "Target");
            if (!o.containsKey(code)) continue; // a new brawler's cards are listed with the brawler
            String kind = "5".equals(meta) ? "Гаджет" : "4".equals(meta) ? "Звёздная сила" : "Гиперзаряд";
            String name = b.text(tb.get(rb, "TID"));
            Entry e = entry(s, NEW, brawlerName(code) + " — " + kind.toLowerCase(Locale.ROOT) + " «" + (name != null ? GameDb.nice(name) : rb[0]) + "»"
                    + (tb.flag(rb, "Disabled") ? " (скрыт)" : ""), code);
            String desc = cardText(tb, rb);
            if (desc != null) e.details.add("~" + desc);
        }
    }

    String cardText(GameDb.Table t, String[] r) {
        String raw = b.ru.get(t.get(r, "TID") + "_DESC");
        if (raw == null) return null;
        String s = raw;
        for (int i = 6; i >= 1; i--) {
            String key = i == 1 ? "(<VALUE1>|<VALUE>)" : "<VALUE" + i + ">";
            String v = t.has(VALUE_COLS[i - 1]) ? t.get(r, VALUE_COLS[i - 1]) : "";
            s = s.replaceAll(key, java.util.regex.Matcher.quoteReplacement(v));
        }
        return s.replaceAll("<[^>]*>", "").replace("\\n", " ").replace(' ', ' ').trim();
    }

    // ------------------------------------------------------------------ skins
    void skins() {
        Section s = section("Новые скины", "👕");
        Set<String> old = new HashSet<>();
        for (GameDb.Brawler x : a.brawlers()) for (GameDb.Skin k : x.skins) old.add(k.name);
        for (GameDb.Brawler x : b.brawlers()) {
            if (a.brawler(x.code) == null) continue;
            Entry e = null;
            for (GameDb.Skin k : x.skins) {
                if (old.contains(k.name)) continue;
                if (e == null) e = entry(s, NEW, x.name, x.code);
                String price = k.priceGems > 0 ? " · " + k.priceGems + " 💎" : k.priceBling > 0 ? " · " + k.priceBling + " блинг" : "";
                String rar = k.rarity.isEmpty() ? "" : " · " + GameDb.rarityName(k.rarity);
                e.details.add("~" + k.title.replace('\n', ' ').replaceAll("\\s+", " ").trim() + rar + price + (k.disabled ? " (скрыт)" : ""));
            }
        }
    }

    // ------------------------------------------------------------------ modes and maps
    void modes() {
        Section s = section("Новые режимы", "🎮");
        GameDb.Table ta = a.table("game_mode_variations.csv"), tb = b.table("game_mode_variations.csv");
        for (String[] r : tb.rows) {
            if (r.length == 0 || r[0].isEmpty() || ta.row(r[0]) != null) continue;
            String t = b.text(tb.get(r, "TID"));
            entry(s, NEW, (t != null ? GameDb.nice(t) : GameDb.nice(r[0])) + (tb.flag(r, "Disabled") ? " (скрыт)" : ""), null);
        }
    }

    public static String modeName(GameDb db, String variation) {
        GameDb.Table t = db.table("game_mode_variations.csv");
        String[] r = t.row(variation);
        String n = r == null ? null : db.text(t.get(r, "TID"));
        return n != null ? GameDb.nice(n) : GameDb.nice(variation);
    }

    void maps() {
        Section s = section("Карты", "🗺");
        GameDb.Table ta = a.table("locations.csv"), tb = b.table("locations.csv");
        Map<String, String> da = mapData(a), db = mapData(b);
        Map<String, List<String>> byMode = new LinkedHashMap<>();
        Set<String> seenMaps = new HashSet<>();
        for (String[] r : tb.rows) {
            if (r.length == 0 || r[0].isEmpty()) continue;
            String map = tb.get(r, "Map");
            String name = b.text(tb.get(r, "TID"));
            String title = (name != null ? name : GameDb.nice(r[0])) + (tb.flag(r, "Disabled") ? " (скрыта)" : "");
            String mode = modeName(b, tb.get(r, "GameModeVariation"));
            if (ta.row(r[0]) == null) {
                byMode.computeIfAbsent(mode, k -> new ArrayList<>()).add(title);
            } else if (!map.isEmpty() && seenMaps.add(map) && da.containsKey(map) && db.containsKey(map) && !da.get(map).equals(db.get(map))) {
                entry(s, CHANGED, "Изменена карта: " + title + " · " + mode, null);
            }
        }
        for (Map.Entry<String, List<String>> m : byMode.entrySet()) {
            Entry e = entry(s, NEW, "Новые карты · " + m.getKey() + " (" + m.getValue().size() + ")", null);
            for (String t : m.getValue()) e.details.add("~" + t);
        }
    }

    static Map<String, String> mapData(GameDb db) {
        Map<String, String> out = new HashMap<>();
        GameDb.Table t = db.table("maps.csv");
        String cur = null;
        StringBuilder sb = new StringBuilder();
        for (String[] r : t.rows) {
            String m = t.get(r, "Map");
            if (!m.isEmpty()) {
                if (cur != null) out.put(cur, sb.toString());
                cur = m;
                sb.setLength(0);
            }
            sb.append(t.get(r, "Data")).append('\n');
        }
        if (cur != null) out.put(cur, sb.toString());
        return out;
    }

    // ------------------------------------------------------------------ cosmetics, music, texts
    void cosmetics() {
        Section s = section("Пины, спреи, иконки", "📌");
        String[][] kinds = {{"pins", "Пины"}, {"sprays", "Спреи"}, {"icons", "Иконки игрока"}};
        for (String[] k : kinds) {
            Set<String> old = new HashSet<>();
            for (GameDb.Item2d it : a.items(k[0])) old.add(it.name);
            Map<String, Integer> per = new LinkedHashMap<>();
            int total = 0;
            for (GameDb.Item2d it : b.items(k[0])) {
                if (old.contains(it.name)) continue;
                total++;
                String who = it.character == null || it.character.isEmpty() ? "общие" : brawlerName(it.character);
                per.merge(who, 1, Integer::sum);
            }
            if (total == 0) continue;
            Entry e = entry(s, NEW, k[1] + ": +" + total, null);
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Integer> p : per.entrySet()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(p.getKey()).append(" ").append(p.getValue());
            }
            e.details.add("~" + sb);
        }
    }

    void music() {
        Section s = section("Музыка и звуки", "🎵");
        GameDb.Table ta = a.table("music.csv"), tb = b.table("music.csv");
        Set<String> oldFiles = new HashSet<>();
        for (String[] r : ta.rows) oldFiles.add(ta.get(r, "FileName"));
        Entry e = null;
        String name = "";
        for (String[] r : tb.rows) {
            if (!tb.get(r, "Name").isEmpty()) name = tb.get(r, "Name");
            String f = tb.get(r, "FileName");
            if (f.isEmpty() || oldFiles.contains(f)) continue;
            if (e == null) e = entry(s, NEW, "Новая музыка", null);
            e.details.add("~" + SoundLib.musicTitle(name) + " — " + GameDb.fileName(f));
        }
        GameDb.Table sa = a.table("sounds.csv"), sb = b.table("sounds.csv");
        int added = 0;
        for (String[] r : sb.rows) if (r.length > 0 && !r[0].isEmpty() && sa.row(r[0]) == null) added++;
        if (added > 0) entry(s, NEW, "Новых звуков в sounds.csv: " + added, null);
    }

    void texts() {
        int added = 0, changed = 0;
        for (Map.Entry<String, String> t : b.ru.entrySet()) {
            String o = a.ru.get(t.getKey());
            if (o == null) added++;
            else if (!o.equals(t.getValue())) changed++;
        }
        if (added + changed == 0) return;
        Section s = section("Тексты", "💬");
        entry(s, CHANGED, "Новых строк: " + added + " · изменено: " + changed, null);
    }

    /** everything as plain text (to share or copy) */
    public String toText(String title) {
        StringBuilder sb = new StringBuilder(title).append("\n\n");
        for (Section s : sections) {
            sb.append(s.icon).append(' ').append(s.title.toUpperCase(Locale.ROOT)).append('\n');
            for (Entry e : s.entries) {
                sb.append(e.kind == NEW ? "+ " : e.kind == REMOVED ? "− " : "• ").append(e.title).append('\n');
                for (String d : e.details) {
                    char m = d.charAt(0);
                    sb.append("    ").append(m == '+' ? "▲ " : m == '-' ? "▼ " : "").append(d.substring(1)).append('\n');
                }
            }
            sb.append('\n');
        }
        return sb.toString().trim();
    }
}
