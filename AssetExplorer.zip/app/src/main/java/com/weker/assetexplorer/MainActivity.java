package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {

    static final int REQ_IMPORT = 1, REQ_EXPORT = 2;
    static final int LIMIT = 3000;

    private Db db;
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private final Db.Filter filter = new Db.Filter();
    private List<Db.Version> versions = new ArrayList<>();
    private List<Db.Row> rows = new ArrayList<>();
    private int searchGen;

    private TextView versionBtn, countText, onlyNewChip, sortChip;
    private EditText search;
    private GridView grid;
    private View emptyView;
    private LinearLayout typeChips, tagChips;
    private Adapter adapter;

    private static final String[] SORTS = {"Сначала новое", "По имени", "По размеру", "По папкам"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        db = Db.get(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        buildUi();
        reloadVersions(true);
    }

    // ================================================================== UI
    private void buildUi() {
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.bold(this, "Asset Explorer", 20, Ui.TEXT);
        top.addView(title, Ui.lp(0, -2, 1));
        TextView menu = Ui.bold(this, "⋮", 22, Ui.TEXT);
        menu.setPadding(p, 0, Ui.dp(this, 4), 0);
        menu.setOnClickListener(v -> showMenu());
        top.addView(menu);
        root.addView(top);

        // version + updates
        LinearLayout vrow = new LinearLayout(this);
        vrow.setPadding(0, Ui.dp(this, 8), 0, 0);
        versionBtn = Ui.button(this, "Версия: —", false);
        versionBtn.setOnClickListener(v -> pickVersion());
        vrow.addView(versionBtn, Ui.lp(0, -2, 1));
        TextView upd = Ui.button(this, "Обновления", true);
        upd.setOnClickListener(v -> showUpdates());
        LinearLayout.LayoutParams ulp = Ui.lp(-2, -2, 0);
        ulp.leftMargin = Ui.dp(this, 8);
        vrow.addView(upd, ulp);
        TextView fighters = Ui.button(this, "Бойцы", true);
        fighters.setOnClickListener(v -> openBrawlers());
        vrow.addView(fighters, new LinearLayout.LayoutParams(ulp));
        root.addView(vrow);

        // search
        search = new EditText(this);
        search.setHint("Поиск: имя файла, «пин», «скин shelly», «3д»…");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        search.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        LinearLayout.LayoutParams slp = Ui.lp(-1, -2, 0);
        slp.topMargin = Ui.dp(this, 10);
        root.addView(search, slp);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                filter.text = e.toString();
                main.removeCallbacks(runSearch);
                main.postDelayed(runSearch, 250);
            }
        });

        // toggles
        LinearLayout toggles = new LinearLayout(this);
        toggles.setPadding(0, Ui.dp(this, 8), 0, 0);
        onlyNewChip = Ui.chip(this, "Только новое в версии");
        onlyNewChip.setOnClickListener(v -> {
            filter.onlyChanged = !filter.onlyChanged;
            Ui.setChip(this, onlyNewChip, filter.onlyChanged);
            refresh();
        });
        toggles.addView(onlyNewChip);
        sortChip = Ui.chip(this, "↕ " + SORTS[0]);
        sortChip.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Сортировка")
                .setItems(SORTS, (d, w) -> {
                    filter.sort = w;
                    sortChip.setText("↕ " + SORTS[w]);
                    refresh();
                }).show());
        toggles.addView(sortChip);
        root.addView(toggles);

        // chips
        typeChips = chipRow(root);
        tagChips = chipRow(root);
        fillChips();

        countText = Ui.text(this, "", 12, Ui.MUTED);
        countText.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        root.addView(countText);

        FrameLayout frame = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 108));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(Ui.dp(this, 6));
        grid.setVerticalSpacing(Ui.dp(this, 6));
        grid.setPadding(0, 0, 0, Ui.dp(this, 12));
        grid.setClipToPadding(false);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        adapter = new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, pos, id) -> {
            Intent i = new Intent(this, PreviewActivity.class);
            i.putExtra("id", rows.get(pos).id);
            startActivity(i);
        });
        frame.addView(grid);

        LinearLayout empty = new LinearLayout(this);
        empty.setOrientation(LinearLayout.VERTICAL);
        empty.setGravity(Gravity.CENTER);
        TextView et = Ui.text(this, "Пока пусто.\nЗакинь .zip с файлами игры (APK, XAPK или папку assets в архиве) — "
                + "приложение распакует его, разложит по категориям и запомнит версию.", 15, Ui.MUTED);
        et.setGravity(Gravity.CENTER);
        empty.addView(et);
        TextView ib = Ui.button(this, "Выбрать ZIP", true);
        ib.setOnClickListener(v -> pickZip());
        LinearLayout.LayoutParams ilp = Ui.lp(-2, -2, 0);
        ilp.topMargin = Ui.dp(this, 16);
        empty.addView(ib, ilp);
        emptyView = empty;
        frame.addView(empty);
        root.addView(frame, Ui.lp(-1, 0, 1));

        setContentView(root);
    }

    private LinearLayout chipRow(LinearLayout root) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        hs.addView(row);
        hs.setPadding(0, Ui.dp(this, 8), 0, 0);
        root.addView(hs);
        return row;
    }

    private void fillChips() {
        typeChips.removeAllViews();
        tagChips.removeAllViews();
        addChip(typeChips, "Все типы", null, true);
        for (Map.Entry<String, String> e : Categorizer.TYPE_NAMES.entrySet()) addChip(typeChips, e.getValue(), e.getKey(), true);
        addChip(tagChips, "Все темы", null, false);
        for (Map.Entry<String, String> e : Categorizer.TAG_NAMES.entrySet()) addChip(tagChips, e.getValue(), e.getKey(), false);
        updateChips();
    }

    private void addChip(LinearLayout row, String label, String key, boolean isType) {
        TextView c = Ui.chip(this, label);
        c.setTag(key == null ? "" : key);
        c.setOnClickListener(v -> {
            if (isType) filter.type = key;
            else filter.tag = key;
            updateChips();
            refresh();
        });
        row.addView(c);
    }

    private void updateChips() {
        for (int i = 0; i < typeChips.getChildCount(); i++) {
            TextView t = (TextView) typeChips.getChildAt(i);
            Ui.setChip(this, t, t.getTag().equals(filter.type == null ? "" : filter.type));
        }
        for (int i = 0; i < tagChips.getChildCount(); i++) {
            TextView t = (TextView) tagChips.getChildAt(i);
            Ui.setChip(this, t, t.getTag().equals(filter.tag == null ? "" : filter.tag));
        }
    }

    // ================================================================== data
    private final Runnable runSearch = this::refresh;

    private void reloadVersions(boolean selectNewest) {
        bg.execute(() -> {
            List<Db.Version> vs = db.versions();
            main.post(() -> {
                versions = vs;
                if (vs.isEmpty()) {
                    filter.vid = -1;
                } else if (selectNewest || findVersion(filter.vid) == null) {
                    filter.vid = vs.get(0).id;
                }
                Db.Version cur = findVersion(filter.vid);
                versionBtn.setText(cur == null ? "Версия: —" : "Версия: " + cur.name);
                refresh();
            });
        });
    }

    private Db.Version findVersion(long id) {
        for (Db.Version v : versions) if (v.id == id) return v;
        return null;
    }

    private void refresh() {
        final int gen = ++searchGen;
        final Db.Filter f = copy(filter);
        bg.execute(() -> {
            List<Db.Row> r = f.vid < 0 ? new ArrayList<>() : db.search(f, LIMIT);
            main.post(() -> {
                if (gen != searchGen) return;
                rows = r;
                adapter.notifyDataSetChanged();
                emptyView.setVisibility(versions.isEmpty() ? View.VISIBLE : View.GONE);
                grid.setVisibility(versions.isEmpty() ? View.GONE : View.VISIBLE);
                String n = r.size() >= LIMIT ? "больше " + LIMIT + " (уточни поиск)" : String.valueOf(r.size());
                countText.setText(versions.isEmpty() ? "" : "Найдено: " + n);
            });
        });
    }

    static Db.Filter copy(Db.Filter f) {
        Db.Filter c = new Db.Filter();
        c.vid = f.vid;
        c.onlyChanged = f.onlyChanged;
        c.type = f.type;
        c.tag = f.tag;
        c.text = f.text;
        c.sort = f.sort;
        return c;
    }

    // ================================================================== versions
    private void pickVersion() {
        if (versions.isEmpty()) {
            pickZip();
            return;
        }
        String[] names = new String[versions.size()];
        for (int i = 0; i < names.length; i++) names[i] = versions.get(i).name + "  ·  " + versions.get(i).files + " файлов";
        new AlertDialog.Builder(this).setTitle("Выбери версию")
                .setItems(names, (d, w) -> {
                    filter.vid = versions.get(w).id;
                    versionBtn.setText("Версия: " + versions.get(w).name);
                    refresh();
                })
                .setPositiveButton("+ Импорт ZIP", (d, w) -> pickZip())
                .show();
    }

    private void showUpdates() {
        if (versions.isEmpty()) {
            pickZip();
            return;
        }
        ProgressBar pb = new ProgressBar(this);
        AlertDialog wait = new AlertDialog.Builder(this).setView(pb).setCancelable(false).show();
        bg.execute(() -> {
            List<Db.Version> vs = db.versions();
            db.fillStats(vs);
            List<String> lines = new ArrayList<>();
            for (int i = 0; i < vs.size(); i++) {
                Db.Version v = vs.get(i);
                StringBuilder sb = new StringBuilder();
                sb.append(v.name).append('\n');
                if (i == vs.size() - 1) {
                    sb.append("   базовая версия · ").append(v.files).append(" файлов");
                } else {
                    sb.append("   +").append(v.added).append(" новых · ").append(v.changed).append(" изменено · −")
                            .append(v.removed).append(" удалено");
                    int m = db.typeCount(v.id, Categorizer.T_3D, true);
                    int t = db.typeCount(v.id, Categorizer.T_TEX, true);
                    int im = db.typeCount(v.id, Categorizer.T_IMG, true);
                    int s = db.typeCount(v.id, Categorizer.T_SFX, true) + db.typeCount(v.id, Categorizer.T_MUSIC, true);
                    sb.append("\n   3D: ").append(m).append(" · текстуры: ").append(t).append(" · картинки: ").append(im)
                            .append(" · звуки: ").append(s);
                }
                lines.add(sb.toString());
            }
            main.post(() -> {
                wait.dismiss();
                versions = vs;
                new AlertDialog.Builder(this).setTitle("Обновления (новые сверху)")
                        .setItems(lines.toArray(new String[0]), (d, w) -> {
                            Db.Version v = vs.get(w);
                            filter.vid = v.id;
                            filter.onlyChanged = w < vs.size() - 1;
                            Ui.setChip(this, onlyNewChip, filter.onlyChanged);
                            versionBtn.setText("Версия: " + v.name);
                            refresh();
                        })
                        .setNeutralButton("Управление", (d, w) -> manageVersions())
                        .setNegativeButton("Закрыть", null)
                        .show();
            });
        });
    }

    private void manageVersions() {
        String[] names = new String[versions.size()];
        for (int i = 0; i < names.length; i++) names[i] = versions.get(i).name;
        new AlertDialog.Builder(this).setTitle("Переименовать или удалить")
                .setItems(names, (d, w) -> {
                    Db.Version v = versions.get(w);
                    EditText in = new EditText(this);
                    in.setText(v.name);
                    new AlertDialog.Builder(this).setTitle("Версия").setView(in)
                            .setPositiveButton("Сохранить", (d2, w2) -> bg.execute(() -> {
                                db.renameVersion(v.id, in.getText().toString().trim());
                                main.post(() -> reloadVersions(false));
                            }))
                            .setNegativeButton("Удалить версию", (d2, w2) -> confirmDelete(v))
                            .show();
                }).show();
    }

    private void confirmDelete(Db.Version v) {
        new AlertDialog.Builder(this).setTitle("Удалить " + v.name + "?")
                .setMessage("Файлы этой версии будут удалены из приложения (оригинальный zip не трогается).")
                .setPositiveButton("Удалить", (d, w) -> bg.execute(() -> {
                    db.deleteVersion(v.id, Blobs.dir(this));
                    main.post(() -> reloadVersions(true));
                }))
                .setNegativeButton("Отмена", null).show();
    }

    // ================================================================== menu
    private void showMenu() {
        String[] items = {"Импорт ZIP (новая версия)", "Бойцы: способности по частям", "Экспорт найденного в папку", "Как пользоваться"};
        new AlertDialog.Builder(this).setItems(items, (d, w) -> {
            if (w == 0) pickZip();
            else if (w == 1) openBrawlers();
            else if (w == 2) startExport();
            else help();
        }).show();
    }

    private void openBrawlers() {
        if (versions.isEmpty() || filter.vid < 0) {
            pickZip();
            return;
        }
        Intent i = new Intent(this, BrawlersActivity.class);
        i.putExtra("vid", filter.vid);
        startActivity(i);
    }

    private void help() {
        new AlertDialog.Builder(this).setTitle("Как пользоваться")
                .setMessage("1. «Импорт ZIP» — выбери архив с файлами игры (APK, XAPK или zip с папкой assets). "
                        + "Версия берётся из fingerprint.json, иначе из имени файла.\n\n"
                        + "2. Импортируй несколько версий — в «Обновлениях» видно, что добавили и изменили в каждой. "
                        + "Одинаковые файлы хранятся один раз.\n\n"
                        + "3. Поиск понимает имена файлов и русские слова: пин, скин, иконка, бравлер, 3д, текстура, звук, карта, эффект…\n\n"
                        + "4. Нажми на файл — просмотр, зум, звук, история по версиям. Текстуры можно сохранить в PNG.\n\n"
                        + "5. «Экспорт найденного» сохраняет весь текущий список в папку (текстуры дополнительно в PNG).\n\n"
                        + "6. «Бойцы» — все 2D-эффекты бойца по способностям: атака, супер, гаджеты, звёздные силы, гиперзаряд, "
                        + "появление, лобби. «Собрать вместе» проигрывает все части способности одной сценой: вылет у бойца, "
                        + "полёт снаряда, попадание по врагу / в стену / предел дальности. Сцену можно сохранить в GIF.")
                .setPositiveButton("Понятно", null).show();
    }

    // ================================================================== import
    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed",
                "application/vnd.android.package-archive", "application/octet-stream", "*/*"});
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для выбора файлов", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_IMPORT) runImport(data.getData());
        else if (req == REQ_EXPORT) runExport(data.getData());
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
            // fall through
        }
        return uri.getLastPathSegment();
    }

    private void runImport(Uri uri) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Importer importer = new Importer(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, p, p, p);
        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        box.addView(pb);
        TextView status = Ui.text(this, "Открываю архив…", 13, 0xFF888888);
        status.setPadding(0, Ui.dp(this, 10), 0, 0);
        box.addView(status);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Импорт").setView(box).setCancelable(false)
                .setNegativeButton("Отмена", (d, w) -> importer.cancel()).show();
        String name = displayName(uri);
        new Thread(() -> {
            try {
                Importer.Result r = importer.run(uri, name, (files, bytes, cur) -> main.post(() ->
                        status.setText(String.format(Locale.ROOT, "%d файлов · %s\n%s", files, Ui.size(bytes), cur))));
                main.post(() -> {
                    dlg.dismiss();
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    String msg = "Версия " + r.version + ": " + r.files + " файлов.";
                    if (versions.size() > 0) msg += "\nНовых: " + r.added + ", изменено: " + r.changed + " (относительно предыдущей версии).";
                    new AlertDialog.Builder(this).setTitle("Готово").setMessage(msg).setPositiveButton("ОК", null).show();
                    filter.vid = r.vid;
                    reloadVersions(false);
                });
            } catch (Throwable e) {
                main.post(() -> {
                    dlg.dismiss();
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    new AlertDialog.Builder(this).setTitle("Импорт не удался")
                            .setMessage(String.valueOf(e.getMessage() == null ? e : e.getMessage()))
                            .setPositiveButton("ОК", null).show();
                    reloadVersions(false);
                });
            }
        }, "import").start();
    }

    // ================================================================== export
    private void startExport() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "Список пуст — нечего экспортировать", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        try {
            startActivityForResult(i, REQ_EXPORT);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для выбора папки", Toast.LENGTH_LONG).show();
        }
    }

    private void runExport(Uri tree) {
        final Db.Filter f = copy(filter);
        String ver = findVersion(f.vid) == null ? "export" : findVersion(f.vid).name;
        new AlertDialog.Builder(this).setTitle("Экспорт")
                .setMessage("Сохранить текущий список в выбранную папку?\nТекстуры будут дополнительно сохранены как PNG.")
                .setPositiveButton("Да, с PNG", (d, w) -> doExport(tree, f, ver, true))
                .setNeutralButton("Только оригиналы", (d, w) -> doExport(tree, f, ver, false))
                .setNegativeButton("Отмена", null).show();
    }

    private void doExport(Uri tree, Db.Filter f, String ver, boolean png) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Exporter ex = new Exporter(this);
        TextView status = Ui.text(this, "Готовлю…", 13, 0xFF888888);
        int p = Ui.dp(this, 20);
        status.setPadding(p, p, p, p);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Экспорт").setView(status).setCancelable(false)
                .setNegativeButton("Отмена", (d, w) -> ex.cancel()).show();
        new Thread(() -> {
            String result;
            try {
                List<Db.Row> all = db.search(f, 0);
                int n = ex.export(tree, "BS_" + ver.replaceAll("[^0-9A-Za-z._-]", "_"), all, png,
                        (done, total, cur) -> main.post(() -> status.setText(done + " / " + total + "\n" + cur)));
                result = "Сохранено файлов: " + n;
            } catch (Throwable e) {
                result = "Ошибка: " + e.getMessage();
            }
            String fr = result;
            main.post(() -> {
                dlg.dismiss();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                new AlertDialog.Builder(this).setTitle("Экспорт").setMessage(fr).setPositiveButton("ОК", null).show();
            });
        }, "export").start();
    }

    // ================================================================== grid
    final class Adapter extends BaseAdapter {
        @Override
        public int getCount() { return rows.size(); }

        @Override
        public Object getItem(int i) { return rows.get(i); }

        @Override
        public long getItemId(int i) { return rows.get(i).id; }

        @Override
        public View getView(int pos, View v, ViewGroup parent) {
            Holder h;
            if (v == null) {
                h = new Holder();
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setBackground(Ui.round(Ui.CARD, Ui.dp(MainActivity.this, 10)));
                int pad = Ui.dp(MainActivity.this, 6);
                cell.setPadding(pad, pad, pad, pad);
                FrameLayout box = new FrameLayout(MainActivity.this);
                box.setBackground(Ui.round(0xFF20232F, Ui.dp(MainActivity.this, 8)));
                h.image = new ImageView(MainActivity.this);
                h.image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                box.addView(h.image, new FrameLayout.LayoutParams(-1, -1));
                h.ext = Ui.bold(MainActivity.this, "", 16, Ui.MUTED);
                h.ext.setGravity(Gravity.CENTER);
                box.addView(h.ext, new FrameLayout.LayoutParams(-1, -1));
                h.badge = Ui.bold(MainActivity.this, "", 10, 0xFF0F1117);
                int bp = Ui.dp(MainActivity.this, 4);
                h.badge.setPadding(bp * 2, bp / 2, bp * 2, bp / 2);
                FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
                blp.setMargins(bp, bp, 0, 0);
                box.addView(h.badge, blp);
                cell.addView(box, new LinearLayout.LayoutParams(-1, Ui.dp(MainActivity.this, 96)));
                h.name = Ui.text(MainActivity.this, "", 11, Ui.TEXT);
                h.name.setMaxLines(2);
                h.name.setPadding(0, pad, 0, 0);
                cell.addView(h.name);
                h.size = Ui.text(MainActivity.this, "", 10, Ui.MUTED);
                cell.addView(h.size);
                v = cell;
                v.setTag(h);
            } else {
                h = (Holder) v.getTag();
            }
            Db.Row r = rows.get(pos);
            h.name.setText(r.name);
            h.size.setText(Ui.size(r.size) + " · " + r.ext);
            if (r.status == Db.ST_NEW) {
                h.badge.setVisibility(View.VISIBLE);
                h.badge.setText("NEW");
                h.badge.setBackground(Ui.round(Ui.NEW, Ui.dp(MainActivity.this, 6)));
            } else if (r.status == Db.ST_CHANGED) {
                h.badge.setVisibility(View.VISIBLE);
                h.badge.setText("ИЗМ");
                h.badge.setBackground(Ui.round(Ui.CHANGED, Ui.dp(MainActivity.this, 6)));
            } else {
                h.badge.setVisibility(View.GONE);
            }
            boolean thumb = Decoders.isPreviewableImage(r);
            if (thumb) {
                h.ext.setText("");
                Thumbs.get(MainActivity.this).load(r, h.image);
            } else {
                h.image.setTag(null);
                h.image.setImageDrawable(null);
                h.ext.setText(icon(r));
                android.graphics.Typeface tf = Categorizer.T_FONT.equals(r.type) ? font(r) : null;
                h.ext.setTypeface(tf != null ? tf : android.graphics.Typeface.DEFAULT_BOLD);
                h.ext.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, tf != null ? 30 : 16);
            }
            return v;
        }
    }

    private final java.util.Map<String, android.graphics.Typeface> fonts = new java.util.HashMap<>();

    /** Font files show "Aa" drawn in their own typeface. */
    android.graphics.Typeface font(Db.Row r) {
        if (fonts.containsKey(r.blob)) return fonts.get(r.blob);
        android.graphics.Typeface tf = null;
        try {
            tf = android.graphics.Typeface.createFromFile(Blobs.file(this, r.blob));
        } catch (Exception ignored) {
            // unreadable font
        }
        fonts.put(r.blob, tf);
        return tf;
    }

    static String icon(Db.Row r) {
        switch (r.type) {
            case Categorizer.T_3D: return "3D\n." + r.ext;
            case Categorizer.T_SFX:
            case Categorizer.T_MUSIC: return "♪\n." + r.ext;
            case Categorizer.T_SC: return "SC\n2D";
            case Categorizer.T_CSV: return "CSV";
            case Categorizer.T_FONT: return "Aa";
            default: return r.ext.isEmpty() ? "?" : "." + r.ext;
        }
    }

    static final class Holder {
        ImageView image;
        TextView ext, badge, name, size;
    }
}
