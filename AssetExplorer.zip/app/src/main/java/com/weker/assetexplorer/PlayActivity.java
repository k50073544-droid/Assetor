package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.weker.assetexplorer.codec.Battle;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.MapPlan;
import com.weker.assetexplorer.codec.MapScene;
import com.weker.assetexplorer.codec.Specials;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * "Играть": pick one of the newest brawlers (new in this version compared with the previous imported one) or a
 * hidden one, its gadget and star power, the mode, the map and the location theme (environment), then fight bots.
 */
public final class PlayActivity extends Activity {

    static final Battle.Mode[] MODES = {Battle.Mode.TRAINING, Battle.Mode.GEM, Battle.Mode.SHOWDOWN, Battle.Mode.BALL, Battle.Mode.BOUNTY, Battle.Mode.KNOCKOUT,
            Battle.Mode.HIDE, Battle.Mode.HOCKEY, Battle.Mode.BOSS};

    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private final List<GameDb.Brawler> playable = new ArrayList<>();
    private final Set<String> fresh = new HashSet<>();
    private GameDb.Brawler brawler;
    private GameDb.Skin skin;
    private Battle.Mode mode = Battle.Mode.GEM;
    private MapPlan.Entry map;
    private String theme; // null = the map's own
    private int gadget = 1, star = 1;
    /** graphics: 0 low, 1 medium, 2 high (remembered) */
    private int quality = 2;
    /** bots: 0 easy, 1 normal, 2 hard; aim help: 0 off, 1 light, 2 strong; auto-attack (all remembered) */
    private int difficulty = 0, assist = 2;
    private boolean autoFire;
    private final List<TextView> qualityChips = new ArrayList<>(), difficultyChips = new ArrayList<>(), assistChips = new ArrayList<>(), autoChips = new ArrayList<>();
    private Map<String, List<MapPlan.Entry>> maps;
    private LinearLayout brawlerRow, body;
    private TextView info, mapBtn, themeBtn, skinBtn;
    private final List<TextView> modeChips = new ArrayList<>();
    private final List<TextView> gadgetChips = new ArrayList<>(), starChips = new ArrayList<>();
    private ImageView plan;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);
        int p = Ui.dp(this, 12);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p * 2);
        sv.addView(root);
        root.addView(Ui.bold(this, "Играть за новых бойцов", 19, Ui.TEXT));
        info = Ui.text(this, "Ищу новых бойцов…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(info);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        brawlerRow = new LinearLayout(this);
        hs.addView(brawlerRow);
        root.addView(hs);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body);
        setContentView(sv);
        String loc = getIntent().getStringExtra("location");
        try {
            android.content.SharedPreferences sp = getSharedPreferences("play", MODE_PRIVATE);
            quality = sp.getInt("quality2", defaultQuality()); // a new key: the new renderer is light enough for high graphics
            difficulty = sp.getInt("difficulty", 0);
            assist = sp.getInt("assist", 2);
            autoFire = sp.getBoolean("autofire", false);
        } catch (Exception ignored) {
            quality = 1;
        }
        theme = getIntent().getStringExtra("theme");
        new Thread(() -> {
            try {
                findPlayable();
                maps = MapPlan.byMode(gd.db);
                MapPlan.Entry start = null;
                for (List<MapPlan.Entry> l : maps.values()) for (MapPlan.Entry e : l) if (e.location.equals(loc)) start = e;
                MapPlan.Entry st = start;
                main.post(() -> {
                    if (st != null) {
                        map = st;
                        Battle.Mode m = Battle.Mode.of(st.mode);
                        if (m != null && m != Battle.Mode.TRAINING) mode = m;
                    }
                    build();
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Ошибка: " + e.getMessage()));
            }
        }).start();
    }

    /** low graphics on phones with little memory, medium otherwise */
    int defaultQuality() {
        android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int mc = am == null ? 192 : am.getMemoryClass();
        return mc < 128 ? 0 : mc < 192 ? 1 : 2;
    }

    /** brawlers new in this version (compared with the next older imported one), then hidden ones */
    private void findPlayable() {
        List<Db.Version> vs = Db.get(this).versions();
        Db.Version older = null;
        for (int i = 0; i < vs.size(); i++) if (vs.get(i).id == vid && i + 1 < vs.size()) older = vs.get(i + 1);
        List<GameDb.Brawler> all = gd.db.brawlers();
        if (older != null) {
            GameDb old = GameData.of(this, older.id).db;
            for (GameDb.Brawler x : all) if (!x.hidden && old.brawler(x.code) == null) fresh.add(x.code);
        }
        if (fresh.isEmpty()) { // one version only: the two last brawlers of the table are the newest
            List<GameDb.Brawler> open = new ArrayList<>();
            for (GameDb.Brawler x : all) if (!x.hidden) open.add(x);
            for (int i = Math.max(0, open.size() - 2); i < open.size(); i++) fresh.add(open.get(i).code);
        }
        for (GameDb.Brawler x : all) if (fresh.contains(x.code)) playable.add(x);
        for (GameDb.Brawler x : all) if (x.hidden && x.skins.size() > 0 && x.skins.get(0).model != null) playable.add(x);
        String note = older != null ? "Новые по сравнению с версией " + older.name : "Импортирована одна версия — новыми считаются два последних бойца";
        main.post(() -> info.setText(note + ". Скрытые бойцы — те, что уже есть в файлах, но выключены в игре."));
    }

    private void build() {
        brawlerRow.removeAllViews();
        for (GameDb.Brawler x : playable) brawlerRow.addView(card(x));
        if (brawler == null && !playable.isEmpty()) pick(playable.get(0));
    }

    private View card(GameDb.Brawler x) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = Ui.dp(this, 6);
        c.setPadding(p, p, p, p);
        c.setTag(x.code);
        ImageView iv = new ImageView(this);
        int sz = Ui.dp(this, 76);
        c.addView(iv, Ui.lp(sz, sz, 0));
        TextView t = Ui.bold(this, x.name.replace(" (скрыт)", ""), 12, Ui.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setMaxWidth(Ui.dp(this, 96));
        t.setMaxLines(2);
        c.addView(t);
        TextView tag = Ui.text(this, fresh.contains(x.code) ? "НОВЫЙ" : "скрыт", 10, fresh.contains(x.code) ? Ui.NEW : Ui.MUTED);
        c.addView(tag);
        LinearLayout.LayoutParams lp = Ui.lp(Ui.dp(this, 104), -2, 0);
        lp.rightMargin = Ui.dp(this, 6);
        c.setLayoutParams(lp);
        c.setOnClickListener(v -> pick(x));
        new Thread(() -> {
            Bitmap bm = gd.export(x.portraitFile, x.portraitExport, 160);
            if (bm != null) main.post(() -> iv.setImageBitmap(bm));
        }).start();
        return c;
    }

    private void pick(GameDb.Brawler x) {
        brawler = x;
        skin = x.skins.isEmpty() ? null : x.skins.get(0);
        gadget = 1;
        star = 1;
        for (int i = 0; i < brawlerRow.getChildCount(); i++) {
            View v = brawlerRow.getChildAt(i);
            v.setBackground(Ui.round(x.code.equals(v.getTag()) ? 0xFF3A4A70 : Ui.CARD, Ui.dp(this, 12)));
        }
        body.removeAllViews();
        int p = Ui.dp(this, 10);
        LinearLayout.LayoutParams gap = Ui.lp(-1, -2, 0);
        gap.topMargin = p;
        // what the brawler does
        StringBuilder sb = new StringBuilder();
        for (String l : Specials.describe(x.code)) sb.append("• ").append(l).append('\n');
        if (sb.length() == 0) sb.append(x.hidden ? "Скрытый боец: атака и Супер из таблиц игры.\n" : "Атака, Супер и гаджеты из таблиц игры.\n");
        TextView d = Ui.text(this, sb.toString().trim(), 13, 0xFFC5CAD6);
        d.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        d.setPadding(p, p, p, p);
        body.addView(d, gap);
        // skin
        skinBtn = Ui.button(this, "Скин: " + (skin != null ? skin.title : "—"), false);
        skinBtn.setOnClickListener(v -> pickSkin());
        body.addView(skinBtn, Ui.lp(-1, -2, 0));
        ((LinearLayout.LayoutParams) skinBtn.getLayoutParams()).topMargin = p;
        // gadget and star power
        gadgetChips.clear();
        starChips.clear();
        if (!x.gadgets.isEmpty()) body.addView(choiceRow("Гаджет", x.gadgets, gadgetChips, true));
        if (!x.starPowers.isEmpty()) body.addView(choiceRow("Звёздная сила", x.starPowers, starChips, false));
        // mode
        body.addView(label("Режим"));
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.VERTICAL);
        modeChips.clear();
        LinearLayout row = null;
        for (int i = 0; i < MODES.length; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams rl = Ui.lp(-1, -2, 0);
                rl.bottomMargin = Ui.dp(this, 6);
                modes.addView(row, rl);
            }
            Battle.Mode m = MODES[i];
            TextView t = Ui.chip(this, m.title + (m == Battle.Mode.HIDE || m == Battle.Mode.HOCKEY || m == Battle.Mode.BOSS ? " ✦" : ""));
            t.setOnClickListener(v -> {
                mode = m;
                refresh();
            });
            modeChips.add(t);
            row.addView(t);
        }
        body.addView(modes);
        TextView hint = Ui.text(this, "✦ — режимы этой версии. Любую карту можно сыграть в любом режиме: открой её в «Картах» и нажми «Играть».", 11, Ui.MUTED);
        body.addView(hint);
        // map and theme
        body.addView(label("Карта и окружение"));
        mapBtn = Ui.button(this, "", false);
        mapBtn.setOnClickListener(v -> pickMap());
        body.addView(mapBtn, Ui.lp(-1, -2, 0));
        themeBtn = Ui.button(this, "", false);
        themeBtn.setOnClickListener(v -> pickTheme());
        LinearLayout.LayoutParams tl = Ui.lp(-1, -2, 0);
        tl.topMargin = Ui.dp(this, 6);
        body.addView(themeBtn, tl);
        plan = new ImageView(this);
        plan.setAdjustViewBounds(true);
        LinearLayout.LayoutParams pl = Ui.lp(-1, Ui.dp(this, 200), 0);
        pl.topMargin = Ui.dp(this, 8);
        body.addView(plan, pl);
        // graphics
        body.addView(label("Графика"));
        LinearLayout q = new LinearLayout(this);
        qualityChips.clear();
        String[] qn = {"Низкая (слабый телефон)", "Средняя", "Высокая"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            TextView t = Ui.chip(this, qn[i]);
            t.setOnClickListener(v -> {
                quality = k;
                try {
                    getSharedPreferences("play", MODE_PRIVATE).edit().putInt("quality2", k).apply();
                } catch (Exception ignored) {
                    // not remembered
                }
                refresh();
            });
            qualityChips.add(t);
            q.addView(t);
        }
        HorizontalScrollView qs = new HorizontalScrollView(this);
        qs.addView(q);
        body.addView(qs);
        body.addView(chipRow("Сложность ботов", new String[]{"Лёгкая", "Обычная", "Сложная"}, difficultyChips, k -> {
            difficulty = k;
            remember("difficulty", k);
        }));
        body.addView(chipRow("Помощь в прицеливании", new String[]{"Выключена", "Лёгкая", "Сильная"}, assistChips, k -> {
            assist = k;
            remember("assist", k);
        }));
        body.addView(chipRow("Атака", new String[]{"Кнопкой", "Автоатака"}, autoChips, k -> {
            autoFire = k == 1;
            remember("autofire", k);
        }));
        // play
        GameButton go = new GameButton(this, "Играть", GameButton.YELLOW, CardGrid.font);
        go.setTextSize(22);
        go.setOnClickListener(v -> play());
        LinearLayout.LayoutParams gl = Ui.lp(-1, Ui.dp(this, 64), 0);
        gl.topMargin = Ui.dp(this, 14);
        body.addView(go, gl);
        TextView note = Ui.text(this, "Часть чисел новых бойцов в файлах не записана (они в коде игры) — подобраны по описаниям: "
                + Specials.ASSUMED + ".", 11, Ui.MUTED);
        note.setPadding(0, Ui.dp(this, 8), 0, 0);
        body.addView(note);
        refresh();
    }

    private void remember(String key, int v) {
        try {
            android.content.SharedPreferences.Editor e = getSharedPreferences("play", MODE_PRIVATE).edit();
            if (key.equals("autofire")) e.putBoolean(key, v == 1);
            else e.putInt(key, v);
            e.apply();
        } catch (Exception ignored) {
            // not remembered
        }
    }

    /** a titled row of chips, one of them chosen; picking calls back with its number */
    private View chipRow(String title, String[] names, List<TextView> chips, java.util.function.IntConsumer pick) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label(title));
        LinearLayout row = new LinearLayout(this);
        chips.clear();
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = Ui.chip(this, names[i]);
            t.setOnClickListener(v -> {
                pick.accept(k);
                refresh();
            });
            chips.add(t);
            row.addView(t);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(row);
        box.addView(hs);
        return box;
    }

    private TextView label(String s) {
        TextView t = Ui.bold(this, s, 14, Ui.ACCENT);
        t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
        return t;
    }

    private View choiceRow(String title, List<String> names, List<TextView> chips, boolean isGadget) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label(title));
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < names.size(); i++) {
            final int n = i + 1;
            TextView t = Ui.chip(this, names.get(i));
            t.setOnClickListener(v -> {
                if (isGadget) gadget = n;
                else star = n;
                refresh();
            });
            chips.add(t);
            row.addView(t);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(row);
        box.addView(hs);
        return box;
    }

    private void refresh() {
        for (int i = 0; i < MODES.length && i < modeChips.size(); i++) Ui.setChip(this, modeChips.get(i), MODES[i] == mode);
        for (int i = 0; i < gadgetChips.size(); i++) Ui.setChip(this, gadgetChips.get(i), i + 1 == gadget);
        for (int i = 0; i < starChips.size(); i++) Ui.setChip(this, starChips.get(i), i + 1 == star);
        for (int i = 0; i < qualityChips.size(); i++) Ui.setChip(this, qualityChips.get(i), i == quality);
        for (int i = 0; i < difficultyChips.size(); i++) Ui.setChip(this, difficultyChips.get(i), i == difficulty);
        for (int i = 0; i < assistChips.size(); i++) Ui.setChip(this, assistChips.get(i), i == assist);
        for (int i = 0; i < autoChips.size(); i++) Ui.setChip(this, autoChips.get(i), (i == 1) == autoFire);
        if (mapBtn == null) return;
        mapBtn.setText(mode == Battle.Mode.TRAINING ? "Карта: тренировочная пещера (только манекены)"
                : "Карта: " + (map != null ? map.title + " · " + map.modeTitle : "случайная карта режима"));
        themeBtn.setText("Окружение: " + (theme != null ? GameDb.nice(theme) : map != null ? GameDb.nice(map.theme) + " (как в игре)" : "как в игре"));
        MapPlan.Entry m = map;
        if (m == null) {
            plan.setImageBitmap(null);
            return;
        }
        new Thread(() -> {
            Bitmap bm = MapsActivity.plan(gd, m, 400);
            main.post(() -> {
                if (m == map) plan.setImageBitmap(bm);
            });
        }).start();
    }

    private void pickSkin() {
        if (brawler == null || brawler.skins.isEmpty()) return;
        String[] n = new String[brawler.skins.size()];
        for (int i = 0; i < n.length; i++) n[i] = brawler.skins.get(i).title;
        new AlertDialog.Builder(this).setTitle("Скин").setItems(n, (d, w) -> {
            skin = brawler.skins.get(w);
            skinBtn.setText("Скин: " + skin.title);
        }).show();
    }

    private void pickMap() {
        if (maps == null) return;
        if (mode == Battle.Mode.TRAINING) {
            android.widget.Toast.makeText(this, "В пещере своя карта с манекенами. Окружение можно поменять", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        List<MapPlan.Entry> list = new ArrayList<>();
        for (List<MapPlan.Entry> l : maps.values()) {
            for (MapPlan.Entry e : l) if (Battle.Mode.of(e.mode) == mode && !e.disabled) list.add(e);
        }
        if (list.isEmpty()) {
            android.widget.Toast.makeText(this, "Для этого режима карт нет — выбери любую в «Картах»", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        String[] n = new String[list.size() + 1];
        n[0] = "Случайная карта";
        for (int i = 0; i < list.size(); i++) n[i + 1] = list.get(i).title + "  ·  " + list.get(i).modeTitle;
        new AlertDialog.Builder(this).setTitle("Карта · " + mode.title).setItems(n, (d, w) -> {
            map = w == 0 ? null : list.get(w - 1);
            refresh();
        }).show();
    }

    private void pickTheme() {
        List<String[]> th = MapScene.themes(gd.db);
        String[] n = new String[th.size() + 1];
        n[0] = "Как в игре";
        for (int i = 0; i < th.size(); i++) n[i + 1] = th.get(i)[1];
        new AlertDialog.Builder(this).setTitle("Окружение").setItems(n, (d, w) -> {
            theme = w == 0 ? null : th.get(w - 1)[0];
            refresh();
        }).show();
    }

    private void play() {
        if (brawler == null) return;
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("vid", vid);
        i.putExtra("brawler", brawler.code);
        if (skin != null) i.putExtra("skin", skin.name);
        i.putExtra("mode", mode.name());
        if (mode == Battle.Mode.TRAINING) i.putExtra("map", "Training");
        else if (map != null) i.putExtra("map", map.map);
        i.putExtra("quality", quality);
        i.putExtra("difficulty", difficulty);
        i.putExtra("assist", assist);
        i.putExtra("autofire", autoFire);
        if (theme != null) i.putExtra("theme", theme);
        i.putExtra("gadget", gadget);
        i.putExtra("star", star);
        startActivity(i);
    }
}
