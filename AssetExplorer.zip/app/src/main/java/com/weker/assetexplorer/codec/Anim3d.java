package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Skeletal animation from a Supercell glTF animation file (SC_odin_format.animation): raw, packed and
 * continuous-packed encodings, decoded to per-bone keyframes (translation, rotation quaternion, scale).
 * Bones are identified by node name, so an animation can drive any model with the same rig.
 * Encodings follow Supercell-Flat-Converter by Daniil-SV.
 */
public final class Anim3d {

    public static final class Track {
        public String name;
        public int frames;
        /** frames*3, frames*4 (x y z w), frames*3 */
        public float[] t, r, s;
    }

    public float fps = 30;
    public int frames = 1;
    public final Map<String, Track> tracks = new HashMap<>();
    /** static local transform the animation file gives to bones it doesn't animate (e.g. the gun held in the hand) */
    public final Map<String, float[]> statics = new HashMap<>();
    public final List<String> notes = new ArrayList<>();

    private Glb g;
    private final List<int[]> views = new ArrayList<>();

    public double duration() {
        return Math.max(1, frames - 1) / (double) fps;
    }

    public static boolean isAnimation(Glb g) {
        Map<String, Object> o = Model3d.path(g.json, "extensions", "SC_odin_format");
        return (o != null && o.get("animation") != null) || !Model3d.list(g.json.get("animations")).isEmpty();
    }

    public static Anim3d load(byte[] data) throws IOException {
        Anim3d a = new Anim3d();
        a.g = Glb.parse(data);
        for (Object o : Model3d.list(a.g.json.get("bufferViews"))) {
            Map<String, Object> bv = Model3d.map(o);
            a.views.add(new int[]{Model3d.num(bv.get("byteOffset"), 0), Model3d.num(bv.get("byteLength"), 0), Model3d.num(bv.get("byteStride"), 0)});
        }
        Map<String, Object> odin = Model3d.path(a.g.json, "extensions", "SC_odin_format");
        Map<String, Object> desc = odin == null ? null : Model3d.map(odin.get("animation"));
        if (desc == null) throw new IOException("В файле нет анимации");
        a.fps = Model3d.num(desc.get("frameRate"), 30);
        if (a.fps <= 0) a.fps = 30;
        a.frames = Math.max(1, Model3d.num(desc.get("keyframesCount"), Model3d.num(desc.get("keyframeCount"), 1)));
        List<Object> nodes = Model3d.list(a.g.json.get("nodes"));
        String[] names = new String[nodes.size()];
        for (int i = 0; i < names.length; i++) {
            Map<String, Object> nd = Model3d.map(nodes.get(i));
            names[i] = Model3d.str(nd.get("name"), "node" + i);
            if (nd.get("translation") != null || nd.get("rotation") != null || nd.get("scale") != null || nd.get("matrix") != null) {
                a.statics.put(names[i], Model3d.localMatrix(nd));
            }
        }
        try {
            if (desc.get("packed") != null) a.readPacked(Model3d.map(desc.get("packed")), names);
            else if (desc.get("nodes") != null && desc.get("accessor") != null) a.readRaw(desc, names);
            else throw new IOException("Неизвестный формат анимации");
        } catch (RuntimeException e) {
            throw new IOException("Анимация не читается: " + e);
        }
        if (a.tracks.isEmpty()) throw new IOException("В анимации нет костей");
        return a;
    }

    // ------------------------------------------------------------------ raw: 10 floats per node per frame
    private void readRaw(Map<String, Object> desc, String[] names) {
        List<Object> used = Model3d.list(desc.get("nodes"));
        double[] buf = accessor(Model3d.num(desc.get("accessor"), -1));
        List<Object> counts = Model3d.list(desc.get("keyframeCounts"));
        List<Object> perKey = Model3d.list(desc.get("nodesNumberPerKeyframe"));
        int[] nodeFrames = new int[used.size()];
        if (!counts.isEmpty() && counts.size() == perKey.size()) {
            int k = 0;
            for (int i = 0; i < counts.size(); i++) {
                for (int j = 0; j < Model3d.num(perKey.get(i), 0) && k < nodeFrames.length; j++) nodeFrames[k++] = Model3d.num(counts.get(i), 1);
            }
        } else {
            java.util.Arrays.fill(nodeFrames, frames);
        }
        int p = 0;
        for (int n = 0; n < used.size(); n++) {
            int ni = Model3d.num(used.get(n), -1);
            Track t = track(ni >= 0 && ni < names.length ? names[ni] : "node" + ni, nodeFrames[n]);
            for (int f = 0; f < t.frames; f++, p += 10) {
                if (p + 10 > buf.length) break;
                for (int k = 0; k < 3; k++) t.t[f * 3 + k] = (float) buf[p + k];
                for (int k = 0; k < 4; k++) t.r[f * 4 + k] = (float) buf[p + 3 + k];
                for (int k = 0; k < 3; k++) t.s[f * 3 + k] = (float) buf[p + 7 + k];
            }
            normalize(t);
            tracks.put(t.name, t);
        }
    }

    // ------------------------------------------------------------------ packed
    private void readPacked(Map<String, Object> packed, String[] names) {
        List<Object> nodes = Model3d.list(packed.get("nodes"));
        double[] data = accessor(Model3d.num(packed.get("dataAccessor"), -1));
        double[] base = accessor(Model3d.num(packed.get("nodeAccessor"), -1));
        boolean continuous = packed.get("uintAccessor") != null;
        double[] rot = continuous ? accessor(Model3d.num(packed.get("uintAccessor"), -1)) : null;
        int stride = continuous ? 8 : 12;

        int[] flags = new int[nodes.size()];
        int frameStride = 0;
        boolean anyTime = false;
        for (int i = 0; i < flags.length; i++) {
            flags[i] = Model3d.num(Model3d.map(nodes.get(i)).get("flags"), 0);
            frameStride += elements(flags[i]);
            anyTime |= (flags[i] & 1) != 0;
        }
        int sequential = 0;   // continuous: running position in the data stream
        int nodeOffset = 0;   // packed: offset of this node inside one frame
        for (int i = 0; i < nodes.size(); i++) {
            Map<String, Object> nd = Model3d.map(nodes.get(i));
            int ni = Model3d.num(nd.get("nodeIndex"), 0);
            int fc = Math.max(1, Model3d.num(nd.get("frameCount"), frames));
            int dataSize = Model3d.num(nd.get("dataSize"), 0);
            int fl = flags[i];
            Track t = track(ni >= 0 && ni < names.length ? names[ni] : "node" + ni, fc);

            int b = i * stride;
            float[] bt = {f(base, b), f(base, b + 1), f(base, b + 2)};
            float[] br;
            float[] bs;
            float tMul, sMul;
            if (continuous) {
                br = new float[]{f(rot, i * 4) / 32767f, f(rot, i * 4 + 1) / 32767f, f(rot, i * 4 + 2) / 32767f, f(rot, i * 4 + 3) / 32767f};
                bs = new float[]{f(base, b + 3), f(base, b + 4), f(base, b + 5)};
                tMul = f(base, b + 6);
                sMul = f(base, b + 7);
            } else {
                br = new float[]{f(base, b + 3), f(base, b + 4), f(base, b + 5), f(base, b + 6)};
                bs = new float[]{f(base, b + 7), f(base, b + 8), f(base, b + 9)};
                tMul = f(base, b + 10);
                sMul = f(base, b + 11);
            }
            // raw (still quantized) keys, filled below
            int[][] keys = new int[fc][];
            int per = elements(fl);
            if (continuous) {
                int[] pos = {sequential};
                int end = sequential + dataSize;
                int frame = 0;
                if (fl != 0) {
                    while (frame < fc && pos[0] < end) {
                        if (frame != 0) {
                            int repeat = Math.abs((int) f(data, pos[0]++));
                            for (int k = 0; k < repeat && frame < fc; k++, frame++) keys[frame] = keys[frame - 1];
                        }
                        if (frame >= fc || pos[0] >= end) break;
                        int count = (int) f(data, pos[0]++);
                        for (int k = 0; k < count && frame < fc; k++, frame++) {
                            int[] key = new int[per];
                            for (int e = 0; e < per; e++) key[e] = (int) f(data, pos[0]++);
                            keys[frame] = key;
                        }
                    }
                    for (; frame < fc; frame++) keys[frame] = frame > 0 ? keys[frame - 1] : null;
                }
                if (fl != 0 && pos[0] != end) mismatched++;
                sequential = end;
            } else if (anyTime) {
                for (int frame = 0; frame < fc; frame++) {
                    int[] key = new int[per];
                    for (int e = 0; e < per; e++) key[e] = (int) f(data, sequential++);
                    keys[frame] = key;
                }
            } else {
                for (int frame = 0; frame < fc; frame++) {
                    int[] key = new int[per];
                    int p0 = frameStride * frame + nodeOffset;
                    for (int e = 0; e < per; e++) key[e] = (int) f(data, p0 + e);
                    keys[frame] = key;
                }
                nodeOffset += per;
            }
            // denormalize
            for (int frame = 0; frame < fc; frame++) {
                int[] key = keys[frame];
                int e = 0;
                if (key != null && (fl & 1) != 0) e++; // frame time: not needed
                for (int k = 0; k < 3; k++) t.t[frame * 3 + k] = bt[k];
                System.arraycopy(br, 0, t.r, frame * 4, 4);
                for (int k = 0; k < 3; k++) t.s[frame * 3 + k] = bs[k];
                if (key == null) continue;
                if ((fl & 2) != 0) for (int k = 0; k < 4; k++) t.r[frame * 4 + k] = key[e++] / 32767f;
                if ((fl & 4) != 0) for (int k = 0; k < 3; k++) t.t[frame * 3 + k] = bt[k] + key[e++] * tMul;
                if ((fl & 8) != 0 && (fl & 16) != 0) {
                    for (int k = 0; k < 3; k++) t.s[frame * 3 + k] = bs[k] + key[e++] * sMul;
                } else if ((fl & 8) != 0 || (fl & 16) != 0) {
                    float v = key[e++] * sMul;
                    for (int k = 0; k < 3; k++) t.s[frame * 3 + k] = bs[k] + v;
                }
            }
            normalize(t);
            tracks.put(t.name, t);
        }
        if (mismatched > 0) notes.add("кости с неполными данными: " + mismatched);
    }

    private int mismatched;

    static int elements(int fl) {
        int n = 0;
        if ((fl & 1) != 0) n += 1;
        if ((fl & 2) != 0) n += 4;
        if ((fl & 4) != 0) n += 3;
        if ((fl & 8) != 0 && (fl & 16) != 0) n += 3;
        else if ((fl & 8) != 0 || (fl & 16) != 0) n += 1;
        return n;
    }

    static float f(double[] a, int i) {
        return a != null && i >= 0 && i < a.length ? (float) a[i] : 0f;
    }

    private Track track(String name, int fc) {
        Track t = new Track();
        t.name = name;
        t.frames = fc;
        t.t = new float[fc * 3];
        t.r = new float[fc * 4];
        t.s = new float[fc * 3];
        for (int f = 0; f < fc; f++) {
            t.r[f * 4 + 3] = 1;
            for (int k = 0; k < 3; k++) t.s[f * 3 + k] = 1;
        }
        return t;
    }

    static void normalize(Track t) {
        for (int f = 0; f < t.frames; f++) {
            float x = t.r[f * 4], y = t.r[f * 4 + 1], z = t.r[f * 4 + 2], w = t.r[f * 4 + 3];
            float l = (float) Math.sqrt(x * x + y * y + z * z + w * w);
            if (l < 1e-6f) {
                t.r[f * 4] = t.r[f * 4 + 1] = t.r[f * 4 + 2] = 0;
                t.r[f * 4 + 3] = 1;
            } else {
                for (int k = 0; k < 4; k++) t.r[f * 4 + k] /= l;
            }
        }
    }

    /** raw accessor values (no normalization), Supercell flags in componentType masked off */
    private double[] accessor(int ai) {
        List<Object> accs = Model3d.list(g.json.get("accessors"));
        if (ai < 0 || ai >= accs.size()) return new double[0];
        Map<String, Object> a = Model3d.map(accs.get(ai));
        int count = Model3d.num(a.get("count"), 0);
        int ct = Model3d.num(a.get("componentType"), 5126) & 0xFFFF;
        String type = Model3d.str(a.get("type"), "SCALAR");
        int comps = type.equals("SCALAR") ? 1 : type.equals("VEC2") ? 2 : type.equals("VEC3") ? 3 : type.equals("VEC4") ? 4
                : type.equals("MAT4") ? 16 : 1;
        int bvi = Model3d.num(a.get("bufferView"), -1);
        double[] out = new double[count * comps];
        if (bvi < 0 || bvi >= views.size()) return out;
        int[] bv = views.get(bvi);
        int size = ct == 5120 || ct == 5121 ? 1 : ct == 5122 || ct == 5123 ? 2 : 4;
        int stride = bv[2] > 0 ? bv[2] : size * comps;
        int start = bv[0] + Model3d.num(a.get("byteOffset"), 0);
        byte[] b = g.bin;
        for (int i = 0; i < count; i++) {
            for (int k = 0; k < comps; k++) {
                int p = start + i * stride + k * size;
                if (p + size > b.length) return out;
                double v;
                switch (ct) {
                    case 5120: v = b[p]; break;
                    case 5121: v = b[p] & 0xFF; break;
                    case 5122: v = (short) Model3d.le16(b, p); break;
                    case 5123: v = Model3d.le16(b, p); break;
                    case 5125: v = Model3d.le32(b, p) & 0xFFFFFFFFL; break;
                    default: v = Float.intBitsToFloat(Model3d.le32(b, p)); break;
                }
                out[i * comps + k] = v;
            }
        }
        return out;
    }

    /** local matrix (column-major) of a track at a fractional frame */
    public static float[] sample(Track t, double frame) {
        int n = t.frames;
        double fr = Math.max(0, Math.min(n - 1, frame));
        int a = (int) Math.floor(fr), b = Math.min(n - 1, a + 1);
        float k = (float) (fr - a);
        float[] tr = new float[3], sc = new float[3], q = new float[4];
        for (int i = 0; i < 3; i++) {
            tr[i] = t.t[a * 3 + i] + (t.t[b * 3 + i] - t.t[a * 3 + i]) * k;
            sc[i] = t.s[a * 3 + i] + (t.s[b * 3 + i] - t.s[a * 3 + i]) * k;
        }
        float dot = 0;
        for (int i = 0; i < 4; i++) dot += t.r[a * 4 + i] * t.r[b * 4 + i];
        float sign = dot < 0 ? -1 : 1;
        float l = 0;
        for (int i = 0; i < 4; i++) {
            q[i] = t.r[a * 4 + i] * (1 - k) + t.r[b * 4 + i] * sign * k;
            l += q[i] * q[i];
        }
        l = (float) Math.sqrt(l);
        if (l > 0) for (int i = 0; i < 4; i++) q[i] /= l;
        return trs(tr, q, sc);
    }

    static float[] trs(float[] t, float[] q, float[] s) {
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float[] r = {
                1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0,
                2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0,
                2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0,
                t[0], t[1], t[2], 1};
        for (int c = 0; c < 3; c++) for (int k = 0; k < 3; k++) r[c * 4 + k] *= s[c];
        return r;
    }
}
