package com.weker.assetexplorer;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

import com.weker.assetexplorer.codec.Anim3d;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Render3d;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.IdentityHashMap;
import java.util.Map;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;

/**
 * GPU (OpenGL ES 2.0) view of a {@link Model3d}: full screen resolution, 4× antialiasing, mipmapped textures.
 * Same camera, matcap lighting and gestures as the CPU renderer ({@link Render3d}), so the PNG export matches.
 * If the GPU path fails, {@link #onFailed} is called and the screen switches to {@link SoftModelView}.
 */
public final class GlModelView extends GLSurfaceView implements ModelDisplay, GLSurfaceView.Renderer {

    private final Render3d render = new Render3d();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScaleGestureDetector scale;
    /** called on the UI thread when OpenGL can't be used */
    public Runnable onFailed;

    private volatile Model3d model;
    private volatile Map<String, Img> images;
    private volatile Img override;
    private volatile Anim3d anim;
    private int animStart, animEnd;
    private volatile boolean playing;
    private volatile float speed = 1f;
    private long playBase;
    private double pausedFrame;

    private float lastX, lastY, downX, downY;
    private long lastTap;
    private boolean moved;

    public GlModelView(Context c) {
        super(c);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(new Chooser());
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                render.zoom = Math.max(0.3f, Math.min(12f, render.zoom * d.getScaleFactor()));
                requestRender();
                return true;
            }
        });
    }

    // ------------------------------------------------------------------ ModelDisplay
    @Override
    public Render3d settings() { return render; }

    @Override
    public android.view.View view() { return this; }

    @Override
    public void setModel(Model3d m, Map<String, Img> imgs, Img tex) {
        model = m;
        images = imgs;
        override = tex;
        if (anim != null && m != null) render.frameBounds = m.animationBounds(anim, animStart, animEnd);
        requestRender();
    }

    @Override
    public synchronized void setAnimation(Anim3d a, int start, int end) {
        anim = a;
        if (a != null) {
            animStart = Math.max(0, Math.min(start, a.frames - 1));
            animEnd = end < 0 || end >= a.frames ? a.frames - 1 : Math.max(animStart, end);
        }
        pausedFrame = animStart;
        playBase = System.currentTimeMillis();
        Model3d m = model;
        render.frameBounds = a != null && m != null ? m.animationBounds(a, animStart, animEnd) : null;
        setPlaying(a != null);
        requestRender();
    }

    @Override
    public boolean isPlaying() { return playing; }

    @Override
    public synchronized void setPlaying(boolean p) {
        if (anim == null) p = false;
        if (p && !playing) {
            playBase = System.currentTimeMillis() - (long) ((pausedFrame - animStart) / (anim.fps * speed) * 1000);
        } else if (!p && playing) {
            pausedFrame = currentFrame();
        }
        playing = p;
        setRenderMode(p ? RENDERMODE_CONTINUOUSLY : RENDERMODE_WHEN_DIRTY);
        requestRender();
    }

    @Override
    public float speed() { return speed; }

    @Override
    public synchronized void setSpeed(float s) {
        double f = currentFrame();
        speed = s;
        if (anim != null) playBase = System.currentTimeMillis() - (long) ((f - animStart) / (anim.fps * speed) * 1000);
    }

    @Override
    public synchronized double currentFrame() {
        Anim3d a = anim;
        if (a == null) return 0;
        if (!playing) return pausedFrame;
        double len = Math.max(1, animEnd - animStart);
        double f = (System.currentTimeMillis() - playBase) / 1000.0 * a.fps * speed;
        return animStart + (f % len);
    }

    @Override
    public Model3d posedModel() {
        Model3d m = model;
        Anim3d a = anim;
        if (m == null || a == null) return m;
        return m.pose(a, currentFrame());
    }

    @Override
    public void resetView() {
        render.yaw = 0.5f;
        render.pitch = 0.2f;
        render.zoom = 1f;
        render.panX = render.panY = 0;
        requestRender();
    }

    @Override
    public void request(boolean fast) {
        requestRender();
    }

    @Override
    public void release() {
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    // ------------------------------------------------------------------ GL
    static final String VS = "attribute vec3 aPos;\n"
            + "attribute vec3 aNrm;\n"
            + "attribute vec2 aUv;\n"
            + "uniform mat4 uMvp;\n"
            + "uniform mat3 uRot;\n"
            + "varying vec2 vUv;\n"
            + "varying vec3 vN;\n"
            + "void main() {\n"
            + "  gl_Position = uMvp * vec4(aPos, 1.0);\n"
            + "  vN = uRot * aNrm;\n"
            + "  vUv = aUv;\n"
            + "}\n";

    /** uMode: 0 flat, 1 soft light, 2 matcap diffuse, 3 matcap diffuse + specular (same as Render3d) */
    static final String FS = "precision mediump float;\n"
            + "uniform sampler2D uTex;\n"
            + "uniform sampler2D uLmD;\n"
            + "uniform sampler2D uLmS;\n"
            + "uniform float uMode;\n"
            + "uniform float uTextured;\n"
            + "uniform float uFlip;\n"
            + "varying vec2 vUv;\n"
            + "varying vec3 vN;\n"
            + "void main() {\n"
            + "  vec4 c = vec4(0.77, 0.79, 0.83, 1.0);\n"
            + "  if (uTextured > 0.5) {\n"
            + "    vec2 uv = vec2(vUv.x, uFlip > 0.5 ? 1.0 - vUv.y : vUv.y);\n"
            + "    c = texture2D(uTex, uv);\n"
            + "    if (c.a < 0.4) discard;\n"
            + "  }\n"
            + "  vec3 n = normalize(vN);\n"
            + "  if (n.z < 0.0) n = -n;\n"
            + "  vec3 col = c.rgb;\n"
            + "  if (uMode > 0.5 && uMode < 1.5) {\n"
            + "    col *= 0.52 + 0.58 * max(0.0, dot(n, vec3(-0.45, 0.62, 0.64)));\n"
            + "  } else if (uMode > 1.5) {\n"
            + "    vec2 m = vec2(n.x * 0.48 + 0.5, 0.5 - n.y * 0.48);\n"
            + "    col *= texture2D(uLmD, m).rgb;\n"
            + "    if (uMode > 2.5) col += texture2D(uLmS, m).rgb;\n"
            + "  }\n"
            + "  gl_FragColor = vec4(min(col, vec3(1.0)), 1.0);\n"
            + "}\n";

    private int program, aPos, aNrm, aUv, uMvp, uRot, uTex, uLmD, uLmS, uMode, uTextured, uFlip;
    private int width = 1, height = 1;
    private boolean failed;
    /** textures uploaded to the GPU, by picture (pictures are replaced, not changed, so identity is enough) */
    private final Map<Img, Integer> gpuTextures = new IdentityHashMap<>();
    private int whiteTex;
    /** per-part UV buffers (static), keyed by the part's uv array */
    private final Map<float[], FloatBuffer> uvBuffers = new IdentityHashMap<>();
    private FloatBuffer posBuf, nrmBuf;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        gpuTextures.clear();
        uvBuffers.clear();
        try {
            program = link(compile(GLES20.GL_VERTEX_SHADER, VS), compile(GLES20.GL_FRAGMENT_SHADER, FS));
            aPos = GLES20.glGetAttribLocation(program, "aPos");
            aNrm = GLES20.glGetAttribLocation(program, "aNrm");
            aUv = GLES20.glGetAttribLocation(program, "aUv");
            uMvp = GLES20.glGetUniformLocation(program, "uMvp");
            uRot = GLES20.glGetUniformLocation(program, "uRot");
            uTex = GLES20.glGetUniformLocation(program, "uTex");
            uLmD = GLES20.glGetUniformLocation(program, "uLmD");
            uLmS = GLES20.glGetUniformLocation(program, "uLmS");
            uMode = GLES20.glGetUniformLocation(program, "uMode");
            uTextured = GLES20.glGetUniformLocation(program, "uTextured");
            uFlip = GLES20.glGetUniformLocation(program, "uFlip");
            whiteTex = upload(new Img(1, 1, new int[]{0xFFFFFFFF}));
        } catch (RuntimeException e) {
            fail();
        }
    }

    private void fail() {
        if (failed) return;
        failed = true;
        main.post(() -> {
            if (onFailed != null) onFailed.run();
        });
    }

    static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s));
        return s;
    }

    static int link(int vs, int fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, vs);
        GLES20.glAttachShader(p, fs);
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("link: " + GLES20.glGetProgramInfoLog(p));
        return p;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        GLES20.glViewport(0, 0, width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        int bg = render.background;
        GLES20.glClearColor(((bg >> 16) & 255) / 255f, ((bg >> 8) & 255) / 255f, (bg & 255) / 255f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Model3d m = model;
        if (failed || m == null) return;
        Anim3d a = anim;
        Model3d drawn = a != null ? m.pose(a, currentFrame()) : m;
        try {
            draw(drawn);
        } catch (RuntimeException e) {
            fail();
        }
    }

    private void draw(Model3d m) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthFunc(GLES20.GL_LEQUAL);
        GLES20.glDisable(GLES20.GL_CULL_FACE); // Supercell models use double-sided parts
        GLES20.glUseProgram(program);

        // camera: same numbers as Render3d.render
        float[] b = render.frameBounds != null ? render.frameBounds : m.bounds;
        float cx = (b[0] + b[3]) / 2, cy = (b[1] + b[4]) / 2, cz = (b[2] + b[5]) / 2;
        float dx = b[3] - b[0], dy = b[4] - b[1], dz = b[5] - b[2];
        float radius = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) / 2f * 0.82f;
        if (radius <= 0) radius = 1;
        double fov = Math.toRadians(30);
        float aspect = width / (float) height;
        float fit = Math.min(1, aspect);
        float dist = (float) (radius / Math.sin(fov / 2) / fit / render.zoom);
        float near = Math.max(dist - radius * 4, dist * 0.02f);
        float far = dist + radius * 4;

        float cyw = (float) Math.cos(render.yaw), syw = (float) Math.sin(render.yaw);
        float cp = (float) Math.cos(render.pitch), sp = (float) Math.sin(render.pitch);
        float[] r = {cyw, 0, -syw, syw * sp, cp, cyw * sp, syw * cp, -sp, cyw * cp}; // rows
        // model-view (column-major): rotate (centre moved to the origin), then move back by dist
        float[] mv = {
                r[0], r[3], r[6], 0,
                r[1], r[4], r[7], 0,
                r[2], r[5], r[8], 0,
                -(r[0] * cx + r[1] * cy + r[2] * cz), -(r[3] * cx + r[4] * cy + r[5] * cz), -(r[6] * cx + r[7] * cy + r[8] * cz) - dist, 1};
        float[] proj = new float[16];
        android.opengl.Matrix.perspectiveM(proj, 0, 30f, aspect, near, far);
        float[] pan = new float[16];
        android.opengl.Matrix.setIdentityM(pan, 0);
        pan[12] = render.panX * 2;
        pan[13] = -render.panY * 2;
        float[] pp = new float[16], mvp = new float[16];
        android.opengl.Matrix.multiplyMM(pp, 0, pan, 0, proj, 0);
        android.opengl.Matrix.multiplyMM(mvp, 0, pp, 0, mv, 0);
        float[] rot = {r[0], r[3], r[6], r[1], r[4], r[7], r[2], r[5], r[8]};
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
        GLES20.glUniformMatrix3fv(uRot, 1, false, rot, 0);
        GLES20.glUniform1i(uTex, 0);
        GLES20.glUniform1i(uLmD, 1);
        GLES20.glUniform1i(uLmS, 2);
        GLES20.glUniform1f(uFlip, render.flipV ? 1f : 0f);

        Map<String, Img> imgs = images;
        Img ov = override;
        for (Model3d.Part p : m.parts) {
            if (!p.visible || p.triangles == 0) continue;
            Img tex = null;
            if (render.textured && p.hasUv) tex = ov != null ? ov : imgs != null && p.diffuseTex != null ? imgs.get(p.diffuseTex) : null;
            Img lmD = render.lighting && imgs != null && p.lightmapDiffuse != null ? imgs.get(p.lightmapDiffuse) : null;
            Img lmS = render.lighting && imgs != null && p.lightmapSpecular != null ? imgs.get(p.lightmapSpecular) : null;
            float mode = !render.lighting ? 0 : lmD == null ? 1 : lmS == null ? 2 : 3;
            GLES20.glUniform1f(uMode, mode);
            GLES20.glUniform1f(uTextured, tex != null ? 1f : 0f);
            bind(0, tex);
            bind(1, lmD);
            bind(2, lmS);

            int n = p.triangles * 3;
            posBuf = fill(posBuf, p.pos, n * 3);
            nrmBuf = fill(nrmBuf, p.hasNormals ? p.nrm : faceNormals(p), n * 3);
            FloatBuffer uv = uvBuffers.get(p.uv);
            if (uv == null) {
                uv = fill(null, p.uv, n * 2);
                uvBuffers.put(p.uv, uv);
            }
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, posBuf);
            GLES20.glEnableVertexAttribArray(aNrm);
            GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 0, nrmBuf);
            GLES20.glEnableVertexAttribArray(aUv);
            GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 0, uv);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, n);
        }
    }

    /** flat normals for parts without their own */
    private float[] faceNormals(Model3d.Part p) {
        float[] out = new float[p.triangles * 9];
        for (int t = 0; t < p.triangles; t++) {
            int i = t * 9;
            float ax = p.pos[i + 3] - p.pos[i], ay = p.pos[i + 4] - p.pos[i + 1], az = p.pos[i + 5] - p.pos[i + 2];
            float bx = p.pos[i + 6] - p.pos[i], by = p.pos[i + 7] - p.pos[i + 1], bz = p.pos[i + 8] - p.pos[i + 2];
            float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            for (int k = 0; k < 3; k++) {
                out[i + k * 3] = nx;
                out[i + k * 3 + 1] = ny;
                out[i + k * 3 + 2] = nz;
            }
        }
        return out;
    }

    static FloatBuffer fill(FloatBuffer buf, float[] data, int n) {
        n = Math.min(n, data.length);
        if (buf == null || buf.capacity() < n) {
            buf = ByteBuffer.allocateDirect(Math.max(n, 16) * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        }
        buf.clear();
        buf.put(data, 0, n);
        buf.position(0);
        return buf;
    }

    private void bind(int unit, Img im) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit);
        int id = whiteTex;
        if (im != null) {
            Integer t = gpuTextures.get(im);
            if (t == null) {
                // forget pictures no longer used (face repainted, texture changed)
                if (gpuTextures.size() > 24) {
                    for (Integer old : gpuTextures.values()) GLES20.glDeleteTextures(1, new int[]{old}, 0);
                    gpuTextures.clear();
                }
                t = upload(im);
                gpuTextures.put(im, t);
            }
            id = t;
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
    }

    /** uploads straight (not premultiplied) RGBA so alpha cut-outs keep their colour; mipmaps when the size allows */
    static int upload(Img im) {
        int[] ids = new int[1];
        GLES20.glGenTextures(1, ids, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0]);
        ByteBuffer bb = ByteBuffer.allocateDirect(im.width * im.height * 4).order(ByteOrder.nativeOrder());
        for (int c : im.argb) {
            bb.put((byte) (c >> 16)).put((byte) (c >> 8)).put((byte) c).put((byte) (c >>> 24));
        }
        bb.position(0);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, im.width, im.height, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, bb);
        boolean pot = (im.width & (im.width - 1)) == 0 && (im.height & (im.height - 1)) == 0;
        if (pot) {
            GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT);
        } else {
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        }
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        return ids[0];
    }

    /** RGB888 + depth, 4× multisampling when the phone offers it */
    static final class Chooser implements EGLConfigChooser {
        @Override
        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int EGL_OPENGL_ES2_BIT = 4;
            int[][] attempts = {
                    {EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_DEPTH_SIZE, 16,
                            EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL10.EGL_SAMPLE_BUFFERS, 1, EGL10.EGL_SAMPLES, 4, EGL10.EGL_NONE},
                    {EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_DEPTH_SIZE, 16,
                            EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL10.EGL_NONE},
                    {EGL10.EGL_DEPTH_SIZE, 16, EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL10.EGL_NONE}};
            for (int[] attrs : attempts) {
                EGLConfig[] cfg = new EGLConfig[1];
                int[] num = new int[1];
                if (egl.eglChooseConfig(display, attrs, cfg, 1, num) && num[0] > 0 && cfg[0] != null) return cfg[0];
            }
            throw new IllegalArgumentException("no OpenGL ES 2 config");
        }
    }

    // ------------------------------------------------------------------ touch (same as SoftModelView)
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        getParent().requestDisallowInterceptTouchEvent(true);
        scale.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = downX = e.getX();
                lastY = downY = e.getY();
                moved = false;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_POINTER_UP:
                lastX = SoftModelView.avgX(e);
                lastY = SoftModelView.avgY(e);
                moved = true;
                break;
            case MotionEvent.ACTION_MOVE: {
                float x = SoftModelView.avgX(e), y = SoftModelView.avgY(e);
                float dx = x - lastX, dy = y - lastY;
                lastX = x;
                lastY = y;
                if (Math.abs(e.getX() - downX) + Math.abs(e.getY() - downY) > 12) moved = true;
                if (e.getPointerCount() >= 2) {
                    render.panX += dx / Math.max(1, getWidth());
                    render.panY += dy / Math.max(1, getHeight());
                } else if (!scale.isInProgress()) {
                    float s = (float) (Math.PI / Math.max(1, getWidth()));
                    render.yaw += dx * s;
                    render.pitch = Math.max(-1.5f, Math.min(1.5f, render.pitch + dy * s));
                }
                requestRender();
                break;
            }
            case MotionEvent.ACTION_UP: {
                long now = System.currentTimeMillis();
                if (!moved) {
                    if (now - lastTap < 300) resetView();
                    lastTap = now;
                }
                break;
            }
            default:
                break;
        }
        return true;
    }
}
