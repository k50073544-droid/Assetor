package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A map in 3D as the game builds it from location_themes.csv: the theme's ground and surroundings, a model for
 * every tile (walls turned by the theme's angle steps, crates, barrels, bushes, fences, decorations), water made
 * of the theme's shore pieces, spawn circles and the mode's objects. The same scenery is used by the map browser
 * and by battles, and any theme can be put on any map.
 */
public final class MapScene {

    public final GameDb.MapData map;
    public final Assets assets;
    public final String theme;
    Model3d ground, env, quad, disc, floor, mine;
    Map<String, Img> groundImg, envImg, mineImg;
    Assets.Actor ball, box;
    final Map<Character, Model3d> tileModel = new HashMap<>();
    final Map<Character, Map<String, Img>> tileImg = new HashMap<>();
    /** tile code → turn step in degrees (0 none, 1 any angle, 90 quarter turns) */
    final Map<Character, Integer> angleStep = new HashMap<>();
    /** water shore pieces by name (water_tile_mid_1, …) */
    final Map<String, Model3d> water = new HashMap<>();
    Map<String, Img> waterImg;
    boolean themeFloor, island;
    public int background = 0xFF2A3B2E;
    /** camera: turn around the map (radians), height angle (radians above the ground), distance in tiles */
    public float yaw = 0, pitch = 0.95f, dist = -1, cx, cz;

    public MapScene(GameDb.MapData m, Assets a, String mode) {
        map = m;
        assets = a;
        GameDb db = a.db;
        theme = m.theme == null || m.theme.isEmpty() ? "Default" : m.theme;
        String[] row = db.theme(theme);
        GameDb.Table th = db.table("location_themes.csv");
        if (row != null) {
            island = th.flag(row, "Island");
            int r = th.num(row, "MapPreviewBGColorRed", -1), g = th.num(row, "MapPreviewBGColorGreen", -1), b = th.num(row, "MapPreviewBGColorBlue", -1);
            if (r >= 0 && g >= 0 && b >= 0) background = 0xFF000000 | (r * 3 / 4) << 16 | (g * 3 / 4) << 8 | (b * 3 / 4);
        }
        ground = model(db.themeModel(theme, "GroundModel"), "GroundModel");
        env = model(db.themeModel(theme, "EnvironmentModel"), null);
        groundImg = a.imagesFor(ground);
        envImg = a.imagesFor(env);
        ground = outside(ground, true);
        env = outside(env, false);
        tile('M', "Wall1");
        tile('X', "Wall2");
        tile('Y', "Crate");
        tile('C', "Barrel");
        tile('T', "Themed");
        tile('B', "Fragile");
        tile('D', "Clutter");
        tile('N', "Fence");
        tile('a', "RopeFence");
        tile('I', "Indestructible");
        tile('E', "IndestructibleFence");
        tile('F', "Grass");
        tile('È', "IndestructibleDeco1");
        tile('É', "IndestructibleDeco2");
        tile('Ê', "IndestructibleDeco3");
        tile('Ë', "IndestructibleDeco4");
        tile('À', "Damageable1");
        tile('Á', "Damageable2");
        tile('Â', "Damageable3");
        tile('Ã', "Damageable4");
        if (tileModel.containsKey('F')) {
            tileModel.put('R', tileModel.get('F'));
            tileImg.put('R', tileImg.get('F'));
        }
        Model3d wm = model(db.themeModel(theme, "WaterTileModel"), "WaterTileModel");
        if (wm != null) {
            for (Model3d.Part p : wm.parts) {
                Model3d one = wm.only(p.name);
                if (one != null) water.put(p.name.toLowerCase(java.util.Locale.ROOT), one);
            }
            waterImg = a.imagesFor(wm);
        }
        quad = Scene3d.quad();
        disc = Scene3d.disc(24);
        String md = mode == null ? "" : mode.toLowerCase(java.util.Locale.ROOT);
        if (md.contains("gem")) {
            String gm = db.themeModel(theme, "MineGemSpawnModelOverride");
            mine = a.model(gm != null ? gm : "default_gem_spawn_geo.glb");
            if (mine == null) mine = a.model("default_gem_spawn_geo.glb");
            mineImg = a.imagesFor(mine);
        }
        if (md.contains("ball") || md.contains("hockey")) {
            Assets.Actor b = a.actor(md.contains("hockey") ? "AirDiscDefault" : "BallDefault");
            if (b == null || b.model == null) b = a.actor("BallDefault");
            if (b != null && b.model != null) ball = b;
        }
        if (hasCode('4')) {
            String over = row == null ? "" : th.get(row, "LootBoxSkinOverride");
            box = a.actor(over.isEmpty() ? "LootBox" : over);
            if (box == null || box.model == null) box = a.actor("LootBox");
        }
        cx = m.width / 2f;
        cz = m.height / 2f;
    }

    /** a theme's model; a file this archive doesn't have falls back to the Default theme's */
    Model3d model(String file, String column) {
        Model3d m = file == null ? null : assets.model(file);
        if (m == null && column != null && !"Default".equals(theme)) {
            GameDb.Table t = assets.db.table("location_themes.csv");
            String[] d = t.row("Default");
            String v = d == null ? "" : t.get(d, column);
            if (!v.isEmpty()) m = assets.model(GameDb.fileName(v));
        }
        return m;
    }

    boolean hasCode(char ch) {
        for (char[] r : map.cells) for (char c : r) if (c == ch) return true;
        return false;
    }

    /** every theme of location_themes.csv: {name, title} (switched-off ones last) */
    public static List<String[]> themes(GameDb db) {
        List<String[]> on = new ArrayList<>(), off = new ArrayList<>();
        GameDb.Table t = db.table("location_themes.csv");
        for (String[] r : t.rows) {
            if (r.length == 0 || r[0].isEmpty() || t.get(r, "GroundModel").isEmpty()) continue;
            String title = GameDb.nice(r[0]) + (t.flag(r, "Island") ? " (остров)" : "");
            (t.flag(r, "Disabled") ? off : on).add(new String[]{r[0], title + (t.flag(r, "Disabled") ? " · скрыта" : "")});
        }
        on.addAll(off);
        return on;
    }

    /** scenery is shared by maps of different sizes: keep what lies around the field (and a floor plate under all of it) */
    Model3d outside(Model3d m, boolean isGround) {
        if (m == null) return null;
        float W = map.width, H = map.height;
        Model3d out = Model3d.empty();
        for (Model3d.Part p : m.parts) {
            float x0 = Float.MAX_VALUE, x1 = -Float.MAX_VALUE, z0 = Float.MAX_VALUE, z1 = -Float.MAX_VALUE, h0 = Float.MAX_VALUE, h1 = -Float.MAX_VALUE;
            for (int i = 0; i + 2 < p.pos.length; i += 3) {
                float x = p.pos[i], z = -p.pos[i + 1], h = p.pos[i + 2];
                x0 = Math.min(x0, x);
                x1 = Math.max(x1, x);
                z0 = Math.min(z0, z);
                z1 = Math.max(z1, z);
                h0 = Math.min(h0, h);
                h1 = Math.max(h1, h);
            }
            boolean covers = x0 <= 0.6f && x1 >= W - 0.6f && z0 <= 0.6f && z1 >= H - 0.6f && h1 - h0 < 1.5f;
            boolean inside = x1 > 0.7f && x0 < W - 0.7f && z1 > 0.7f && z0 < H - 0.7f;
            if (covers && isGround) themeFloor = true;
            if (isGround || covers || !inside) out.parts.add(p);
        }
        out.bounds = m.bounds;
        for (Model3d.Part p : out.parts) out.triangles += p.triangles;
        return out.parts.isEmpty() ? null : out;
    }

    /** a tile model from the theme's {@code <key>Model} / {@code <key>Submesh} / {@code <key>AngleStep} columns */
    void tile(char code, String key) {
        GameDb db = assets.db;
        String modelCol = code == 'F' ? "Grass" : key + "Model";
        Model3d m = model(db.themeModel(theme, modelCol), modelCol);
        if (m == null) return;
        String sub = db.themeSubmesh(theme, key + "Submesh");
        if (sub == null && code == 'F') sub = "grass_1";
        Model3d part = sub != null ? m.only(sub) : null;
        if (part == null && code != 'F' && m.parts.size() > 1) part = m.only(m.parts.get(0).name);
        if (part == null) part = m;
        tileModel.put(code, part);
        tileImg.put(code, assets.imagesFor(m));
        GameDb.Table t = db.table("location_themes.csv");
        String[] r = t.row(theme);
        if (r != null && t.has(key + "AngleStep")) angleStep.put(code, t.num(r, key + "AngleStep", 0));
    }

    char cell(char[][] cells, int c, int r) {
        if (r < 0 || c < 0 || r >= cells.length || c >= cells[0].length) return 'J';
        return cells[r][c];
    }

    /** the default distance that shows the whole map */
    public float fitDistance(float aspect) {
        float s = Math.max(map.height, map.width / Math.max(0.5f, aspect));
        return s * 1.45f + 4;
    }

    /** the map browser's view: everything, turned by the orbit camera */
    public Scene3d build(float aspect) {
        Scene3d s = new Scene3d();
        s.background = background;
        s.fovY = 40;
        if (dist <= 0) dist = fitDistance(aspect);
        s.near = Math.max(0.5f, dist * 0.05f);
        s.far = dist * 4 + 80;
        float ch = (float) Math.cos(pitch);
        float ex = cx + (float) Math.sin(yaw) * ch * dist, ez = cz + (float) Math.cos(yaw) * ch * dist, ey = (float) Math.sin(pitch) * dist;
        s.view = Scene3d.lookAt(ex, ey, ez, cx, 0, cz);
        addScenery(s, map.cells, 0, map.width - 1, 0, map.height - 1, -99, -99, true);
        if (mine != null) s.add(mine, mineImg, Scene3d.mul(Scene3d.translate(map.width / 2f, 0, map.height / 2f), Scene3d.zUp())).still = true;
        if (ball != null && MapPlan.centerMark(map, "ball") != 0) {
            float k = 0.8f / Math.max(0.1f, ball.height());
            Scene3d.Item it = s.add(ball.model, ball.images, Scene3d.mul(Scene3d.translate(map.width / 2f, 0, map.height / 2f), Scene3d.scale(k)));
            it.override = ball.override;
            it.still = true;
        }
        if (box != null && box.model != null) {
            for (int r = 0; r < map.height; r++) {
                for (int c = 0; c < map.width; c++) {
                    if (map.cells[r][c] != '4') continue;
                    Scene3d.Item it = s.add(box.model, box.images, Scene3d.mul(Scene3d.translate(c + 0.5f, 0, r + 0.5f), Scene3d.scale(Showcase.CHAR_SCALE * 1.1f)));
                    it.override = box.override;
                    it.still = true;
                }
            }
        }
        return s;
    }

    /**
     * Ground, surroundings, floor, water and the tiles in columns c0..c1, rows r0..r1 of {@code cells}
     * (a battle passes its own cells: broken walls are gone). Bushes near (hx, hz) turn see-through;
     * {@code marks} draws spawn / objective circles and floor pads (the map browser).
     */
    public void addScenery(Scene3d s, char[][] cells, int c0, int c1, int r0, int r1, float hx, float hz, boolean marks) {
        float[] zUp = Scene3d.zUp();
        if (ground != null) {
            Scene3d.Item g = s.add(ground, groundImg, zUp);
            g.still = true;
            g.background = true;
        }
        if (!themeFloor) {
            if (floor == null) floor = floor(cells, map.width, map.height);
            Scene3d.Item fl = s.add(floor, null, Scene3d.translate(0, 0.01f, 0));
            fl.still = true;
            fl.vertexColors = true;
        }
        if (env != null) s.add(env, envImg, zUp).still = true;
        for (int r = Math.max(0, r0); r <= Math.min(map.height - 1, r1); r++) {
            for (int c = Math.max(0, c0); c <= Math.min(map.width - 1, c1); c++) {
                char code = cells[r][c];
                if (code == '.' || code == 'J' || code == '=') continue;
                if (code == 'W') {
                    water(s, cells, c, r);
                    continue;
                }
                if (code == 'V') continue; // invisible water: blocks the way, not drawn
                if (marks) {
                    int mark = MapPlan.markColor(code);
                    if (mark != 0 && code != '4') {
                        Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(c + 0.5f, 0.04f, r + 0.5f), Scene3d.scale(0.42f, 1, 0.42f)));
                        it.color = (mark & 0x00FFFFFF) | 0xAA000000;
                        it.overlay = true;
                        it.still = true;
                    }
                }
                int pad = MapPlan.padColor(code);
                if (pad != 0) {
                    Scene3d.Item it = s.add(quad, null, Scene3d.translate(c, 0.025f, r));
                    it.color = (pad & 0x00FFFFFF) | 0x99000000;
                    it.overlay = true;
                    it.still = true;
                }
                Model3d m = tileModel.get(code);
                if (m == null) continue;
                float turn = turn(code, c, r);
                float[] at = Scene3d.translate(c + 0.5f, 0, r + 0.5f);
                if (turn != 0) at = Scene3d.mul(at, Scene3d.rotateY(turn));
                Scene3d.Item it = s.add(m, tileImg.get(code), Scene3d.mul(at, zUp));
                it.still = true;
                if ((code == 'F' || code == 'R') && Math.abs(c + 0.5f - hx) < 1.6f && Math.abs(r + 0.5f - hz) < 1.6f) it.color = 0x88FFFFFF;
            }
        }
    }

    /** the theme's turn for a tile: the same on every frame (from its position), in the theme's steps */
    float turn(char code, int c, int r) {
        Integer step = angleStep.get(code);
        if (step == null || step <= 0) return 0;
        int h = (c * 73856093) ^ (r * 19349663);
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        int deg = step >= 360 ? 0 : (Math.abs(h) % Math.max(1, 360 / step)) * step;
        return (float) Math.toRadians(deg);
    }

    static boolean wet(char ch) {
        return ch == 'W' || ch == 'V';
    }

    /**
     * Water as the game draws it: one of the theme's shore pieces chosen by which sides and corners are land,
     * turned to fit (bot = land to the south, corners 1..4 = NW, NE, SE, SW). Without a water model: plain blue.
     */
    void water(Scene3d s, char[][] cells, int c, int r) {
        // outside the map counts as water, so the sea runs off the edge
        boolean n = !wet(cell(cells, c, r - 1)) && r > 0, e = !wet(cell(cells, c + 1, r)) && c < map.width - 1,
                so = !wet(cell(cells, c, r + 1)) && r < map.height - 1, w = !wet(cell(cells, c - 1, r)) && c > 0;
        int sides = (n ? 1 : 0) | (e ? 2 : 0) | (so ? 4 : 0) | (w ? 8 : 0);
        int corners = 0;
        if (!n && !w && r > 0 && c > 0 && !wet(cell(cells, c - 1, r - 1))) corners |= 1;
        if (!n && !e && r > 0 && c < map.width - 1 && !wet(cell(cells, c + 1, r - 1))) corners |= 2;
        if (!so && !e && r < map.height - 1 && c < map.width - 1 && !wet(cell(cells, c + 1, r + 1))) corners |= 4;
        if (!so && !w && r < map.height - 1 && c > 0 && !wet(cell(cells, c - 1, r + 1))) corners |= 8;
        if (!water.isEmpty()) {
            for (int k = 0; k < 4; k++) {
                // turn the cell's pattern back k quarter turns and look for a piece drawn that way
                int sd = rot(sides, -k), cn = rot(corners, -k);
                String piece = piece(sd, cn);
                Model3d m = piece == null ? null : water.get(piece);
                if (m == null) continue;
                float[] at = Scene3d.mul(Scene3d.translate(c + 0.5f, 0, r + 0.5f), Scene3d.rotateY((float) (-k * Math.PI / 2)));
                Scene3d.Item it = s.add(m, waterImg, Scene3d.mul(at, Scene3d.zUp()));
                it.still = true;
                return;
            }
        }
        Scene3d.Item it = s.add(quad, null, Scene3d.translate(c, 0.02f, r));
        it.color = island ? 0xFF2C8ED6 : 0xFF34A6EC;
        it.still = true;
    }

    /** a 4-bit ring (N/E/S/W or NW/NE/SE/SW) turned by k quarter turns clockwise */
    static int rot(int v, int k) {
        k = ((k % 4) + 4) % 4;
        for (int i = 0; i < k; i++) v = ((v << 1) | (v >> 3)) & 15;
        return v;
    }

    /** the piece for sides (N1 E2 S4 W8) and inner corners (NW1 NE2 SE4 SW8), drawn with land to the south */
    static String piece(int sides, int corners) {
        switch (sides) {
            case 0:
                switch (corners) {
                    case 0: return "water_tile_mid_1";
                    case 1: return "water_tile_c1_1";
                    case 3: return "water_tile_c12_1";
                    case 5: return "water_tile_c13_1";
                    case 7: return "water_tile_c123_1";
                    case 15: return "water_tile_c1234_1";
                    default: return null;
                }
            case 4:
                switch (corners & 3) {
                    case 0: return "water_tile_bot_1";
                    case 1: return "water_tile_botc1_1";
                    case 2: return "water_tile_botc2_1";
                    default: return "water_tile_botc12_1";
                }
            case 5: return "water_tile_topbot_1";
            case 12: return (corners & 2) != 0 ? "water_tile_botleftc2_1" : "water_tile_botleft_1";
            case 14: return "water_tile_botend_1";
            case 15: return "water_tile_single";
            default: return null;
        }
    }

    /** a light checkerboard under the field (only where the theme has no floor plate); none outside the field */
    static Model3d floor(char[][] cells, int w, int h) {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "floor";
        int n = 0;
        for (int r = 0; r < h; r++) for (int c = 0; c < w; c++) if (cells == null || (cells[r][c] != 'J' && cells[r][c] != '=')) n++;
        p.triangles = n * 2;
        p.pos = new float[p.triangles * 9];
        p.nrm = new float[p.triangles * 9];
        p.uv = new float[p.triangles * 6];
        p.colors = new int[p.triangles * 3];
        p.hasNormals = true;
        int t = 0;
        for (int r = 0; r < h; r++) {
            for (int c = 0; c < w; c++) {
                if (cells != null && (cells[r][c] == 'J' || cells[r][c] == '=')) continue;
                int col = ((r + c) & 1) == 0 ? 0xFFEBC596 : 0xFFE2B887;
                float[] q = {c, 0, r, c + 1, 0, r, c + 1, 0, r + 1, c, 0, r, c + 1, 0, r + 1, c, 0, r + 1};
                for (int k = 0; k < 6; k++) {
                    p.pos[t * 9 + k * 3] = q[k * 3];
                    p.pos[t * 9 + k * 3 + 2] = q[k * 3 + 2];
                    p.nrm[t * 9 + k * 3 + 1] = 1;
                    p.colors[t * 3 + k] = col;
                }
                t += 2;
            }
        }
        m.parts.add(p);
        m.triangles = p.triangles;
        m.bounds = new float[]{0, 0, 0, w, 0, h};
        return m;
    }

    static Model3d floor(int w, int h) {
        return floor(null, w, h);
    }
}
