package com.weker.assetexplorer.codec;

import java.util.HashMap;
import java.util.Map;

/**
 * A map in 3D as the game builds it: the location theme's ground and surroundings, a model for every tile
 * (walls, crates, barrels, bushes, fences, water…), spawn circles and the mode's objects; looked at by an
 * orbiting camera.
 */
public final class MapScene {

    public final GameDb.MapData map;
    public final Assets assets;
    public final String theme;
    Model3d ground, env, quad, disc, floor, mine, ball;
    Map<String, Img> groundImg, envImg, mineImg, ballImg;
    final Map<Character, Model3d> tileModel = new HashMap<>();
    final Map<Character, Map<String, Img>> tileImg = new HashMap<>();
    boolean themeFloor;
    /** camera: turn around the map (radians), height angle (radians above the ground), distance in tiles */
    public float yaw = 0, pitch = 0.95f, dist = -1, cx, cz;

    public MapScene(GameDb.MapData m, Assets a, String mode) {
        map = m;
        assets = a;
        GameDb db = a.db;
        theme = m.theme == null || m.theme.isEmpty() ? "Default" : m.theme;
        ground = a.model(db.themeModel(theme, "GroundModel"));
        env = a.model(db.themeModel(theme, "EnvironmentModel"));
        groundImg = a.imagesFor(ground);
        envImg = a.imagesFor(env);
        ground = outside(ground, true);
        env = outside(env, false);
        tile('M', "Wall1Model", "Wall1Submesh");
        tile('X', "Wall2Model", "Wall2Submesh");
        tile('Y', "CrateModel", "CrateSubmesh");
        tile('C', "BarrelModel", "BarrelSubmesh");
        tile('T', "ThemedModel", "ThemedSubmesh");
        tile('B', "FragileModel", "FragileSubmesh");
        tile('D', "ClutterModel", "ClutterSubmesh");
        tile('N', "FenceModel", null);
        tile('a', "RopeFenceModel", null);
        tile('I', "IndestructibleModel", null);
        tile('E', "IndestructibleFenceModel", null);
        tile('F', "Grass", null);
        tile('È', "IndestructibleDeco1Model", "IndestructibleDeco1Submesh");
        tile('É', "IndestructibleDeco2Model", "IndestructibleDeco2Submesh");
        tile('Ê', "IndestructibleDeco3Model", "IndestructibleDeco3Submesh");
        tile('Ë', "IndestructibleDeco4Model", "IndestructibleDeco4Submesh");
        tile('À', "Damageable1Model", "Damageable1Submesh");
        tile('Á', "Damageable2Model", "Damageable2Submesh");
        tile('Â', "Damageable3Model", "Damageable3Submesh");
        tile('Ã', "Damageable4Model", "Damageable4Submesh");
        if (tileModel.containsKey('F')) {
            tileModel.put('R', tileModel.get('F'));
            tileImg.put('R', tileImg.get('F'));
        }
        quad = Scene3d.quad();
        disc = Scene3d.disc(24);
        String md = mode == null ? "" : mode.toLowerCase(java.util.Locale.ROOT);
        if (md.contains("gem")) {
            String gm = db.themeModel(theme, "MineGemSpawnModelOverride");
            mine = a.model(gm != null ? gm : "default_gem_spawn_geo.glb");
            if (mine == null) mine = a.model("default_gem_spawn_geo.glb");
            mineImg = a.imagesFor(mine);
        }
        if (md.contains("ball") || md.contains("laser")) {
            Assets.Actor b = a.actor("BallDefault");
            if (b != null && b.model != null) {
                ball = b.model;
                ballImg = b.images;
            }
        }
        cx = m.width / 2f;
        cz = m.height / 2f;
    }

    /** scenery is shared by maps of different sizes: keep what lies around the field (and a floor plate under all of it) */
    Model3d outside(Model3d m, boolean isGround) {
        if (m == null) return null;
        float W = map.width, H = map.height;
        Model3d out = Model3d.empty();
        for (Model3d.Part p : m.parts) {
            float x0 = Float.MAX_VALUE, x1 = -Float.MAX_VALUE, z0 = Float.MAX_VALUE, z1 = -Float.MAX_VALUE, h0 = Float.MAX_VALUE, h1 = -Float.MAX_VALUE;
            for (int i = 0; i + 2 < p.pos.length; i += 3) {
                float x = p.pos[i], z = -p.pos[i + 1], h = p.pos[i + 2];
                x0 = Math.min(x0, x);
                x1 = Math.max(x1, x);
                z0 = Math.min(z0, z);
                z1 = Math.max(z1, z);
                h0 = Math.min(h0, h);
                h1 = Math.max(h1, h);
            }
            boolean covers = x0 <= 0.6f && x1 >= W - 0.6f && z0 <= 0.6f && z1 >= H - 0.6f && h1 - h0 < 1.5f;
            boolean inside = x1 > 0.7f && x0 < W - 0.7f && z1 > 0.7f && z0 < H - 0.7f;
            if (covers && isGround) themeFloor = true;
            if (isGround || covers || !inside) out.parts.add(p);
        }
        out.bounds = m.bounds;
        for (Model3d.Part p : out.parts) out.triangles += p.triangles;
        return out.parts.isEmpty() ? null : out;
    }

    void tile(char code, String modelCol, String subCol) {
        GameDb db = assets.db;
        Model3d m = assets.model(db.themeModel(theme, modelCol));
        if (m == null) return;
        String sub = subCol == null ? null : db.themeSubmesh(theme, subCol);
        if (sub == null && subCol == null && code == 'F') sub = "grass_1";
        Model3d part = sub != null ? m.only(sub) : null;
        if (part == null && code != 'F' && m.parts.size() > 1) part = m.only(m.parts.get(0).name);
        if (part == null) part = m;
        tileModel.put(code, part);
        tileImg.put(code, assets.imagesFor(part));
    }

    char cell(int c, int r) {
        if (r < 0 || c < 0 || r >= map.height || c >= map.width) return 'M';
        return map.cells[r][c];
    }

    /** the default distance that shows the whole map */
    public float fitDistance(float aspect) {
        float s = Math.max(map.height, map.width / Math.max(0.5f, aspect));
        return s * 1.45f + 4;
    }

    public Scene3d build(float aspect) {
        Scene3d s = new Scene3d();
        s.background = 0xFF2A3B2E;
        s.fovY = 40;
        if (dist <= 0) dist = fitDistance(aspect);
        s.near = Math.max(0.5f, dist * 0.05f);
        s.far = dist * 4 + 80;
        float ch = (float) Math.cos(pitch);
        float ex = cx + (float) Math.sin(yaw) * ch * dist, ez = cz + (float) Math.cos(yaw) * ch * dist, ey = (float) Math.sin(pitch) * dist;
        s.view = Scene3d.lookAt(ex, ey, ez, cx, 0, cz);
        float[] zUp = Scene3d.zUp();
        if (ground != null) {
            Scene3d.Item g = s.add(ground, groundImg, zUp);
            g.still = true;
            g.background = true;
        }
        if (!themeFloor) {
            if (floor == null) floor = floor(map.width, map.height);
            Scene3d.Item fl = s.add(floor, null, Scene3d.translate(0, 0.01f, 0));
            fl.still = true;
            fl.vertexColors = true;
        }
        if (env != null) s.add(env, envImg, zUp).still = true;
        if (mine != null) s.add(mine, mineImg, Scene3d.mul(Scene3d.translate(map.width / 2f, 0, map.height / 2f), zUp)).still = true;
        if (ball != null) {
            float k = 0.8f / Math.max(0.1f, ball.bounds == null ? 1 : ball.bounds[4] - ball.bounds[1]);
            s.add(ball, ballImg, Scene3d.mul(Scene3d.translate(map.width / 2f, 0, map.height / 2f), Scene3d.scale(k))).still = true;
        }
        for (int r = 0; r < map.height; r++) {
            for (int c = 0; c < map.width; c++) {
                char code = map.cells[r][c];
                if (code == '.' || code == 'J' || code == '=') continue;
                if (code == 'W' || code == 'V') {
                    Scene3d.Item it = s.add(quad, null, Scene3d.translate(c, 0.03f, r));
                    it.color = 0xFF34A6EC;
                    it.overlay = true;
                    it.still = true;
                    float t = 0.13f;
                    if (!water(c, r - 1)) rim(s, c, r, 1, t);
                    if (!water(c, r + 1)) rim(s, c, r + 1 - t, 1, t);
                    if (!water(c - 1, r)) rim(s, c, r, t, 1);
                    if (!water(c + 1, r)) rim(s, c + 1 - t, r, t, 1);
                    continue;
                }
                int mark = MapPlan.markColor(code);
                if (mark != 0) {
                    Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(c + 0.5f, 0.04f, r + 0.5f), Scene3d.scale(0.42f, 1, 0.42f)));
                    it.color = (mark & 0x00FFFFFF) | 0xAA000000;
                    it.overlay = true;
                    it.still = true;
                }
                int pad = MapPlan.padColor(code);
                if (pad != 0) {
                    Scene3d.Item it = s.add(quad, null, Scene3d.translate(c, 0.025f, r));
                    it.color = (pad & 0x00FFFFFF) | 0x99000000;
                    it.overlay = true;
                    it.still = true;
                }
                Model3d m = tileModel.get(code);
                if (m == null) continue;
                s.add(m, tileImg.get(code), Scene3d.mul(Scene3d.translate(c + 0.5f, 0, r + 0.5f), zUp)).still = true;
            }
        }
        return s;
    }

    boolean water(int c, int r) {
        char ch = cell(c, r);
        return ch == 'W' || ch == 'V';
    }

    void rim(Scene3d s, float x, float z, float w, float h) {
        Scene3d.Item it = s.add(quad, null, Scene3d.mul(Scene3d.translate(x, 0.05f, z), Scene3d.scale(w, 1, h)));
        it.color = 0xFFF3A0A0;
        it.overlay = true;
        it.still = true;
    }

    static Model3d floor(int w, int h) {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "floor";
        p.triangles = w * h * 2;
        p.pos = new float[p.triangles * 9];
        p.nrm = new float[p.triangles * 9];
        p.uv = new float[p.triangles * 6];
        p.colors = new int[p.triangles * 3];
        p.hasNormals = true;
        int t = 0;
        for (int r = 0; r < h; r++) {
            for (int c = 0; c < w; c++) {
                int col = ((r + c) & 1) == 0 ? 0xFFEBC596 : 0xFFE2B887;
                float[] q = {c, 0, r, c + 1, 0, r, c + 1, 0, r + 1, c, 0, r, c + 1, 0, r + 1, c, 0, r + 1};
                for (int k = 0; k < 6; k++) {
                    p.pos[t * 9 + k * 3] = q[k * 3];
                    p.pos[t * 9 + k * 3 + 2] = q[k * 3 + 2];
                    p.nrm[t * 9 + k * 3 + 1] = 1;
                    p.colors[t * 3 + k] = col;
                }
                t += 2;
            }
        }
        m.parts.add(p);
        m.triangles = p.triangles;
        m.bounds = new float[]{0, 0, 0, w, 0, h};
        return m;
    }
}
