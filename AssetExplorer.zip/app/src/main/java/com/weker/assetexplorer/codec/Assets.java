package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Loads and caches 3D models, textures and animations by file name (through a {@link GameDb.Source}),
 * and builds animated characters from the game's skin tables (skins.csv → skin_confs.csv → animations.csv / faces.csv).
 */
public final class Assets {

    /** turns a .png / .jpg into pixels (platform dependent); .sctx / .ktx are decoded here */
    public interface ImageDecoder {
        Img decode(byte[] data);
    }

    public final GameDb db;
    final GameDb.Source src;
    public ImageDecoder images;
    final Map<String, Model3d> models = new HashMap<>();
    final Map<String, Img> textures = new HashMap<>();
    final Map<String, Anim3d> anims = new HashMap<>();
    final Map<String, Sc2> scs = new HashMap<>();
    public final List<String> missing = new ArrayList<>();

    public Assets(GameDb db, GameDb.Source src) {
        this.db = db;
        this.src = src;
    }

    public synchronized Model3d model(String file) {
        if (file == null) return null;
        if (models.containsKey(file)) return models.get(file);
        Model3d m = null;
        try {
            byte[] d = src.read(file);
            if (d != null) m = Model3d.load(d);
            else missing.add(file);
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        models.put(file, m);
        return m;
    }

    /** drops decoded textures (a battle on low graphics kept them at half size) */
    public synchronized void forgetTextures() {
        textures.clear();
    }

    public synchronized Img texture(String name) {
        if (name == null) return null;
        if (textures.containsKey(name)) return textures.get(name);
        String file = name;
        Img im = null;
        if (name.contains("#")) { // a 2D export as texture: file#w,h,export
            try {
                String[] f = name.split("#", 2);
                String[] v = f[1].split(",");
                Sc2 sc = sc(f[0]);
                if (sc != null && v.length >= 3) {
                    int size = Math.max(64, Math.min(256, Integer.parseInt(v[0].trim()) * 4));
                    synchronized (sc) {
                        im = sc.renderExport(v[2].trim(), size);
                    }
                    if (im != null && (im.width != im.height)) im = square(im);
                }
            } catch (Throwable e) {
                im = null;
            }
            if (im == null) missing.add(name);
            textures.put(name, im);
            return im;
        }
        try {
            byte[] d = src.read(file);
            String base = file.contains(".") ? file.substring(0, file.lastIndexOf('.')) : file;
            for (String ext : new String[]{".sctx", ".ktx", ".png"}) {
                if (d != null) break;
                if (file.endsWith(ext)) continue;
                d = src.read(base + ext);
                if (d != null) file = base + ext;
            }
            if (d == null) {
                missing.add(file);
            } else {
                String n = file.toLowerCase(Locale.ROOT);
                if ((n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")) && images != null) {
                    im = images.decode(d);
                } else {
                    Img.Gpu g = gpuTextures ? SupercellFiles.gpuTexture(d) : null;
                    if (g != null) { // stays compressed: the graphics chip reads ASTC itself
                        im = new Img(g.width[0], g.height[0], null);
                        im.gpu = g;
                    } else {
                        SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(d, file);
                        if (!ts.images.isEmpty()) im = ts.images.get(0);
                    }
                }
            }
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        while (im != null && im.argb != null && MAX_TEXTURE > 0 && Math.max(im.width, im.height) > MAX_TEXTURE && im.width > 1 && im.height > 1) im = half(im);
        textures.put(name, im);
        return im;
    }

    /**
     * Battles keep textures the way the game's files store them (ASTC with mip levels) and hand them to the GPU
     * as they are: nothing is decoded while loading, and a texture takes 8–16 times less memory.
     */
    public boolean gpuTextures;
    /** battles use the in-game lightmaps where a material names the lobby ("menu_…") ones */
    public boolean ingameLight;

    /** the pixels of a texture, decoded if it was kept compressed */
    public static Img pixels(Img im) {
        if (im == null || im.argb != null || im.gpu == null) return im;
        return SupercellFiles.decode(im.gpu);
    }

    static final String[][] INGAME_LIGHT = {
            {"menu_diffuse_lightmap", "diffuse_lightmap"}, {"menu_specular_lightmap", "specular_lightmap"},
            {"menu_metal_diffuse_lightmap", "metal_diffuse_lightmap"}, {"menu_metal_specular_lightmap", "metal_specular_lightmap"},
            {"menu_silver_specular_lightmap", "metal_specular_lightmap"}, {"menu_gold_specular_lightmap", "metal_specular_lightmap"}};

    /** the lightmap a battle uses instead of a lobby one (same name when there is no such pair) */
    String ingame(String name) {
        if (!ingameLight || name == null || !name.startsWith("menu_")) return name;
        int dot = name.lastIndexOf('.');
        String base = dot < 0 ? name : name.substring(0, dot), ext = dot < 0 ? "" : name.substring(dot);
        for (String[] p : INGAME_LIGHT) if (p[0].equals(base)) return p[1] + ext;
        return name;
    }

    /** largest texture side kept (0 = as stored): a weak phone halves big textures, which looks the same on its screen */
    public static int MAX_TEXTURE = 0;

    /** half size, each pixel the average of four */
    static Img half(Img im) {
        int w = im.width / 2, h = im.height / 2;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int o = y * 2 * im.width + x * 2;
                int a = im.argb[o], b = im.argb[o + 1], c = im.argb[o + im.width], d = im.argb[o + im.width + 1];
                int r = 0;
                for (int sh = 0; sh < 32; sh += 8) {
                    int v = ((a >>> sh) & 255) + ((b >>> sh) & 255) + ((c >>> sh) & 255) + ((d >>> sh) & 255);
                    r |= ((v + 2) >> 2) << sh;
                }
                px[y * w + x] = r;
            }
        }
        return new Img(w, h, px);
    }

    /** the textures a model's materials name (diffuse + lightmaps), by file name */
    /** stretches a picture to a square (a texture fills its UV square) */
    static Img square(Img im) {
        int n = Math.max(im.width, im.height);
        int[] px = new int[n * n];
        for (int y = 0; y < n; y++) {
            int sy = y * im.height / n;
            for (int x = 0; x < n; x++) px[y * n + x] = im.argb[sy * im.width + x * im.width / n];
        }
        return new Img(n, n, px);
    }

    public Map<String, Img> imagesFor(Model3d m) {
        Map<String, Img> out = new HashMap<>();
        if (m == null) return out;
        for (String t : m.materialTextures()) {
            String real = ingame(t);
            Img im = texture(real);
            if (im == null && !real.equals(t)) im = texture(t);
            if (im != null) out.put(t, im);
        }
        return out;
    }

    public synchronized Anim3d anim(String file) {
        if (file == null) return null;
        if (anims.containsKey(file)) return anims.get(file);
        Anim3d a = null;
        try {
            byte[] d = src.read(file);
            if (d != null) a = Anim3d.load(d);
            else missing.add(file);
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        anims.put(file, a);
        return a;
    }

    /** where 2D files come from when the app keeps its own cache of them (outside textures, memory limits) */
    public ScSprites.ScSource scLoader;

    public synchronized Sc2 sc(String file) {
        if (scLoader != null) return scLoader.sc(file);
        if (scs.containsKey(file)) return scs.get(file);
        Sc2 s = null;
        try {
            byte[] d = src.read(file);
            if (d != null) s = Sc2.parse(d);
        } catch (Throwable e) {
            missing.add(file + " (" + e.getMessage() + ")");
        }
        scs.put(file, s);
        return s;
    }

    // ------------------------------------------------------------------ characters
    public static final class Clip {
        public Anim3d anim;
        public int start, end;
        public String name;

        public double length() {
            return Math.max(1, end - start) / (double) Math.max(1, anim.fps);
        }
    }

    /** how many different poses a second an animation is shown with */
    public static double POSES_PER_SECOND = 20;
    /** posed copies kept per character: at most this many floats of positions and normals (a weak phone keeps fewer) */
    public static long POSE_FLOATS = 4_000_000L;

    /** an animated character (brawler skin, training dummy…) */
    public static final class Actor {
        public Model3d model;
        public Map<String, Img> images = new HashMap<>();
        public Img override;
        /** idle, walk, attack, ulti, win, lose… */
        public final Map<String, Clip> clips = new LinkedHashMap<>();
        public String skin, conf, modelFile, face;
        /** posed copies, newest last (dummies standing together share one) */
        private final LinkedHashMap<String, Model3d> cache = new LinkedHashMap<>(16, 0.75f, true);
        private long poseFloats;

        /** the model in an action at a time since the action started */
        public synchronized Model3d posed(String action, double seconds, boolean loop) {
            Clip c = clips.get(action);
            if (c == null) c = clips.get("idle");
            if (c == null || c.anim == null) return model;
            double len = Math.max(1, c.end - c.start);
            // 20 poses a second (as smooth as the eye needs on a phone), shared by everybody in the same skin
            double q = Math.floor(seconds * POSES_PER_SECOND) / POSES_PER_SECOND;
            double f = q * c.anim.fps;
            f = loop ? f % len : Math.min(f, len);
            f = Math.round((c.start + f) * 4) / 4.0;
            String key = action + "@" + f;
            Model3d m = cache.get(key);
            if (m == null) {
                m = model.pose(c.anim, f);
                cache.put(key, m);
                if (poseFloats == 0) for (Model3d.Part p : m.parts) poseFloats += (p.pos == null ? 0 : p.pos.length) * 2L;
                long keep = Math.max(4, Math.min(48, POSE_FLOATS / Math.max(1, poseFloats)));
                while (cache.size() > keep) cache.remove(cache.keySet().iterator().next());
            }
            return m;
        }

        /** poses by action: one per half frame of its clip, made when first shown */
        private final Map<String, Model3d.Pose[]> poses = new HashMap<>();

        /**
         * The action at a time since it started, as matrices for GPU skinning (see {@link Model3d#poseOf}): the model
         * is not copied, so a 30 000-triangle brawler costs a few kilobytes per frame instead of megabytes.
         */
        public synchronized Model3d.Pose pose(String action, double seconds, boolean loop) {
            Clip c = clips.get(action);
            if (c == null) {
                action = "idle";
                c = clips.get(action);
            }
            if (c == null || c.anim == null || model == null) return null;
            int len = Math.max(1, c.end - c.start);
            int per = len > 240 ? 1 : 2; // poses per animation frame
            double f = seconds * c.anim.fps;
            f = loop ? f % len : Math.min(f, len);
            int i = (int) Math.round(f * per);
            Model3d.Pose[] list = poses.get(action);
            if (list == null || list.length != len * per + 1) {
                list = new Model3d.Pose[len * per + 1];
                poses.put(action, list);
            }
            i = Math.max(0, Math.min(list.length - 1, i));
            if (list[i] == null) list[i] = model.poseOf(c.anim, c.start + i / (double) per);
            return list[i];
        }

        /** model height (rest pose) */
        public float height() {
            return model == null || model.bounds == null ? 1 : model.bounds[4] - model.bounds[1];
        }
    }

    static final String[][] SLOTS = {
            {"idle", "Idle"}, {"walk", "Walk"}, {"attack", "PrimarySkill"}, {"ulti", "SecondarySkill"},
            {"win", "Happy"}, {"lose", "Sad"}, {"reload", "Reloading"}};

    /** a character from a skin name (skins.csv), e.g. "BanditGirlDefault" or "MeleeBotDefault" */
    public Actor actor(String skin) {
        GameDb.Table skins = db.table("skins.csv");
        GameDb.Table confs = db.table("skin_confs.csv");
        String[] s = skins.row(skin);
        String confName = s != null ? skins.get(s, "Conf") : skin;
        String[] c = confs.row(confName);
        Actor a = new Actor();
        a.skin = skin;
        a.conf = confName;
        if (c == null) return a;
        a.modelFile = GameDb.fileName(confs.get(c, "Model"));
        a.model = model(a.modelFile);
        if (a.model == null) return a;
        a.images = imagesFor(a.model);
        String skinTex = s != null ? skins.get(s, "DiffuseTexture") : "";
        String body = FaceOverlay.bodyTexture(a.model);
        if (!skinTex.isEmpty()) {
            Img t = texture(GameDb.fileName(skinTex));
            if (t != null) {
                if (body != null) a.images.put(body, t);
                else a.override = t;
            }
        }
        // the 2D face painted on the body texture
        String[] face = faceOf(confs.get(c, "IdleFace"));
        if (face != null) {
            Sc2 sc = sc(face[0]);
            a.face = face[1];
            try {
                if (body != null && a.images.get(body) != null) a.images.put(body, FaceOverlay.apply(pixels(a.images.get(body)), sc, face[1], 0));
                else if (a.override != null) a.override = FaceOverlay.apply(pixels(a.override), sc, face[1], 0);
            } catch (Throwable ignored) {
                // without a face
            }
        }
        for (String[] slot : SLOTS) {
            // a list ("Idle;Idle_transform;…;GiantIdle") gives the forms of a brawler: idle, idle1, idle2, idle3…
            String[] list = confs.get(c, slot[1] + "Anim").split(";");
            for (int i = 0; i < list.length; i++) {
                Clip clip = clip(list[i].trim());
                if (clip != null && a.model.matchingBones(clip.anim) > 0) a.clips.put(i == 0 ? slot[0] : slot[0] + i, clip);
            }
        }
        if (!a.clips.containsKey("ulti") && a.clips.containsKey("attack")) a.clips.put("ulti", a.clips.get("attack"));
        return a;
    }

    /** animations.csv row -> loaded clip */
    public Clip clip(String name) {
        if (name == null || name.isEmpty()) return null;
        GameDb.Table t = db.table("animations.csv");
        String[] r = t.row(name);
        if (r == null) return null;
        Anim3d an = anim(GameDb.fileName(t.get(r, "FileName")));
        if (an == null) return null;
        Clip c = new Clip();
        c.name = name;
        c.anim = an;
        c.start = Math.max(0, Math.min(an.frames - 1, t.num(r, "StartFrame", 0)));
        int e = t.num(r, "EndFrame", -1);
        c.end = e < 0 || e >= an.frames ? an.frames - 1 : Math.max(c.start, e);
        return c;
    }

    /** faces.csv row -> {file, export} */
    public String[] faceOf(String name) {
        if (name == null || name.isEmpty()) return null;
        GameDb.Table t = db.table("faces.csv");
        String[] r = t.row(name);
        if (r == null) return null;
        String f = GameDb.fileName(t.get(r, "FileName")), e = t.get(r, "ExportName");
        return f.isEmpty() || e.isEmpty() ? null : new String[]{f, e};
    }
}
