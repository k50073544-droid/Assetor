package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Sc2;

import java.io.File;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Grid of sprites cut from an SC2 file, with search and PNG export. */
public final class SpritesActivity extends Activity {

    static final int REQ_SAVE_ONE = 1, REQ_SAVE_ALL = 2;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final LruCache<Integer, Bitmap> cache = new LruCache<Integer, Bitmap>(24 * 1024) {
        @Override
        protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount() / 1024; }
    };
    private Db.Row row;
    private Sc2 sc2;
    private List<Item> shown = new ArrayList<>();
    private boolean objects = true;

    /** Either a whole exported object (pin) or a single shape (detail). */
    static final class Item {
        final String name;
        final String export;
        final Sc2.ShapeDef shape;
        final int key;

        Item(String export, Sc2.ShapeDef shape, int key) {
            this.export = export;
            this.shape = shape;
            this.name = export != null ? export : shape.name;
            this.key = key;
        }
    }
    private Adapter adapter;
    private TextView count;
    private Item pending;
    private boolean bigOnly = true;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        row = Db.get(this).file(getIntent().getLongExtra("id", -1));
        if (row == null) {
            finish();
            return;
        }
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, row.name, 18, Ui.TEXT));
        TextView hint = Ui.text(this, "«Целые» — объекты, собранные как в игре (самый крупный кадр анимации). «Детали» — отдельные куски из атласа.", 12, Ui.MUTED);
        hint.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(hint);

        EditText search = new EditText(this);
        search.setHint("Поиск по имени…");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        search.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 10));
        root.addView(search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { filter(e.toString()); }
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        TextView whole = Ui.chip(this, "Целые");
        TextView parts = Ui.chip(this, "Детали");
        Ui.setChip(this, whole, true);
        whole.setOnClickListener(v -> {
            objects = true;
            Ui.setChip(this, whole, true);
            Ui.setChip(this, parts, false);
            filter(search.getText().toString());
        });
        parts.setOnClickListener(v -> {
            objects = false;
            Ui.setChip(this, whole, false);
            Ui.setChip(this, parts, true);
            filter(search.getText().toString());
        });
        bar.addView(whole);
        bar.addView(parts);
        TextView small = Ui.chip(this, "Без мелких");
        Ui.setChip(this, small, true);
        small.setOnClickListener(v -> {
            bigOnly = !bigOnly;
            Ui.setChip(this, small, bigOnly);
            filter(search.getText().toString());
        });
        bar.addView(small);
        TextView saveAll = Ui.button(this, "Сохранить все PNG", true);
        saveAll.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(i, REQ_SAVE_ALL);
        });
        bar.addView(saveAll);
        root.addView(bar);
        count = Ui.text(this, "Загружаю…", 12, Ui.MUTED);
        root.addView(count);

        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 100));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(Ui.dp(this, 6));
        grid.setVerticalSpacing(Ui.dp(this, 6));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        adapter = new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((pa, v, pos, id) -> open(shown.get(pos)));
        LinearLayout.LayoutParams glp = Ui.lp(-1, 0, 1);
        glp.topMargin = Ui.dp(this, 6);
        root.addView(grid, glp);
        setContentView(root);

        pool.execute(() -> {
            try {
                File f = Blobs.file(this, row.blob);
                Sc2 s = Sc2.parse(Decoders.readAll(f));
                resolveExternal(s);
                main.post(() -> {
                    sc2 = s;
                    if (s.exportOrder.isEmpty() || s.clips.isEmpty()) {
                        objects = false;
                        Ui.setChip(this, whole, false);
                        Ui.setChip(this, parts, true);
                    }
                    filter("");
                });
            } catch (Throwable e) {
                main.post(() -> count.setText("Не удалось прочитать: " + e.getMessage()));
            }
        });
    }

    /** Textures stored in separate files (external_texture) are looked up among imported files. */
    private void resolveExternal(Sc2 s) {
        Db db = Db.get(this);
        for (int i = 0; i < s.textures.size(); i++) {
            Sc2.Tex t = s.textures.get(i);
            if ((t.data != null && t.data.length > 0) || t.external == null) continue;
            List<String> one = new ArrayList<>();
            one.add(t.external);
            List<Db.Row> found = db.byPaths(row.vid, one);
            if (found.isEmpty()) continue;
            try {
                Db.Row r = found.get(0);
                com.weker.assetexplorer.codec.SupercellFiles.TextureSet ts =
                        com.weker.assetexplorer.codec.SupercellFiles.decodeTextures(Decoders.readAll(Blobs.file(this, r.blob)), r.name);
                if (!ts.images.isEmpty()) s.setExternalTexture(i, ts.images.get(0));
            } catch (Exception ignored) {
                // leave texture missing
            }
        }
    }

    private void filter(String q) {
        if (sc2 == null) return;
        String l = q.toLowerCase(Locale.ROOT).trim();
        List<Item> r = new ArrayList<>();
        int total;
        if (objects) {
            total = sc2.exportOrder.size();
            for (int i = 0; i < sc2.exportOrder.size(); i++) {
                String e = sc2.exportOrder.get(i);
                if (!l.isEmpty() && !e.toLowerCase(Locale.ROOT).contains(l)) continue;
                r.add(new Item(e, null, 1_000_000 + i));
            }
        } else {
            total = sc2.shapes.size();
            for (Sc2.ShapeDef sd : sc2.shapes) {
                if (!l.isEmpty() && !sd.name.toLowerCase(Locale.ROOT).contains(l)) continue;
                if (bigOnly && tiny(sd)) continue;
                r.add(new Item(null, sd, sd.id));
            }
        }
        shown = r;
        count.setText((objects ? "Объектов: " : "Деталей: ") + r.size() + " из " + total);
        adapter.notifyDataSetChanged();
    }

    /** Renders an item: whole object at its best frame, or a single shape. */
    private Img render(Item it, int max) throws java.io.IOException {
        if (it.export != null) return sc2.renderExport(it.export, sc2.bestFrame(it.export), max);
        return sc2.renderShape(it.shape, max);
    }

    /** solid-colour shapes and very small pieces */
    private boolean tiny(Sc2.ShapeDef s) {
        int pts = 0;
        for (Sc2.Cmd c : s.cmds) pts += c.count;
        return pts <= 4 && s.cmds.size() <= 1;
    }

    private void open(Item sd) {
        ProgressBar pb = new ProgressBar(this);
        AlertDialog wait = new AlertDialog.Builder(this).setView(pb).setCancelable(false).show();
        pool.execute(() -> {
            Bitmap bm = null;
            try {
                Img im = render(sd, 1024);
                if (im != null) bm = Decoders.toBitmap(im);
            } catch (Throwable ignored) {
                // shown as error below
            }
            Bitmap fb = bm;
            main.post(() -> {
                wait.dismiss();
                if (fb == null) {
                    Toast.makeText(this, "Не удалось вырезать", Toast.LENGTH_SHORT).show();
                    return;
                }
                ZoomImageView z = new ZoomImageView(this);
                z.setLayoutParams(new ViewGroup.LayoutParams(-1, Ui.dp(this, 360)));
                z.setBitmap(fb);
                new AlertDialog.Builder(this).setTitle(sd.name + "  (" + fb.getWidth() + "x" + fb.getHeight() + ")")
                        .setView(z)
                        .setPositiveButton("Сохранить PNG", (d, w) -> {
                            pending = sd;
                            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("image/png");
                            i.putExtra(Intent.EXTRA_TITLE, sd.name + ".png");
                            startActivityForResult(i, REQ_SAVE_ONE);
                        })
                        .setNegativeButton("Закрыть", null).show();
            });
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null || sc2 == null) return;
        Uri uri = data.getData();
        if (req == REQ_SAVE_ONE && pending != null) {
            Item sd = pending;
            pool.execute(() -> {
                String msg;
                try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                    Img im = render(sd, 2048);
                    if (o == null || im == null) throw new java.io.IOException("нет данных");
                    Decoders.toBitmap(im).compress(Bitmap.CompressFormat.PNG, 100, o);
                    msg = "Сохранено";
                } catch (Exception e) {
                    msg = "Ошибка: " + e.getMessage();
                }
                String m = msg;
                main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
            });
        } else if (req == REQ_SAVE_ALL) {
            saveAll(uri, new ArrayList<>(shown));
        }
    }

    private void saveAll(Uri tree, List<Item> list) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        TextView status = Ui.text(this, "Готовлю…", 13, 0xFF888888);
        int p = Ui.dp(this, 20);
        status.setPadding(p, p, p, p);
        boolean[] cancel = {false};
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Сохранение спрайтов").setView(status).setCancelable(false)
                .setNegativeButton("Отмена", (d, w) -> cancel[0] = true).show();
        pool.execute(() -> {
            int done = 0;
            String err = null;
            try {
                Uri base = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
                String folder = row.name.replace(".sc", "") + (objects ? "_objects" : "_parts");
                Uri dir = DocumentsContract.createDocument(getContentResolver(), base, DocumentsContract.Document.MIME_TYPE_DIR, folder);
                if (dir == null) throw new java.io.IOException("не удалось создать папку");
                for (Item sd : list) {
                    if (cancel[0]) break;
                    Img im = render(sd, 2048);
                    if (im == null) continue;
                    Uri out = DocumentsContract.createDocument(getContentResolver(), dir, "image/png", sd.name + ".png");
                    if (out == null) continue;
                    try (OutputStream o = getContentResolver().openOutputStream(out)) {
                        if (o != null) {
                            Bitmap b = Decoders.toBitmap(im);
                            b.compress(Bitmap.CompressFormat.PNG, 100, o);
                            b.recycle();
                        }
                    }
                    done++;
                    int fd = done;
                    if (done % 5 == 0) main.post(() -> status.setText(fd + " / " + list.size()));
                }
            } catch (Throwable e) {
                err = e.getMessage();
            }
            String msg = err == null ? "Сохранено PNG: " + done : "Ошибка: " + err + " (успели: " + done + ")";
            main.post(() -> {
                dlg.dismiss();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("ОК", null).show();
            });
        });
    }

    final class Adapter extends BaseAdapter {
        public int getCount() { return shown.size(); }

        public Object getItem(int i) { return shown.get(i); }

        public long getItemId(int i) { return i; }

        public View getView(int pos, View v, ViewGroup parent) {
            LinearLayout cell;
            ImageView img;
            TextView name;
            if (v == null) {
                cell = new LinearLayout(SpritesActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setBackground(Ui.round(Ui.CARD, Ui.dp(SpritesActivity.this, 10)));
                int pad = Ui.dp(SpritesActivity.this, 6);
                cell.setPadding(pad, pad, pad, pad);
                FrameLayout box = new FrameLayout(SpritesActivity.this);
                box.setBackground(Ui.round(0xFF3A3F52, Ui.dp(SpritesActivity.this, 8)));
                img = new ImageView(SpritesActivity.this);
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                img.setId(1);
                box.addView(img, new FrameLayout.LayoutParams(-1, -1));
                cell.addView(box, new LinearLayout.LayoutParams(-1, Ui.dp(SpritesActivity.this, 88)));
                name = Ui.text(SpritesActivity.this, "", 10, Ui.TEXT);
                name.setMaxLines(2);
                name.setId(2);
                cell.addView(name);
                v = cell;
            }
            img = v.findViewById(1);
            name = v.findViewById(2);
            Item sd = shown.get(pos);
            name.setText(sd.name);
            int key = sd.key;
            img.setTag(key);
            Bitmap c = cache.get(key);
            if (c != null) {
                img.setImageBitmap(c);
            } else {
                img.setImageDrawable(null);
                ImageView target = img;
                pool.execute(() -> {
                    if (!Integer.valueOf(key).equals(target.getTag())) return;
                    try {
                        Img im = render(sd, 192);
                        if (im == null) return;
                        Bitmap b = Decoders.toBitmap(im);
                        cache.put(key, b);
                        main.post(() -> {
                            if (Integer.valueOf(key).equals(target.getTag())) target.setImageBitmap(b);
                        });
                    } catch (Throwable ignored) {
                        // leave empty
                    }
                });
            }
            return v;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }
}
