package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.GlbWriter;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Render3d;
import com.weker.assetexplorer.codec.SupercellFiles;


import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Interactive 3D view of a .glb model with its texture. */
public final class Model3dActivity extends Activity {

    static final int REQ_PNG = 1, REQ_GLB = 2;
    static final int[] BGS = {0xFF20232F, 0xFF8A8F9C, 0xFFF2F3F5};

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private Db.Row row;
    private Model3d model;
    /** material textures and lightmaps found in the archive, by file name */
    private java.util.Map<String, Img> images = new java.util.HashMap<>();
    /** manual texture for every part (null = textures named by the model's materials) */
    private Img texture;
    private Db.Row textureRow;
    private List<Db.Row> candidates = new ArrayList<>();
    private ModelView view;
    private TextView info, texBtn, lightChip;
    private int bgIndex;
    private boolean pngTransparent;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        row = Db.get(this).file(getIntent().getLongExtra("id", -1));
        if (row == null) {
            finish();
            return;
        }
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, p);
        root.addView(Ui.bold(this, row.name, 17, Ui.TEXT));
        info = Ui.text(this, "Читаю модель…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(info);

        view = new ModelView(this);
        view.setBackground(Ui.round(BGS[0], Ui.dp(this, 12)));
        root.addView(view, Ui.lp(-1, 0, 1));

        TextView hint = Ui.text(this, "Один палец — вращать · два пальца — приблизить и сдвинуть · двойной тап — сброс", 11, Ui.MUTED);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        root.addView(hint);

        texBtn = Ui.button(this, "Текстура: …", false);
        texBtn.setSingleLine(true);
        texBtn.setOnClickListener(v -> pickTexture());
        root.addView(texBtn, Ui.lp(-1, -2, 0));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(this, 8), 0, 0);
        lightChip = Ui.chip(this, "Свет");
        Ui.setChip(this, lightChip, true);
        lightChip.setOnClickListener(v -> {
            view.render.lighting = !view.render.lighting;
            Ui.setChip(this, lightChip, view.render.lighting);
            view.request(false);
        });
        bar.addView(lightChip);
        TextView bgChip = Ui.chip(this, "Фон");
        bgChip.setOnClickListener(v -> {
            bgIndex = (bgIndex + 1) % BGS.length;
            view.render.background = BGS[bgIndex];
            view.setBackground(Ui.round(BGS[bgIndex], Ui.dp(this, 12)));
            view.request(false);
        });
        bar.addView(bgChip);
        TextView partsChip = Ui.chip(this, "Части");
        partsChip.setOnClickListener(v -> pickParts());
        bar.addView(partsChip);
        TextView flip = Ui.chip(this, "Перевернуть UV");
        flip.setOnClickListener(v -> {
            view.render.flipV = !view.render.flipV;
            Ui.setChip(this, flip, view.render.flipV);
            view.request(false);
        });
        bar.addView(flip);
        TextView save = Ui.button(this, "Сохранить", true);
        save.setOnClickListener(v -> saveMenu());
        bar.addView(save);
        hs.addView(bar);
        root.addView(hs);
        setContentView(root);

        bg.execute(() -> {
            try {
                Loaded l = load(this, row);
                main.post(() -> {
                    model = l.model;
                    images = l.images;
                    candidates = l.candidates;
                    texture = l.override;
                    textureRow = l.overrideRow;
                    info.setText(l.describe());
                    updateTexButton();
                    view.setModel(l.model, l.images, l.override);
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Не удалось открыть модель: " + e.getMessage()));
            }
        });
    }

    /** Everything needed to draw a model: the model, its textures, and a fallback texture if it names none. */
    static final class Loaded {
        Model3d model;
        java.util.Map<String, Img> images = new java.util.HashMap<>();
        List<Db.Row> candidates = new ArrayList<>();
        Img override;
        Db.Row overrideRow;
        final List<String> found = new ArrayList<>(), missing = new ArrayList<>();

        String describe() {
            StringBuilder sb = new StringBuilder(model.summary());
            if (!found.isEmpty()) sb.append("\nТекстуры модели: ").append(android.text.TextUtils.join(", ", found));
            if (!missing.isEmpty()) sb.append("\nНет в архиве: ").append(android.text.TextUtils.join(", ", missing));
            if (overrideRow != null) sb.append("\nТекстура подобрана по имени: ").append(overrideRow.name);
            else if (found.isEmpty()) sb.append("\nТекстура не найдена — выбери вручную.");
            if (!model.info.isEmpty()) sb.append('\n').append(model.info.get(0));
            return sb.toString();
        }
    }

    static Loaded load(Context c, Db.Row row) throws IOException {
        Loaded l = new Loaded();
        l.model = Model3d.load(Decoders.readAll(Blobs.file(c, row.blob)));
        Db db = Db.get(c);
        boolean anyDiffuse = false;
        java.util.Set<String> diffuse = new java.util.HashSet<>();
        for (Model3d.Part p : l.model.parts) if (p.diffuseTex != null) diffuse.add(p.diffuseTex);
        for (String name : l.model.materialTextures()) {
            List<String> one = new ArrayList<>();
            one.add(name);
            List<Db.Row> r = db.byPaths(row.vid, one);
            boolean isLightmap = !diffuse.contains(name);
            if (r.isEmpty()) {
                if (!isLightmap) l.missing.add(name);
                continue;
            }
            try {
                l.images.put(name, decodeTexture(c, r.get(0)));
                if (!isLightmap) {
                    l.found.add(name);
                    anyDiffuse = true;
                }
            } catch (Throwable e) {
                if (!isLightmap) l.missing.add(name + " (не читается)");
            }
        }
        l.candidates = textureCandidates(c, row, l.model);
        if (!anyDiffuse) { // older models don't name their texture: guess by file name
            for (int i = 0; i < l.candidates.size() && i < 3 && l.override == null; i++) {
                try {
                    l.override = decodeTexture(c, l.candidates.get(i));
                    l.overrideRow = l.candidates.get(i);
                } catch (Throwable ignored) {
                    // try the next one
                }
            }
        }
        return l;
    }

    private void updateTexButton() {
        String t;
        if (textureRow != null) t = textureRow.name;
        else if (texture == null && model != null && !model.materialTextures().isEmpty() && !images.isEmpty()) t = "из модели";
        else t = "нет";
        texBtn.setText("Текстура: " + t + "  ▾");
    }

    // ------------------------------------------------------------------ textures
    /**
     * Textures to offer, best first: the ones the model itself names, then textures in the same folder
     * whose name starts like the model's (shelly_redux_geo.glb -> shelly_redux_tex.sctx, shelly_*).
     */
    static List<Db.Row> textureCandidates(Context c, Db.Row row, Model3d m) {
        Db db = Db.get(c);
        List<Db.Row> out = new ArrayList<>();
        List<String> refs = new ArrayList<>();
        for (String r : m.textureRefs()) if (!r.toLowerCase(Locale.ROOT).contains("lightmap")) refs.add(r);
        for (Db.Row r : db.byPaths(row.vid, refs)) addUnique(out, r);
        String base = row.name.replaceAll("(?i)\\.glb$|\\.gltf$|\\.scw$", "").replaceAll("(?i)_(geo|rig|mesh|model)$", "");
        String first = base.contains("_") ? base.substring(0, base.indexOf('_')) : base;
        List<Db.Row> near = db.texturesNear(row, first, 400);
        List<Db.Row> sorted = new ArrayList<>(near);
        sorted.sort((a, b) -> Integer.compare(score(b.name, base), score(a.name, base)));
        for (Db.Row r : sorted) {
            if (r.name.toLowerCase(Locale.ROOT).contains("lightmap")) continue;
            addUnique(out, r);
        }
        return out;
    }

    static void addUnique(List<Db.Row> l, Db.Row r) {
        for (Db.Row x : l) if (x.path.equals(r.path)) return;
        l.add(r);
    }

    /** how well a texture name matches the model base name */
    static int score(String tex, String base) {
        String t = tex.toLowerCase(Locale.ROOT).replaceAll("\\.[a-z0-9]+$", "");
        String b = base.toLowerCase(Locale.ROOT);
        if (t.equals(b + "_tex") || t.equals(b)) return 10000;
        int common = 0;
        while (common < Math.min(t.length(), b.length()) && t.charAt(common) == b.charAt(common)) common++;
        int s = common * 10;
        if (t.endsWith("_tex")) s += 5;
        if (t.contains("chroma") || t.contains("_blue") || t.contains("_red")) s -= 3;
        return s - t.length() / 10;
    }

    static Img decodeTexture(Context c, Db.Row r) throws IOException {
        byte[] d = Decoders.readAll(Blobs.file(c, r.blob));
        if (Categorizer.T_IMG.equals(r.type)) {
            Bitmap b = BitmapFactory.decodeByteArray(d, 0, d.length);
            if (b == null) throw new IOException("картинка не читается");
            int[] px = new int[b.getWidth() * b.getHeight()];
            b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
            return new Img(b.getWidth(), b.getHeight(), px);
        }
        SupercellFiles.TextureSet ts = SupercellFiles.decodeTextures(d, r.name);
        if (ts.images.isEmpty()) throw new IOException("в файле нет картинки");
        return ts.images.get(0);
    }

    private void pickTexture() {
        if (model == null) return;
        List<String> names = new ArrayList<>();
        names.add("Авто — текстуры из материалов модели");
        names.add("— без текстуры —");
        for (Db.Row r : candidates) names.add((textureRow != null && r.path.equals(textureRow.path) ? "✓ " : "") + r.name);
        names.add("Найти другую текстуру…");
        new AlertDialog.Builder(this).setTitle("Текстура (лучшие совпадения сверху)")
                .setItems(names.toArray(new String[0]), (d, w) -> {
                    if (w == 0) {
                        textureRow = null;
                        texture = null;
                        view.render.textured = true;
                        updateTexButton();
                        view.setTexture(null);
                    } else if (w == 1) {
                        textureRow = null;
                        texture = null;
                        view.render.textured = false;
                        texBtn.setText("Текстура: нет  ▾");
                        view.request(false);
                    } else if (w == names.size() - 1) {
                        searchTexture();
                    } else {
                        setTexture(candidates.get(w - 2));
                    }
                }).show();
    }

    private void searchTexture() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 12);
        box.setPadding(p, p, p, 0);
        EditText q = new EditText(this);
        q.setHint("часть имени, например gold");
        q.setSingleLine(true);
        box.addView(q);
        ListView lv = new ListView(this);
        List<Db.Row> found = new ArrayList<>();
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(-1, Ui.dp(this, 360)));
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Текстуры в папке модели").setView(box)
                .setNegativeButton("Отмена", null).show();
        Runnable search = () -> {
            String text = q.getText().toString().trim();
            bg.execute(() -> {
                List<Db.Row> r = Db.get(this).texturesNear(row, text, 300);
                main.post(() -> {
                    found.clear();
                    found.addAll(r);
                    ad.clear();
                    for (Db.Row x : r) ad.add(x.name);
                    ad.notifyDataSetChanged();
                });
            });
        };
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            public void afterTextChanged(Editable e) {
                main.removeCallbacks(search);
                main.postDelayed(search, 250);
            }
        });
        lv.setOnItemClickListener((pa, v, pos, id) -> {
            dlg.dismiss();
            Db.Row r = found.get(pos);
            addUnique(candidates, r);
            setTexture(r);
        });
        search.run();
    }

    private void setTexture(Db.Row r) {
        view.render.textured = true;
        texBtn.setText("Текстура: загружаю…");
        bg.execute(() -> {
            try {
                Img t = decodeTexture(this, r);
                main.post(() -> {
                    textureRow = r;
                    texture = t;
                    updateTexButton();
                    view.setTexture(t);
                });
            } catch (Throwable e) {
                main.post(() -> {
                    updateTexButton();
                    Toast.makeText(this, "Не удалось прочитать " + r.name + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ------------------------------------------------------------------ parts
    private void pickParts() {
        if (model == null) return;
        int n = model.parts.size();
        String[] names = new String[n];
        boolean[] on = new boolean[n];
        for (int i = 0; i < n; i++) {
            Model3d.Part p = model.parts.get(i);
            names[i] = p.name + "  ·  " + p.triangles + " треуг.";
            on[i] = p.visible;
        }
        new AlertDialog.Builder(this).setTitle("Какие части показывать")
                .setMultiChoiceItems(names, on, (d, w, checked) -> {
                    model.parts.get(w).visible = checked;
                    view.request(false);
                })
                .setPositiveButton("Готово", null).show();
    }

    // ------------------------------------------------------------------ saving
    private void saveMenu() {
        if (model == null) return;
        String base = row.name.replaceAll("(?i)\\.glb$", "");
        String[] items = {"PNG 1024 px — прозрачный фон", "PNG 1024 px — с фоном", ".glb для Blender (с текстурой)"};
        new AlertDialog.Builder(this).setTitle("Сохранить").setItems(items, (d, w) -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            if (w < 2) {
                pngTransparent = w == 0;
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_TITLE, base + ".png");
                startActivityForResult(i, REQ_PNG);
            } else {
                i.setType("model/gltf-binary");
                i.putExtra(Intent.EXTRA_TITLE, base + "_blender.glb");
                startActivityForResult(i, REQ_GLB);
            }
        }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null || model == null) return;
        Uri uri = data.getData();
        Img tex = texture;
        java.util.Map<String, Img> imgs = images;
        boolean transparent = pngTransparent;
        Render3d r = new Render3d();
        r.yaw = view.render.yaw;
        r.pitch = view.render.pitch;
        r.zoom = view.render.zoom;
        r.panX = view.render.panX;
        r.panY = view.render.panY;
        r.lighting = view.render.lighting;
        r.flipV = view.render.flipV;
        r.textured = view.render.textured;
        r.background = transparent ? 0 : view.render.background;
        int vw = Math.max(1, view.getWidth()), vh = Math.max(1, view.getHeight());
        Toast.makeText(this, "Сохраняю…", Toast.LENGTH_SHORT).show();
        bg.execute(() -> {
            String msg;
            try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new IOException("нет доступа");
                if (req == REQ_PNG) {
                    int w = 1024, h = Math.max(1, Math.round(1024f * vh / vw));
                    if (h > 1024) {
                        w = Math.round(1024f * vw / vh);
                        h = 1024;
                    }
                    Img im = r.render(model, imgs, tex, w, h, 2);
                    Decoders.toBitmap(im).compress(Bitmap.CompressFormat.PNG, 100, o);
                } else {
                    // one texture per material in the exported file
                    java.util.Map<String, byte[]> pngs = new java.util.HashMap<>();
                    for (Model3d.Part p : model.parts) {
                        Img t = !r.textured ? null : tex != null ? tex : p.diffuseTex != null ? imgs.get(p.diffuseTex) : null;
                        String key = tex != null ? "override" : p.diffuseTex;
                        if (t == null || key == null || pngs.containsKey(key)) continue;
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        Decoders.toBitmap(t).compress(Bitmap.CompressFormat.PNG, 100, bo);
                        pngs.put(key, bo.toByteArray());
                    }
                    BufferedOutputStream bout = new BufferedOutputStream(o, 1 << 16);
                    GlbWriter.write(model, pngs, tex != null ? "override" : null, bout);
                    bout.flush();
                }
                msg = "Сохранено";
            } catch (Throwable e) {
                msg = "Ошибка: " + e.getMessage();
            }
            String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (view != null) view.release();
        bg.shutdownNow();
    }
}
