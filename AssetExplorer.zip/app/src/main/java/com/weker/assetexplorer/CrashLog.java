package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * When the app dies, the reason is written to a file; at the next start it is shown (and can be copied), so a crash
 * on a phone can be told apart from a lack of memory and fixed. Also keeps a short trail of what the game was doing.
 */
public final class CrashLog {

    private static File dir;
    private static boolean installed;
    /** what the game was doing last (loading, a battle frame, a screen) */
    private static volatile String stage = "запуск";
    private static volatile String detail = "";

    private CrashLog() {
    }

    public static synchronized void install(Context c) {
        if (installed) return;
        installed = true;
        dir = c.getApplicationContext().getFilesDir();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                write("crash.txt", describe("ВЫЛЕТ в потоке " + t.getName(), e), false);
            } catch (Throwable ignored) {
                // nothing more can be done
            }
            if (old != null) old.uncaughtException(t, e);
        });
    }

    /** what is happening now ("бой", "загрузка эффектов"…); cheap, called often */
    public static void stage(String s) {
        stage = s;
    }

    public static void detail(String s) {
        detail = s;
    }

    /** an error the game survived (a skipped frame, a file it gave up on): kept for the next look at the log */
    public static void survived(String what, Throwable e) {
        try {
            if (dir == null) return;
            write("errors.txt", describe(what, e), true);
        } catch (Throwable ignored) {
            // the log itself must never hurt
        }
    }

    private static String describe(String title, Throwable e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println(title + " · " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date()));
        pw.println("Этап: " + stage + (detail.isEmpty() ? "" : " (" + detail + ")"));
        pw.println("Устройство: " + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        Runtime rt = Runtime.getRuntime();
        pw.println(String.format(Locale.ROOT, "Память: занято %d МБ из %d МБ", (rt.totalMemory() - rt.freeMemory()) >> 20, rt.maxMemory() >> 20));
        if (e != null) {
            if (e instanceof OutOfMemoryError) pw.println("Причина: не хватило памяти");
            e.printStackTrace(pw);
        }
        pw.flush();
        return sw.toString();
    }

    private static synchronized void write(String name, String text, boolean append) throws java.io.IOException {
        if (dir == null) return;
        File f = new File(dir, name);
        if (append && f.exists() && f.length() > 40_000) f.delete(); // the trail stays short
        try (FileOutputStream o = new FileOutputStream(f, append)) {
            o.write((text + "\n").getBytes(StandardCharsets.UTF_8));
        }
    }

    /** the last crash's text (once: it is cleared when read), or null */
    public static synchronized String takeCrash(Context c) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "crash.txt");
            if (!f.exists()) return null;
            byte[] b = new byte[(int) Math.min(f.length(), 20_000)];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                int n = in.read(b);
                String s = new String(b, 0, Math.max(0, n), StandardCharsets.UTF_8);
                in.close();
                f.delete();
                return s;
            }
        } catch (Throwable e) {
            return null;
        }
    }

    /** the survived-errors trail's text, or null */
    public static String trail(Context c) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "errors.txt");
            if (!f.exists() || f.length() == 0) return null;
            byte[] b = new byte[(int) Math.min(f.length(), 12_000)];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                int n = in.read(b);
                return new String(b, 0, Math.max(0, n), StandardCharsets.UTF_8);
            }
        } catch (Throwable e) {
            return null;
        }
    }

    /** shows the last crash, if there was one, with a button to copy it */
    public static void showIfAny(Activity a) {
        final String text = takeCrash(a);
        if (text == null) return;
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextSize(11);
        t.setTextIsSelectable(true);
        int p = (int) (12 * a.getResources().getDisplayMetrics().density);
        t.setPadding(p, p, p, p);
        ScrollView sv = new ScrollView(a);
        sv.addView(t);
        new AlertDialog.Builder(a)
                .setTitle("Прошлый раз игра закрылась с ошибкой")
                .setView(sv)
                .setPositiveButton("Копировать", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Ошибка Asset Explorer", text));
                    Toast.makeText(a, "Скопировано", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }
}
