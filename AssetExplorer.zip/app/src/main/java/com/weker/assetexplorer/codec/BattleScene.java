package com.weker.assetexplorer.codec;

import java.util.HashMap;
import java.util.Map;

/**
 * What a battle looks like from one player's seat: the location theme's ground, surroundings and tile models,
 * every brawler / pet / box with its skin and animation, the ball, gems, stars, power cubes, shots and the gas.
 */
public final class BattleScene {

    public final Battle battle;
    public final Assets assets;
    Model3d ground, env, quad, disc, gem;
    Map<String, Img> groundImg, envImg;
    /** tile code → model (with its textures) */
    final Map<Character, Model3d> tileModel = new HashMap<>();
    final Map<Character, Map<String, Img>> tileImg = new HashMap<>();
    final Map<String, Assets.Actor> actors = new HashMap<>();
    Assets.Actor ball;
    Model3d cube;
    Map<String, Img> cubeImg;
    Model3d floor, mine;
    Map<String, Img> mineImg;
    int floorVersion = -1;
    public float camX, camZ;
    public float camHeight = 13.5f, camBack = 8.5f;
    /** the player whose eyes we use (bushes hide enemies from them); null = see everything */
    public Battle.Fighter viewer;

    public BattleScene(Battle b, Assets a) {
        battle = b;
        assets = a;
        GameDb db = a.db;
        String theme = b.theme == null || b.theme.isEmpty() ? "Default" : b.theme;
        ground = a.model(db.themeModel(theme, "GroundModel"));
        env = a.model(db.themeModel(theme, "EnvironmentModel"));
        groundImg = a.imagesFor(ground);
        envImg = a.imagesFor(env);
        ground = outside(ground, true);
        env = outside(env, false);
        tile(theme, 'M', "Wall1Model", "Wall1Submesh");
        tile(theme, 'X', "Wall2Model", "Wall2Submesh");
        tile(theme, 'Y', "CrateModel", "CrateSubmesh");
        tile(theme, 'C', "BarrelModel", "BarrelSubmesh");
        tile(theme, 'T', "ThemedModel", "ThemedSubmesh");
        tile(theme, 'B', "FragileModel", "FragileSubmesh");
        tile(theme, 'D', "ClutterModel", "ClutterSubmesh");
        tile(theme, 'N', "FenceModel", null);
        tile(theme, 'a', "RopeFenceModel", null);
        tile(theme, 'I', "IndestructibleModel", null);
        tile(theme, 'E', "IndestructibleFenceModel", null);
        tile(theme, 'F', "Grass", null);
        if (tileModel.containsKey('F')) {
            tileModel.put('R', tileModel.get('F'));
            tileImg.put('R', tileImg.get('F'));
        }
        quad = Scene3d.quad();
        disc = Scene3d.disc(20);
        gem = diamond();
        ball = a.actor("BallDefault");
        cube = a.model("item_renamed_showdown_boost.glb");
        if (b.mode == Battle.Mode.GEM) {
            String gm = db.themeModel(theme, "MineGemSpawnModelOverride");
            mine = a.model(gm != null ? gm : "default_gem_spawn_geo.glb");
            if (mine == null) mine = a.model("default_gem_spawn_geo.glb");
            mineImg = a.imagesFor(mine);
        }
        cubeImg = a.imagesFor(cube);
    }

    /** the theme's floor plate covers the whole play field (then no checkerboard is needed) */
    boolean themeFloor;

    /**
     * Scenery models are shared by maps of different sizes: keep only what lies around the play field
     * (and a floor plate that covers all of it), so nothing stands inside the map.
     */
    Model3d outside(Model3d m, boolean isGround) {
        if (m == null) return null;
        float W = battle.width, H = battle.height;
        Model3d out = Model3d.empty();
        for (Model3d.Part p : m.parts) {
            float x0 = Float.MAX_VALUE, x1 = -Float.MAX_VALUE, z0 = Float.MAX_VALUE, z1 = -Float.MAX_VALUE, h0 = Float.MAX_VALUE, h1 = -Float.MAX_VALUE;
            for (int i = 0; i + 2 < p.pos.length; i += 3) {
                float x = p.pos[i], z = -p.pos[i + 1], h = p.pos[i + 2]; // Z-up model → world
                x0 = Math.min(x0, x);
                x1 = Math.max(x1, x);
                z0 = Math.min(z0, z);
                z1 = Math.max(z1, z);
                h0 = Math.min(h0, h);
                h1 = Math.max(h1, h);
            }
            boolean covers = x0 <= 0.6f && x1 >= W - 0.6f && z0 <= 0.6f && z1 >= H - 0.6f && h1 - h0 < 1.5f;
            boolean inside = x1 > 0.7f && x0 < W - 0.7f && z1 > 0.7f && z0 < H - 0.7f;
            if (covers && isGround) themeFloor = true;
            if (covers || !inside) out.parts.add(p);
        }
        out.bounds = m.bounds;
        for (Model3d.Part p : out.parts) out.triangles += p.triangles;
        return out.parts.isEmpty() ? null : out;
    }

    void tile(String theme, char code, String modelCol, String subCol) {
        GameDb db = assets.db;
        Model3d m = assets.model(db.themeModel(theme, modelCol));
        if (m == null) return;
        String sub = subCol == null ? null : db.themeSubmesh(theme, subCol);
        if (sub == null && subCol == null && code == 'F') sub = "grass_1";
        Model3d part = sub != null ? m.only(sub) : null;
        if (part == null && code != 'F' && m.parts.size() > 1) { // fences and the like: the first piece
            part = m.only(m.parts.get(0).name);
        }
        if (part == null) part = m;
        tileModel.put(code, part);
        tileImg.put(code, assets.imagesFor(part));
    }

    public Assets.Actor actor(String skin) {
        if (skin == null) return null;
        Assets.Actor a = actors.get(skin);
        if (a == null && !actors.containsKey(skin)) {
            a = assets.actor(skin);
            actors.put(skin, a);
        }
        return a;
    }

    /** loads every model the battle needs now (call off the drawing thread) */
    public void preload() {
        for (Battle.Fighter f : battle.fighters) actor(f.kit.skin);
    }

    public void follow(float dt) {
        Battle.Fighter v = viewer;
        float px = v != null ? v.x : battle.width / 2f, pz = v != null ? v.z : battle.height / 2f;
        float tx = battle.width <= 22 ? Math.max(5.5f, Math.min(battle.width - 5.5f, px)) : px;
        float tz = Math.max(3f, Math.min(battle.height - 2.5f, pz));
        float k = dt <= 0 ? 1 : Math.min(1, dt * 6);
        camX += (tx - camX) * k;
        camZ += (tz - camZ) * k;
    }

    public Scene3d build() {
        Battle b = battle;
        Scene3d s = new Scene3d();
        s.background = 0xFF2A3B2E;
        s.fovY = 36;
        s.near = 2f;
        s.far = 90f;
        s.view = Scene3d.lookAt(camX, camHeight, camZ + camBack, camX, 0, camZ - 0.6f);
        float[] zUp = Scene3d.zUp();
        if (ground != null) {
            Scene3d.Item g = s.add(ground, groundImg, zUp);
            g.still = true;
            g.background = true;
        }
        if (floor == null || floorVersion != b.width * 1000 + b.height) {
            floor = floor(b.width, b.height);
            floorVersion = b.width * 1000 + b.height;
        }
        if (!themeFloor) {
            Scene3d.Item fl = s.add(floor, null, Scene3d.translate(0, 0.01f, 0));
            fl.still = true;
            fl.vertexColors = true;
        }
        if (env != null) s.add(env, envImg, zUp).still = true;
        if (mine != null) s.add(mine, mineImg, Scene3d.mul(Scene3d.translate(b.mineX, 0, b.mineZ), zUp)).still = true;
        // tiles near the camera only (Showdown maps are 60×60)
        int c0 = (int) Math.max(0, camX - 14), c1 = (int) Math.min(b.width - 1, camX + 14);
        int r0 = (int) Math.max(0, camZ - 14), r1 = (int) Math.min(b.height - 1, camZ + 9);
        Battle.Fighter me = viewer;
        for (int r = r0; r <= r1; r++) {
            for (int c = c0; c <= c1; c++) {
                char ch = b.cells[r][c];
                if (ch == '.' || ch == 'J') continue;
                if (ch == 'W' || ch == 'V') {
                    Scene3d.Item it = s.add(quad, null, Scene3d.translate(c, 0.03f, r));
                    it.color = 0xFF3C9FD8;
                    it.overlay = true;
                    it.still = true;
                    continue;
                }
                Model3d m = tileModel.get(ch);
                if (m == null) continue;
                Scene3d.Item it = s.add(m, tileImg.get(ch), Scene3d.mul(Scene3d.translate(c + 0.5f, 0, r + 0.5f), zUp));
                it.still = true;
                if ((ch == 'F' || ch == 'R') && me != null && me.alive && Math.abs(c + 0.5f - me.x) < 1.6f && Math.abs(r + 0.5f - me.z) < 1.6f) it.color = 0x88FFFFFF;
            }
        }
        // gas
        if (b.poison > 0.05f) {
            float p = b.poison;
            gas(s, 0, 0, b.width, p);
            gas(s, 0, b.height - p, b.width, p);
            gas(s, 0, p, p, b.height - 2 * p);
            gas(s, b.width - p, p, p, b.height - 2 * p);
        }
        // areas
        for (Battle.Area a : b.areas) {
            Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(a.x, 0.05f, a.z), Scene3d.scale(a.radius, 1, a.radius)));
            it.color = a.heal ? 0x5550E060 : teamColor(a.team, 0x44);
            it.overlay = true;
        }
        // items
        for (Battle.Item it : b.items) {
            float bob = 0.35f + 0.08f * (float) Math.sin(b.time * 4 + it.x);
            if (it.type == 2 && cube != null) {
                Scene3d.Item x = s.add(cube, cubeImg, Scene3d.mul(Scene3d.translate(it.x, 0.1f, it.z), Scene3d.mul(Scene3d.rotateY(b.time), Scene3d.scale(0.1f))));
                x.color = 0xFFFFFFFF;
            } else {
                Scene3d.Item x = s.add(gem, null, Scene3d.mul(Scene3d.translate(it.x, bob, it.z), Scene3d.mul(Scene3d.rotateY(b.time * 2), Scene3d.scale(0.28f))));
                x.color = it.type == 0 ? 0xFFC651FF : it.type == 1 ? 0xFFFFD23A : 0xFF52E06A;
                x.flash = 0x202020;
            }
        }
        // fighters
        for (Battle.Fighter f : b.fighters) {
            if (!f.alive) continue;
            boolean seen = me == null || b.visibleTo(f, me);
            if (!seen) continue;
            shadow(s, f);
            Assets.Actor a = actor(f.kit.skin);
            if (a == null || a.model == null) continue;
            boolean loop = "idle".equals(f.action) || "walk".equals(f.action);
            Model3d m = a.posed(f.box ? "idle" : f.action, f.box ? b.time : b.time - f.actionStart, f.box || loop);
            float k = CaveScene.CHAR_SCALE * f.kit.scale / 100f * (f.pet ? 0.9f : 1f);
            if (f.box) k = CaveScene.CHAR_SCALE * 1.1f;
            Scene3d.Item it = s.add(m, a.images, Scene3d.mul(Scene3d.translate(f.x, 0, f.z), Scene3d.mul(Scene3d.rotateY(f.face), Scene3d.scale(k))));
            it.override = a.override;
            boolean ghost = f.invisible(b.time) || (f.inBush && me != null && !(me.team != f.team) );
            if (ghost) it.color = 0x99FFFFFF;
            if (f.flash > 0) it.flash = 0x707070;
        }
        // ball
        if (b.mode == Battle.Mode.BALL) {
            Scene3d.Item sh = s.add(disc, null, Scene3d.mul(Scene3d.translate(b.ballX, 0.04f, b.ballZ), Scene3d.scale(0.3f, 1, 0.26f)));
            sh.color = 0x50000000;
            sh.overlay = true;
            if (ball != null && ball.model != null) {
                float bs = 0.8f / Math.max(0.1f, ball.height());
                Scene3d.Item it = s.add(ball.model, ball.images, Scene3d.mul(Scene3d.translate(b.ballX, b.ballH, b.ballZ), Scene3d.scale(bs)));
                it.override = ball.override;
            } else {
                Scene3d.Item it = s.add(gem, null, Scene3d.mul(Scene3d.translate(b.ballX, 0.3f + b.ballH, b.ballZ), Scene3d.scale(0.3f)));
                it.color = 0xFFF2F2F2;
            }
        }
        // shots
        for (Battle.Shot sh : b.shots) {
            float r = Math.max(0.13f, Math.min(0.5f, sh.radius * 0.8f));
            Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(sh.x, sh.h, sh.z), Scene3d.scale(r, 1, r)));
            it.color = sh.ulti ? 0xFFFFD040 : (me != null && sh.team == me.team) ? 0xFF8FD3FF : 0xFFFF6A50;
            it.overlay = true;
        }
        return s;
    }

    void gas(Scene3d s, float x, float z, float w, float h) {
        Scene3d.Item it = s.add(quad, null, Scene3d.mul(Scene3d.translate(x, 0.06f, z), Scene3d.scale(w, 1, h)));
        it.color = 0x6640C040;
        it.overlay = true;
    }

    int teamColor(int team, int alpha) {
        Battle.Fighter me = viewer;
        boolean mine = me != null ? team == me.team : team == 0;
        return (alpha << 24) | (mine ? 0x3D8BFF : 0xFF4040);
    }

    void shadow(Scene3d s, Battle.Fighter f) {
        float r = Math.max(0.3f, f.kit.radius * 1.15f);
        Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(f.x, 0.04f, f.z), Scene3d.scale(r, 1, r * 0.85f)));
        it.color = 0x50000000;
        it.overlay = true;
        if (f.box || f.dummy) return;
        Scene3d.Item ring = s.add(disc, null, Scene3d.mul(Scene3d.translate(f.x, 0.045f, f.z), Scene3d.scale(r * 1.05f, 1, r * 0.95f)));
        ring.color = f == viewer ? 0x9940E060 : teamColor(f.team, 0x88);
        ring.overlay = true;
    }

    public float headHeight(Battle.Fighter f) {
        Assets.Actor a = actor(f.kit.skin);
        float h = a != null && a.model != null ? a.height() : 12;
        if (f.box) return h * CaveScene.CHAR_SCALE * 1.1f + 0.2f;
        return h * CaveScene.CHAR_SCALE * f.kit.scale / 100f + 0.25f;
    }

    static Model3d floor(int w, int h) {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "floor";
        p.triangles = w * h * 2;
        p.pos = new float[p.triangles * 9];
        p.nrm = new float[p.triangles * 9];
        p.uv = new float[p.triangles * 6];
        p.colors = new int[p.triangles * 3];
        p.hasNormals = true;
        int t = 0;
        for (int r = 0; r < h; r++) {
            for (int c = 0; c < w; c++) {
                int col = ((r + c) & 1) == 0 ? 0xFFEBC596 : 0xFFE2B887;
                float[] q = {c, 0, r, c + 1, 0, r, c + 1, 0, r + 1, c, 0, r, c + 1, 0, r + 1, c, 0, r + 1};
                for (int k = 0; k < 6; k++) {
                    p.pos[t * 9 + k * 3] = q[k * 3];
                    p.pos[t * 9 + k * 3 + 2] = q[k * 3 + 2];
                    p.nrm[t * 9 + k * 3 + 1] = 1;
                    p.colors[t * 3 + k] = col;
                }
                t += 2;
            }
        }
        m.parts.add(p);
        m.triangles = p.triangles;
        m.bounds = new float[]{0, 0, 0, w, 0, h};
        return m;
    }

    /** an eight-sided gem (gems, bounty stars) */
    static Model3d diamond() {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "gem";
        float[][] v = {{1, 0, 0}, {0, 0, 1}, {-1, 0, 0}, {0, 0, -1}};
        p.triangles = 8;
        p.pos = new float[72];
        p.nrm = new float[72];
        p.uv = new float[48];
        int t = 0;
        for (int i = 0; i < 4; i++) {
            float[] a = v[i], c = v[(i + 1) % 4];
            for (int top = 0; top < 2; top++) {
                float y = top == 0 ? 1.3f : -1.3f;
                float[] tri = {a[0], 0, a[2], c[0], 0, c[2], 0, y, 0};
                float nx = (a[0] + c[0]) / 2, nz = (a[2] + c[2]) / 2, ny = top == 0 ? 0.6f : -0.6f;
                for (int k = 0; k < 3; k++) {
                    p.pos[t * 9 + k * 3] = tri[k * 3];
                    p.pos[t * 9 + k * 3 + 1] = tri[k * 3 + 1];
                    p.pos[t * 9 + k * 3 + 2] = tri[k * 3 + 2];
                    p.nrm[t * 9 + k * 3] = nx;
                    p.nrm[t * 9 + k * 3 + 1] = ny;
                    p.nrm[t * 9 + k * 3 + 2] = nz;
                }
                t++;
            }
        }
        p.hasNormals = true;
        m.parts.add(p);
        m.triangles = 8;
        m.bounds = new float[]{-1, -1.3f, -1, 1, 1.3f, 1};
        return m;
    }
}
