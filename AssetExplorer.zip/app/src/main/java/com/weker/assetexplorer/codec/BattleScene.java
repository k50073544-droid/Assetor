package com.weker.assetexplorer.codec;

import java.util.HashMap;
import java.util.Map;

/**
 * What a battle looks like from one player's seat: the location theme's scenery ({@link MapScene}),
 * every brawler / pet / box with its skin and animation, the ball, gems, stars, power cubes, shots and the gas.
 */
public final class BattleScene {

    public final Battle battle;
    static final Model3d DOT = Scene3d.disc(12);
    /** the game's effects (set by the screen); null = plain dots */
    public BattleFx effects;
    public final Assets assets;
    Model3d quad, disc, gem;
    final Map<String, Assets.Actor> actors = new HashMap<>();
    Assets.Actor ball;
    Model3d cube;
    Map<String, Img> cubeImg;
    Model3d mine;
    Map<String, Img> mineImg;
    public float camX, camZ;
    /** camera like the game's battle camera (matched against its screenshots: the whole 17-tile map plus its sides) */
    public float camHeight = 15.5f, camBack = 13f;
    /** the player whose eyes we use (bushes hide enemies from them); null = see everything */
    public Battle.Fighter viewer;

    /** the map's scenery in the battle's theme (shared with the map browser) */
    public final MapScene scenery;
    Assets.Actor moth;

    public BattleScene(Battle b, Assets a) {
        battle = b;
        assets = a;
        GameDb db = a.db;
        String theme = b.theme == null || b.theme.isEmpty() ? "Default" : b.theme;
        GameDb.MapData md = new GameDb.MapData();
        md.width = b.width;
        md.height = b.height;
        md.cells = b.cells;
        md.theme = theme;
        scenery = new MapScene(md, a, b.mode == Battle.Mode.GEM ? "gem" : "");
        quad = Scene3d.quad();
        disc = Scene3d.disc(20);
        gem = diamond();
        ball = a.actor(b.mode == Battle.Mode.HOCKEY ? "AirDiscDefault" : "BallDefault");
        if (ball == null || ball.model == null) ball = a.actor("BallDefault");
        cube = a.model("item_renamed_showdown_boost.glb");
        if (b.mode == Battle.Mode.GEM) {
            String gm = db.themeModel(theme, "MineGemSpawnModelOverride");
            mine = a.model(gm != null ? gm : "default_gem_spawn_geo.glb");
            if (mine == null) mine = a.model("default_gem_spawn_geo.glb");
            mineImg = a.imagesFor(mine);
        }
        cubeImg = a.imagesFor(cube);
        for (Battle.Fighter f : b.fighters) {
            if (Specials.isVince(f)) {
                moth = a.actor("StackerDefaultAddonMoth");
                break;
            }
        }
    }

    public Assets.Actor actor(String skin) {
        if (skin == null) return null;
        Assets.Actor a = actors.get(skin);
        if (a == null && !actors.containsKey(skin)) {
            a = assets.actor(skin);
            actors.put(skin, a);
        }
        return a;
    }

    /** loads every model the battle needs now (call off the drawing thread) */
    public void preload() {
        for (Battle.Fighter f : battle.fighters) actor(f.kit.skin);
        if (moth != null) actor("StackerPetDefault");
    }

    /** the camera follows you; when you are out, a teammate who is still fighting (or the boss) */
    public void follow(float dt) {
        Battle.Fighter v = viewer;
        if (v != null && !v.alive && battle.respawnTime < 0) {
            Battle.Fighter alt = null;
            for (Battle.Fighter f : battle.fighters) {
                if (!f.alive || f.pet || f.box) continue;
                if (alt == null || (f.team == v.team && alt.team != v.team)) alt = f;
            }
            if (alt != null) v = alt;
        }
        float px = v != null ? v.x : battle.width / 2f, pz = v != null ? v.z : battle.height / 2f;
        float tx = battle.width <= 22 ? battle.width / 2f : px;
        float tz = Math.max(3f, Math.min(battle.height - 2.5f, pz));
        float k = dt <= 0 ? 1 : Math.min(1, dt * 6);
        camX += (tx - camX) * k;
        camZ += (tz - camZ) * k;
    }

    public Scene3d build() {
        Battle b = battle;
        Scene3d s = new Scene3d();
        s.background = scenery.background;
        s.fovY = 33;
        s.near = 2f;
        s.far = 110f;
        s.view = Scene3d.lookAt(camX, camHeight, camZ + camBack, camX, 0, camZ - 1.2f);
        Battle.Fighter me = viewer;
        // tiles near the camera only (Showdown maps are 60×60)
        int c0 = (int) Math.max(0, camX - 14), c1 = (int) Math.min(b.width - 1, camX + 14);
        int r0 = (int) Math.max(0, camZ - 14), r1 = (int) Math.min(b.height - 1, camZ + 9);
        float hx = me != null && me.alive ? me.x : -99, hz = me != null && me.alive ? me.z : -99;
        scenery.addScenery(s, b.cells, c0, c1, r0, r1, hx, hz, false);
        if (mine != null) s.add(mine, mineImg, Scene3d.mul(Scene3d.translate(b.mineX, 0, b.mineZ), Scene3d.zUp())).still = true;
        // gas
        if (b.poison > 0.05f) {
            float p = b.poison;
            gas(s, 0, 0, b.width, p);
            gas(s, 0, b.height - p, b.width, p);
            gas(s, 0, p, p, b.height - 2 * p);
            gas(s, b.width - p, p, p, b.height - 2 * p);
        }
        // areas
        for (Battle.Area a : b.areas) {
            if (a.kind.equals("push")) continue;
            Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(a.x, 0.05f, a.z), Scene3d.scale(a.radius, 1, a.radius)));
            it.color = a.heal ? 0x5550E060 : a.kind.equals("magnet") ? 0x337A5CFF : a.kind.equals("grounded") ? 0x3359C8FF : teamColor(a.team, 0x44);
            it.overlay = true;
        }
        // items
        for (Battle.Item it : b.items) {
            float bob = 0.35f + 0.08f * (float) Math.sin(b.time * 4 + it.x);
            if (it.type == 2 && cube != null) {
                Scene3d.Item x = s.add(cube, cubeImg, Scene3d.mul(Scene3d.translate(it.x, 0.1f, it.z), Scene3d.mul(Scene3d.rotateY(b.time), Scene3d.scale(0.1f))));
                x.color = 0xFFFFFFFF;
            } else {
                Scene3d.Item x = s.add(gem, null, Scene3d.mul(Scene3d.translate(it.x, bob, it.z), Scene3d.mul(Scene3d.rotateY(b.time * 2), Scene3d.scale(0.28f))));
                x.color = it.type == 0 ? 0xFFC651FF : it.type == 1 ? 0xFFFFD23A : 0xFF52E06A;
                x.flash = 0x202020;
            }
        }
        // fighters
        for (Battle.Fighter f : b.fighters) {
            if (!f.alive) continue;
            boolean seen = me == null || b.visibleTo(f, me);
            if (!seen) continue;
            shadow(s, f);
            Assets.Actor a = actor(f.kit.skin);
            if (a == null || a.model == null) continue;
            boolean loop = "idle".equals(f.action) || "walk".equals(f.action);
            Model3d m = a.posed(f.box ? "idle" : f.action, f.box ? b.time : b.time - f.actionStart, f.box || loop);
            float k = Showcase.CHAR_SCALE * f.kit.scale / 100f * (f.pet ? 0.9f : 1f);
            if (f.box) k = Showcase.CHAR_SCALE * 1.1f;
            Scene3d.Item it = s.add(m, a.images, Scene3d.mul(Scene3d.translate(f.x, 0, f.z), Scene3d.mul(Scene3d.rotateY(f.face), Scene3d.scale(k))));
            it.override = a.override;
            boolean ghost = f.invisible(b.time) || (f.inBush && me != null && !(me.team != f.team) );
            if (ghost) it.color = 0x99FFFFFF;
            if (f.flash > 0) it.flash = 0x707070;
            if (f.markUntil > b.time) { // Vince's caterpillar mark
                Scene3d.Item mk = s.add(disc, null, Scene3d.mul(Scene3d.translate(f.x, 0.06f, f.z), Scene3d.scale(0.5f, 1, 0.5f)));
                mk.color = 0x8890E040;
                mk.overlay = true;
            }
            int moths = Specials.visibleMoths(f);
            if (moths > 0 && moth != null && moth.model != null) {
                for (int i = 0; i < moths; i++) {
                    float ang = b.time * 1.6f + (float) (Math.PI * 2 * i / moths);
                    float mx = f.x + (float) Math.cos(ang) * 0.7f, mz = f.z + (float) Math.sin(ang) * 0.7f;
                    Model3d mm = moth.posed("idle", b.time + i * 0.3f, true);
                    Scene3d.Item mi = s.add(mm, moth.images, Scene3d.mul(Scene3d.translate(mx, 0.9f + 0.1f * (float) Math.sin(b.time * 3 + i), mz),
                            Scene3d.mul(Scene3d.rotateY(ang + (float) Math.PI), Scene3d.scale(Showcase.CHAR_SCALE * 0.6f))));
                    mi.override = moth.override;
                }
            }
        }
        // ball
        if (b.mode == Battle.Mode.BALL || b.mode == Battle.Mode.HOCKEY) {
            Scene3d.Item sh = s.add(disc, null, Scene3d.mul(Scene3d.translate(b.ballX, 0.04f, b.ballZ), Scene3d.scale(0.3f, 1, 0.26f)));
            sh.color = 0x50000000;
            sh.overlay = true;
            if (ball != null && ball.model != null) {
                float bs = 0.8f / Math.max(0.1f, ball.height());
                Scene3d.Item it = s.add(ball.model, ball.images, Scene3d.mul(Scene3d.translate(b.ballX, b.ballH, b.ballZ), Scene3d.scale(bs)));
                it.override = ball.override;
            } else {
                Scene3d.Item it = s.add(gem, null, Scene3d.mul(Scene3d.translate(b.ballX, 0.3f + b.ballH, b.ballZ), Scene3d.scale(0.3f)));
                it.color = 0xFFF2F2F2;
            }
        }
        // shots and effects
        if (effects != null) {
            effects.addTo(s, me);
        } else {
            for (Battle.Shot sh : b.shots) {
                float r = Math.max(0.13f, Math.min(0.5f, sh.radius * 0.8f));
                Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(sh.x, sh.h, sh.z), Scene3d.scale(r, 1, r)));
                it.color = sh.ulti ? 0xFFFFD040 : (me != null && sh.team == me.team) ? 0xFF8FD3FF : 0xFFFF6A50;
                it.overlay = true;
            }
        }
        return s;
    }

    void gas(Scene3d s, float x, float z, float w, float h) {
        Scene3d.Item it = s.add(quad, null, Scene3d.mul(Scene3d.translate(x, 0.06f, z), Scene3d.scale(w, 1, h)));
        it.color = 0x6640C040;
        it.overlay = true;
    }

    int teamColor(int team, int alpha) {
        Battle.Fighter me = viewer;
        boolean mine = me != null ? team == me.team : team == 0;
        return (alpha << 24) | (mine ? 0x3D8BFF : 0xFF4040);
    }

    /** the shadow and the team circle under a fighter: green for you, red for enemies (as in the game) */
    void shadow(Scene3d s, Battle.Fighter f) {
        float r = Math.max(0.3f, f.kit.radius * 1.15f);
        Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(f.x, 0.04f, f.z), Scene3d.scale(r, 1, r * 0.85f)));
        it.color = 0x50000000;
        it.overlay = true;
        if (f.box) return;
        boolean mine = f == viewer, friend = viewer != null && f.team == viewer.team;
        float rr = f.dummy ? Math.max(0.55f, f.kit.radius * 1.5f) : r * 1.25f;
        Scene3d.Item fill = s.add(disc, null, Scene3d.mul(Scene3d.translate(f.x, 0.045f, f.z), Scene3d.scale(rr, 1, rr)));
        fill.color = mine ? 0x6640D040 : friend ? 0x553D8BFF : 0x66FF4A4A;
        fill.overlay = true;
        Scene3d.Item ring = s.add(RING, null, Scene3d.mul(Scene3d.translate(f.x, 0.05f, f.z), Scene3d.scale(rr, 1, rr)));
        ring.color = mine ? 0xEE2FB52F : friend ? 0xCC3D8BFF : 0xCCFF3A3A;
        ring.overlay = true;
    }

    static final Model3d RING = ring(32, 0.82f);

    /** a flat ring (inner radius {@code in}, outer 1) */
    static Model3d ring(int n, float in) {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "ring";
        p.triangles = n * 2;
        p.pos = new float[n * 18];
        p.nrm = new float[n * 18];
        p.uv = new float[n * 12];
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float[] q = {c0 * in, 0, s0 * in, c0, 0, s0, c1, 0, s1, c0 * in, 0, s0 * in, c1, 0, s1, c1 * in, 0, s1 * in};
            System.arraycopy(q, 0, p.pos, i * 18, 18);
            for (int k = 0; k < 6; k++) p.nrm[i * 18 + k * 3 + 1] = 1;
        }
        p.hasNormals = true;
        m.parts.add(p);
        m.triangles = p.triangles;
        m.bounds = new float[]{-1, 0, -1, 1, 0, 1};
        return m;
    }

    public float headHeight(Battle.Fighter f) {
        Assets.Actor a = actor(f.kit.skin);
        float h = a != null && a.model != null ? a.height() : 12;
        if (f.box) return h * Showcase.CHAR_SCALE * 1.1f + 0.2f;
        return h * Showcase.CHAR_SCALE * f.kit.scale / 100f + 0.25f;
    }

    /** an eight-sided gem (gems, bounty stars) */
    static Model3d diamond() {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "gem";
        float[][] v = {{1, 0, 0}, {0, 0, 1}, {-1, 0, 0}, {0, 0, -1}};
        p.triangles = 8;
        p.pos = new float[72];
        p.nrm = new float[72];
        p.uv = new float[48];
        int t = 0;
        for (int i = 0; i < 4; i++) {
            float[] a = v[i], c = v[(i + 1) % 4];
            for (int top = 0; top < 2; top++) {
                float y = top == 0 ? 1.3f : -1.3f;
                float[] tri = {a[0], 0, a[2], c[0], 0, c[2], 0, y, 0};
                float nx = (a[0] + c[0]) / 2, nz = (a[2] + c[2]) / 2, ny = top == 0 ? 0.6f : -0.6f;
                for (int k = 0; k < 3; k++) {
                    p.pos[t * 9 + k * 3] = tri[k * 3];
                    p.pos[t * 9 + k * 3 + 1] = tri[k * 3 + 1];
                    p.pos[t * 9 + k * 3 + 2] = tri[k * 3 + 2];
                    p.nrm[t * 9 + k * 3] = nx;
                    p.nrm[t * 9 + k * 3 + 1] = ny;
                    p.nrm[t * 9 + k * 3 + 2] = nz;
                }
                t++;
            }
        }
        p.hasNormals = true;
        m.parts.add(p);
        m.triangles = 8;
        m.bounds = new float[]{-1, -1.3f, -1, 1, 1.3f, 1};
        return m;
    }
}
