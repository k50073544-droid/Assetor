package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Reads the game's own tables to know which 2D pieces belong to which ability:
 * characters.csv (weapon / super / hypercharge skills), cards.csv (gadgets, star powers),
 * accessories.csv (gadget -> skill), skills.csv (skill -> projectiles, areas),
 * projectiles_skin.csv and area_effects_skin.csv (-> .sc file + export names), ru.csv (names).
 * Everything is optional: missing tables just mean fewer links.
 */
public final class GameData {

    /** a piece named by the tables */
    public static final class Ref {
        public String file;   // "effects_brawler.sc" (no folder)
        public String export;
        public int ability, phase;
        public boolean red;
    }

    public static final class Hero {
        public String code, key, name;
        /** hero_icon_… export in hero_portraits.sc */
        public String portrait;
        /** other names the game uses for this brawler (icons, emblems): the effect files may use any of them */
        public final List<String> names = new ArrayList<>();
        /** ability -> russian name of the gadget / star power / hypercharge */
        public final Map<Integer, String> abilityNames = new HashMap<>();
        public final List<Ref> refs = new ArrayList<>();
    }

    public final Map<String, Hero> heroes = new LinkedHashMap<>();

    /** column-name access to a csv table (row 0 = names, row 1 = types) */
    static final class Table {
        final Map<String, Integer> col = new HashMap<>();
        final List<String[]> rows;
        final Map<String, String[]> byName = new HashMap<>();

        Table(List<String[]> raw) {
            rows = raw == null ? new ArrayList<>() : raw;
            if (!rows.isEmpty()) {
                String[] h = rows.get(0);
                for (int i = 0; i < h.length; i++) col.put(h[i].trim(), i);
            }
            for (int i = 2; i < rows.size(); i++) {
                String n = get(rows.get(i), "Name");
                if (!n.isEmpty() && !byName.containsKey(n)) byName.put(n, rows.get(i));
            }
        }

        String get(String[] r, String c) {
            Integer i = col.get(c);
            return i == null || r == null || i >= r.length ? "" : r[i].trim();
        }

        List<String[]> data() { return rows.size() > 2 ? rows.subList(2, rows.size()) : new ArrayList<>(); }
    }

    /**
     * @param tables file name (e.g. "characters.csv") -> parsed rows; ru = localization (TID -> text), may be empty
     */
    public static GameData build(Map<String, List<String[]>> tables, Map<String, String> ru) {
        GameData gd = new GameData();
        Table chars = new Table(tables.get("characters.csv"));
        Table skills = new Table(tables.get("skills.csv"));
        Table cards = new Table(tables.get("cards.csv"));
        Table acc = new Table(tables.get("accessories.csv"));
        Table proj = new Table(tables.get("projectiles_skin.csv"));
        if (proj.rows.isEmpty()) proj = new Table(tables.get("projectiles.csv")); // older versions
        Table area = new Table(tables.get("area_effects_skin.csv"));
        if (area.rows.isEmpty()) area = new Table(tables.get("area_effects.csv"));

        Map<String, Hero> byCode = new HashMap<>();
        for (String[] r : chars.data()) {
            if (!"Hero".equals(chars.get(r, "Type"))) continue;
            if ("true".equalsIgnoreCase(chars.get(r, "Disabled"))) continue;
            String item = chars.get(r, "ItemName");
            if (item.isEmpty()) continue;
            Hero h = new Hero();
            h.code = chars.get(r, "Name");
            h.key = BrawlerIndex.normalizeKey(item);
            String tid = chars.get(r, "TID");
            h.name = niceName(ru.get(tid), true);
            if (gd.heroes.containsKey(h.key)) continue;
            h.portrait = chars.get(r, "IconExportName");
            addName(h, h.portrait, "hero_icon_");
            addName(h, chars.get(r, "EmblemExportName"), "mastery_brawler_icon_");
            gd.heroes.put(h.key, h);
            byCode.put(h.code, h);

            String weapon = chars.get(r, "WeaponSkill");
            String ulti = chars.get(r, "UltimateSkill");
            gd.addSkill(h, skills, proj, area, weapon, BrawlerIndex.A_ATTACK, false);
            gd.addSkill(h, skills, proj, area, ulti, BrawlerIndex.A_SUPER, false);
            // hypercharge: overcharged weapon skill, overcharged super, overcharged projectiles of the super
            String[] w = skills.byName.get(weapon);
            String ocWeapon = skills.get(w, "OverchargedVersion");
            if (!ocWeapon.isEmpty() && !ocWeapon.equals(weapon)) gd.addSkill(h, skills, proj, area, ocWeapon, BrawlerIndex.A_HYPER, false);
            String ocUlti = chars.get(r, "OverchargedUltimateSkill");
            if (!ocUlti.isEmpty()) gd.addSkill(h, skills, proj, area, ocUlti, BrawlerIndex.A_HYPER, false);
            gd.addSkill(h, skills, proj, area, ulti, BrawlerIndex.A_HYPER, true);
        }

        // gadgets, star powers, hypercharge names (cards.csv in their own order)
        Map<Hero, int[]> counters = new HashMap<>();
        for (String[] r : cards.data()) {
            Hero h = byCode.get(cards.get(r, "Target"));
            if (h == null || "true".equalsIgnoreCase(cards.get(r, "Disabled"))) continue;
            String meta = cards.get(r, "MetaType");
            String name = niceName(ru.get(cards.get(r, "TID")), false);
            String icon = cards.get(r, "IconExportName");
            addName(h, icon, "icon_item_");
            addName(h, icon, "icon_sp_");
            addName(h, icon, "icon_overcharge_");
            int[] c = counters.get(h);
            if (c == null) counters.put(h, c = new int[2]);
            if ("5".equals(meta)) { // gadget
                c[0]++;
                int ab = c[0] == 1 ? BrawlerIndex.A_GADGET1 : c[0] == 2 ? BrawlerIndex.A_GADGET2 : BrawlerIndex.A_GADGET;
                if (name != null) h.abilityNames.put(ab, name);
                String accName = cards.get(r, "Skill");
                String skill = acc.get(acc.byName.get(accName), "Skill");
                if (skill.isEmpty()) skill = accName;
                gd.addSkill(h, skills, proj, area, skill, ab, false);
            } else if ("4".equals(meta)) { // star power
                c[1]++;
                int ab = c[1] == 1 ? BrawlerIndex.A_STAR1 : c[1] == 2 ? BrawlerIndex.A_STAR2 : BrawlerIndex.A_STAR;
                if (name != null) h.abilityNames.put(ab, name);
                for (String pj : split(cards.get(r, "Projectiles"))) gd.addProjectile(h, proj, pj, ab);
            } else if ("6".equals(meta)) { // hypercharge
                if (name != null) h.abilityNames.put(BrawlerIndex.A_HYPER, name);
            }
        }
        return gd;
    }

    /** "icon_item_cosmo_1" with prefix "icon_item_" -> "cosmo" */
    static void addName(Hero h, String export, String prefix) {
        if (export == null || !export.startsWith(prefix)) return;
        String n = export.substring(prefix.length()).replaceAll("_\\d+.*$", "").replaceAll("_(small|big|ingame).*$", "");
        n = BrawlerIndex.normalizeKey(n);
        if (!n.isEmpty() && !h.names.contains(n)) h.names.add(n);
    }

    private void addSkill(Hero h, Table skills, Table proj, Table area, String skill, int ability, boolean overchargedOnly) {
        if (skill == null || skill.isEmpty()) return;
        String[] s = skills.byName.get(skill);
        if (s == null) return;
        if (!overchargedOnly) {
            for (String p : split(skills.get(s, "Projectiles"))) addProjectile(h, proj, p, ability);
            addArea(h, area, skills.get(s, "AreaEffectObject"), ability);
            addArea(h, area, skills.get(s, "AreaEffectObject2"), ability);
        } else {
            for (String p : split(skills.get(s, "OverchargedProjectiles"))) addProjectile(h, proj, p, ability);
            for (String p : split(skills.get(s, "OverchargedChainProjectile"))) addProjectile(h, proj, p, ability);
            addArea(h, area, skills.get(s, "OverchargedAreaEffectObject"), ability);
            addArea(h, area, skills.get(s, "OverchargedAreaEffectObject2"), ability);
        }
    }

    private void addProjectile(Hero h, Table proj, String name, int ability) {
        String[] p = proj.byName.get(name);
        if (p == null) return;
        String file = fileName(proj.get(p, "FileName"));
        if (file.isEmpty()) return;
        ref(h, file, proj.get(p, "BlueExportName"), ability, BrawlerIndex.P_FLY, false);
        ref(h, file, proj.get(p, "RedExportName"), ability, BrawlerIndex.P_FLY, true);
        ref(h, file, proj.get(p, "BlueGroundGlowExportName"), ability, BrawlerIndex.P_FLY, false);
        ref(h, file, proj.get(p, "RedGroundGlowExportName"), ability, BrawlerIndex.P_FLY, true);
        String pre = fileName(proj.get(p, "PreExplosionExportFileName"));
        if (pre.isEmpty()) pre = file;
        ref(h, pre, proj.get(p, "PreExplosionBlueExportName"), ability, BrawlerIndex.P_HIT, false);
        ref(h, pre, proj.get(p, "PreExplosionRedExportName"), ability, BrawlerIndex.P_HIT, true);
    }

    private void addArea(Hero h, Table area, String name, int ability) {
        if (name.isEmpty()) return;
        String[] a = area.byName.get(name);
        if (a == null) return;
        String file = fileName(area.get(a, "FileName"));
        if (file.isEmpty()) return;
        ref(h, file, area.get(a, "BlueExportName"), ability, BrawlerIndex.P_AREA, false);
        ref(h, file, area.get(a, "RedExportName"), ability, BrawlerIndex.P_AREA, true);
        ref(h, file, area.get(a, "OwnExportName"), ability, BrawlerIndex.P_AREA, false);
        ref(h, file, area.get(a, "ExportNameTop"), ability, BrawlerIndex.P_AREA, false);
        ref(h, file, area.get(a, "ExportNameTopRed"), ability, BrawlerIndex.P_AREA, true);
    }

    private void ref(Hero h, String file, String export, int ability, int phase, boolean red) {
        if (export == null || export.isEmpty()) return;
        for (Ref r : h.refs) if (r.export.equals(export) && r.file.equals(file) && r.ability == ability) return;
        Ref r = new Ref();
        r.file = file;
        r.export = export;
        r.ability = ability;
        r.phase = phase;
        r.red = red || export.toLowerCase(Locale.ROOT).contains("_red");
        h.refs.add(r);
    }

    static String fileName(String path) {
        int i = path.lastIndexOf('/');
        return (i < 0 ? path : path.substring(i + 1)).trim();
    }

    static List<String> split(String v) {
        List<String> out = new ArrayList<>();
        if (v == null) return out;
        for (String s : v.split("[;,]")) if (!s.trim().isEmpty()) out.add(s.trim());
        return out;
    }

    /** "ШЕЛЛИ" -> "Шелли", "СТРЕЛЬБА ПО ТАРЕЛКАМ" -> "Стрельба по тарелкам"; strips <c..> colour tags */
    static String niceName(String s, boolean everyWord) {
        if (s == null) return null;
        String t = s.replaceAll("<[^>]*>", "").trim();
        if (t.isEmpty()) return null;
        if (t.equals(t.toUpperCase(Locale.ROOT))) {
            StringBuilder sb = new StringBuilder();
            boolean start = true;
            for (char c : t.toLowerCase(Locale.forLanguageTag("ru")).toCharArray()) {
                sb.append(start ? Character.toUpperCase(c) : c);
                start = everyWord && (c == ' ' || c == '-' || c == '.');
            }
            t = sb.toString();
        }
        return t;
    }

    /** TID -> text from a localization csv ("TID","RU" columns). */
    public static Map<String, String> localization(List<String[]> rows) {
        Map<String, String> m = new HashMap<>();
        if (rows == null) return m;
        for (int i = 1; i < rows.size(); i++) {
            String[] r = rows.get(i);
            if (r.length >= 2 && !r[0].isEmpty()) m.put(r[0].trim(), r[1]);
        }
        return m;
    }

    /** The csv files this class can use. */
    public static final String[] TABLES = {"characters.csv", "skills.csv", "cards.csv", "accessories.csv",
            "projectiles_skin.csv", "projectiles.csv", "area_effects_skin.csv", "area_effects.csv"};

    /** Minimal CSV parser with quotes (same rules as the table viewer). */
    public static List<String[]> parseCsv(String text) {
        List<String[]> rows = new ArrayList<>();
        List<String> cur = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        cell.append('"');
                        i++;
                    } else {
                        q = false;
                    }
                } else {
                    cell.append(c);
                }
            } else if (c == '"') {
                q = true;
            } else if (c == ',') {
                cur.add(cell.toString());
                cell.setLength(0);
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                cur.add(cell.toString());
                cell.setLength(0);
                rows.add(cur.toArray(new String[0]));
                cur.clear();
            } else {
                cell.append(c);
            }
        }
        if (cell.length() > 0 || !cur.isEmpty()) {
            cur.add(cell.toString());
            rows.add(cur.toArray(new String[0]));
        }
        return rows;
    }
}
