package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A 3D scene: models placed with their own matrices, seen by a perspective camera.
 * World is Y-up. Matrices are 4x4 column-major (like OpenGL). Drawn by the GPU on the phone,
 * and by {@link Render3d#renderScene} on a computer (tests) — the same numbers for both.
 */
public final class Scene3d {

    public static final class Item {
        public Model3d model;
        public Map<String, Img> images;
        public Img override;
        /** model -> world */
        public float[] matrix = identity();
        /** ARGB colour multiplied in (alpha = see-through), 0xFFFFFFFF = as is */
        public int color = 0xFFFFFFFF;
        /** RGB added (white flash when hit), 0 = none */
        public int flash;
        /** parts never change (VBO on the GPU) */
        public boolean still;
        /** draw without lighting and without depth writes (shadows, glows) */
        public boolean overlay;
        /** drawn first and never hides anything (far surroundings, ground decals) */
        public boolean background;
        /** use the parts' per-corner colours instead of a texture */
        public boolean vertexColors;
        /** only parts whose name is in this list (null = all) */
        public List<String> onlyParts;
    }

    public final List<Item> items = new ArrayList<>();
    public float[] view = identity();
    public float fovY = 40f, near = 0.5f, far = 200f;
    public int background = 0xFF1E2230;

    public Item add(Model3d m, Map<String, Img> images, float[] matrix) {
        Item it = new Item();
        it.model = m;
        it.images = images;
        it.matrix = matrix;
        items.add(it);
        return it;
    }

    // ------------------------------------------------------------------ matrices
    public static float[] identity() {
        return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
    }

    /** a * b */
    public static float[] mul(float[] a, float[] b) {
        float[] o = new float[16];
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
                o[c * 4 + r] = s;
            }
        }
        return o;
    }

    public static float[] translate(float x, float y, float z) {
        float[] m = identity();
        m[12] = x;
        m[13] = y;
        m[14] = z;
        return m;
    }

    public static float[] scale(float s) {
        return scale(s, s, s);
    }

    public static float[] scale(float x, float y, float z) {
        float[] m = identity();
        m[0] = x;
        m[5] = y;
        m[10] = z;
        return m;
    }

    /** rotation around Y (radians); angle 0 keeps +Z forward */
    public static float[] rotateY(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float[] m = identity();
        m[0] = c;
        m[2] = -s;
        m[8] = s;
        m[10] = c;
        return m;
    }

    /** Z-up model (map tiles, ground) into the Y-up world: (x, y, z) -> (x, z, -y) */
    public static float[] zUp() {
        return new float[]{1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1};
    }

    public static float[] lookAt(float ex, float ey, float ez, float cx, float cy, float cz) {
        float fx = cx - ex, fy = cy - ey, fz = cz - ez;
        float fl = (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
        fx /= fl;
        fy /= fl;
        fz /= fl;
        // side = f x up(0,1,0)
        float sx = -fz, sy = 0, sz = fx;
        float sl = (float) Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-6f) {
            sx = 1;
            sl = 1;
        }
        sx /= sl;
        sz /= sl;
        // up = s x f
        float ux = sy * fz - sz * fy, uy = sz * fx - sx * fz, uz = sx * fy - sy * fx;
        return new float[]{
                sx, ux, -fx, 0,
                sy, uy, -fy, 0,
                sz, uz, -fz, 0,
                -(sx * ex + sy * ey + sz * ez), -(ux * ex + uy * ey + uz * ez), fx * ex + fy * ey + fz * ez, 1};
    }

    public float[] projection(float aspect) {
        float f = (float) (1 / Math.tan(Math.toRadians(fovY) / 2));
        float[] m = new float[16];
        m[0] = f / aspect;
        m[5] = f;
        m[10] = (far + near) / (near - far);
        m[11] = -1;
        m[14] = 2 * far * near / (near - far);
        return m;
    }

    public static float[] apply(float[] m, float x, float y, float z) {
        return new float[]{
                m[0] * x + m[4] * y + m[8] * z + m[12],
                m[1] * x + m[5] * y + m[9] * z + m[13],
                m[2] * x + m[6] * y + m[10] * z + m[14]};
    }

    /** world point -> screen pixels {x, y, depth}; depth <= 0 means behind the camera */
    public float[] project(float x, float y, float z, int w, int h) {
        float[] c = apply(view, x, y, z);
        float depth = -c[2];
        float f = (float) ((h / 2.0) / Math.tan(Math.toRadians(fovY) / 2));
        if (depth <= 1e-4f) return new float[]{-1e5f, -1e5f, depth};
        return new float[]{w / 2f + c[0] * f / depth, h / 2f - c[1] * f / depth, depth};
    }

    /** screen pixel -> point on the ground plane y = 0 (null when the ray misses it) */
    public float[] unproject(float sx, float sy, int w, int h) {
        float f = (float) ((h / 2.0) / Math.tan(Math.toRadians(fovY) / 2));
        float dx = (sx - w / 2f) / f, dy = -(sy - h / 2f) / f, dz = -1;
        // camera -> world: inverse of the rotation part of view (transpose), camera position
        float[] v = view;
        float wx = v[0] * dx + v[1] * dy + v[2] * dz;
        float wy = v[4] * dx + v[5] * dy + v[6] * dz;
        float wz = v[8] * dx + v[9] * dy + v[10] * dz;
        float ex = -(v[0] * v[12] + v[1] * v[13] + v[2] * v[14]);
        float ey = -(v[4] * v[12] + v[5] * v[13] + v[6] * v[14]);
        float ez = -(v[8] * v[12] + v[9] * v[13] + v[10] * v[14]);
        if (Math.abs(wy) < 1e-6f) return null;
        float t = -ey / wy;
        if (t < 0) return null;
        return new float[]{ex + wx * t, 0, ez + wz * t};
    }

    /** a flat disc (shadow / marker) of radius 1 on y = 0, as a model without texture */
    public static Model3d disc(int segments) {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "disc";
        p.triangles = segments;
        p.pos = new float[segments * 9];
        p.nrm = new float[segments * 9];
        p.uv = new float[segments * 6];
        for (int i = 0; i < segments; i++) {
            double a0 = Math.PI * 2 * i / segments, a1 = Math.PI * 2 * (i + 1) / segments;
            float[] t = {0, 0, 0, (float) Math.cos(a0), 0, (float) Math.sin(a0), (float) Math.cos(a1), 0, (float) Math.sin(a1)};
            System.arraycopy(t, 0, p.pos, i * 9, 9);
            for (int k = 0; k < 3; k++) p.nrm[i * 9 + k * 3 + 1] = 1;
        }
        p.hasNormals = true;
        m.parts.add(p);
        m.triangles = segments;
        m.bounds = new float[]{-1, 0, -1, 1, 0, 1};
        return m;
    }

    /** a unit square tile on y = 0 from (0,0) to (1,1) in x/z */
    public static Model3d quad() {
        Model3d m = Model3d.empty();
        Model3d.Part p = new Model3d.Part();
        p.name = "quad";
        p.triangles = 2;
        p.pos = new float[]{0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1};
        p.nrm = new float[18];
        for (int k = 0; k < 6; k++) p.nrm[k * 3 + 1] = 1;
        p.uv = new float[]{0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1};
        p.hasNormals = true;
        p.hasUv = false;
        m.parts.add(p);
        m.triangles = 2;
        m.bounds = new float[]{0, 0, 0, 1, 0, 1};
        return m;
    }
}
