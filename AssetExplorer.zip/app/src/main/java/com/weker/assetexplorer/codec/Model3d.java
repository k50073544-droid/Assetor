package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Triangles of a glTF model (Supercell flat glTF with the SC_odin_format vertex layout, or plain glTF),
 * in the bind pose: positions, normals and UVs per corner, ready to rasterize.
 * Odin layout follows Supercell-Flat-Converter by Daniil-SV.
 */
public final class Model3d {

    public static final class Part {
        public String name = "";
        public boolean skinned;
        /** per corner (3 per triangle): xyz, nxnynz, uv */
        public float[] pos, nrm, uv;
        public int triangles;
        public boolean visible = true;
        public boolean hasUv, hasNormals;
        /** texture file names from the material (null when the material has none) */
        public String diffuseTex, lightmapDiffuse, lightmapSpecular;
        public String material = "";
        /** skinning: 4 joint slots (index into the skin's joint list) and weights per corner; null when not skinned */
        public int[] joints;
        public float[] weights;
        public int skin = -1;
        /** node the part hangs on (rigid parts follow it in animations) */
        public int node = -1;
    }

    /** glTF skin: joint node indices and their inverse bind matrices (column-major 4x4) */
    public static final class Skin {
        public int[] joints;
        public float[][] inverseBind;
    }

    public final List<Skin> skins = new ArrayList<>();
    /** node hierarchy (for animations): names, parent index (-1 = root), rest local matrix */
    public String[] nodeNames = new String[0];
    public int[] nodeParent = new int[0];
    public float[][] nodeLocal = new float[0][];

    public boolean hasSkinning() {
        for (Part p : parts) if (p.joints != null && p.skin >= 0 && p.skin < skins.size()) return true;
        return false;
    }

    /** "sc3d/alli_make_tex.sctx#repeat" -> "alli_make_tex.sctx" */
    public static String texName(Object o) {
        if (!(o instanceof String)) return null;
        String s = ((String) o).split("#")[0].trim();
        int i = s.lastIndexOf('/');
        s = i >= 0 ? s.substring(i + 1) : s;
        return s.isEmpty() ? null : s;
    }

    /** every texture file name used by the materials of visible and hidden parts */
    public List<String> materialTextures() {
        List<String> out = new ArrayList<>();
        for (Part p : parts) {
            for (String n : new String[]{p.diffuseTex, p.lightmapDiffuse, p.lightmapSpecular}) {
                if (n != null && !out.contains(n)) out.add(n);
            }
        }
        return out;
    }

    public final List<Part> parts = new ArrayList<>();
    public final List<String> info = new ArrayList<>();
    /** min xyz, max xyz over all parts */
    public float[] bounds;
    public int triangles, vertices;

    // odin attribute formats
    static final int F_UBYTE4 = 3, F_RGBA = 9, F_BYTE3 = 12, F_SHORT2N = 22, F_FLOAT2 = 29, F_FLOAT3 = 30, F_WEIGHTS = 36;
    static final int A_POS = 0, A_NORMAL = 1, A_UV0 = 2, A_BONEINDEX = 5, A_BONEWEIGHTS = 6;

    private Glb g;
    private List<Object> materials = new ArrayList<>();
    private final List<int[]> views = new ArrayList<>(); // offset, length, stride

    public static Model3d load(byte[] data) throws IOException {
        Model3d m = new Model3d();
        m.g = Glb.parse(data);
        m.build();
        return m;
    }

    // ------------------------------------------------------------------ helpers over the json tree
    @SuppressWarnings("unchecked")
    static Map<String, Object> map(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }

    @SuppressWarnings("unchecked")
    static List<Object> list(Object o) { return o instanceof List ? (List<Object>) o : new ArrayList<>(); }

    static int num(Object o, int def) { return o instanceof Number ? ((Number) o).intValue() : def; }

    static Map<String, Object> path(Map<String, Object> m, String... keys) {
        Map<String, Object> c = m;
        for (String k : keys) {
            if (c == null) return null;
            c = map(c.get(k));
        }
        return c;
    }

    // ------------------------------------------------------------------ build
    private void build() throws IOException {
        Map<String, Object> j = g.json;
        for (Object o : list(j.get("bufferViews"))) {
            Map<String, Object> bv = map(o);
            views.add(new int[]{num(bv.get("byteOffset"), 0), num(bv.get("byteLength"), 0), num(bv.get("byteStride"), 0)});
        }
        Map<String, Object> odin = path(j, "extensions", "SC_odin_format");
        int odinView = odin == null ? -1 : num(odin.get("bufferView"), -1);
        List<Object> infos = odin == null ? new ArrayList<>() : list(odin.get("meshDataInfos"));
        List<Object> nodes = list(j.get("nodes"));
        List<Object> meshes = list(j.get("meshes"));

        List<Object> odinMats = odin == null ? new ArrayList<>() : list(odin.get("materials"));
        materials = !odinMats.isEmpty() ? odinMats : list(j.get("materials"));
        float[][] world = worldMatrices(nodes);
        for (Object so : list(j.get("skins"))) {
            Map<String, Object> sk = map(so);
            Skin skin = new Skin();
            List<Object> jl = list(sk.get("joints"));
            skin.joints = new int[jl.size()];
            for (int i = 0; i < jl.size(); i++) skin.joints[i] = num(jl.get(i), -1);
            float[] ibm = accessor(num(sk.get("inverseBindMatrices"), -1));
            skin.inverseBind = new float[skin.joints.length][];
            for (int i = 0; i < skin.joints.length; i++) {
                skin.inverseBind[i] = i * 16 + 16 <= ibm.length ? java.util.Arrays.copyOfRange(ibm, i * 16, i * 16 + 16)
                        : new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
            }
            skins.add(skin);
        }
        boolean any = false;
        for (int ni = 0; ni < nodes.size(); ni++) {
            Map<String, Object> n = map(nodes.get(ni));
            int mi = num(n.get("mesh"), -1);
            if (mi < 0 || mi >= meshes.size()) continue;
            any = true;
            addMesh(map(meshes.get(mi)), str(n.get("name"), "mesh " + mi), n.get("skin") != null ? null : world[ni],
                    n.get("skin") != null, odinView, infos);
            int si = num(n.get("skin"), -1);
            for (Part p : parts) {
                if (p.node >= 0) continue;
                p.node = ni;
                if (p.skinned) p.skin = si;
            }
        }
        if (!any) { // meshes without nodes
            for (int mi = 0; mi < meshes.size(); mi++) addMesh(map(meshes.get(mi)), "mesh " + mi, null, false, odinView, infos);
        }
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (Part p : parts) {
            triangles += p.triangles;
            for (int i = 0; i < p.pos.length; i += 3) {
                for (int k = 0; k < 3; k++) {
                    b[k] = Math.min(b[k], p.pos[i + k]);
                    b[k + 3] = Math.max(b[k + 3], p.pos[i + k]);
                }
            }
        }
        if (parts.isEmpty() || b[0] > b[3]) {
            throw new IOException(meshes.isEmpty() ? "В файле нет геометрии (это анимация, камера или материалы)" : "Не удалось прочитать геометрию");
        }
        bounds = b;
    }

    static String str(Object o, String def) { return o instanceof String ? (String) o : def; }

    private void addMesh(Map<String, Object> mesh, String name, float[] mat, boolean skinned, int odinView, List<Object> infos) {
        if (mesh == null) return;
        for (Object po : list(mesh.get("primitives"))) {
            Map<String, Object> prim = map(po);
            if (prim == null) continue;
            int mode = num(prim.get("mode"), 4);
            if (mode != 4) continue;
            int[] idx = indices(num(prim.get("indices"), -1));
            Part part;
            Map<String, Object> o = path(prim, "extensions", "SC_odin_format");
            try {
                if (o != null && odinView >= 0) {
                    int ii = num(o.get("meshDataInfoIndex"), -1);
                    Map<String, Object> mdi = o.containsKey("vertexDescriptors") ? o : (ii >= 0 && ii < infos.size() ? map(infos.get(ii)) : null);
                    if (mdi == null) continue;
                    part = odinPart(mdi, odinView, idx);
                } else {
                    part = plainPart(map(prim.get("attributes")), idx);
                }
            } catch (RuntimeException e) {
                info.add("Часть «" + name + "» не прочитана: " + e);
                continue;
            }
            if (part == null) continue;
            part.name = name;
            part.skinned = skinned;
            applyMaterial(part, num(prim.get("material"), -1));
            if (mat != null) transform(part, mat);
            parts.add(part);
        }
    }

    /** Odin materials name textures in variables.textures; plain glTF ones through textures/images. */
    private void applyMaterial(Part p, int mi) {
        if (mi < 0 || mi >= materials.size()) return;
        Map<String, Object> m = map(materials.get(mi));
        if (m == null) return;
        p.material = str(m.get("name"), "material " + mi);
        Map<String, Object> tex = path(m, "variables", "textures");
        if (tex != null) {
            p.diffuseTex = texName(tex.get("diffuseTex"));
            if (p.diffuseTex == null) p.diffuseTex = texName(tex.get("diffuse"));
            p.lightmapDiffuse = texName(tex.get("lightmapDiffuse"));
            p.lightmapSpecular = texName(tex.get("lightmapSpecular"));
            return;
        }
        Map<String, Object> base = path(m, "pbrMetallicRoughness", "baseColorTexture");
        if (base == null) return;
        List<Object> textures = list(g.json.get("textures")), images = list(g.json.get("images"));
        int ti = num(base.get("index"), -1);
        if (ti < 0 || ti >= textures.size()) return;
        int ii = num(map(textures.get(ti)).get("source"), -1);
        if (ii < 0 || ii >= images.size()) return;
        Map<String, Object> im = map(images.get(ii));
        p.diffuseTex = texName(im.get("uri"));
        if (p.diffuseTex == null) p.diffuseTex = texName(im.get("name"));
    }

    /** index list (triangles); sequential when the primitive has no index accessor */
    private int[] indices(int acc) {
        if (acc < 0) return null;
        float[] v = accessor(acc);
        int[] r = new int[v.length - v.length % 3];
        for (int i = 0; i < r.length; i++) r[i] = (int) v[i];
        return r;
    }

    private Part odinPart(Map<String, Object> mdi, int odinView, int[] idx) {
        if (idx == null) return null;
        byte[] bin = g.bin;
        int base = views.get(odinView)[0];
        Part p = new Part();
        int n = idx.length;
        p.triangles = n / 3;
        p.pos = new float[n * 3];
        p.nrm = new float[n * 3];
        p.uv = new float[n * 2];
        for (Object dO : list(mdi.get("vertexDescriptors"))) {
            Map<String, Object> desc = map(dO);
            int off = base + num(desc.get("offset"), 0), stride = num(desc.get("stride"), 0);
            for (Object aO : list(desc.get("attributes"))) {
                Map<String, Object> a = map(aO);
                int type = num(a.get("index"), -1), fmt = num(a.get("format"), -1), ao = num(a.get("offset"), 0);
                float[] dst;
                int comps;
                if (type == A_POS) { dst = p.pos; comps = 3; }
                else if (type == A_NORMAL) { dst = p.nrm; comps = 3; p.hasNormals = true; }
                else if (type == A_UV0) { dst = p.uv; comps = 2; p.hasUv = true; }
                else if (type == A_BONEINDEX || type == A_BONEWEIGHTS) {
                    readBones(p, bin, off, stride, ao, fmt, type == A_BONEINDEX, idx);
                    continue;
                } else continue;
                float[] tmp = new float[4];
                for (int i = 0; i < n; i++) {
                    int at = off + stride * idx[i] + ao;
                    if (!readFormat(bin, at, fmt, tmp)) {
                        if (type == A_NORMAL) p.hasNormals = false;
                        if (type == A_UV0) p.hasUv = false;
                        info.add("неизвестный формат вершин " + fmt);
                        break;
                    }
                    System.arraycopy(tmp, 0, dst, i * comps, comps);
                }
            }
        }
        return p;
    }

    /** bone indices (4 bytes) or weights (packed 11/11/10 bits, or 4 floats/bytes) per corner */
    private void readBones(Part p, byte[] bin, int off, int stride, int ao, int fmt, boolean indices, int[] idx) {
        int n = idx.length;
        if (p.joints == null) {
            p.joints = new int[n * 4];
            p.weights = new float[n * 4];
            for (int i = 0; i < n; i++) p.weights[i * 4] = 1; // until weights are read
        }
        for (int i = 0; i < n; i++) {
            int at = off + stride * idx[i] + ao;
            if (at < 0 || at + 4 > bin.length) return;
            if (indices) {
                for (int k = 0; k < 4; k++) p.joints[i * 4 + k] = bin[at + k] & 0xFF;
            } else if (fmt == F_WEIGHTS) {
                long v = le32(bin, at) & 0xFFFFFFFFL;
                float x = (v >> 21) * 0.0002442f, y = ((v >> 10) & 0x7FF) * 0.0002442f, z = (v & 0x3FF) * 0.0002442f;
                p.weights[i * 4] = 1 - x - y - z;
                p.weights[i * 4 + 1] = x;
                p.weights[i * 4 + 2] = y;
                p.weights[i * 4 + 3] = z;
            } else {
                float[] tmp = new float[4];
                if (fmt == F_UBYTE4 || fmt == F_RGBA) readFormat(bin, at, fmt, tmp);
                else if (at + 16 <= bin.length) for (int k = 0; k < 4; k++) tmp[k] = Float.intBitsToFloat(le32(bin, at + 4 * k));
                System.arraycopy(tmp, 0, p.weights, i * 4, 4);
            }
        }
    }

    /** decodes one Odin attribute value into out; false for unknown formats */
    static boolean readFormat(byte[] b, int at, int fmt, float[] out) {
        if (at < 0) return false;
        switch (fmt) {
            case F_FLOAT3:
                if (at + 12 > b.length) return false;
                for (int k = 0; k < 3; k++) out[k] = Float.intBitsToFloat(le32(b, at + 4 * k));
                return true;
            case F_FLOAT2:
                if (at + 8 > b.length) return false;
                for (int k = 0; k < 2; k++) out[k] = Float.intBitsToFloat(le32(b, at + 4 * k));
                return true;
            case F_BYTE3:
                if (at + 3 > b.length) return false;
                for (int k = 0; k < 3; k++) out[k] = Math.max(-1f, b[at + k] / 127f);
                return true;
            case F_SHORT2N:
                if (at + 4 > b.length) return false;
                for (int k = 0; k < 2; k++) out[k] = Math.max(-1f, (short) le16(b, at + 2 * k) / 32767f);
                return true;
            case F_UBYTE4:
            case F_RGBA:
                if (at + 4 > b.length) return false;
                for (int k = 0; k < 4; k++) out[k] = (b[at + k] & 0xFF) / 255f;
                return true;
            default:
                return false;
        }
    }

    private Part plainPart(Map<String, Object> attrs, int[] idx) {
        if (attrs == null || attrs.get("POSITION") == null) return null;
        float[] pos = accessor(num(attrs.get("POSITION"), -1));
        float[] nrm = attrs.get("NORMAL") != null ? accessor(num(attrs.get("NORMAL"), -1)) : null;
        float[] uv = attrs.get("TEXCOORD_0") != null ? accessor(num(attrs.get("TEXCOORD_0"), -1)) : null;
        int vc = pos.length / 3;
        if (idx == null) {
            idx = new int[vc - vc % 3];
            for (int i = 0; i < idx.length; i++) idx[i] = i;
        }
        Part p = new Part();
        int n = idx.length;
        p.triangles = n / 3;
        p.pos = new float[n * 3];
        p.nrm = new float[n * 3];
        p.uv = new float[n * 2];
        p.hasNormals = nrm != null && nrm.length >= vc * 3;
        p.hasUv = uv != null && uv.length >= vc * 2;
        float[] jn = attrs.get("JOINTS_0") != null ? accessor(num(attrs.get("JOINTS_0"), -1)) : null;
        float[] wt = attrs.get("WEIGHTS_0") != null ? accessor(num(attrs.get("WEIGHTS_0"), -1)) : null;
        if (jn != null && wt != null && jn.length >= vc * 4 && wt.length >= vc * 4) {
            p.joints = new int[n * 4];
            p.weights = new float[n * 4];
            for (int i = 0; i < n; i++) {
                int v = idx[i];
                if (v < 0 || v >= vc) continue;
                for (int k = 0; k < 4; k++) {
                    p.joints[i * 4 + k] = (int) jn[v * 4 + k];
                    p.weights[i * 4 + k] = wt[v * 4 + k];
                }
            }
        }
        for (int i = 0; i < n; i++) {
            int v = idx[i];
            if (v < 0 || v >= vc) continue;
            System.arraycopy(pos, v * 3, p.pos, i * 3, 3);
            if (p.hasNormals) System.arraycopy(nrm, v * 3, p.nrm, i * 3, 3);
            if (p.hasUv) System.arraycopy(uv, v * 2, p.uv, i * 2, 2);
        }
        return p;
    }

    /** all values of an accessor as floats (normalized ints scaled) */
    private float[] accessor(int ai) {
        List<Object> accs = list(g.json.get("accessors"));
        if (ai < 0 || ai >= accs.size()) return new float[0];
        Map<String, Object> a = map(accs.get(ai));
        int count = num(a.get("count"), 0);
        int ct = num(a.get("componentType"), 5126) & 0xFFFF; // Supercell puts flags in the high bits
        String type = str(a.get("type"), "SCALAR");
        int comps = type.equals("SCALAR") ? 1 : type.equals("VEC2") ? 2 : type.equals("VEC3") ? 3 : type.equals("VEC4") ? 4
                : type.equals("MAT4") ? 16 : type.equals("MAT3") ? 9 : 4;
        boolean norm = Boolean.TRUE.equals(a.get("normalized"));
        int bvi = num(a.get("bufferView"), -1);
        float[] out = new float[count * comps];
        if (bvi < 0 || bvi >= views.size()) return out;
        int[] bv = views.get(bvi);
        int size = ct == 5120 || ct == 5121 ? 1 : ct == 5122 || ct == 5123 ? 2 : 4;
        int stride = bv[2] > 0 ? bv[2] : size * comps;
        int start = bv[0] + num(a.get("byteOffset"), 0);
        byte[] b = g.bin;
        for (int i = 0; i < count; i++) {
            for (int k = 0; k < comps; k++) {
                int p = start + i * stride + k * size;
                if (p + size > b.length) return out;
                float v;
                switch (ct) {
                    case 5120: v = norm ? Math.max(-1f, b[p] / 127f) : b[p]; break;
                    case 5121: v = norm ? (b[p] & 0xFF) / 255f : (b[p] & 0xFF); break;
                    case 5122: v = norm ? Math.max(-1f, (short) le16(b, p) / 32767f) : (short) le16(b, p); break;
                    case 5123: v = norm ? le16(b, p) / 65535f : le16(b, p); break;
                    case 5125: v = (float) (le32(b, p) & 0xFFFFFFFFL); break;
                    default: v = Float.intBitsToFloat(le32(b, p)); break;
                }
                out[i * comps + k] = v;
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ animation
    private float[][] restWorld;
    private Map<String, Integer> nodeByName;

    /**
     * A copy of the model posed by an animation at a (fractional) frame. Bones are matched by name;
     * bones the animation doesn't move keep their rest pose relative to their parent.
     * Parts share UVs and materials with this model; visibility is copied.
     */
    public Model3d pose(Anim3d a, double frame) {
        int n = nodeNames.length;
        synchronized (this) {
            if (restWorld == null) prepareRest();
        }
        float[][] world = new float[n][];
        Anim3d.Track[] tr = new Anim3d.Track[n];
        float[][] st = new float[n][];
        for (int i = 0; i < n; i++) {
            tr[i] = a.tracks.get(nodeNames[i]);
            st[i] = a.statics.get(nodeNames[i]);
        }
        // parents as the animation sees them (skips "bone:SSC" helper nodes the model has in between)
        int[] par = nodeParent.clone();
        for (int i = 0; i < n; i++) {
            if (tr[i] == null && st[i] == null) continue;
            String pn = a.parentOf.get(nodeNames[i]);
            if (pn == null) continue;
            Integer pi = nodeByName.get(pn);
            if (pi != null && pi != i) par[i] = pi;
        }
        for (int i = 0; i < n; i++) world[i] = animWorld(i, par, tr, st, world, frame, 0);

        Model3d out = new Model3d();
        out.bounds = bounds;
        out.triangles = triangles;
        out.skins.addAll(skins);
        out.nodeNames = nodeNames;
        for (Part p : parts) {
            Part q = new Part();
            q.name = p.name;
            q.material = p.material;
            q.diffuseTex = p.diffuseTex;
            q.lightmapDiffuse = p.lightmapDiffuse;
            q.lightmapSpecular = p.lightmapSpecular;
            q.uv = p.uv;
            q.hasUv = p.hasUv;
            q.hasNormals = p.hasNormals;
            q.triangles = p.triangles;
            q.visible = p.visible;
            q.skinned = p.skinned;
            Skin sk = p.skin >= 0 && p.skin < skins.size() ? skins.get(p.skin) : null;
            if (p.joints != null && sk != null) {
                float[][] m = new float[sk.joints.length][];
                for (int j = 0; j < m.length; j++) {
                    int jn = sk.joints[j];
                    m[j] = jn >= 0 && jn < n ? mul(world[jn], sk.inverseBind[j]) : null;
                }
                skin(p, q, m);
            } else if (p.node >= 0 && p.node < n && !p.skinned) {
                // rigid part: move it by how much its node moved from the rest pose
                float[] delta = mul(world[p.node], invert(restWorld[p.node]));
                q.pos = p.pos.clone();
                q.nrm = p.nrm.clone();
                transform(q, delta);
            } else {
                q.pos = p.pos;
                q.nrm = p.nrm;
            }
            out.parts.add(q);
        }
        return out;
    }

    private float[] animWorld(int i, int[] par, Anim3d.Track[] tr, float[][] st, float[][] world, double frame, int depth) {
        if (world[i] != null) return world[i];
        float[] local = tr[i] != null ? Anim3d.sample(tr[i], frame) : st[i] != null ? st[i] : restLocal(i);
        int p = par[i];
        world[i] = p < 0 || depth > 64 ? local : mul(animWorld(p, par, tr, st, world, frame, depth + 1), local);
        return world[i];
    }

    private float[][] restLocalCache;

    private float[] restLocal(int i) {
        if (restLocalCache[i] == null) {
            int p = nodeParent[i];
            restLocalCache[i] = p < 0 ? restWorld[i] : mul(invert(restWorld[p]), restWorld[i]);
        }
        return restLocalCache[i];
    }

    /** rest world matrices: joints from their inverse bind matrices, other nodes from the hierarchy */
    private void prepareRest() {
        int n = nodeNames.length;
        float[][] bind = new float[n][];
        for (Skin sk : skins) {
            for (int j = 0; j < sk.joints.length; j++) {
                int jn = sk.joints[j];
                if (jn >= 0 && jn < n && bind[jn] == null) bind[jn] = invert(sk.inverseBind[j]);
            }
        }
        restWorld = new float[n][];
        for (int i = 0; i < n; i++) restWorld[i] = rest(i, bind, 0);
        restLocalCache = new float[n][];
        nodeByName = new HashMap<>();
        for (int i = 0; i < n; i++) nodeByName.put(nodeNames[i], i);
    }

    private float[] rest(int i, float[][] bind, int depth) {
        if (restWorld[i] != null) return restWorld[i];
        if (bind[i] != null) return restWorld[i] = bind[i];
        int p = nodeParent[i];
        restWorld[i] = p < 0 || depth > 64 ? nodeLocal[i] : mul(rest(p, bind, depth + 1), nodeLocal[i]);
        return restWorld[i];
    }

    /** linear blend skinning of positions and normals */
    static void skin(Part p, Part q, float[][] m) {
        int n = p.triangles * 3;
        q.pos = new float[n * 3];
        q.nrm = new float[n * 3];
        float[] acc = new float[12];
        for (int i = 0; i < n; i++) {
            java.util.Arrays.fill(acc, 0);
            float wsum = 0;
            for (int k = 0; k < 4; k++) {
                float w = p.weights[i * 4 + k];
                if (w <= 0) continue;
                int j = p.joints[i * 4 + k];
                if (j < 0 || j >= m.length || m[j] == null) continue;
                float[] mm = m[j];
                acc[0] += w * mm[0]; acc[1] += w * mm[1]; acc[2] += w * mm[2];
                acc[3] += w * mm[4]; acc[4] += w * mm[5]; acc[5] += w * mm[6];
                acc[6] += w * mm[8]; acc[7] += w * mm[9]; acc[8] += w * mm[10];
                acc[9] += w * mm[12]; acc[10] += w * mm[13]; acc[11] += w * mm[14];
                wsum += w;
            }
            float x = p.pos[i * 3], y = p.pos[i * 3 + 1], z = p.pos[i * 3 + 2];
            float nx = p.nrm[i * 3], ny = p.nrm[i * 3 + 1], nz = p.nrm[i * 3 + 2];
            if (wsum <= 0) {
                System.arraycopy(p.pos, i * 3, q.pos, i * 3, 3);
                System.arraycopy(p.nrm, i * 3, q.nrm, i * 3, 3);
                continue;
            }
            if (Math.abs(wsum - 1) > 1e-3f) for (int k = 0; k < 12; k++) acc[k] /= wsum;
            q.pos[i * 3] = acc[0] * x + acc[3] * y + acc[6] * z + acc[9];
            q.pos[i * 3 + 1] = acc[1] * x + acc[4] * y + acc[7] * z + acc[10];
            q.pos[i * 3 + 2] = acc[2] * x + acc[5] * y + acc[8] * z + acc[11];
            q.nrm[i * 3] = acc[0] * nx + acc[3] * ny + acc[6] * nz;
            q.nrm[i * 3 + 1] = acc[1] * nx + acc[4] * ny + acc[7] * nz;
            q.nrm[i * 3 + 2] = acc[2] * nx + acc[5] * ny + acc[8] * nz;
        }
    }

    /** box around the visible parts (min xyz, max xyz) */
    public float[] measure() {
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (Part p : parts) {
            if (!p.visible) continue;
            for (int i = 0; i + 2 < p.pos.length; i += 3) {
                for (int k = 0; k < 3; k++) {
                    b[k] = Math.min(b[k], p.pos[i + k]);
                    b[k + 3] = Math.max(b[k + 3], p.pos[i + k]);
                }
            }
        }
        return b[0] > b[3] ? bounds : b;
    }

    /** box around the whole animation (a few sampled frames), so the camera doesn't jump while it plays */
    public float[] animationBounds(Anim3d a, int start, int end) {
        if (end < 0 || end >= a.frames) end = a.frames - 1;
        float[] u = null;
        for (int i = 0; i <= 6; i++) {
            float[] b = pose(a, start + (end - start) * i / 6.0).measure();
            if (u == null) u = b.clone();
            else for (int k = 0; k < 3; k++) {
                u[k] = Math.min(u[k], b[k]);
                u[k + 3] = Math.max(u[k + 3], b[k + 3]);
            }
        }
        return u;
    }

    /** how many of the animation's bones exist in this model */
    public int matchingBones(Anim3d a) {
        int c = 0;
        for (String nm : nodeNames) if (a.tracks.containsKey(nm)) c++;
        return c;
    }

    /** general 4x4 inverse (column-major) */
    static float[] invert(float[] m) {
        double[] a = new double[16];
        for (int i = 0; i < 16; i++) a[i] = m[i];
        double[] inv = new double[16];
        inv[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10];
        inv[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10];
        inv[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9];
        inv[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9];
        inv[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10];
        inv[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10];
        inv[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9];
        inv[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9];
        inv[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6];
        inv[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6];
        inv[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5];
        inv[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5];
        inv[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6];
        inv[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6];
        inv[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5];
        inv[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5];
        double det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12];
        float[] r = new float[16];
        if (Math.abs(det) < 1e-20) {
            r[0] = r[5] = r[10] = r[15] = 1;
            return r;
        }
        for (int i = 0; i < 16; i++) r[i] = (float) (inv[i] / det);
        return r;
    }

    // ------------------------------------------------------------------ node transforms
    /** world matrix (column-major 4x4) of every node; parents from children lists or SC_odin_format.parent */
    private float[][] worldMatrices(List<Object> nodes) {
        int n = nodes.size();
        int[] parent = new int[n];
        java.util.Arrays.fill(parent, -1);
        float[][] local = new float[n][];
        for (int i = 0; i < n; i++) {
            Map<String, Object> nd = map(nodes.get(i));
            local[i] = localMatrix(nd);
            for (Object c : list(nd.get("children"))) {
                int ci = num(c, -1);
                if (ci >= 0 && ci < n) parent[ci] = i;
            }
        }
        for (int i = 0; i < n; i++) {
            Map<String, Object> o = path(map(nodes.get(i)), "extensions", "SC_odin_format");
            if (o != null && o.get("parent") != null) {
                int pi = num(o.get("parent"), -1);
                if (pi >= 0 && pi < n && pi != i) parent[i] = pi;
            }
        }
        float[][] world = new float[n][];
        for (int i = 0; i < n; i++) world[i] = resolve(i, parent, local, world, 0);
        nodeNames = new String[n];
        for (int i = 0; i < n; i++) nodeNames[i] = str(map(nodes.get(i)).get("name"), "");
        nodeParent = parent;
        nodeLocal = local;
        return world;
    }

    private float[] resolve(int i, int[] parent, float[][] local, float[][] world, int depth) {
        if (world[i] != null) return world[i];
        if (parent[i] < 0 || depth > 64) return world[i] = local[i];
        return world[i] = mul(resolve(parent[i], parent, local, world, depth + 1), local[i]);
    }

    static float[] localMatrix(Map<String, Object> nd) {
        List<Object> m = list(nd.get("matrix"));
        if (m.size() == 16) {
            float[] r = new float[16];
            for (int i = 0; i < 16; i++) r[i] = ((Number) m.get(i)).floatValue();
            return r;
        }
        float[] t = vec(nd.get("translation"), new float[]{0, 0, 0});
        float[] q = vec(nd.get("rotation"), new float[]{0, 0, 0, 1});
        float[] s = vec(nd.get("scale"), new float[]{1, 1, 1});
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float[] r = {
                1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0,
                2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0,
                2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0,
                t[0], t[1], t[2], 1};
        for (int c = 0; c < 3; c++) for (int k = 0; k < 3; k++) r[c * 4 + k] *= s[c];
        return r;
    }

    static float[] vec(Object o, float[] def) {
        List<Object> l = list(o);
        if (l.size() != def.length) return def;
        float[] r = new float[def.length];
        for (int i = 0; i < r.length; i++) r[i] = ((Number) l.get(i)).floatValue();
        return r;
    }

    static float[] mul(float[] a, float[] b) {
        float[] r = new float[16];
        for (int c = 0; c < 4; c++) {
            for (int rr = 0; rr < 4; rr++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += a[k * 4 + rr] * b[c * 4 + k];
                r[c * 4 + rr] = s;
            }
        }
        return r;
    }

    static void transform(Part p, float[] m) {
        boolean identity = true;
        float[] id = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
        for (int i = 0; i < 16; i++) if (Math.abs(m[i] - id[i]) > 1e-6) identity = false;
        if (identity) return;
        for (int i = 0; i < p.pos.length; i += 3) {
            float x = p.pos[i], y = p.pos[i + 1], z = p.pos[i + 2];
            p.pos[i] = m[0] * x + m[4] * y + m[8] * z + m[12];
            p.pos[i + 1] = m[1] * x + m[5] * y + m[9] * z + m[13];
            p.pos[i + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
            float nx = p.nrm[i], ny = p.nrm[i + 1], nz = p.nrm[i + 2];
            p.nrm[i] = m[0] * nx + m[4] * ny + m[8] * nz;
            p.nrm[i + 1] = m[1] * nx + m[5] * ny + m[9] * nz;
            p.nrm[i + 2] = m[2] * nx + m[6] * ny + m[10] * nz;
        }
    }

    static int le32(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
    }

    static int le16(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
    }

    /** a short summary for the info panel */
    public String summary() {
        StringBuilder sb = new StringBuilder();
        sb.append(g.flat ? "Supercell glTF (flatbuffer + Odin)" : "glTF").append(" · частей: ").append(parts.size())
                .append(" · треугольников: ").append(triangles);
        sb.append(String.format(java.util.Locale.ROOT, "\nРазмер: %.1f × %.1f × %.1f", bounds[3] - bounds[0], bounds[4] - bounds[1], bounds[5] - bounds[2]));
        return sb.toString();
    }

    public Map<String, Object> json() { return g.json; }

    /** names of every texture-like string in the file (images, material variables) */
    public List<String> textureRefs() {
        List<String> out = new ArrayList<>();
        collect(g.json, out, 0);
        return out;
    }

    @SuppressWarnings("unchecked")
    static void collect(Object o, List<String> out, int depth) {
        if (depth > 12) return;
        if (o instanceof Map) for (Object v : ((Map<String, Object>) o).values()) collect(v, out, depth + 1);
        else if (o instanceof List) for (Object v : (List<Object>) o) collect(v, out, depth + 1);
        else if (o instanceof String) {
            String s = ((String) o).split("#")[0];
            String l = s.toLowerCase(java.util.Locale.ROOT);
            if ((l.endsWith(".sctx") || l.endsWith(".png") || l.endsWith(".ktx")) && !out.contains(s)) out.add(s);
        }
    }
}
