package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Triangles of a glTF model (Supercell flat glTF with the SC_odin_format vertex layout, or plain glTF),
 * in the bind pose: positions, normals and UVs per corner, ready to rasterize.
 * Odin layout follows Supercell-Flat-Converter by Daniil-SV.
 */
public final class Model3d {

    public static final class Part {
        public String name = "";
        public boolean skinned;
        /** per corner (3 per triangle): xyz, nxnynz, uv */
        public float[] pos, nrm, uv;
        public int triangles;
        public boolean visible = true;
        public boolean hasUv, hasNormals;
        /** texture file names from the material (null when the material has none) */
        public String diffuseTex, lightmapDiffuse, lightmapSpecular;
        public String material = "";
    }

    /** "sc3d/alli_make_tex.sctx#repeat" -> "alli_make_tex.sctx" */
    public static String texName(Object o) {
        if (!(o instanceof String)) return null;
        String s = ((String) o).split("#")[0].trim();
        int i = s.lastIndexOf('/');
        s = i >= 0 ? s.substring(i + 1) : s;
        return s.isEmpty() ? null : s;
    }

    /** every texture file name used by the materials of visible and hidden parts */
    public List<String> materialTextures() {
        List<String> out = new ArrayList<>();
        for (Part p : parts) {
            for (String n : new String[]{p.diffuseTex, p.lightmapDiffuse, p.lightmapSpecular}) {
                if (n != null && !out.contains(n)) out.add(n);
            }
        }
        return out;
    }

    public final List<Part> parts = new ArrayList<>();
    public final List<String> info = new ArrayList<>();
    /** min xyz, max xyz over all parts */
    public float[] bounds;
    public int triangles, vertices;

    // odin attribute formats
    static final int F_UBYTE4 = 3, F_RGBA = 9, F_BYTE3 = 12, F_SHORT2N = 22, F_FLOAT2 = 29, F_FLOAT3 = 30, F_WEIGHTS = 36;
    static final int A_POS = 0, A_NORMAL = 1, A_UV0 = 2;

    private Glb g;
    private List<Object> materials = new ArrayList<>();
    private final List<int[]> views = new ArrayList<>(); // offset, length, stride

    public static Model3d load(byte[] data) throws IOException {
        Model3d m = new Model3d();
        m.g = Glb.parse(data);
        m.build();
        return m;
    }

    // ------------------------------------------------------------------ helpers over the json tree
    @SuppressWarnings("unchecked")
    static Map<String, Object> map(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }

    @SuppressWarnings("unchecked")
    static List<Object> list(Object o) { return o instanceof List ? (List<Object>) o : new ArrayList<>(); }

    static int num(Object o, int def) { return o instanceof Number ? ((Number) o).intValue() : def; }

    static Map<String, Object> path(Map<String, Object> m, String... keys) {
        Map<String, Object> c = m;
        for (String k : keys) {
            if (c == null) return null;
            c = map(c.get(k));
        }
        return c;
    }

    // ------------------------------------------------------------------ build
    private void build() throws IOException {
        Map<String, Object> j = g.json;
        for (Object o : list(j.get("bufferViews"))) {
            Map<String, Object> bv = map(o);
            views.add(new int[]{num(bv.get("byteOffset"), 0), num(bv.get("byteLength"), 0), num(bv.get("byteStride"), 0)});
        }
        Map<String, Object> odin = path(j, "extensions", "SC_odin_format");
        int odinView = odin == null ? -1 : num(odin.get("bufferView"), -1);
        List<Object> infos = odin == null ? new ArrayList<>() : list(odin.get("meshDataInfos"));
        List<Object> nodes = list(j.get("nodes"));
        List<Object> meshes = list(j.get("meshes"));

        List<Object> odinMats = odin == null ? new ArrayList<>() : list(odin.get("materials"));
        materials = !odinMats.isEmpty() ? odinMats : list(j.get("materials"));
        float[][] world = worldMatrices(nodes);
        boolean any = false;
        for (int ni = 0; ni < nodes.size(); ni++) {
            Map<String, Object> n = map(nodes.get(ni));
            int mi = num(n.get("mesh"), -1);
            if (mi < 0 || mi >= meshes.size()) continue;
            any = true;
            addMesh(map(meshes.get(mi)), str(n.get("name"), "mesh " + mi), n.get("skin") != null ? null : world[ni],
                    n.get("skin") != null, odinView, infos);
        }
        if (!any) { // meshes without nodes
            for (int mi = 0; mi < meshes.size(); mi++) addMesh(map(meshes.get(mi)), "mesh " + mi, null, false, odinView, infos);
        }
        float[] b = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE};
        for (Part p : parts) {
            triangles += p.triangles;
            for (int i = 0; i < p.pos.length; i += 3) {
                for (int k = 0; k < 3; k++) {
                    b[k] = Math.min(b[k], p.pos[i + k]);
                    b[k + 3] = Math.max(b[k + 3], p.pos[i + k]);
                }
            }
        }
        if (parts.isEmpty() || b[0] > b[3]) {
            throw new IOException(meshes.isEmpty() ? "В файле нет геометрии (это анимация, камера или материалы)" : "Не удалось прочитать геометрию");
        }
        bounds = b;
    }

    static String str(Object o, String def) { return o instanceof String ? (String) o : def; }

    private void addMesh(Map<String, Object> mesh, String name, float[] mat, boolean skinned, int odinView, List<Object> infos) {
        if (mesh == null) return;
        for (Object po : list(mesh.get("primitives"))) {
            Map<String, Object> prim = map(po);
            if (prim == null) continue;
            int mode = num(prim.get("mode"), 4);
            if (mode != 4) continue;
            int[] idx = indices(num(prim.get("indices"), -1));
            Part part;
            Map<String, Object> o = path(prim, "extensions", "SC_odin_format");
            try {
                if (o != null && odinView >= 0) {
                    int ii = num(o.get("meshDataInfoIndex"), -1);
                    Map<String, Object> mdi = o.containsKey("vertexDescriptors") ? o : (ii >= 0 && ii < infos.size() ? map(infos.get(ii)) : null);
                    if (mdi == null) continue;
                    part = odinPart(mdi, odinView, idx);
                } else {
                    part = plainPart(map(prim.get("attributes")), idx);
                }
            } catch (RuntimeException e) {
                info.add("Часть «" + name + "» не прочитана: " + e);
                continue;
            }
            if (part == null) continue;
            part.name = name;
            part.skinned = skinned;
            applyMaterial(part, num(prim.get("material"), -1));
            if (mat != null) transform(part, mat);
            parts.add(part);
        }
    }

    /** Odin materials name textures in variables.textures; plain glTF ones through textures/images. */
    private void applyMaterial(Part p, int mi) {
        if (mi < 0 || mi >= materials.size()) return;
        Map<String, Object> m = map(materials.get(mi));
        if (m == null) return;
        p.material = str(m.get("name"), "material " + mi);
        Map<String, Object> tex = path(m, "variables", "textures");
        if (tex != null) {
            p.diffuseTex = texName(tex.get("diffuseTex"));
            if (p.diffuseTex == null) p.diffuseTex = texName(tex.get("diffuse"));
            p.lightmapDiffuse = texName(tex.get("lightmapDiffuse"));
            p.lightmapSpecular = texName(tex.get("lightmapSpecular"));
            return;
        }
        Map<String, Object> base = path(m, "pbrMetallicRoughness", "baseColorTexture");
        if (base == null) return;
        List<Object> textures = list(g.json.get("textures")), images = list(g.json.get("images"));
        int ti = num(base.get("index"), -1);
        if (ti < 0 || ti >= textures.size()) return;
        int ii = num(map(textures.get(ti)).get("source"), -1);
        if (ii < 0 || ii >= images.size()) return;
        Map<String, Object> im = map(images.get(ii));
        p.diffuseTex = texName(im.get("uri"));
        if (p.diffuseTex == null) p.diffuseTex = texName(im.get("name"));
    }

    /** index list (triangles); sequential when the primitive has no index accessor */
    private int[] indices(int acc) {
        if (acc < 0) return null;
        float[] v = accessor(acc);
        int[] r = new int[v.length - v.length % 3];
        for (int i = 0; i < r.length; i++) r[i] = (int) v[i];
        return r;
    }

    private Part odinPart(Map<String, Object> mdi, int odinView, int[] idx) {
        if (idx == null) return null;
        byte[] bin = g.bin;
        int base = views.get(odinView)[0];
        Part p = new Part();
        int n = idx.length;
        p.triangles = n / 3;
        p.pos = new float[n * 3];
        p.nrm = new float[n * 3];
        p.uv = new float[n * 2];
        for (Object dO : list(mdi.get("vertexDescriptors"))) {
            Map<String, Object> desc = map(dO);
            int off = base + num(desc.get("offset"), 0), stride = num(desc.get("stride"), 0);
            for (Object aO : list(desc.get("attributes"))) {
                Map<String, Object> a = map(aO);
                int type = num(a.get("index"), -1), fmt = num(a.get("format"), -1), ao = num(a.get("offset"), 0);
                float[] dst;
                int comps;
                if (type == A_POS) { dst = p.pos; comps = 3; }
                else if (type == A_NORMAL) { dst = p.nrm; comps = 3; p.hasNormals = true; }
                else if (type == A_UV0) { dst = p.uv; comps = 2; p.hasUv = true; }
                else continue;
                float[] tmp = new float[4];
                for (int i = 0; i < n; i++) {
                    int at = off + stride * idx[i] + ao;
                    if (!readFormat(bin, at, fmt, tmp)) {
                        if (type == A_NORMAL) p.hasNormals = false;
                        if (type == A_UV0) p.hasUv = false;
                        info.add("неизвестный формат вершин " + fmt);
                        break;
                    }
                    System.arraycopy(tmp, 0, dst, i * comps, comps);
                }
            }
        }
        return p;
    }

    /** decodes one Odin attribute value into out; false for unknown formats */
    static boolean readFormat(byte[] b, int at, int fmt, float[] out) {
        if (at < 0) return false;
        switch (fmt) {
            case F_FLOAT3:
                if (at + 12 > b.length) return false;
                for (int k = 0; k < 3; k++) out[k] = Float.intBitsToFloat(le32(b, at + 4 * k));
                return true;
            case F_FLOAT2:
                if (at + 8 > b.length) return false;
                for (int k = 0; k < 2; k++) out[k] = Float.intBitsToFloat(le32(b, at + 4 * k));
                return true;
            case F_BYTE3:
                if (at + 3 > b.length) return false;
                for (int k = 0; k < 3; k++) out[k] = Math.max(-1f, b[at + k] / 127f);
                return true;
            case F_SHORT2N:
                if (at + 4 > b.length) return false;
                for (int k = 0; k < 2; k++) out[k] = Math.max(-1f, (short) le16(b, at + 2 * k) / 32767f);
                return true;
            case F_UBYTE4:
            case F_RGBA:
                if (at + 4 > b.length) return false;
                for (int k = 0; k < 4; k++) out[k] = (b[at + k] & 0xFF) / 255f;
                return true;
            default:
                return false;
        }
    }

    private Part plainPart(Map<String, Object> attrs, int[] idx) {
        if (attrs == null || attrs.get("POSITION") == null) return null;
        float[] pos = accessor(num(attrs.get("POSITION"), -1));
        float[] nrm = attrs.get("NORMAL") != null ? accessor(num(attrs.get("NORMAL"), -1)) : null;
        float[] uv = attrs.get("TEXCOORD_0") != null ? accessor(num(attrs.get("TEXCOORD_0"), -1)) : null;
        int vc = pos.length / 3;
        if (idx == null) {
            idx = new int[vc - vc % 3];
            for (int i = 0; i < idx.length; i++) idx[i] = i;
        }
        Part p = new Part();
        int n = idx.length;
        p.triangles = n / 3;
        p.pos = new float[n * 3];
        p.nrm = new float[n * 3];
        p.uv = new float[n * 2];
        p.hasNormals = nrm != null && nrm.length >= vc * 3;
        p.hasUv = uv != null && uv.length >= vc * 2;
        for (int i = 0; i < n; i++) {
            int v = idx[i];
            if (v < 0 || v >= vc) continue;
            System.arraycopy(pos, v * 3, p.pos, i * 3, 3);
            if (p.hasNormals) System.arraycopy(nrm, v * 3, p.nrm, i * 3, 3);
            if (p.hasUv) System.arraycopy(uv, v * 2, p.uv, i * 2, 2);
        }
        return p;
    }

    /** all values of an accessor as floats (normalized ints scaled) */
    private float[] accessor(int ai) {
        List<Object> accs = list(g.json.get("accessors"));
        if (ai < 0 || ai >= accs.size()) return new float[0];
        Map<String, Object> a = map(accs.get(ai));
        int count = num(a.get("count"), 0);
        int ct = num(a.get("componentType"), 5126) & 0xFFFF; // Supercell puts flags in the high bits
        String type = str(a.get("type"), "SCALAR");
        int comps = type.equals("SCALAR") ? 1 : type.equals("VEC2") ? 2 : type.equals("VEC3") ? 3 : type.equals("VEC4") ? 4
                : type.equals("MAT4") ? 16 : type.equals("MAT3") ? 9 : 4;
        boolean norm = Boolean.TRUE.equals(a.get("normalized"));
        int bvi = num(a.get("bufferView"), -1);
        float[] out = new float[count * comps];
        if (bvi < 0 || bvi >= views.size()) return out;
        int[] bv = views.get(bvi);
        int size = ct == 5120 || ct == 5121 ? 1 : ct == 5122 || ct == 5123 ? 2 : 4;
        int stride = bv[2] > 0 ? bv[2] : size * comps;
        int start = bv[0] + num(a.get("byteOffset"), 0);
        byte[] b = g.bin;
        for (int i = 0; i < count; i++) {
            for (int k = 0; k < comps; k++) {
                int p = start + i * stride + k * size;
                if (p + size > b.length) return out;
                float v;
                switch (ct) {
                    case 5120: v = norm ? Math.max(-1f, b[p] / 127f) : b[p]; break;
                    case 5121: v = norm ? (b[p] & 0xFF) / 255f : (b[p] & 0xFF); break;
                    case 5122: v = norm ? Math.max(-1f, (short) le16(b, p) / 32767f) : (short) le16(b, p); break;
                    case 5123: v = norm ? le16(b, p) / 65535f : le16(b, p); break;
                    case 5125: v = (float) (le32(b, p) & 0xFFFFFFFFL); break;
                    default: v = Float.intBitsToFloat(le32(b, p)); break;
                }
                out[i * comps + k] = v;
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ node transforms
    /** world matrix (column-major 4x4) of every node; parents from children lists or SC_odin_format.parent */
    private float[][] worldMatrices(List<Object> nodes) {
        int n = nodes.size();
        int[] parent = new int[n];
        java.util.Arrays.fill(parent, -1);
        float[][] local = new float[n][];
        for (int i = 0; i < n; i++) {
            Map<String, Object> nd = map(nodes.get(i));
            local[i] = localMatrix(nd);
            for (Object c : list(nd.get("children"))) {
                int ci = num(c, -1);
                if (ci >= 0 && ci < n) parent[ci] = i;
            }
        }
        for (int i = 0; i < n; i++) {
            Map<String, Object> o = path(map(nodes.get(i)), "extensions", "SC_odin_format");
            if (o != null && o.get("parent") != null) {
                int pi = num(o.get("parent"), -1);
                if (pi >= 0 && pi < n && pi != i) parent[i] = pi;
            }
        }
        float[][] world = new float[n][];
        for (int i = 0; i < n; i++) world[i] = resolve(i, parent, local, world, 0);
        return world;
    }

    private float[] resolve(int i, int[] parent, float[][] local, float[][] world, int depth) {
        if (world[i] != null) return world[i];
        if (parent[i] < 0 || depth > 64) return world[i] = local[i];
        return world[i] = mul(resolve(parent[i], parent, local, world, depth + 1), local[i]);
    }

    static float[] localMatrix(Map<String, Object> nd) {
        List<Object> m = list(nd.get("matrix"));
        if (m.size() == 16) {
            float[] r = new float[16];
            for (int i = 0; i < 16; i++) r[i] = ((Number) m.get(i)).floatValue();
            return r;
        }
        float[] t = vec(nd.get("translation"), new float[]{0, 0, 0});
        float[] q = vec(nd.get("rotation"), new float[]{0, 0, 0, 1});
        float[] s = vec(nd.get("scale"), new float[]{1, 1, 1});
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float[] r = {
                1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0,
                2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0,
                2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0,
                t[0], t[1], t[2], 1};
        for (int c = 0; c < 3; c++) for (int k = 0; k < 3; k++) r[c * 4 + k] *= s[c];
        return r;
    }

    static float[] vec(Object o, float[] def) {
        List<Object> l = list(o);
        if (l.size() != def.length) return def;
        float[] r = new float[def.length];
        for (int i = 0; i < r.length; i++) r[i] = ((Number) l.get(i)).floatValue();
        return r;
    }

    static float[] mul(float[] a, float[] b) {
        float[] r = new float[16];
        for (int c = 0; c < 4; c++) {
            for (int rr = 0; rr < 4; rr++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += a[k * 4 + rr] * b[c * 4 + k];
                r[c * 4 + rr] = s;
            }
        }
        return r;
    }

    static void transform(Part p, float[] m) {
        boolean identity = true;
        float[] id = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
        for (int i = 0; i < 16; i++) if (Math.abs(m[i] - id[i]) > 1e-6) identity = false;
        if (identity) return;
        for (int i = 0; i < p.pos.length; i += 3) {
            float x = p.pos[i], y = p.pos[i + 1], z = p.pos[i + 2];
            p.pos[i] = m[0] * x + m[4] * y + m[8] * z + m[12];
            p.pos[i + 1] = m[1] * x + m[5] * y + m[9] * z + m[13];
            p.pos[i + 2] = m[2] * x + m[6] * y + m[10] * z + m[14];
            float nx = p.nrm[i], ny = p.nrm[i + 1], nz = p.nrm[i + 2];
            p.nrm[i] = m[0] * nx + m[4] * ny + m[8] * nz;
            p.nrm[i + 1] = m[1] * nx + m[5] * ny + m[9] * nz;
            p.nrm[i + 2] = m[2] * nx + m[6] * ny + m[10] * nz;
        }
    }

    static int le32(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8 | (d[p + 2] & 0xFF) << 16 | (d[p + 3] & 0xFF) << 24;
    }

    static int le16(byte[] d, int p) {
        return (d[p] & 0xFF) | (d[p + 1] & 0xFF) << 8;
    }

    /** a short summary for the info panel */
    public String summary() {
        StringBuilder sb = new StringBuilder();
        sb.append(g.flat ? "Supercell glTF (flatbuffer + Odin)" : "glTF").append(" · частей: ").append(parts.size())
                .append(" · треугольников: ").append(triangles);
        sb.append(String.format(java.util.Locale.ROOT, "\nРазмер: %.1f × %.1f × %.1f", bounds[3] - bounds[0], bounds[4] - bounds[1], bounds[5] - bounds[2]));
        return sb.toString();
    }

    public Map<String, Object> json() { return g.json; }

    /** names of every texture-like string in the file (images, material variables) */
    public List<String> textureRefs() {
        List<String> out = new ArrayList<>();
        collect(g.json, out, 0);
        return out;
    }

    @SuppressWarnings("unchecked")
    static void collect(Object o, List<String> out, int depth) {
        if (depth > 12) return;
        if (o instanceof Map) for (Object v : ((Map<String, Object>) o).values()) collect(v, out, depth + 1);
        else if (o instanceof List) for (Object v : (List<Object>) o) collect(v, out, depth + 1);
        else if (o instanceof String) {
            String s = ((String) o).split("#")[0];
            String l = s.toLowerCase(java.util.Locale.ROOT);
            if ((l.endsWith(".sctx") || l.endsWith(".png") || l.endsWith(".ktx")) && !out.contains(s)) out.add(s);
        }
    }
}
