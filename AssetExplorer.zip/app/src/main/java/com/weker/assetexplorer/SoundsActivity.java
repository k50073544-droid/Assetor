package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.SoundLib;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * "Музыка и звуки": every track of music.csv (menus, battles, seasons, wins / losses) with a player,
 * and every sounds.csv entry — voice lines and sounds by brawler, interface, battle — with search.
 * Tap plays, long tap saves the .ogg.
 */
public final class SoundsActivity extends Activity {

    static final int REQ_SAVE = 9301;

    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private Sfx sfx;
    private List<SoundLib.Track> music = new ArrayList<>();
    private List<SoundLib.Sound> sounds = new ArrayList<>();
    /** rows on screen: String = group header, Track or Sound */
    private final List<Object> rows = new ArrayList<>();
    private final Adapter adapter = new Adapter();
    private int tab;
    private String query = "", group;
    private TextView info, groupBtn, nowTitle, nowTime, playBtn;
    private final TextView[] tabs = new TextView[2];
    private SeekBar seek;
    private LinearLayout player;
    private MediaPlayer mp;
    private SoundLib.Track playing;
    private String pendingSave;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        sfx.maxAtOnce = 2;
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        root.addView(Ui.bold(this, "Музыка и звуки", 19, Ui.TEXT));
        info = Ui.text(this, "Читаю таблицы…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        root.addView(info);
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setGravity(Gravity.CENTER_VERTICAL);
        String[] names = {"Музыка", "Звуки"};
        for (int i = 0; i < 2; i++) {
            TextView t = Ui.chip(this, names[i]);
            final int k = i;
            t.setOnClickListener(v -> {
                tab = k;
                group = null;
                groupBtn.setText("Все группы");
                refresh();
            });
            tabs[i] = t;
            tabRow.addView(t);
        }
        groupBtn = Ui.button(this, "Все группы", false);
        groupBtn.setOnClickListener(v -> pickGroup());
        tabRow.addView(groupBtn, Ui.lp(0, -2, 1));
        root.addView(tabRow);
        EditText search = new EditText(this);
        search.setHint("Поиск: «шелли», «победа», «menu»…");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        search.setPadding(p, Ui.dp(this, 9), p, Ui.dp(this, 9));
        LinearLayout.LayoutParams sl = Ui.lp(-1, -2, 0);
        sl.topMargin = Ui.dp(this, 8);
        sl.bottomMargin = Ui.dp(this, 6);
        root.addView(search, sl);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) {
                query = e.toString().trim().toLowerCase(Locale.ROOT);
                refresh();
            }
        });
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((pa, v, i, id) -> tap(rows.get(i)));
        lv.setOnItemLongClickListener((pa, v, i, id) -> {
            longTap(rows.get(i));
            return true;
        });
        root.addView(lv, Ui.lp(-1, 0, 1));
        root.addView(playerBar());
        setContentView(root);
        new Thread(() -> {
            try {
                Set<String> loose = new HashSet<>();
                Db.Filter f = new Db.Filter();
                f.vid = vid;
                f.type = Categorizer.T_MUSIC;
                for (Db.Row r : Db.get(this).search(f, 5000)) loose.add(r.name);
                List<SoundLib.Track> m = SoundLib.music(gd.db, loose);
                List<SoundLib.Sound> s = SoundLib.sounds(gd.db);
                main.post(() -> {
                    music = m;
                    sounds = s;
                    refresh();
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Ошибка: " + e.getMessage()));
            }
        }).start();
    }

    private View playerBar() {
        player = new LinearLayout(this);
        player.setOrientation(LinearLayout.VERTICAL);
        player.setBackground(Ui.round(Ui.CARD2, Ui.dp(this, 14)));
        int p = Ui.dp(this, 10);
        player.setPadding(p, p, p, p);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        playBtn = Ui.button(this, "⏸", true);
        playBtn.setOnClickListener(v -> {
            if (mp == null) return;
            if (mp.isPlaying()) mp.pause();
            else mp.start();
            playBtn.setText(mp.isPlaying() ? "⏸" : "▶");
        });
        row.addView(playBtn, Ui.lp(Ui.dp(this, 48), -2, 0));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(Ui.dp(this, 10), 0, 0, 0);
        nowTitle = Ui.bold(this, "", 14, Ui.TEXT);
        nowTitle.setSingleLine(true);
        t.addView(nowTitle);
        nowTime = Ui.text(this, "", 11, Ui.MUTED);
        t.addView(nowTime);
        row.addView(t, Ui.lp(0, -2, 1));
        TextView stop = Ui.button(this, "■", false);
        stop.setOnClickListener(v -> stopMusic());
        row.addView(stop, Ui.lp(Ui.dp(this, 48), -2, 0));
        player.addView(row);
        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean user) {
                if (user && mp != null) mp.seekTo(v);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        player.addView(seek, Ui.lp(-1, -2, 0));
        player.setVisibility(View.GONE);
        LinearLayout.LayoutParams lp = Ui.lp(-1, -2, 0);
        lp.topMargin = Ui.dp(this, 6);
        lp.bottomMargin = Ui.dp(this, 8);
        player.setLayoutParams(lp);
        return player;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (mp != null) {
                try {
                    seek.setMax(Math.max(1, mp.getDuration()));
                    seek.setProgress(mp.getCurrentPosition());
                    nowTime.setText(time(mp.getCurrentPosition()) + " / " + time(mp.getDuration())
                            + (playing != null ? "  ·  " + playing.file : ""));
                } catch (IllegalStateException ignored) {
                    // released
                }
            }
            main.postDelayed(this, 500);
        }
    };

    static String time(int ms) {
        int s = Math.max(0, ms / 1000);
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    // ------------------------------------------------------------------ list
    private List<String> groups() {
        List<String> g = new ArrayList<>();
        if (tab == 0) {
            for (String s : SoundLib.MUSIC_GROUPS) g.add(s);
        } else {
            for (SoundLib.Sound s : sounds) if (!g.contains(s.group)) g.add(s.group);
            g.sort((a, b) -> rank(a) != rank(b) ? rank(a) - rank(b) : a.compareTo(b));
        }
        return g;
    }

    static int rank(String g) {
        if (g.startsWith(SoundLib.VOICE)) return 0;
        if (g.startsWith(SoundLib.BRAWLER)) return 1;
        if (g.equals(SoundLib.BATTLE)) return 2;
        return 3;
    }

    private void pickGroup() {
        List<String> g = groups();
        List<String> names = new ArrayList<>();
        names.add("Все группы");
        names.addAll(g);
        new AlertDialog.Builder(this).setTitle("Группа").setItems(names.toArray(new String[0]), (d, w) -> {
            group = w == 0 ? null : g.get(w - 1);
            groupBtn.setText(group == null ? "Все группы" : group);
            refresh();
        }).show();
    }

    private boolean match(String... texts) {
        if (query.isEmpty()) return true;
        for (String t : texts) if (t != null && t.toLowerCase(Locale.ROOT).contains(query)) return true;
        return false;
    }

    private void refresh() {
        for (int i = 0; i < 2; i++) Ui.setChip(this, tabs[i], i == tab);
        rows.clear();
        int n = 0;
        for (String g : groups()) {
            if (group != null && !group.equals(g)) continue;
            boolean head = false;
            if (tab == 0) {
                for (SoundLib.Track t : music) {
                    if (!g.equals(t.group) || !match(t.title, t.name, t.file, String.join(" ", t.usedBy))) continue;
                    if (!head) rows.add(g);
                    head = true;
                    rows.add(t);
                    n++;
                }
            } else {
                for (SoundLib.Sound s : sounds) {
                    if (!g.equals(s.group) || !match(s.title, s.group, String.join(" ", s.files))) continue;
                    if (!head) rows.add(g);
                    head = true;
                    rows.add(s);
                    n++;
                }
            }
        }
        adapter.notifyDataSetChanged();
        info.setText(tab == 0 ? "Треков: " + n + " из " + music.size() + " · нажми — слушать, долгое нажатие — сохранить .ogg"
                : "Звуков: " + n + " из " + sounds.size() + " · нажми — проиграть, долгое нажатие — все файлы и сохранение");
    }

    final class Adapter extends BaseAdapter {
        @Override
        public int getCount() { return rows.size(); }

        @Override
        public Object getItem(int i) { return rows.get(i); }

        @Override
        public long getItemId(int i) { return i; }

        @Override
        public int getViewTypeCount() { return 2; }

        @Override
        public int getItemViewType(int i) { return rows.get(i) instanceof String ? 0 : 1; }

        @Override
        public boolean isEnabled(int i) { return !(rows.get(i) instanceof String); }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            Object o = rows.get(i);
            if (o instanceof String) {
                TextView t = v instanceof TextView ? (TextView) v : Ui.bold(SoundsActivity.this, "", 14, Ui.ACCENT);
                t.setPadding(Ui.dp(SoundsActivity.this, 4), Ui.dp(SoundsActivity.this, 14), 0, Ui.dp(SoundsActivity.this, 6));
                t.setText((String) o);
                return t;
            }
            LinearLayout cell;
            if (v instanceof LinearLayout) cell = (LinearLayout) v;
            else {
                cell = new LinearLayout(SoundsActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                int p = Ui.dp(SoundsActivity.this, 10);
                cell.setPadding(p, Ui.dp(SoundsActivity.this, 8), p, Ui.dp(SoundsActivity.this, 8));
                cell.addView(Ui.bold(SoundsActivity.this, "", 14, Ui.TEXT));
                TextView sub = Ui.text(SoundsActivity.this, "", 11, Ui.MUTED);
                sub.setMaxLines(2);
                cell.addView(sub);
            }
            cell.setBackground(Ui.round(o == playing ? 0xFF2F3A55 : Ui.CARD, Ui.dp(SoundsActivity.this, 10)));
            TextView title = (TextView) cell.getChildAt(0), sub = (TextView) cell.getChildAt(1);
            if (o instanceof SoundLib.Track) {
                SoundLib.Track t = (SoundLib.Track) o;
                title.setText((o == playing ? "♪ " : "") + t.title);
                String used = t.usedBy.isEmpty() ? "" : " · карты: " + String.join(", ", t.usedBy.subList(0, Math.min(4, t.usedBy.size())))
                        + (t.usedBy.size() > 4 ? " и ещё " + (t.usedBy.size() - 4) : "");
                sub.setText(t.file + (t.background ? " · догружается" : "") + used);
            } else {
                SoundLib.Sound s = (SoundLib.Sound) o;
                title.setText(s.title);
                sub.setText(s.files.size() == 1 ? s.files.get(0) : s.files.size() + " вариантов · " + s.files.get(0) + "…");
            }
            ViewGroup.LayoutParams lp = cell.getLayoutParams();
            if (!(lp instanceof android.widget.AbsListView.LayoutParams)) cell.setLayoutParams(new android.widget.AbsListView.LayoutParams(-1, -2));
            return cell;
        }
    }

    // ------------------------------------------------------------------ playing
    private void tap(Object o) {
        if (o instanceof SoundLib.Track) playMusic((SoundLib.Track) o);
        else if (o instanceof SoundLib.Sound) {
            SoundLib.Sound s = (SoundLib.Sound) o;
            String f = s.files.get((int) (Math.random() * s.files.size()));
            if (!sfx.playFile(f)) Toast.makeText(this, "Файла " + Sfx.GameDbName.base(f) + " нет в архиве", Toast.LENGTH_SHORT).show();
        }
    }

    private void playMusic(SoundLib.Track t) {
        stopMusic();
        File f = gd.file(t.file);
        if (f == null || !f.exists()) {
            Toast.makeText(this, "Файла " + t.file + " нет в архиве" + (t.background ? " (игра догружает его отдельно)" : ""), Toast.LENGTH_LONG).show();
            return;
        }
        try {
            mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.setLooping(t.loop);
            mp.prepare();
            mp.start();
            playing = t;
            nowTitle.setText(t.title);
            playBtn.setText("⏸");
            player.setVisibility(View.VISIBLE);
            main.removeCallbacks(tick);
            main.post(tick);
            mp.setOnCompletionListener(p -> playBtn.setText("▶"));
        } catch (Exception e) {
            Toast.makeText(this, "Не играет: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            stopMusic();
        }
        adapter.notifyDataSetChanged();
    }

    private void stopMusic() {
        main.removeCallbacks(tick);
        if (mp != null) {
            try {
                mp.release();
            } catch (Throwable ignored) {
                // gone
            }
            mp = null;
        }
        playing = null;
        if (player != null) player.setVisibility(View.GONE);
        adapter.notifyDataSetChanged();
    }

    private void longTap(Object o) {
        if (o instanceof SoundLib.Track) {
            save(((SoundLib.Track) o).file);
            return;
        }
        SoundLib.Sound s = (SoundLib.Sound) o;
        String[] items = new String[s.files.size()];
        for (int i = 0; i < items.length; i++) items[i] = "▶  " + Sfx.GameDbName.base(s.files.get(i));
        new AlertDialog.Builder(this).setTitle(s.title).setItems(items, (d, w) -> sfx.playFile(s.files.get(w)))
                .setPositiveButton("Сохранить…", (d, w) -> {
                    if (s.files.size() == 1) {
                        save(s.files.get(0));
                        return;
                    }
                    new AlertDialog.Builder(this).setTitle("Какой файл сохранить").setItems(items, (d2, w2) -> save(s.files.get(w2))).show();
                })
                .setNegativeButton("Закрыть", null).show();
    }

    private void save(String file) {
        String base = Sfx.GameDbName.base(file);
        File f = gd.file(base);
        if (f == null || !f.exists()) {
            Toast.makeText(this, "Файла " + base + " нет в архиве", Toast.LENGTH_SHORT).show();
            return;
        }
        pendingSave = base;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/ogg");
        i.putExtra(Intent.EXTRA_TITLE, base);
        try {
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для сохранения файлов", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SAVE || res != RESULT_OK || data == null || data.getData() == null || pendingSave == null) return;
        Uri uri = data.getData();
        File f = gd.file(pendingSave);
        new Thread(() -> {
            String msg;
            try (InputStream in = new FileInputStream(f); OutputStream o = getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new java.io.IOException("нет доступа");
                Importer.copy(in, o, null);
                msg = "Сохранено";
            } catch (Exception e) {
                msg = "Ошибка: " + e.getMessage();
            }
            String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
        }).start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sfx.stopAll();
        if (mp != null && mp.isPlaying()) {
            mp.pause();
            playBtn.setText("▶");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopMusic();
    }
}
