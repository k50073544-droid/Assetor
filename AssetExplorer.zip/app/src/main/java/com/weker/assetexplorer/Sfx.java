package com.weker.assetexplorer;

import android.media.MediaPlayer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Plays the game's sounds by their sounds.csv name (a random one of the files, as the game does). */
public final class Sfx {

    private final GameData gd;
    private final List<MediaPlayer> playing = new ArrayList<>();
    private final Random rnd = new Random();
    /** a few at once at most; voice lines cut each other off */
    public int maxAtOnce = 4;

    public Sfx(GameData gd) {
        this.gd = gd;
    }

    /** returns the file that is played, or null when the sound isn't in the archive */
    public String play(String sound) {
        if (sound == null || sound.isEmpty()) return null;
        List<String> files = gd.db.soundFiles(sound);
        if (files.isEmpty()) files.add(sound.contains(".") ? sound : sound + ".ogg");
        String name = files.get(rnd.nextInt(files.size()));
        return playFile(name) ? name : null;
    }

    /** a sound file by name (sfx/xxx.ogg or xxx.ogg) */
    public boolean playFile(String name) {
        File f = gd.file(GameDbName.base(name));
        if (f == null || !f.exists()) return false;
        try {
            synchronized (playing) {
                while (playing.size() >= maxAtOnce) {
                    MediaPlayer old = playing.remove(0);
                    try {
                        old.release();
                    } catch (Throwable ignored) {
                        // already gone
                    }
                }
            }
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnCompletionListener(p -> {
                synchronized (playing) {
                    playing.remove(p);
                }
                p.release();
            });
            mp.prepare();
            mp.start();
            synchronized (playing) {
                playing.add(mp);
            }
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    public void stopAll() {
        synchronized (playing) {
            for (MediaPlayer p : playing) {
                try {
                    p.release();
                } catch (Throwable ignored) {
                    // gone
                }
            }
            playing.clear();
        }
    }

    /** file name without folders */
    static final class GameDbName {
        static String base(String p) {
            int i = p.lastIndexOf('/');
            return i < 0 ? p : p.substring(i + 1);
        }
    }
}
