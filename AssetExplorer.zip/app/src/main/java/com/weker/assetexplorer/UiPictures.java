package com.weker.assetexplorer;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * The game's own battle controls (the blue and red sticks, the super button and its skull, the gadget button), cut once
 * out of ui.sc into small PNG files in the cache. ui.sc is far too big to keep open (over 100 MB once read), so it is
 * opened only here, once per version, with nothing else loaded; in a battle just the little pictures are read.
 * Where that isn't possible (too little memory, no ui.sc) the battle draws the controls itself.
 */
final class UiPictures {

    /** export, the frames to keep (0 = dim / charging, 1 = bright / ready, 2 = the knob while aiming) and the frame that sets the box */
    private static final Object[][] SPEC = {
            {"virtuastick_move_bg", new int[]{0, 1}, 1},
            {"virtuastick_move_stick", new int[]{0, 1}, 1},
            {"virtuastick_attack_bg", new int[]{0, 1}, 1},
            {"virtuastick_attack_stick", new int[]{0, 1}, 1},
            {"virtuastick_ulti_bg", new int[]{0, 1}, 1},
            {"ulti_stick", new int[]{0, 1, 2}, 1},
            {"button_ulti_skull", new int[]{0}, 0},
            {"virtuastick_item_bg", new int[]{0, 1}, 1},
            {"item_base_stick", new int[]{0, 1, 2}, 1},
            {"overcharge_button", new int[]{0}, 0},
    };
    private static final int SIZE = 320;
    /** needs this much heap to open ui.sc (about 250 MB at the peak) */
    private static final long NEEDS = 360L << 20;

    private UiPictures() {
    }

    private static File dir(GameData gd) {
        return new File(gd.cacheDir(), "ui5b");
    }

    private static File marker(GameData gd) {
        return new File(dir(gd), "done_" + gd.vid + ".txt");
    }

    private static File tries(GameData gd) {
        return new File(dir(gd), "tries_" + gd.vid + ".txt");
    }

    static boolean done(GameData gd) {
        return marker(gd).exists();
    }

    /**
     * Cuts the pictures if that hasn't been done for this version. Heavy (opens ui.sc): call from a background thread
     * before anything else is loaded. Gives up quietly on any trouble (and tries again at most twice).
     */
    static void prepare(GameData gd) {
        if (done(gd)) return;
        try {
            if (Runtime.getRuntime().maxMemory() < NEEDS) return;
            File t = tries(gd);
            int n = 0;
            if (t.exists()) {
                try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(t))) {
                    n = Integer.parseInt(r.readLine().trim());
                } catch (Exception ignored) {
                    n = 0;
                }
            }
            if (n >= 2) return;
            dir(gd).mkdirs();
            try (FileOutputStream o = new FileOutputStream(t)) {
                o.write(String.valueOf(n + 1).getBytes()); // counted before the risky part: a crash here is not repeated forever
            }
            File ui = gd.file("ui.sc");
            if (ui == null) return;
            StringBuilder got = new StringBuilder();
            for (Object[] sp : SPEC) {
                String name = (String) sp[0];
                int[] frames = (int[]) sp[1];
                boolean all = true;
                for (int fr : frames) if (!new File(dir(gd), name + "_" + fr + ".png").exists()) all = false;
                if (all) {
                    got.append(name).append('\n');
                    continue;
                }
                Bitmap[] bs = gd.exportFrames("ui.sc", name, frames, (Integer) sp[2], SIZE);
                for (int i = 0; i < frames.length; i++) {
                    if (bs[i] == null) continue;
                    try (FileOutputStream o = new FileOutputStream(new File(dir(gd), name + "_" + frames[i] + ".png"))) {
                        bs[i].compress(Bitmap.CompressFormat.PNG, 100, o);
                    }
                    bs[i].recycle();
                }
                got.append(name).append('\n');
            }
            try (FileOutputStream o = new FileOutputStream(marker(gd))) {
                o.write(got.toString().getBytes());
            }
        } catch (Throwable e) {
            CrashLog.survived("картинки интерфейса", e);
        } finally {
            gd.forget("ui.sc");
            gd.forgetAll();
            System.gc();
        }
    }

    /** the cut pictures by "name_frame" (those that exist), each decoded at about {@code max} pixels */
    static Map<String, Bitmap> load(GameData gd, int max) {
        Map<String, Bitmap> m = new HashMap<>();
        for (Object[] sp : SPEC) {
            for (int fr : (int[]) sp[1]) {
                String key = sp[0] + "_" + fr;
                File f = new File(dir(gd), key + ".png");
                if (!f.exists()) continue;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getPath(), o);
                    int s = 1;
                    while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2;
                    o = new BitmapFactory.Options();
                    o.inSampleSize = s;
                    Bitmap b = BitmapFactory.decodeFile(f.getPath(), o);
                    if (b != null) m.put(key, b);
                } catch (Throwable e) {
                    // a missing picture is drawn instead
                }
            }
        }
        return m;
    }
}
