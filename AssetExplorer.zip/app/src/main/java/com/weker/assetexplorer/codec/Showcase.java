package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * A short clip of a brawler (any skin) doing its attack or super with the game's own effects:
 * the skin's attack effect at the muzzle (skin_confs / skills AttackEffect), its projectiles with their
 * pictures, trails and range-end puffs (projectiles_skin.csv), lobbed shots landing with their explosion
 * (area_effects_skin.csv). Rendered on the CPU frame by frame and written as a GIF.
 */
public final class Showcase {

    public static final float CHAR_SCALE = 0.1f;

    final GameDb db;
    final Assets assets;
    final Fx fx;
    final Assets.Actor actor;
    final String skin, code, action;
    final BrawlerStats.Attack attack;
    final String[] proj, area;
    final String castEffect, useEffect;
    final float scale, range, speed, gravity;
    final boolean lob;
    final int bursts;
    final float burstGap;
    final boolean twoGuns;
    final Model3d floor, disc;
    public int background = 0xFF2B3A55;
    /** seconds before the shot leaves */
    public float fireAt = 0.25f;

    static final class Shot {
        float x, z, h, angle, age, flight, dist, max;
        boolean done;
    }

    final List<Shot> shots = new ArrayList<>();
    float time;
    int fired;

    /**
     * @param action "attack" or "ulti"
     */
    public Showcase(GameDb db, Assets assets, GameDb.Source src, Fx.Sprites sprites, String code, String skin, String action) {
        this.db = db;
        this.assets = assets;
        this.code = code;
        this.skin = skin;
        this.action = "ulti".equals(action) ? "ulti" : "attack";
        fx = new Fx(src, sprites);
        actor = assets.actor(skin);
        GameDb.Table ch = db.table("characters.csv");
        String[] cr = ch.row(code);
        scale = cr == null ? 1 : ch.num(cr, "Scale", 100) / 100f;
        String skillName = cr == null ? "" : ch.get(cr, "ulti".equals(this.action) ? "UltimateSkill" : "WeaponSkill");
        attack = BrawlerStats.attack(db, skillName);
        GameDb.Table sk = db.table("skills.csv");
        String[] sr = sk.row(skillName);
        int active = sr == null ? 0 : sk.num(sr, "ActiveTime", 0), between = sr == null ? 0 : sk.num(sr, "MsBetweenAttacks", 0);
        bursts = between > 0 && active > between ? Math.min(8, active / between) : 1;
        burstGap = Math.max(0.05f, between / 1000f);
        twoGuns = sr != null && sk.flag(sr, "TwoGuns");
        range = Math.max(2.5f, Math.min(12f, attack.range <= 0 ? 6 : attack.range));
        String logicProj = attack.projectile.split("[;,]")[0].trim();
        String[] pj = logicProj.isEmpty() ? null : projectile(logicProj);
        if (pj != null && pj[0].isEmpty() && "Attractor".equals(code)) pj = projectile("AttractorOrbiterProjectile"); // Cosmo's carrier has no picture
        proj = pj;
        GameDb.Table pl = db.table("projectiles_logic.csv");
        String[] pr = logicProj.isEmpty() ? null : pl.row(logicProj);
        float sp = pr == null ? 3000 : pl.num(pr, "Speed", 3000);
        speed = Math.max(2f, sp / 300f);
        lob = pr != null && (pl.flag(pr, "Indirect") || pl.num(pr, "Gravity", 0) > 0);
        gravity = pr == null ? 0 : pl.num(pr, "Gravity", 0);
        String areaName = attack.area;
        if (areaName.isEmpty() && pr != null) areaName = pl.get(pr, "SpawnAreaEffectObject");
        area = area(areaName);
        String c = confValue("ulti".equals(this.action) ? "UltiAttackEffect" : "MainAttackEffect");
        if (c.isEmpty()) c = attack.effect;
        castEffect = c;
        useEffect = confValue("ulti".equals(this.action) ? "UltiUseEffect" : "MainAttackUseEffect");
        floor = MapScene.floor((int) Math.ceil(range) + 20, 30);
        disc = Scene3d.disc(24);
    }

    /** total length in seconds */
    public float length() {
        Assets.Clip c = actor == null ? null : actor.clips.get(action);
        float anim = c == null ? 1f : (float) c.length();
        float travel = range / speed + (bursts - 1) * burstGap;
        return Math.max(anim, fireAt + travel + 0.9f) + 0.2f;
    }

    public boolean hasModel() {
        return actor != null && actor.model != null;
    }

    /** prepares the effect pictures first so the clip starts complete */
    public void prewarm() {
        fx.prewarm(castEffect, 0);
        fx.prewarm(useEffect, 0);
        if (proj != null) {
            fx.warmClip(proj[0], proj[1]);
            for (int i = 4; i <= 7; i++) fx.prewarm(proj[i], 0);
        }
        if (area != null) fx.prewarm(area[0], 0);
        fx.takeSounds();
    }

    // ------------------------------------------------------------------ the shot
    void fire(int n) {
        float side = twoGuns ? ((n & 1) == 0 ? 0.18f : -0.18f) : 0;
        if (n == 0 || bursts > 1) fx.play(castEffect, 0.45f, 0.55f, side, ANGLE, 1);
        if (n == 0 && !useEffect.isEmpty()) fx.play(useEffect, 0, 0.05f, 0, ANGLE, 1);
        int count = Math.max(1, Math.min(12, attack.bullets));
        float spread = (float) Math.toRadians(attack.spread);
        for (int i = 0; i < count; i++) {
            Shot s = new Shot();
            float off = count == 1 ? 0 : -spread / 2 + spread * i / (count - 1);
            s.angle = ANGLE + off;
            s.x = 0.45f;
            s.z = side;
            s.h = 0.55f;
            s.max = lob ? range * (count == 1 ? 1 : 0.9f + 0.1f * i / (count - 1)) : range;
            shots.add(s);
        }
    }

    /** brawler faces +x */
    static final float ANGLE = (float) (Math.PI / 2);

    public void step(float dt) {
        time += dt;
        while (fired < bursts && time >= fireAt + fired * burstGap) fire(fired++);
        for (Shot s : shots) {
            if (s.done) continue;
            s.age += dt;
            float d = speed * dt;
            s.dist += d;
            s.x += (float) Math.sin(s.angle) * d;
            s.z += (float) Math.cos(s.angle) * d;
            if (lob) {
                float t = Math.min(1, s.dist / s.max);
                s.h = 0.5f + 4f * (0.4f + s.max * 0.12f) * t * (1 - t);
            }
            if (proj != null && !proj[7].isEmpty() && ((int) (s.age / 0.07f) != (int) ((s.age - dt) / 0.07f)))
                fx.play(proj[7], s.x, s.h, s.z, s.angle, 1);
            if (s.dist >= s.max) {
                s.done = true;
                if (area != null) fx.play(area[0], s.x, 0.05f, s.z, 0, Float.parseFloat(area[1]) / 100f);
                else if (proj != null && !proj[6].isEmpty()) fx.play(proj[6], s.x, 0.3f, s.z, s.angle, 1);
            }
        }
        shots.removeIf(s -> s.done);
        if (fired == bursts && shots.isEmpty() && proj == null && area != null && time - dt < fireAt + 0.3f && time >= fireAt + 0.3f)
            fx.play(area[0], range * 0.5f, 0.05f, 0, 0, Float.parseFloat(area[1]) / 100f);
        fx.step(dt);
        fx.takeSounds();
    }

    // ------------------------------------------------------------------ the picture
    public Scene3d build(float aspect) {
        Scene3d s = new Scene3d();
        s.background = background;
        s.fovY = 33;
        float extra = area != null ? 1.6f : 0.6f;
        float cx = (range + extra - 1.2f) / 2f;
        float half = (range + extra + 1.2f) / 2f;
        float tan = (float) Math.tan(Math.toRadians(s.fovY / 2));
        float zHalf = lob ? 1.2f : Math.max(1.2f, range * (float) Math.sin(Math.toRadians(Math.min(120, attack.spread)) / 2) + 0.6f);
        float dist = 1.1f * Math.max(6f, Math.max(half / tan / Math.max(0.6f, aspect), zHalf * 0.62f / tan));
        s.view = Scene3d.lookAt(cx, dist * 0.62f, dist * 0.78f, cx, 0.5f, -0.7f);
        s.near = 0.5f;
        s.far = dist * 3 + 40;
        Scene3d.Item fl = s.add(floor, null, Scene3d.translate(-10, 0, -18f));
        fl.vertexColors = true;
        fl.still = true;
        fl.background = true; // effects on the ground are flat pictures standing up: the floor must not hide their lower half
        Scene3d.Item sh = s.add(disc, null, Scene3d.mul(Scene3d.translate(0, 0.03f, 0), Scene3d.scale(0.45f, 1, 0.4f)));
        sh.color = 0x50000000;
        sh.overlay = true;
        Scene3d.Item ring = s.add(disc, null, Scene3d.mul(Scene3d.translate(0, 0.035f, 0), Scene3d.scale(0.62f, 1, 0.62f)));
        ring.color = 0x6640D040;
        ring.overlay = true;
        if (hasModel()) {
            Model3d m = actor.posed(action, time, false);
            float k = CHAR_SCALE * scale;
            Scene3d.Item it = s.add(m, actor.images, Scene3d.mul(Scene3d.rotateY(ANGLE), Scene3d.scale(k)));
            it.override = actor.override;
        }
        Fx.Sprites sp = fx.sprites;
        for (Shot sh2 : shots) {
            if (proj == null || sp == null) {
                Scene3d.Item it = s.add(disc, null, Scene3d.mul(Scene3d.translate(sh2.x, sh2.h, sh2.z), Scene3d.scale(0.15f)));
                it.color = 0xFF8FD3FF;
                it.overlay = true;
                continue;
            }
            float sc = Float.parseFloat(proj[8]) / 100f;
            int frames = Math.max(1, sp.frames(proj[0], proj[1])), fps = sp.fps(proj[0], proj[1]);
            Fx.Sprite f = sp.get(proj[0], proj[1], (int) (sh2.age * fps) % frames);
            boolean noRotate = proj[9].contains("DoNotRotate") || lob;
            Fx.billboard(s, f, sh2.x, sh2.h, sh2.z, noRotate ? 0 : Fx.screenAngle(s, sh2.angle), sc, 1, 1, 1, 1, false);
            if (!proj[3].isEmpty()) {
                Fx.Sprite shadow = sp.get(proj[0], proj[3], 0);
                if (shadow == null) shadow = sp.get("effects.sc", proj[3], 0);
                Fx.billboard(s, shadow, sh2.x, 0.02f, sh2.z, 0, sc * 0.8f, 0.5f, 1, 1, 1, false);
            }
        }
        fx.addTo(s);
        return s;
    }

    /** the whole clip as a GIF */
    public void writeGif(OutputStream out, int w, int h, int fps, Progress progress) throws IOException {
        prewarm();
        float len = length();
        int n = Math.max(2, Math.round(len * fps));
        float dt = 1f / fps;
        List<int[]> frames = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            if (i > 0) step(dt);
            frames.add(Render3d.renderScene(build(w / (float) h), w, h).argb);
            if (progress != null && !progress.at(i + 1, n * 2)) return;
        }
        List<int[]> samples = new ArrayList<>();
        for (int i = 0; i < n; i += Math.max(1, n / 12)) samples.add(frames.get(i));
        GifEncoder ge = new GifEncoder(out, w, h, samples, -1);
        int delay = Math.max(2, Math.round(100f / fps));
        for (int i = 0; i < n; i++) {
            ge.addFrame(frames.get(i), delay);
            frames.set(i, null);
            if (progress != null && !progress.at(n + i + 1, n * 2)) return;
        }
        ge.finish();
    }

    public interface Progress {
        /** return false to stop */
        boolean at(int done, int total);
    }

    // ------------------------------------------------------------------ tables
    String[] conf() {
        GameDb.Table skins = db.table("skins.csv"), confs = db.table("skin_confs.csv");
        String[] s = skins.row(skin);
        return confs.row(s != null ? skins.get(s, "Conf") : skin);
    }

    String confValue(String col) {
        String[] c = conf();
        return c == null ? "" : db.table("skin_confs.csv").get(c, col);
    }

    /** {file, blue, red, shadow, hitEnv, hitChar, reached, trail, scale%, rendering}; a skin may replace the look */
    String[] projectile(String logic) {
        GameDb.Table t = db.table("projectiles_skin.csv");
        if (!t.has("LogicProjectile")) t = db.table("projectiles.csv");
        String[] row = null;
        String[] c = conf();
        if (c != null) {
            for (String n : db.table("skin_confs.csv").get(c, "Projectiles").split("[;,]")) {
                String[] r = t.row(n.trim());
                if (r != null && logic.equals(t.get(r, "LogicProjectile"))) row = r;
            }
        }
        if (row == null) row = t.row(logic);
        if (row == null) for (String[] r : t.rows) if (logic.equals(t.get(r, "LogicProjectile"))) {
            row = r;
            break;
        }
        if (row == null) return null;
        return new String[]{GameDb.fileName(t.get(row, "FileName")), t.get(row, "BlueExportName"), t.get(row, "RedExportName"),
                t.get(row, "ShadowExportName"), t.get(row, "HitEffectEnv"), t.get(row, "HitEffectChar"), t.get(row, "MaxRangeReachedEffect"),
                t.get(row, "TrailEffect"), String.valueOf(t.num(row, "Scale", 100)), t.get(row, "Rendering")};
    }

    /** {effect, scale%} */
    String[] area(String logic) {
        if (logic == null || logic.isEmpty()) return null;
        GameDb.Table t = db.table("area_effects_skin.csv");
        String[] row = null;
        String[] c = conf();
        if (c != null) {
            for (String n : db.table("skin_confs.csv").get(c, "AreaEffects").split("[;,]")) {
                String[] r = t.row(n.trim());
                if (r != null && logic.equals(t.get(r, "Logic"))) row = r;
            }
        }
        if (row == null) row = t.row(logic);
        return row == null || t.get(row, "Effect").isEmpty() ? null : new String[]{t.get(row, "Effect"), String.valueOf(t.num(row, "Scale", 100))};
    }
}
