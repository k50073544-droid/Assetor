package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.Battle;
import com.weker.assetexplorer.codec.BattleScene;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Scene3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * The training cave as in the game: the "Training" map with its dummies, and the brawler with the attack,
 * super and gadget the game files describe (shots, throws, dashes, pets, turrets, shields…).
 * Controls and look come from the game's own ui.sc and font.
 */
public final class CaveActivity extends Activity implements GLSurfaceView.Renderer {

    private final Handler main = new Handler(Looper.getMainLooper());
    private GameData gd;
    private Sfx sfx;
    private GLSurfaceView gl;
    private Hud hud;
    private TextView status;
    private final GlScene glScene = new GlScene();
    private final Object lock = new Object();
    private Battle battle;
    private BattleScene scene;
    private Battle.Fighter me;
    private Scene3d lastScene;
    private long lastNanos;
    private volatile float moveX, moveZ;
    /** {what, dx, dz}: 0 attack, 1 super, 2 gadget */
    private final ConcurrentLinkedQueue<float[]> fire = new ConcurrentLinkedQueue<>();
    private String skin, brawler;
    private GameDb.Brawler info;
    // game pictures
    private Bitmap moveBg, moveStick, attackBg, attackStick, ultiBg, ultiStick, itemBg, itemStick, gadgetIcon;
    private Typeface font = Typeface.DEFAULT_BOLD;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        long vid = getIntent().getLongExtra("vid", -1);
        brawler = getIntent().getStringExtra("brawler");
        skin = getIntent().getStringExtra("skin");
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        sfx.maxAtOnce = 6;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1E2230);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(new GlModelView.Chooser());
        gl.setRenderer(this);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        hud = new Hud(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        status = Ui.bold(this, "Загружаю тренировочную пещеру…", 18, Ui.TEXT);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0xEE0F1A3A);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        new Thread(() -> {
            try {
                font = GameUi.font(gd);
                main.post(() -> status.setTypeface(font));
                GameDb db = gd.db;
                info = db.brawler(brawler);
                if (skin == null && info != null) skin = info.defaultSkin;
                Battle bt = new Battle(db, Battle.Mode.TRAINING, null, System.nanoTime());
                Battle.Fighter f = bt.add(brawler, skin, 0, "me", info != null ? info.name : brawler);
                bt.start();
                BattleScene sc = new BattleScene(bt, gd.assets);
                sc.viewer = f;
                sc.preload();
                sc.camX = f.x;
                sc.camZ = f.z;
                loadPictures();
                synchronized (lock) {
                    battle = bt;
                    scene = sc;
                    me = f;
                    lastNanos = 0;
                }
                main.post(() -> {
                    status.setVisibility(View.GONE);
                    if (info != null) sfx.play(info.voice.get("Появление"));
                    if (sc.actor(f.kit.skin) == null || sc.actor(f.kit.skin).model == null) {
                        android.widget.Toast.makeText(this, "Модели бойца нет в архиве — он показан тенью", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Throwable e) {
                main.post(() -> status.setText("Не удалось открыть пещеру: " + e.getMessage()
                        + "\nНужны таблицы игры (maps.csv, characters.csv, skills.csv…) и 3D-модели в импортированном архиве."));
            }
        }, "cave-load").start();
    }

    /** joysticks and buttons from ui.sc, the gadget icon from cards.csv */
    private void loadPictures() {
        int s = Ui.dp(this, 120);
        moveBg = GameUi.pic(gd, "virtuastick_move_bg", s);
        moveStick = GameUi.pic(gd, "virtuastick_move_stick", s);
        attackBg = GameUi.pic(gd, "virtuastick_attack_bg", s);
        attackStick = GameUi.pic(gd, "virtuastick_attack_stick", s);
        ultiBg = GameUi.pic(gd, "virtuastick_ulti_bg", s);
        ultiStick = GameUi.pic(gd, "ulti_stick", s);
        itemBg = GameUi.pic(gd, "virtuastick_item_bg", s);
        itemStick = GameUi.pic(gd, "item_base_stick", s);
        GameDb.Table cards = gd.db.table("cards.csv");
        for (String[] c : cards.rows) {
            if (!brawler.equals(cards.get(c, "Target")) || !"5".equals(cards.get(c, "MetaType"))) continue;
            String file = GameDb.fileName(cards.get(c, "IconSWF")), ex = cards.get(c, "IconExportName");
            if (!ex.isEmpty()) gadgetIcon = gd.export(file.isEmpty() ? "ui.sc" : file, ex, Ui.dp(this, 48));
            break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
        sfx.stopAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
        lastNanos = 0;
    }

    // ------------------------------------------------------------------ GL thread: step + draw
    @Override
    public void onSurfaceCreated(GL10 g, EGLConfig config) {
        try {
            glScene.init();
        } catch (RuntimeException e) {
            main.post(() -> {
                status.setVisibility(View.VISIBLE);
                status.setText("OpenGL ES 2.0 недоступен: " + e.getMessage());
            });
        }
    }

    @Override
    public void onSurfaceChanged(GL10 g, int w, int h) {
        glScene.resize(w, h);
    }

    @Override
    public void onDrawFrame(GL10 g) {
        Scene3d s = null;
        List<String> events = new ArrayList<>();
        synchronized (lock) {
            if (battle != null) {
                long now = System.nanoTime();
                float dt = lastNanos == 0 ? 0 : (now - lastNanos) / 1e9f;
                lastNanos = now;
                float[] f;
                while ((f = fire.poll()) != null) battle.use(me, (int) f[0], f[1], f[2]);
                battle.input(me, moveX, moveZ);
                battle.step(dt);
                scene.follow(dt);
                events.addAll(battle.events);
                battle.events.clear();
                s = scene.build();
                lastScene = s;
            }
        }
        try {
            glScene.draw(s != null ? s : new Scene3d());
        } catch (RuntimeException e) {
            // a bad frame is skipped
        }
        if (!events.isEmpty()) main.post(() -> sounds(events));
        hud.postInvalidate();
    }

    private long lastVoice;

    private void sounds(List<String> events) {
        if (info == null || me == null) return;
        long now = System.currentTimeMillis();
        String mine = ":" + me.id;
        for (String e : events) {
            String voice = null;
            if (e.equals("ulti" + mine)) voice = info.voice.get("Супер");
            else if (e.equals("kill" + mine)) voice = info.voice.get("Победил врага");
            else if (e.equals("hit" + mine) && now - lastVoice > 2500) voice = info.voice.get("Получил урон");
            else if (e.equals("dead" + mine)) voice = info.voice.get("Поражение");
            else if (e.equals("respawn" + mine)) voice = info.voice.get("Появление");
            else if (e.equals("attack" + mine) && now - lastVoice > 4000 && Math.random() < 0.25) voice = info.voice.get("Атака");
            if (voice != null && sfx.play(voice) != null) lastVoice = now;
        }
    }

    // ------------------------------------------------------------------ HUD
    /** joysticks, buttons, health / ammo bars and damage numbers, drawn like the game does */
    final class Hud extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint grey = new Paint(Paint.FILTER_BITMAP_FLAG);
        int movePtr = -1;
        float moveCx, moveCy, moveX0, moveY0;
        int aimPtr = -1, aimWhat;
        boolean aimMoved;
        float aimCx, aimCy, aimDx, aimDy;
        final float R;

        Hud(Context c) {
            super(c);
            R = Ui.dp(c, 56);
            text.setTextAlign(Paint.Align.CENTER);
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(0);
            grey.setColorFilter(new ColorMatrixColorFilter(cm));
            grey.setAlpha(150);
        }

        float attackX() { return getWidth() - R * 1.9f; }

        float attackY() { return getHeight() - R * 1.6f; }

        float ultiX() { return getWidth() - R * 3.9f; }

        float ultiY() { return getHeight() - R * 1.05f; }

        float itemX() { return getWidth() - R * 3.55f; }

        float itemY() { return getHeight() - R * 2.75f; }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            int idx = e.getActionIndex();
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    float x = e.getX(idx), y = e.getY(idx);
                    int id = e.getPointerId(idx);
                    if (x < Ui.dp(getContext(), 70) && y < Ui.dp(getContext(), 70)) {
                        finish();
                        return true;
                    }
                    if (x < getWidth() * 0.45f && movePtr < 0) {
                        movePtr = id;
                        moveCx = moveX0 = x;
                        moveCy = moveY0 = y;
                    } else if (aimPtr < 0) {
                        int what = 0;
                        float cx = attackX(), cy = attackY();
                        if (Math.hypot(x - ultiX(), y - ultiY()) < R * 0.75f) {
                            what = 1;
                            cx = ultiX();
                            cy = ultiY();
                        } else if (Math.hypot(x - itemX(), y - itemY()) < R * 0.55f) {
                            what = 2;
                            cx = itemX();
                            cy = itemY();
                        } else if (Math.hypot(x - cx, y - cy) > R * 1.5f) {
                            cx = x;
                            cy = y;
                        }
                        aimPtr = id;
                        aimWhat = what;
                        aimCx = cx;
                        aimCy = cy;
                        aimDx = aimDy = 0;
                        aimMoved = false;
                    }
                    break;
                }
                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        int id = e.getPointerId(i);
                        float x = e.getX(i), y = e.getY(i);
                        if (id == movePtr) {
                            moveX0 = x;
                            moveY0 = y;
                            float dx = (x - moveCx) / R, dy = (y - moveCy) / R;
                            float l = (float) Math.sqrt(dx * dx + dy * dy);
                            if (l > 1) {
                                dx /= l;
                                dy /= l;
                            }
                            moveX = dx;
                            moveZ = dy;
                        } else if (id == aimPtr) {
                            aimDx = (x - aimCx) / R;
                            aimDy = (y - aimCy) / R;
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (l > 0.25f) aimMoved = true;
                            if (l > 1) {
                                aimDx /= l;
                                aimDy /= l;
                            }
                        }
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL: {
                    int id = e.getPointerId(idx);
                    if (id == movePtr) {
                        movePtr = -1;
                        moveX = moveZ = 0;
                    } else if (id == aimPtr) {
                        aimPtr = -1;
                        if (a != MotionEvent.ACTION_CANCEL) {
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (!aimMoved || l > 0.25f) fire.add(new float[]{aimWhat, aimMoved ? aimDx : 0, aimMoved ? aimDy : 0});
                        }
                        aimDx = aimDy = 0;
                    }
                    break;
                }
                default:
                    break;
            }
            invalidate();
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            text.setTypeface(font);
            synchronized (lock) {
                if (battle == null || lastScene == null) return;
                drawWorld(c, battle, scene, lastScene);
                drawControls(c, battle, me);
            }
        }

        private void drawWorld(Canvas c, Battle b, BattleScene sc, Scene3d s) {
            int w = getWidth(), h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            // aim guide, as the game shows it: a white cone (yellow for the super)
            if (aimPtr >= 0 && aimMoved && me.alive) {
                Battle.Skill sk = aimWhat == 0 ? me.kit.weapon : aimWhat == 1 ? me.kit.ulti : me.kit.gadget;
                if (sk != null) {
                    float ang = (float) Math.atan2(aimDx, aimDy);
                    float len = (float) Math.min(1, Math.hypot(aimDx, aimDy));
                    Path path = new Path();
                    if (sk.kind == Battle.Kind.LOB || sk.kind == Battle.Kind.SUMMON || sk.kind == Battle.Kind.JUMP) {
                        float tx = me.x + (float) Math.sin(ang) * sk.range * len, tz = me.z + (float) Math.cos(ang) * sk.range * len;
                        float rad = Math.max(0.8f, sk.areaRadius);
                        for (int i = 0; i <= 24; i++) {
                            double t = Math.PI * 2 * i / 24;
                            float[] q = s.project(tx + (float) Math.cos(t) * rad, 0.05f, tz + (float) Math.sin(t) * rad, w, h);
                            if (i == 0) path.moveTo(q[0], q[1]);
                            else path.lineTo(q[0], q[1]);
                        }
                    } else {
                        float half = (float) Math.toRadians(Math.max(5, Math.min(170, sk.spread / 2f + 3)));
                        float[] a0 = s.project(me.x, 0.05f, me.z, w, h);
                        path.moveTo(a0[0], a0[1]);
                        for (int i = 0; i <= 12; i++) {
                            float t = ang - half + 2 * half * i / 12f;
                            float[] q = s.project(me.x + (float) Math.sin(t) * sk.range, 0.05f, me.z + (float) Math.cos(t) * sk.range, w, h);
                            path.lineTo(q[0], q[1]);
                        }
                    }
                    path.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(aimWhat == 1 ? 0x77FFD23A : aimWhat == 2 ? 0x7768E05A : 0x77FFFFFF);
                    c.drawPath(path, p);
                }
            }
            // health bars over everybody
            for (Battle.Fighter f : b.fighters) {
                if (!f.alive || (f != me && !b.visibleTo(f, me))) continue;
                bar(c, s, sc, f, w, h, d);
            }
            // damage numbers
            text.setTextSize(17 * d);
            for (Battle.Popup pp : b.popups) {
                float[] q = s.project(pp.x, 2.1f + pp.age * 0.9f, pp.z, w, h);
                text.setAlpha((int) (255 * Math.max(0, 1 - pp.age / 1.1f)));
                GameUi.outlined(c, pp.text, q[0], q[1], text, pp.color, 4 * d);
            }
            text.setAlpha(255);
            if (!me.alive) {
                text.setTextSize(26 * d);
                GameUi.outlined(c, String.format(Locale.ROOT, "ВОЗРОЖДЕНИЕ ЧЕРЕЗ %d", (int) Math.ceil(Math.max(0, me.respawnIn))), w / 2f, h * 0.4f, text, 0xFFFFFFFF, 5 * d);
            }
            for (Battle.Fighter f : b.fighters) {
                if (f.alive || !f.dummy || f.respawnIn > 4.8f) continue;
                float[] q = s.project(f.x, 0.4f, f.z, w, h);
                text.setTextSize(14 * d);
                GameUi.outlined(c, String.valueOf((int) Math.ceil(f.respawnIn)), q[0], q[1], text, 0xCCFFFFFF, 3 * d);
            }
        }

        /** the game's bar: dark frame, green (you) / red (enemies), number on it, ammo under yours */
        private void bar(Canvas c, Scene3d s, BattleScene sc, Battle.Fighter f, int w, int h, float d) {
            float[] q = s.project(f.x, sc.headHeight(f), f.z, w, h);
            boolean mine = f == me;
            float bw = (mine ? 66 : f.maxHp >= 50000 ? 86 : 58) * d, bh = 11 * d;
            float x = q[0] - bw / 2, y = q[1] - bh;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xE0101010);
            c.drawRoundRect(new RectF(x - 2.5f * d, y - 2.5f * d, x + bw + 2.5f * d, y + bh + 2.5f * d), 5 * d, 5 * d, p);
            p.setColor(mine ? 0xFF2FD55A : f.team == me.team ? 0xFF3D9BFF : 0xFFF2393C);
            float part = Math.max(0, Math.min(1, f.hp / f.maxHp));
            c.drawRoundRect(new RectF(x, y, x + bw * part, y + bh), 4 * d, 4 * d, p);
            p.setColor(0x33FFFFFF);
            c.drawRect(x, y, x + bw * part, y + bh * 0.45f, p);
            text.setTextSize(12.5f * d);
            GameUi.outlined(c, String.valueOf((int) Math.ceil(f.hp)), q[0], y + bh - 1.2f * d, text, 0xFFFFFFFF, 3 * d);
            if (mine) {
                int max = f.kit.weapon.maxCharge;
                float sw = bw / max;
                for (int i = 0; i < max; i++) {
                    float fill = Math.max(0, Math.min(1, f.ammo - i));
                    float ax = x + i * sw, ay = y + bh + 4.5f * d;
                    p.setColor(0xE0101010);
                    c.drawRect(ax + 0.8f * d, ay, ax + sw - 0.8f * d, ay + 6 * d, p);
                    p.setColor(fill >= 1 ? 0xFFFF9C11 : 0xFF9A5A18);
                    c.drawRect(ax + 1.6f * d, ay + 1 * d, ax + 1.6f * d + (sw - 3.2f * d) * fill, ay + 5 * d, p);
                }
                text.setTextSize(13 * d);
                GameUi.outlined(c, f.name, q[0], y - 6 * d, text, 0xFF7FD8FF, 3 * d);
            }
        }

        private void drawControls(Canvas c, Battle b, Battle.Fighter f) {
            float d = getResources().getDisplayMetrics().density;
            // exit, top left
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xCC1A1A2A);
            c.drawRoundRect(new RectF(12 * d, 12 * d, 56 * d, 56 * d), 10 * d, 10 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 0; k < 2; k++) {
                p.setStrokeWidth(k == 0 ? 9 * d : 5 * d);
                p.setColor(k == 0 ? 0xFF000000 : 0xFFFFFFFF);
                c.drawLine(25 * d, 25 * d, 43 * d, 43 * d, p);
                c.drawLine(43 * d, 25 * d, 25 * d, 43 * d, p);
            }
            p.setStyle(Paint.Style.FILL);
            text.setTextAlign(Paint.Align.LEFT);
            text.setTextSize(16 * d);
            GameUi.outlined(c, "ТРЕНИРОВКА", 68 * d, 32 * d, text, 0xFFFFFFFF, 4 * d);
            text.setTextSize(12 * d);
            GameUi.outlined(c, String.format(Locale.ROOT, "Урон: %d · побеждено: %d", f.damageDone, f.kills), 68 * d, 50 * d, text, 0xFFE0E6FF, 3 * d);
            text.setTextAlign(Paint.Align.CENTER);
            // movement stick: appears where you touch
            float mcx = movePtr >= 0 ? moveCx : R * 1.9f, mcy = movePtr >= 0 ? moveCy : getHeight() - R * 1.6f;
            float mdx = 0, mdy = 0;
            if (movePtr >= 0) {
                mdx = moveX0 - moveCx;
                mdy = moveY0 - moveCy;
                float l = (float) Math.hypot(mdx, mdy);
                if (l > R) {
                    mdx = mdx / l * R;
                    mdy = mdy / l * R;
                }
            }
            stick(c, moveBg, moveStick, mcx, mcy, mdx, mdy, 1f, movePtr >= 0 ? 255 : 150, false, 0xFF2F6FE0);
            // attack
            boolean aA = aimPtr >= 0 && aimWhat == 0;
            stick(c, attackBg, attackStick, aA ? aimCx : attackX(), aA ? aimCy : attackY(), aA ? aimDx * R : 0, aA ? aimDy * R : 0, 1f, 255, false, 0xFFE0352F);
            // super: grey until charged, the charge ring fills around it
            boolean ready = f.superCharge >= 1;
            boolean aU = aimPtr >= 0 && aimWhat == 1;
            float ux = ultiX(), uy = ultiY();
            stick(c, ultiBg, ultiStick, ux, uy, aU ? aimDx * R * 0.8f : 0, aU ? aimDy * R * 0.8f : 0, 0.72f, 255, !ready, 0xFFFFC21F);
            if (!ready) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(6 * d);
                p.setColor(0xFFFFC21F);
                float rr = R * 0.5f;
                c.drawArc(new RectF(ux - rr, uy - rr, ux + rr, uy + rr), -90, 360 * f.superCharge, false, p);
                p.setStyle(Paint.Style.FILL);
            }
            // gadget: green button with the gadget's icon and uses left
            if (f.kit.gadget != null) {
                boolean aG = aimPtr >= 0 && aimWhat == 2;
                float gx = itemX(), gy = itemY();
                stick(c, itemBg, itemStick, gx, gy, aG ? aimDx * R * 0.5f : 0, aG ? aimDy * R * 0.5f : 0, 0.5f, 255, f.gadgets <= 0, 0xFF3BD24A);
                if (gadgetIcon != null) {
                    float gs = R * 0.42f;
                    Paint ip = f.gadgets > 0 ? p : grey;
                    c.drawBitmap(gadgetIcon, null, new RectF(gx - gs / 2, gy - gs / 2, gx + gs / 2, gy + gs / 2), ip);
                }
                text.setTextSize(13 * d);
                GameUi.outlined(c, String.valueOf(f.gadgets), gx + R * 0.38f, gy + R * 0.4f, text, 0xFFFFFFFF, 3 * d);
            }
        }

        /** one of the game's sticks: its ring, and the knob moved by the finger */
        private void stick(Canvas c, Bitmap bg, Bitmap knob, float cx, float cy, float dx, float dy, float scale, int alpha, boolean off, int fallback) {
            float rb = R * scale, rk = R * 0.62f * scale;
            Paint bp = off ? grey : p;
            int oldA = p.getAlpha();
            if (!off) p.setAlpha(alpha);
            if (bg != null) {
                c.drawBitmap(bg, null, new RectF(cx - rb, cy - rb, cx + rb, cy + rb), bp);
            } else {
                p.setColor((fallback & 0x00FFFFFF) | 0x44000000);
                c.drawCircle(cx, cy, rb, p);
            }
            if (knob != null) {
                c.drawBitmap(knob, null, new RectF(cx + dx - rk, cy + dy - rk, cx + dx + rk, cy + dy + rk), bp);
            } else {
                p.setColor(off ? 0xFF777777 : fallback);
                c.drawCircle(cx + dx, cy + dy, rk * 0.8f, p);
            }
            p.setAlpha(oldA);
        }
    }
}
