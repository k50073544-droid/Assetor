package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.weker.assetexplorer.codec.Cave;
import com.weker.assetexplorer.codec.CaveScene;
import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.Scene3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * The training cave: the game's "Training" map with its dummies, and the chosen brawler with its real
 * attack and super numbers. Left stick moves; right stick aims and fires on release (a tap fires at the nearest
 * dummy); the yellow button is the super once it is charged.
 */
public final class CaveActivity extends Activity implements GLSurfaceView.Renderer {

    private final Handler main = new Handler(Looper.getMainLooper());
    private GameData gd;
    private Sfx sfx;
    private GLSurfaceView gl;
    private Hud hud;
    private TextView status;
    private final GlScene glScene = new GlScene();
    /** both are touched only under synchronized (lock) */
    private final Object lock = new Object();
    private Cave cave;
    private CaveScene scene;
    private Scene3d lastScene;
    private long lastNanos;
    private volatile float moveX, moveZ;
    /** fire requests from the UI thread: {dx, dz, isUlti} */
    private final ConcurrentLinkedQueue<float[]> fire = new ConcurrentLinkedQueue<>();
    private String skin, brawler;
    private GameDb.Brawler info;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        long vid = getIntent().getLongExtra("vid", -1);
        brawler = getIntent().getStringExtra("brawler");
        skin = getIntent().getStringExtra("skin");
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        sfx.maxAtOnce = 6;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1E2230);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(new GlModelView.Chooser());
        gl.setRenderer(this);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        hud = new Hud(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        status = Ui.bold(this, "Загружаю тренировочную пещеру…", 16, Ui.TEXT);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0xCC0F1117);
        root.addView(status, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        new Thread(() -> {
            try {
                GameDb db = gd.db;
                info = db.brawler(brawler);
                if (skin == null && info != null) skin = info.defaultSkin;
                Cave c = new Cave(db, brawler);
                CaveScene s = new CaveScene(c, gd.assets, skin);
                synchronized (lock) {
                    cave = c;
                    scene = s;
                    lastNanos = 0;
                }
                main.post(() -> {
                    status.setVisibility(View.GONE);
                    if (info != null) sfx.play(info.voice.get("Появление"));
                    if (s.player == null || s.player.model == null) {
                        android.widget.Toast.makeText(this, "Модель бойца не найдена в архиве — он показан тенью", android.widget.Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Throwable e) {
                main.post(() -> status.setText("Не удалось открыть пещеру: " + e.getMessage()
                        + "\nНужны таблицы игры (maps.csv, characters.csv, skills.csv…) и 3D-модели в импортированном архиве."));
            }
        }, "cave-load").start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
        sfx.stopAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
        lastNanos = 0;
    }

    // ------------------------------------------------------------------ GL thread: step + draw
    @Override
    public void onSurfaceCreated(GL10 g, EGLConfig config) {
        try {
            glScene.init();
        } catch (RuntimeException e) {
            main.post(() -> {
                status.setVisibility(View.VISIBLE);
                status.setText("OpenGL ES 2.0 недоступен: " + e.getMessage());
            });
        }
    }

    @Override
    public void onSurfaceChanged(GL10 g, int w, int h) {
        glScene.resize(w, h);
    }

    @Override
    public void onDrawFrame(GL10 g) {
        Scene3d s = null;
        List<String> events = new ArrayList<>();
        synchronized (lock) {
            if (cave != null) {
                long now = System.nanoTime();
                float dt = lastNanos == 0 ? 0 : (now - lastNanos) / 1e9f;
                lastNanos = now;
                float[] f;
                while ((f = fire.poll()) != null) cave.attack(f[0], f[1], f[2] > 0.5f);
                cave.step(dt, moveX, moveZ);
                scene.follow(dt);
                events.addAll(cave.events);
                cave.events.clear();
                s = scene.build();
                lastScene = s;
            }
        }
        if (s == null) {
            Scene3d empty = new Scene3d();
            glScene.draw(empty);
        } else {
            try {
                glScene.draw(s);
            } catch (RuntimeException e) {
                // keep running; a bad frame is skipped
            }
        }
        if (!events.isEmpty()) main.post(() -> sounds(events));
        hud.postInvalidate();
    }

    private long lastVoice;

    private void sounds(List<String> events) {
        if (info == null) return;
        long now = System.currentTimeMillis();
        for (String e : events) {
            String voice = null;
            switch (e) {
                case "ulti": voice = info.voice.get("Супер"); break;
                case "kill": voice = info.voice.get("Победил врага"); break;
                case "hurt": voice = now - lastVoice > 2500 ? info.voice.get("Получил урон") : null; break;
                case "dead": voice = info.voice.get("Поражение"); break;
                case "respawn": voice = info.voice.get("Появление"); break;
                case "attack": voice = now - lastVoice > 4000 && Math.random() < 0.25 ? info.voice.get("Атака") : null; break;
                default: break;
            }
            if (voice != null && sfx.play(voice) != null) lastVoice = now;
        }
    }

    // ------------------------------------------------------------------ HUD
    /** sticks, buttons, health bars and damage numbers over the 3D view */
    final class Hud extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        // move stick
        int movePtr = -1;
        float moveCx, moveCy, moveX0, moveY0;
        // attack stick / super button
        int aimPtr = -1;
        boolean aimUlti, aimMoved;
        float aimCx, aimCy, aimDx, aimDy;
        final float R;

        Hud(Context c) {
            super(c);
            R = Ui.dp(c, 52);
            text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextAlign(Paint.Align.CENTER);
        }

        float attackX() { return getWidth() - R * 2.1f; }

        float attackY() { return getHeight() - R * 1.7f; }

        float ultiX() { return getWidth() - R * 4.2f; }

        float ultiY() { return getHeight() - R * 1.0f; }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            int idx = e.getActionIndex();
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    float x = e.getX(idx), y = e.getY(idx);
                    int id = e.getPointerId(idx);
                    if (x < Ui.dp(getContext(), 64) && y < Ui.dp(getContext(), 64)) {
                        finish();
                        return true;
                    }
                    if (x < getWidth() * 0.45f && movePtr < 0) {
                        movePtr = id;
                        moveCx = moveX0 = x;
                        moveCy = moveY0 = y;
                    } else if (aimPtr < 0) {
                        boolean onUlti = dist(x, y, ultiX(), ultiY()) < R * 0.9f;
                        aimPtr = id;
                        aimUlti = onUlti;
                        aimCx = onUlti ? ultiX() : attackX();
                        aimCy = onUlti ? ultiY() : attackY();
                        if (!onUlti && dist(x, y, aimCx, aimCy) > R * 1.6f) { // anywhere on the right: stick starts there
                            aimCx = x;
                            aimCy = y;
                        }
                        aimDx = aimDy = 0;
                        aimMoved = false;
                    }
                    break;
                }
                case MotionEvent.ACTION_MOVE:
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        int id = e.getPointerId(i);
                        float x = e.getX(i), y = e.getY(i);
                        if (id == movePtr) {
                            moveX0 = x;
                            moveY0 = y;
                            float dx = (x - moveCx) / R, dy = (y - moveCy) / R;
                            float l = (float) Math.sqrt(dx * dx + dy * dy);
                            if (l > 1) {
                                dx /= l;
                                dy /= l;
                            }
                            moveX = dx;
                            moveZ = dy;
                        } else if (id == aimPtr) {
                            aimDx = (x - aimCx) / R;
                            aimDy = (y - aimCy) / R;
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (l > 0.25f) aimMoved = true;
                            if (l > 1) {
                                aimDx /= l;
                                aimDy /= l;
                            }
                        }
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                case MotionEvent.ACTION_CANCEL: {
                    int id = e.getPointerId(idx);
                    if (id == movePtr) {
                        movePtr = -1;
                        moveX = moveZ = 0;
                    } else if (id == aimPtr) {
                        aimPtr = -1;
                        if (a != MotionEvent.ACTION_CANCEL) {
                            float l = (float) Math.sqrt(aimDx * aimDx + aimDy * aimDy);
                            if (!aimMoved || l > 0.25f) fire.add(new float[]{aimMoved ? aimDx : 0, aimMoved ? aimDy : 0, aimUlti ? 1 : 0});
                        }
                        aimDx = aimDy = 0;
                    }
                    break;
                }
                default:
                    break;
            }
            invalidate();
            return true;
        }

        float dist(float x, float y, float x2, float y2) {
            return (float) Math.hypot(x - x2, y - y2);
        }

        @Override
        protected void onDraw(Canvas c) {
            Cave cv;
            CaveScene sc;
            Scene3d s;
            synchronized (lock) {
                cv = cave;
                sc = scene;
                s = lastScene;
                if (cv == null || s == null) return;
                drawWorld(c, cv, sc, s);
            }
            drawControls(c, cv);
        }

        private void drawWorld(Canvas c, Cave cv, CaveScene sc, Scene3d s) {
            int w = getWidth(), h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            // aim guide
            if (aimPtr >= 0 && aimMoved && cv.player.alive) {
                Cave.Weapon wp = aimUlti ? cv.ulti : cv.weapon;
                float ang = (float) Math.atan2(aimDx, aimDy);
                float half = (float) Math.toRadians(Math.max(4, wp.spread / 2f + 2));
                float[] a0 = s.project(cv.player.x, 0.05f, cv.player.z, w, h);
                android.graphics.Path path = new android.graphics.Path();
                path.moveTo(a0[0], a0[1]);
                for (int i = 0; i <= 12; i++) {
                    float t = ang - half + 2 * half * i / 12f;
                    float[] q = s.project(cv.player.x + (float) Math.sin(t) * wp.range, 0.05f, cv.player.z + (float) Math.cos(t) * wp.range, w, h);
                    path.lineTo(q[0], q[1]);
                }
                path.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor(aimUlti ? 0x66FFD23A : 0x66FFFFFF);
                c.drawPath(path, p);
            }
            // health bars
            for (Cave.Unit u : cv.dummies) if (u.alive) bar(c, s, sc, u, 0xFFE8473B, w, h, d, false);
            if (cv.player.alive) bar(c, s, sc, cv.player, 0xFF4CD964, w, h, d, true);
            // damage numbers
            text.setTextSize(15 * d);
            for (Cave.Popup pp : cv.popups) {
                float[] q = s.project(pp.x, 2.0f + pp.age * 0.9f, pp.z, w, h);
                int alpha = (int) (255 * Math.max(0, 1 - pp.age / 1.1f));
                text.setColor(0xFF000000 | 0);
                text.setAlpha(alpha);
                c.drawText(pp.text, q[0] + 1.5f * d, q[1] + 1.5f * d, text);
                text.setColor(pp.color);
                text.setAlpha(alpha);
                c.drawText(pp.text, q[0], q[1], text);
            }
            text.setAlpha(255);
            // dead / respawn
            if (!cv.player.alive) {
                text.setTextSize(22 * d);
                text.setColor(0xFFFFFFFF);
                c.drawText(String.format(Locale.ROOT, "Возрождение через %d…", (int) Math.ceil(cv.respawnTime - cv.player.deadFor)), w / 2f, h * 0.4f, text);
            }
            for (Cave.Unit u : cv.dummies) {
                if (u.alive || u.deadFor < 0.2f) continue;
                float[] q = s.project(u.x, 0.3f, u.z, w, h);
                text.setTextSize(12 * d);
                text.setColor(0xAAFFFFFF);
                c.drawText(String.valueOf((int) Math.ceil(cv.respawnTime - u.deadFor)), q[0], q[1], text);
            }
        }

        private void bar(Canvas c, Scene3d s, CaveScene sc, Cave.Unit u, int color, int w, int h, float d, boolean me) {
            float[] q = s.project(u.x, sc.headHeight(u), u.z, w, h);
            float bw = (me ? 64 : u.maxHp >= 50000 ? 80 : 54) * d, bh = 9 * d;
            float x = q[0] - bw / 2, y = q[1] - bh;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xCC111111);
            c.drawRoundRect(new RectF(x - 2 * d, y - 2 * d, x + bw + 2 * d, y + bh + 2 * d), 4 * d, 4 * d, p);
            p.setColor(color);
            c.drawRoundRect(new RectF(x, y, x + bw * Math.max(0, u.hp / u.maxHp), y + bh), 3 * d, 3 * d, p);
            text.setTextSize(10.5f * d);
            text.setColor(0xFFFFFFFF);
            c.drawText(String.valueOf((int) Math.ceil(u.hp)), q[0], y + bh - 1.5f * d, text);
            if (me) { // ammo under the health bar
                Cave cv = cave;
                int max = cv.weapon.maxCharge;
                float sw = bw / max;
                for (int i = 0; i < max; i++) {
                    float fill = Math.max(0, Math.min(1, cv.ammo - i));
                    float ax = x + i * sw, ay = y + bh + 4 * d;
                    p.setColor(0xCC111111);
                    c.drawRect(ax + 1 * d, ay, ax + sw - 1 * d, ay + 5 * d, p);
                    p.setColor(fill >= 1 ? 0xFFFF9A1F : 0xFF8A5A20);
                    c.drawRect(ax + 1 * d, ay, ax + 1 * d + (sw - 2 * d) * fill, ay + 5 * d, p);
                }
                text.setTextSize(11 * d);
                text.setColor(0xFFFFFFFF);
                c.drawText(cv.brawlerName, q[0], y - 6 * d, text);
            }
        }

        private void drawControls(Canvas c, Cave cv) {
            float d = getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.FILL);
            // back
            p.setColor(0x88000000);
            c.drawCircle(32 * d, 32 * d, 20 * d, p);
            text.setTextSize(20 * d);
            text.setColor(0xFFFFFFFF);
            c.drawText("✕", 32 * d, 39 * d, text);
            // stats
            text.setTextSize(12 * d);
            text.setTextAlign(Paint.Align.LEFT);
            c.drawText(String.format(Locale.ROOT, "Урон: %d   Побеждено: %d", cv.damageDealt, cv.kills), 62 * d, 30 * d, text);
            text.setColor(0xCCFFFFFF);
            c.drawText("Атака " + cv.weapon.damage + (cv.weapon.bullets > 1 ? "×" + cv.weapon.bullets : "")
                    + " · супер " + cv.ulti.damage + (cv.ulti.bullets > 1 ? "×" + cv.ulti.bullets : ""), 62 * d, 46 * d, text);
            text.setTextAlign(Paint.Align.CENTER);
            // move stick
            if (movePtr >= 0) {
                p.setColor(0x44FFFFFF);
                c.drawCircle(moveCx, moveCy, R, p);
                p.setColor(0xCCFFFFFF);
                float dx = moveX0 - moveCx, dy = moveY0 - moveCy, l = (float) Math.hypot(dx, dy);
                if (l > R) {
                    dx = dx / l * R;
                    dy = dy / l * R;
                }
                c.drawCircle(moveCx + dx, moveCy + dy, R * 0.45f, p);
            } else {
                p.setColor(0x22FFFFFF);
                c.drawCircle(R * 2.1f, getHeight() - R * 1.7f, R, p);
                text.setTextSize(11 * d);
                text.setColor(0x88FFFFFF);
                c.drawText("ходить", R * 2.1f, getHeight() - R * 1.7f + 4 * d, text);
            }
            // attack stick
            boolean aimA = aimPtr >= 0 && !aimUlti;
            float ax = aimA ? aimCx : attackX(), ay = aimA ? aimCy : attackY();
            p.setColor(0x55E8473B);
            c.drawCircle(ax, ay, R, p);
            p.setColor(0xFFE8473B);
            c.drawCircle(ax + (aimA ? aimDx * R : 0), ay + (aimA ? aimDy * R : 0), R * 0.48f, p);
            text.setTextSize(11 * d);
            text.setColor(0xFFFFFFFF);
            c.drawText("атака", ax, ay + 4 * d, text);
            // super button with its charge ring
            float ux = ultiX(), uy = ultiY();
            boolean ready = cv.superCharge >= 1;
            p.setColor(ready ? 0xFFFFC21F : 0x66333333);
            float ur = R * 0.62f;
            boolean aimU = aimPtr >= 0 && aimUlti;
            c.drawCircle(ux + (aimU ? aimDx * R * 0.6f : 0), uy + (aimU ? aimDy * R * 0.6f : 0), ur, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(5 * d);
            p.setColor(0xFFFFC21F);
            c.drawArc(new RectF(ux - ur - 5 * d, uy - ur - 5 * d, ux + ur + 5 * d, uy + ur + 5 * d), -90, 360 * cv.superCharge, false, p);
            p.setStyle(Paint.Style.FILL);
            text.setColor(ready ? 0xFF2A1B00 : 0xAAFFFFFF);
            c.drawText(ready ? "СУПЕР" : (int) (cv.superCharge * 100) + "%", ux, uy + 4 * d, text);
        }
    }
}
