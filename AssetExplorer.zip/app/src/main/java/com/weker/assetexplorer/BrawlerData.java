package com.weker.assetexplorer;

import android.content.Context;
import android.database.Cursor;

import com.weker.assetexplorer.codec.BrawlerIndex;
import com.weker.assetexplorer.codec.GameData;
import com.weker.assetexplorer.codec.Sc2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Builds and keeps the brawler index for one imported version, plus a small cache of parsed .sc files.
 * Export names of every effects file are cached on disk by blob, so only the first opening is slow.
 */
public final class BrawlerData {

    public interface Progress {
        void on(String text);
    }

    private static BrawlerData current;

    public final long vid;
    public BrawlerIndex index;
    /** file id -> row */
    public final Map<Long, Db.Row> rows = new HashMap<>();
    public Db.Row portraits;
    public String note = "";

    private BrawlerData(long vid) {
        this.vid = vid;
    }

    public static synchronized BrawlerData get(long vid) {
        return current != null && current.vid == vid && current.index != null ? current : null;
    }

    public static synchronized BrawlerData load(Context c, long vid, Progress p) throws IOException {
        BrawlerData d = get(vid);
        if (d != null) return d;
        d = new BrawlerData(vid);
        d.build(c.getApplicationContext(), p);
        synchronized (BrawlerData.class) {
            if (current != null && current.vid != vid) clearSc();
            current = d;
        }
        return d;
    }

    private void build(Context c, Progress p) throws IOException {
        Db db = Db.get(c);
        List<Db.Row> files = new ArrayList<>();
        try (Cursor cur = db.getReadableDatabase().rawQuery("SELECT " + Db.COLS + " FROM files WHERE vid=? AND ext='sc' ORDER BY name",
                new String[]{"" + vid})) {
            while (cur.moveToNext()) {
                Db.Row r = Db.row(cur);
                if (BrawlerIndex.isEffectsFile(r.name)) files.add(r);
                else if (r.name.equalsIgnoreCase("hero_portraits.sc")) portraits = r;
            }
        }
        if (files.isEmpty()) throw new IOException("В этой версии нет файлов effects_brawler*.sc — нечего собирать.");

        BrawlerIndex idx = new BrawlerIndex();
        Map<String, Long> ids = new HashMap<>();
        Map<String, Set<String>> exports = new HashMap<>();
        Set<String> fileKeys = new HashSet<>();
        for (Db.Row r : files) {
            String fb = BrawlerIndex.fileBrawler(r.name);
            if (fb != null) fileKeys.add(fb);
        }
        idx.addKnown(fileKeys);
        int n = 0;
        // per-brawler files first, so the shared effects_brawler.sc only fills the gaps
        files.sort((a, b) -> Boolean.compare(BrawlerIndex.fileBrawler(a.name) == null, BrawlerIndex.fileBrawler(b.name) == null));
        for (Db.Row r : files) {
            n++;
            if (p != null) p.on("Читаю " + r.name + " (" + n + " из " + files.size() + ")");
            List<String> ex;
            try {
                ex = exportNames(c, r);
            } catch (Throwable e) {
                continue; // broken file: skip it
            }
            rows.put(r.id, r);
            ids.put(r.name, r.id);
            exports.put(r.name, new HashSet<>(ex));
            idx.add(r.id, r.name, ex);
        }

        // game tables: which projectile / area belongs to which ability, Russian names
        if (p != null) p.on("Читаю таблицы игры…");
        Map<String, List<String[]>> tables = new LinkedHashMap<>();
        for (String t : GameData.TABLES) {
            Db.Row r = byName(db, t, "csv_logic/");
            if (r == null) continue;
            try {
                tables.put(t, GameData.parseCsv(new String(Decoders.content(Blobs.file(c, r.blob)), StandardCharsets.UTF_8)));
            } catch (Throwable ignored) {
                // table missing or unreadable
            }
        }
        Map<String, String> ru = new HashMap<>();
        Db.Row loc = byName(db, "ru.csv", "localization/");
        if (loc != null) {
            try {
                ru = GameData.localization(GameData.parseCsv(new String(Decoders.content(Blobs.file(c, loc.blob)), StandardCharsets.UTF_8)));
            } catch (Throwable ignored) {
                // no names
            }
        }
        if (!tables.isEmpty()) {
            try {
                idx.apply(GameData.build(tables, ru), ids, exports);
            } catch (Throwable e) {
                note = "Таблицы игры прочитать не удалось: " + e.getMessage();
            }
        } else {
            note = "Таблиц csv_logic в архиве нет — части разложены только по именам.";
        }
        idx.finish();
        index = idx;
    }

    /** the row with this file name; prefers paths containing folderHint */
    private Db.Row byName(Db db, String name, String folderHint) {
        Db.Row best = null;
        try (Cursor cur = db.getReadableDatabase().rawQuery("SELECT " + Db.COLS + " FROM files WHERE vid=? AND name=? COLLATE NOCASE",
                new String[]{"" + vid, name})) {
            while (cur.moveToNext()) {
                Db.Row r = Db.row(cur);
                if (best == null || r.path.toLowerCase(Locale.ROOT).contains(folderHint)) best = r;
            }
        }
        return best;
    }

    /** export names of an .sc file, cached in files/exports/<blob>.txt */
    static List<String> exportNames(Context c, Db.Row r) throws IOException {
        File dir = new File(c.getFilesDir(), "exports");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File f = new File(dir, r.blob + ".txt");
        List<String> out = new ArrayList<>();
        if (f.exists()) {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String l;
                while ((l = in.readLine()) != null) if (!l.isEmpty()) out.add(l);
            }
            return out;
        }
        // parsed only for the names: not kept in the render cache
        out.addAll(Sc2.parse(Decoders.readAll(Blobs.file(c, r.blob))).exportOrder);
        File tmp = new File(dir, r.blob + ".tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
            for (String e : out) w.write(e + "\n");
        }
        //noinspection ResultOfMethodCallIgnored
        tmp.renameTo(f);
        return out;
    }

    // ------------------------------------------------------------------ parsed .sc cache
    private static final LinkedHashMap<String, Sc2> SC = new LinkedHashMap<>(4, 0.75f, true);

    /** Parsed file (with external textures resolved). Keeps the 2 most recently used files in memory. */
    public static Sc2 sc(Context c, Db.Row r) throws IOException {
        synchronized (SC) {
            Sc2 s = SC.get(r.blob);
            if (s != null) return s;
        }
        Sc2 s = Sc2.parse(Decoders.readAll(Blobs.file(c, r.blob)));
        resolveExternal(c, r, s);
        synchronized (SC) {
            SC.put(r.blob, s);
            while (SC.size() > 2) {
                String oldest = SC.keySet().iterator().next();
                SC.remove(oldest);
            }
        }
        return s;
    }

    public static void clearSc() {
        synchronized (SC) {
            SC.clear();
        }
    }

    /** Textures stored in separate files (external_texture) are looked up among imported files. */
    static void resolveExternal(Context c, Db.Row row, Sc2 s) {
        Db db = Db.get(c);
        for (int i = 0; i < s.textures.size(); i++) {
            Sc2.Tex t = s.textures.get(i);
            if ((t.data != null && t.data.length > 0) || t.external == null) continue;
            List<String> one = new ArrayList<>();
            one.add(t.external);
            List<Db.Row> found = db.byPaths(row.vid, one);
            if (found.isEmpty()) continue;
            try {
                Db.Row r = found.get(0);
                com.weker.assetexplorer.codec.SupercellFiles.TextureSet ts =
                        com.weker.assetexplorer.codec.SupercellFiles.decodeTextures(Decoders.readAll(Blobs.file(c, r.blob)), r.name);
                if (!ts.images.isEmpty()) s.setExternalTexture(i, ts.images.get(0));
            } catch (Exception ignored) {
                // leave texture missing
            }
        }
    }

    // ------------------------------------------------------------------ portraits
    /** export names to try for a brawler's portrait in hero_portraits.sc */
    static List<String> portraitNames(String key) {
        List<String> c = new ArrayList<>();
        c.add(key);
        Map<String, String> extra = new HashMap<>();
        extra.put("dynamike", "mike");
        extra.put("jessie", "jess");
        extra.put("rico", "rick");
        extra.put("darryl", "barrelbot");
        extra.put("melodie", "melody");
        extra.put("jaeyong", "jae");
        extra.put("larrylawrie", "twins");
        extra.put("lola", "lolla");
        extra.put("elprimo", "primo");
        extra.put("kenji", "samurai");
        if (extra.containsKey(key)) c.add(extra.get(key));
        List<String> out = new ArrayList<>();
        for (String k : c) {
            out.add("hero_icon_" + k + "_small");
            out.add("hero_icon_" + k + "_big");
            out.add("hero_icon_" + k);
        }
        return out;
    }

    /** first portrait export that exists, or null */
    static String portraitExport(Sc2 s, BrawlerIndex.Brawler b) {
        if (b.portrait != null) {
            if (s.exportIds.containsKey(b.portrait + "_small")) return b.portrait + "_small";
            if (s.exportIds.containsKey(b.portrait)) return b.portrait;
        }
        for (String n : portraitNames(b.key)) if (s.exportIds.containsKey(n)) return n;
        return null;
    }
}
