package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.List;

/**
 * The newest brawlers, whose tricks the plain table rules can't express, built from what the game files say
 * (skills, projectiles, area effects, status effects, cards and the texts that describe them).
 *
 * <p>Космо (Attractor): «Орбита» — a slow carrier shot (AttractorCarrierProjectile, passes walls) with three
 * orbiting shots (AttractorOrbiterProjectile 1..3: radius 100→600, damage 25 %→100 % and size 40 %→115 % over
 * their flight); «Гравитация» — a magnet that sticks to the enemy it hits and for 6 s pulls the team's shots to it
 * (AttractorProjectileMagnetArea, 4 tiles, +20 % speed). Gadgets: «Планетарное отбрасывание» (pushback area),
 * «Телескопическая ловушка» (6 s area: no dashes / jumps, everyone seen). Star powers: «Прецессия» (faster orbit),
 * «Аттрактор боеприпасов» (a super hit gives 2 ammo).
 *
 * <p>Винс (Stacker): caterpillars appear around him (StackerAmmoSpawnArea); his shot or his feet turn them into
 * moths; every moth makes the attack stronger and he loses half of them when defeated. «Выстрел баристы»: marks
 * enemies (they take more from his attack); with 5 / 10 / 15 moths it fires 3 / 5 / 7 shots, gives ammo back,
 * bounces, slows (StackerUltiLevel1..3). Gadgets: «Горячий кофе» (exploding cup), «Метамольфозы» (nearby
 * caterpillars become two moths each). Star powers: «Идите к папочке» (caterpillars crawl to him), «Жучий жгут»
 * (+1200 health per moth).
 *
 * <p>Numbers the files don't carry (they live in the game's code) are set to fit the descriptions and are listed in
 * {@link #ASSUMED}.
 */
public final class Specials {

    private Specials() {}

    static final String COSMO = "Attractor", VINCE = "Stacker";
    /** Cosmo: an orbiting shot's full damage at power 11; Vince: extra damage per moth, mark bonus, moths per super level */
    static final int ORBIT_DAMAGE = 1000, MOTH_DAMAGE = 40;
    static final float MARK_BONUS = 0.3f;
    static final int[] SUPER_LEVELS = {5, 10, 15};
    public static final String ASSUMED = "Космо: урон орбиты 1000; Винс: +40 урона за мотылька, метка +30 %, уровни Супера 5/10/15 мотыльков; "
            + Specials70.ASSUMED;

    public static boolean isVinceCode(String code) {
        return VINCE.equals(code);
    }

    static boolean isCosmo(Battle.Fighter f) {
        return f != null && COSMO.equals(f.kit.code);
    }

    static boolean isVince(Battle.Fighter f) {
        return f != null && VINCE.equals(f.kit.code);
    }

    /** brawler-specific skill kinds after the kit is read from the tables */
    static boolean noReload(Battle.Fighter f) {
        return Specials70.noReload(f);
    }

    static boolean freeSuper(Battle b, Battle.Fighter f) {
        return Specials70.freeSuper(b, f);
    }

    static boolean recast(Battle b, Battle.Fighter f) {
        return Specials70.recast(b, f);
    }

    static void kit(Battle b, Battle.Kit k) {
        Specials70.kit(k);
        if (COSMO.equals(k.code)) {
            k.weapon.kind = Battle.Kind.ORBIT;
            k.weapon.damage = ORBIT_DAMAGE;
            k.weapon.speed = 1600 / Battle.UNIT;
            k.weapon.range = 27 / 3f;
            k.weapon.proj = "AttractorCarrierProjectile";
            k.weapon.pierceChars = true;
            k.weapon.pierceEnv = true;
            if (k.gadget != null && k.gadget.kind == Battle.Kind.LOB) {
                k.gadget.kind = k.gadgetPick == 1 ? Battle.Kind.PUSH : Battle.Kind.GROUNDED;
            }
            if (k.gadget != null) {
                k.gadget.areaRadius = k.gadget.kind == Battle.Kind.PUSH ? 3f : 4.33f;
                if (k.gadget.kind == Battle.Kind.GROUNDED) k.gadget.areaTime = 6;
            }
        } else if (VINCE.equals(k.code)) {
            k.weapon.proj = "StackerProjectile";
            k.ulti.pierceChars = true;
            k.ulti.pierceEnv = true;
            k.ulti.breaksWalls = false;
        }
    }

    // ------------------------------------------------------------------ casting
    static boolean cast(Battle b, Battle.Fighter f, Battle.Skill s, float angle, float dist, boolean isUlti) {
        if (Specials70.cast(b, f, s, angle, dist)) return true;
        switch (s.kind) {
            case ORBIT:
                orbit(b, f, s, angle);
                return true;
            case PUSH: case GROUNDED: {
                float d = Math.max(1.5f, Math.min(s.range, dist));
                float tx = f.x + (float) Math.sin(angle) * d, tz = f.z + (float) Math.cos(angle) * d;
                b.lob(f, s, tx, tz, false, 0);
                return true;
            }
            case METAMORPH: {
                int n = 0;
                for (Battle.Fighter o : new ArrayList<>(b.fighters)) {
                    if (!o.critter || !o.alive || o.ownerId != f.id) continue;
                    if (Math.hypot(o.x - f.x, o.z - f.z) > s.areaRadius) continue;
                    collect(b, f, o, 2);
                    n++;
                }
                b.fx.add(new Object[]{"area", f.x, f.z, s.areaName, f, s.areaRadius});
                if (n == 0) b.message(f, "Рядом нет гусениц");
                return true;
            }
            default:
                break;
        }
        if (isUlti && isVince(f)) {
            vinceSuper(b, f, s, angle);
            return true;
        }
        return false;
    }

    /** Cosmo: the carrier and its three planets */
    static void orbit(Battle b, Battle.Fighter f, Battle.Skill s, float angle) {
        b.shoot(f, s, angle, false, 0);
        Battle.Shot c = b.shots.get(b.shots.size() - 1);
        c.damage = 0;
        c.visual = true;
        c.radius = 0.1f;
        float life = s.range / Math.max(0.5f, s.speed);
        float spin = (float) (Math.PI * 2 * 2 / life) * (f.kit.starPower == 1 && !f.kit.starPowerName.isEmpty() ? 1.3f : 1f);
        String[] looks = {"AttractorOrbiterProjectile", "AttractorOrbiterProjectile2", "AttractorOrbiterProjectile3"};
        for (int i = 0; i < 3; i++) {
            Battle.Shot o = new Battle.Shot();
            o.id = b.nextId++;
            o.team = f.team;
            o.owner = f.id;
            o.carrier = c.id;
            o.phase = (float) (Math.PI * 2 * i / 3);
            o.spin = spin;
            o.maxLife = life;
            o.radius = 0.5f;
            o.baseDamage = f.nextAttackBoost > b.time ? s.damage * 3 / 2 : s.damage;
            o.damage = o.baseDamage / 4;
            o.skill = s;
            o.proj = looks[i];
            o.scale = 0.4f;
            o.speed = s.speed;
            o.left = 99;
            o.x = c.x;
            o.z = c.z;
            o.h = 0.6f;
            o.angle = angle;
            b.shots.add(o);
        }
    }

    /** Vince's super: 1 / 3 / 5 / 7 shots by moths collected */
    static void vinceSuper(Battle b, Battle.Fighter f, Battle.Skill s, float angle) {
        int level = 0;
        for (int t : SUPER_LEVELS) if (f.moths >= t) level++;
        int n = level == 0 ? 1 : level * 2 + 1;
        float spread = (float) Math.toRadians(level == 0 ? 0 : level == 1 ? 150 / 6f : 200 / 6f) * (n - 1) / 2f;
        for (int i = 0; i < n; i++) {
            float off = n == 1 ? 0 : -spread + 2 * spread * i / (n - 1);
            b.shoot(f, s, angle + off, true, 0);
            Battle.Shot sh = b.shots.get(b.shots.size() - 1);
            sh.vinceSuper = true;
            sh.ammoBack = level >= 1;
            sh.bounces = level >= 2 ? 1 : 0;
            sh.slows = level >= 3;
        }
        if (level > 0) b.message(f, "Выстрел баристы " + (level + 1));
    }

    // ------------------------------------------------------------------ flight
    /** moves shots that don't fly straight; true when done here */
    static boolean move(Battle b, Battle.Shot s, float dt) {
        if (s.parked) {
            s.age += dt;
            return true;
        }
        if (Specials70.curve(b, s, dt)) return true;
        if (s.carrier >= 0) {
            Battle.Shot c = null;
            for (Battle.Shot x : b.shots) if (x.id == s.carrier) c = x;
            s.life += dt;
            if (c == null || s.life >= s.maxLife) {
                s.dead = true;
                b.fx.add(new Object[]{"reach", s.x, s.z, s, null});
                return true;
            }
            float t = Math.min(1, s.life / s.maxLife);
            float rad = (100 + 500 * t) / Battle.UNIT;
            float a = s.phase + s.spin * s.life;
            float nx = c.x + (float) Math.cos(a) * rad, nz = c.z + (float) Math.sin(a) * rad;
            s.angle = (float) Math.atan2(nx - s.x, nz - s.z);
            s.x = nx;
            s.z = nz;
            s.age += dt;
            float k = Math.min(1, t / 0.8f);
            s.damage = Math.round(s.baseDamage * (0.25f + 0.75f * k));
            s.scale = 0.4f + 0.75f * t;
            s.radius = 0.35f + 0.25f * t;
            // a magnet nearby pulls the planet off its orbit
            if (magnetFor(b, s) != null) {
                s.carrier = -1;
                s.dx = (float) Math.sin(s.angle);
                s.dz = (float) Math.cos(s.angle);
                s.speed = 4000 / Battle.UNIT;
                s.left = 6;
                return false;
            }
            b.hitAt(s);
            return true;
        }
        if (s.homing >= 0) {
            Battle.Fighter t = b.byId(s.homing);
            if (t == null || !t.alive) {
                s.dead = true;
                return true;
            }
            float dx = t.x - s.x, dz = t.z - s.z, d = (float) Math.hypot(dx, dz);
            float step = s.speed * dt;
            if (d <= step + 0.2f + (s.visual ? 0 : t.kit.radius)) {
                s.dead = true;
                if (!s.visual) { // Rey's super shot finds its target
                    Battle.Fighter from = b.byId(s.owner);
                    b.fx.add(new Object[]{"hitChar", t.x, t.z, s, t});
                    b.damage(from, t, s.damage, s.ulti);
                    onHit(b, s, from, t);
                }
                return true;
            }
            s.x += dx / d * step;
            s.z += dz / d * step;
            s.angle = (float) Math.atan2(dx, dz);
            s.age += dt;
            return true;
        }
        // Cosmo's magnet: the team's shots near the marked enemy turn to it, 20 % faster
        Battle.Area m = s.lob || s.visual ? null : magnetFor(b, s);
        if (m != null) {
            Battle.Fighter t = b.byId(m.target);
            float want = (float) Math.atan2(t.x - s.x, t.z - s.z), cur = (float) Math.atan2(s.dx, s.dz);
            float diff = (float) Math.atan2(Math.sin(want - cur), Math.cos(want - cur));
            float turn = Math.max(-9 * dt, Math.min(9 * dt, diff));
            cur += turn;
            s.dx = (float) Math.sin(cur);
            s.dz = (float) Math.cos(cur);
            s.angle = cur;
            if (s.speed < 30) s.speed *= 1 + 0.2f * dt * 4;
            s.left = Math.max(s.left, 1.5f);
        }
        return false;
    }

    static Battle.Area magnetFor(Battle b, Battle.Shot s) {
        for (Battle.Area a : b.areas) {
            if (!"magnet".equals(a.kind) || a.team != s.team) continue;
            if (Math.hypot(s.x - a.x, s.z - a.z) <= a.radius) return a;
        }
        return null;
    }

    // ------------------------------------------------------------------ hits
    static void onHit(Battle b, Battle.Shot s, Battle.Fighter from, Battle.Fighter to) {
        if (from == null) return;
        Specials70.onHit(b, s, from, to);
        if (isCosmo(from) && s.ulti && !to.box) {
            for (Battle.Area a : b.areas) if ("magnet".equals(a.kind) && a.owner == from.id) a.left = 0;
            Battle.Area a = new Battle.Area();
            a.kind = "magnet";
            a.look = "AttractorProjectileMagnetAreaActions";
            a.target = to.id;
            a.follow = true;
            a.x = to.x;
            a.z = to.z;
            a.radius = 1200 / Battle.UNIT;
            a.team = from.team;
            a.owner = from.id;
            a.left = 6;
            a.tick = 99;
            a.next = 99;
            b.areas.add(a);
            b.events.add("magnet:" + from.id);
            if (from.kit.starPower == 2 && !from.kit.starPowerName.isEmpty()) from.ammo = Math.min(from.kit.weapon.maxCharge, from.ammo + 2);
        }
        if (isVince(from) && s.vinceSuper && !to.box) {
            to.markUntil = b.time + 10;
            if (s.ammoBack) from.ammo = Math.min(from.kit.weapon.maxCharge, from.ammo + 1);
            if (s.slows) to.slowUntil = Math.max(to.slowUntil, b.time + 3);
            if (s.bounces > 0) {
                Battle.Fighter next = null;
                float best = 5;
                for (Battle.Fighter o : b.fighters) {
                    if (!o.alive || o == to || o.box || o.critter || !b.enemies(from, o) || s.hit.contains(o.id)) continue;
                    float d = (float) Math.hypot(o.x - to.x, o.z - to.z);
                    if (d < best) {
                        best = d;
                        next = o;
                    }
                }
                if (next != null) {
                    Battle.Shot n = new Battle.Shot();
                    n.id = b.nextId++;
                    n.team = s.team;
                    n.owner = s.owner;
                    n.ulti = true;
                    n.skill = s.skill;
                    n.damage = s.damage;
                    n.speed = s.speed;
                    n.radius = s.radius;
                    n.pierceChars = false;
                    n.pierceEnv = true;
                    n.vinceSuper = true;
                    n.slows = s.slows;
                    n.x = to.x;
                    n.z = to.z;
                    n.h = s.h;
                    n.angle = (float) Math.atan2(next.x - to.x, next.z - to.z);
                    n.dx = (float) Math.sin(n.angle);
                    n.dz = (float) Math.cos(n.angle);
                    n.left = best + 1;
                    n.hit.add(to.id);
                    b.shots.add(n);
                }
            }
        }
    }

    /** damage changes: Vince's attack grows with moths and hurts marked enemies more */
    static float damage(Battle b, Battle.Fighter from, Battle.Fighter to, float d, boolean ulti) {
        d = Specials70.damage(b, from, to, d, ulti);
        if (isVince(from) && !ulti) {
            d += from.moths * MOTH_DAMAGE;
            if (to.markUntil > b.time) d *= 1 + MARK_BONUS;
        }
        return d;
    }

    static void onDeath(Battle b, Battle.Fighter f) {
        if (isVince(f) && f.moths > 0) {
            f.moths -= f.moths / 2;
            b.events.add("mothLost:" + f.id);
        }
        if (isVince(f)) for (Battle.Fighter o : b.fighters) if (o.critter && o.ownerId == f.id) o.alive = false;
    }

    // ------------------------------------------------------------------ every step
    static void step(Battle b, float dt) {
        Specials70.step(b, dt);
        Quiz.step(b, dt);
        for (Battle.Fighter f : new ArrayList<>(b.fighters)) {
            if (!isVince(f) || !f.alive) continue;
            int mine = 0;
            for (Battle.Fighter o : b.fighters) if (o.critter && o.alive && o.ownerId == f.id) mine++;
            if (mine < 3 && b.time >= f.nextCritter) {
                f.nextCritter = b.time + 3.5f;
                spawnCritter(b, f);
            }
        }
        for (Battle.Fighter c : b.fighters) {
            if (!c.critter || !c.alive) continue;
            Battle.Fighter owner = b.byId(c.ownerId);
            if (owner == null || !owner.alive) {
                c.alive = false;
                continue;
            }
            // caterpillars crawl about (to Vince with «Идите к папочке»); stepping on one collects it
            boolean toDaddy = owner.kit.starPower == 1 && !owner.kit.starPowerName.isEmpty();
            float d = (float) Math.hypot(owner.x - c.x, owner.z - c.z);
            if (d < owner.kit.radius + 0.35f) {
                collect(b, owner, c, 1);
                continue;
            }
            float tx, tz;
            if (toDaddy && d < 8) {
                tx = owner.x;
                tz = owner.z;
            } else {
                c.thinkIn -= dt;
                if (c.thinkIn <= 0 || c.goalX < 0) {
                    c.thinkIn = 2 + b.rnd.nextFloat() * 2;
                    c.goalX = c.x + (b.rnd.nextFloat() - 0.5f) * 3;
                    c.goalZ = c.z + (b.rnd.nextFloat() - 0.5f) * 3;
                }
                tx = c.goalX;
                tz = c.goalZ;
            }
            float dx = tx - c.x, dz = tz - c.z, l = (float) Math.hypot(dx, dz);
            if (l > 0.1f) {
                float sp = c.kit.speed * (toDaddy ? 2.5f : 1) * dt;
                float nx = c.x + dx / l * sp, nz = c.z + dz / l * sp;
                if (!b.collides(nx, nz, 0.2f)) {
                    c.x = nx;
                    c.z = nz;
                }
                c.face = (float) Math.atan2(dx, dz);
                if (!"walk".equals(c.action)) {
                    c.action = "walk";
                    c.actionStart = b.time;
                }
            }
        }
        b.fighters.removeIf(f -> f.critter && !f.alive);
        // Cosmo's trap: inside it enemies can't dash or jump and are seen
        for (Battle.Area a : b.areas) {
            if (!"grounded".equals(a.kind)) continue;
            for (Battle.Fighter o : b.fighters) {
                if (!o.alive || o.box || o.team == a.team) continue;
                if (Math.hypot(o.x - a.x, o.z - a.z) > a.radius) continue;
                o.groundedUntil = b.time + 0.25f;
                o.revealUntil = b.time + 0.25f;
            }
        }
    }

    static void spawnCritter(Battle b, Battle.Fighter v) {
        for (int k = 0; k < 20; k++) {
            double a = b.rnd.nextDouble() * Math.PI * 2;
            float d = 2 + b.rnd.nextFloat() * 3;
            float x = v.x + (float) Math.cos(a) * d, z = v.z + (float) Math.sin(a) * d;
            if (x < 0.5f || z < 0.5f || x > b.width - 0.5f || z > b.height - 0.5f || b.collides(x, z, 0.3f)) continue;
            Battle.Fighter c = b.add("StackerPet", null, v.team, "pet", "Гусеница");
            c.pet = true;
            c.critter = true;
            c.bot = false;
            c.ownerId = v.id;
            c.x = x;
            c.z = z;
            c.maxHp = c.hp = 1;
            c.goalX = -1;
            b.fx.add(new Object[]{"spawn", c});
            return;
        }
    }

    /** a caterpillar becomes a moth (or two): it flies to Vince */
    static void collect(Battle b, Battle.Fighter v, Battle.Fighter c, int count) {
        if (!c.alive) return;
        c.alive = false;
        v.moths += count;
        Battle.Shot m = new Battle.Shot();
        m.id = b.nextId++;
        m.team = v.team;
        m.owner = v.id;
        m.visual = true;
        m.homing = v.id;
        m.proj = "StackerCollectProjectile";
        m.speed = 3600 / Battle.UNIT;
        m.x = c.x;
        m.z = c.z;
        m.h = 0.8f;
        b.shots.add(m);
        b.events.add("moth:" + v.id);
        if (v.kit.starPower == 2 && !v.kit.starPowerName.isEmpty()) b.healUnit(v, 1200 * count);
    }

    /** Vince's own shot turns caterpillars it passes into moths (the shot goes on) */
    static void shotOverCritters(Battle b, Battle.Shot s) {
        Battle.Fighter owner = b.byId(s.owner);
        if (!isVince(owner) || s.ulti || s.visual) return;
        for (Battle.Fighter c : new ArrayList<>(b.fighters)) {
            if (!c.critter || !c.alive || c.ownerId != owner.id) continue;
            if (Math.hypot(c.x - s.x, c.z - s.z) < 0.6f) collect(b, owner, c, 1);
        }
    }

    /** the moths circling Vince (how many to draw) */
    static int visibleMoths(Battle.Fighter f) {
        return isVince(f) ? Math.min(6, f.moths) : 0;
    }

    public static List<String> describe(String code) {
        List<String> l = Specials70.describe(code);
        if (COSMO.equals(code)) {
            l.add("Атака «Орбита»: три снаряда кружат вокруг носителя, расходятся и бьют сильнее к концу полёта");
            l.add("Супер «Гравитация»: магнит на враге 6 с притягивает снаряды твоей команды");
        } else if (VINCE.equals(code)) {
            l.add("Гусеницы появляются рядом: наступи или попади атакой — получишь мотылька (+урон)");
            l.add("Супер: метка гусеницы; с 5/10/15 мотыльками — 3/5/7 снарядов, патрон за попадание, отскок, замедление");
            l.add("При поражении теряется половина мотыльков");
        }
        return l;
    }
}
