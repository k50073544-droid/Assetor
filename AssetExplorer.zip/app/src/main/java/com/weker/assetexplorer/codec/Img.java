package com.weker.assetexplorer.codec;

/** Decoded image: ARGB pixels (not premultiplied). */
public final class Img {
    public final int width, height;
    /** pixels; null for a picture kept only in its GPU form ({@link #gpu}): {@link #pixels()} decodes it when drawing in software */
    public int[] argb;
    public String note = "";
    /** the picture as a graphics chip takes it (ASTC blocks, every mip level): uploaded without decoding */
    public Gpu gpu;

    /** compressed texture data: OpenGL format, and each mip level's size and place in {@link #data} */
    public static final class Gpu {
        /** OpenGL internal format (0x93B0… = ASTC 4x4…) */
        public int format;
        public int blockW, blockH;
        public byte[] data;
        public int[] offset, size, width, height;

        public int levels() {
            return offset == null ? 0 : offset.length;
        }

        public long bytes() {
            long n = 0;
            for (int s : size) n += s;
            return n;
        }
    }

    /**
     * A picture whose pixels are worked out only where something looks at them (a corner of a big atlas that a button
     * is cut from): {@link #ensure} before reading a pixel, {@link #pixels()} to have the whole of it.
     */
    public interface Lazy {
        void ensure(int x, int y);

        void finish();
    }

    public Lazy lazy;

    /** the pixels, decoded from the GPU form on first use (software drawing and tools; a phone's GL path never calls this) */
    public int[] pixels() {
        if (lazy != null) {
            Lazy l = lazy;
            lazy = null;
            l.finish();
        }
        if (argb == null && gpu != null) argb = SupercellFiles.decode(gpu).argb;
        return argb;
    }

    public Img(int width, int height, int[] argb) {
        this.width = width;
        this.height = height;
        this.argb = argb;
    }
}
