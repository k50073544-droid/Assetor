package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.List;

/**
 * Brawlers of version 70, built from their table rows and descriptions.
 *
 * <p>Громожабы (FrogWizard): two ammo; a frog jumps out and sits where it lands (FrogWizardWeaponArea); when the
 * second one lands, the triangle between the three frogs is struck — more on its edges (FrogWizardRecallTriangle:
 * border 200, inside 70 %) — and they hop back together, refilling both ammo. Super «Жабзилла»: one giant frog with
 * three jumps (FrogWizardUltiArea, 130 % in the middle; the third reaches further). Gadgets: «Парный кульбит» (both
 * frogs at once, needs full ammo), «Электротерапия» (the next triangle heals allies inside). Star powers: «Лечебные
 * прыжки» (super jumps heal), «Трясина» (edges slow 15 % for 2 s).
 *
 * <p>Рэй (Tracker): his shots mark enemies; the longer a mark has been on, the harder his next shot hits. Super
 * «Эндшпиль»: aims up to 3 s with a 30 % shield, marking every enemy in 10 tiles, then fires a homing shot at the most
 * marked one; using the super again fires at once. Gadgets: «Королевский гамбит» (5 queens in a cone, knock back),
 * «Рэй Лопез» (a knight that marks and slows 20 % for 2 s). Star powers: «Контроль времени» (super marks slow 25 %),
 * «Взятие на проходе» (a hit on a full mark passes it to the nearest enemy).
 *
 * <p>Руби (CardDealer): two cards fly in a figure eight; both hitting one enemy deal extra damage. Super «Роял-флеш»:
 * a zone for 4 s that grounds enemies and hurts them every second (15 % of their health, at least 1200). Gadgets:
 * «Перетасовка» (a card that splits into 5, hurting enemies and healing allies), «Колода из киоска» (bouncing cards
 * that knock back). Star powers: «Счастливое число» (more cards in the zone), «Удваиваю!» (a double hit burns).
 */
final class Specials70 {

    private Specials70() {}

    static final String FROGS = "FrogWizard", REY = "Tracker", RUBY = "CardDealer";
    public static final String ASSUMED = "заполнение метки Рэя 2,5 с (до ×2 урона), лечение «Лечебных прыжков» 25 %, "
            + "Руби: бонус двойного попадания 10 % здоровья (не меньше 1200), «Счастливое число» +40 % урона зоны";

    static boolean is(Battle.Fighter f, String code) {
        return f != null && code.equals(f.kit.code);
    }

    static void kit(Battle.Kit k) {
        switch (k.code) {
            case FROGS:
                k.weapon.kind = Battle.Kind.FROG;
                k.weapon.maxCharge = 2;
                k.weapon.areaRadius = 400 / Battle.UNIT;
                k.ulti.kind = Battle.Kind.FROG_SUPER;
                k.ulti.range = 18 / 3f;
                k.ulti.areaRadius = 800 / Battle.UNIT;
                if (k.gadget != null) k.gadget.kind = k.gadgetPick == 1 ? Battle.Kind.FROG_DOUBLE : Battle.Kind.FROG_HEAL;
                break;
            case REY:
                k.ulti.kind = Battle.Kind.REY_SUPER;
                k.ulti.range = 3000 / Battle.UNIT;
                k.ulti.proj = "TrackerUltiMarkedProjectile";
                if (k.gadget != null) {
                    if (k.gadgetPick == 1) {
                        k.gadget.kind = Battle.Kind.QUEENS;
                    } else {
                        k.gadget.kind = Battle.Kind.KNIGHT;
                        k.gadget.areaRadius = 900 / Battle.UNIT;
                    }
                }
                break;
            case RUBY:
                k.weapon.kind = Battle.Kind.CARDS;
                k.weapon.pierceChars = true;
                k.ulti.kind = Battle.Kind.RUBY_ZONE;
                k.ulti.areaRadius = 800 / Battle.UNIT;
                k.ulti.areaTime = 4;
                if (k.gadget != null) k.gadget.kind = k.gadgetPick == 1 ? Battle.Kind.SPLIT : Battle.Kind.BOUNCE;
                break;
            default:
                break;
        }
    }

    static boolean noReload(Battle.Fighter f) {
        return is(f, FROGS);
    }

    /** a super that needs no charge now: the giant frog's next jump */
    static boolean freeSuper(Battle b, Battle.Fighter f) {
        return is(f, FROGS) && f.ultiJumps > 0 && b.time < f.ultiJumpsUntil;
    }

    /** Rey's super pressed again while aiming: fire now */
    static boolean recast(Battle b, Battle.Fighter f) {
        if (!is(f, REY) || f.channelUntil <= b.time) return false;
        reyFire(b, f);
        return true;
    }

    // ------------------------------------------------------------------ casting
    static boolean cast(Battle b, Battle.Fighter f, Battle.Skill s, float angle, float dist) {
        switch (s.kind) {
            case FROG: {
                float d = Math.max(1.5f, Math.min(s.range, dist));
                b.lob(f, s, f.x + (float) Math.sin(angle) * d, f.z + (float) Math.cos(angle) * d, false, 0);
                Battle.Shot sh = b.shots.get(b.shots.size() - 1);
                sh.tag = "frog";
                sh.proj = f.frogsOut == 0 ? "FrogWizardProjectile1" : "FrogWizardProjectile2";
                f.frogsOut++;
                f.form = Math.min(2, f.frogsOut);
                f.frogsBack = b.time + 4;
                return true;
            }
            case FROG_DOUBLE: {
                if (f.frogsOut > 0 || f.ammo < f.kit.weapon.maxCharge - 0.01f) {
                    b.message(f, "Нужен полный боезапас");
                    f.gadgets++;
                    return true;
                }
                f.ammo = 0;
                float d = Math.max(1.5f, Math.min(s.range, dist));
                for (int i = 0; i < 2; i++) {
                    float a = angle + (float) Math.toRadians(i == 0 ? -22.5 : 22.5);
                    b.lob(f, f.kit.weapon, f.x + (float) Math.sin(a) * d, f.z + (float) Math.cos(a) * d, false, 0);
                    Battle.Shot sh = b.shots.get(b.shots.size() - 1);
                    sh.tag = "frog";
                    sh.proj = i == 0 ? "FrogWizardProjectile1" : "FrogWizardProjectile2";
                }
                f.frogsOut = 2;
                f.form = 2;
                f.frogsBack = b.time + 4;
                return true;
            }
            case FROG_HEAL:
                f.healNext = true;
                b.message(f, "Следующий треугольник лечит союзников");
                return true;
            case FROG_SUPER: {
                if (f.ultiJumps <= 0 || b.time >= f.ultiJumpsUntil) {
                    f.ultiJumps = 3;
                    recallFrogs(b, f, false);
                }
                f.form = 3;
                f.ultiJumps--;
                f.ultiJumpsUntil = b.time + 6;
                float range = f.ultiJumps == 0 ? 28 / 3f : s.range;
                float d = Math.max(1, Math.min(range, dist));
                float tx = f.x + (float) Math.sin(angle) * d, tz = f.z + (float) Math.cos(angle) * d;
                for (int k = 0; k < 20 && b.collides(tx, tz, f.kit.radius); k++) {
                    d -= 0.4f;
                    tx = f.x + (float) Math.sin(angle) * d;
                    tz = f.z + (float) Math.cos(angle) * d;
                }
                float time = Math.max(0.25f, d / 10f);
                f.dashVx = (float) Math.sin(angle) * (d / time);
                f.dashVz = (float) Math.cos(angle) * (d / time);
                f.dashLeft = d;
                f.dashDamage = 0;
                f.dashHit.clear();
                f.nextAttackBoost = -1; // passes over walls as it jumps
                b.later.add(new Object[]{b.time + time, "frogLand", f.id, f.ultiJumps == 0 ? 1.25f : 1f});
                return true;
            }
            case REY_SUPER: {
                f.channelUntil = b.time + 3;
                f.form = 1;
                return true;
            }
            case QUEENS: {
                for (int i = 0; i < 5; i++) {
                    float a = angle + (float) Math.toRadians(-60 + 30 * i);
                    b.shoot(f, s, a, false, 0);
                    Battle.Shot sh = b.shots.get(b.shots.size() - 1);
                    sh.push = 1.5f;
                    sh.pierceChars = true;
                }
                return true;
            }
            case KNIGHT: {
                float d = Math.max(1.5f, Math.min(s.range, dist));
                b.lob(f, s, f.x + (float) Math.sin(angle) * d, f.z + (float) Math.cos(angle) * d, false, 0);
                b.shots.get(b.shots.size() - 1).tag = "knight";
                return true;
            }
            case CARDS: {
                String[] looks = {"CardDealerProjectile", "CardDealerProjectile2"};
                for (int i = 0; i < 2; i++) {
                    b.shoot(f, s, angle, false, 0);
                    Battle.Shot sh = b.shots.get(b.shots.size() - 1);
                    sh.proj = looks[i];
                    sh.tag = i == 0 ? "card0" : "card1";
                    sh.curve = i == 0 ? 0.9f : -0.9f;
                    sh.ox = sh.x;
                    sh.oz = sh.z;
                    sh.odx = sh.dx;
                    sh.odz = sh.dz;
                    sh.pierceChars = true;
                }
                return true;
            }
            case RUBY_ZONE: {
                float d = Math.max(1.5f, Math.min(s.range, dist));
                b.lob(f, s, f.x + (float) Math.sin(angle) * d, f.z + (float) Math.cos(angle) * d, true, 0);
                Battle.Shot sh = b.shots.get(b.shots.size() - 1);
                sh.tag = "zone";
                sh.proj = "CardDealerUltiProjectile";
                return true;
            }
            case SPLIT: {
                b.shoot(f, s, angle, false, 0);
                Battle.Shot sh = b.shots.get(b.shots.size() - 1);
                sh.tag = "split";
                sh.proj = "CardDealerGadget1SkillProjectile";
                return true;
            }
            case BOUNCE: {
                for (int i = 0; i < 4; i++) {
                    b.shoot(f, s, angle, false, i * 0.2f);
                }
                return true;
            }
            default:
                return false;
        }
    }

    /** the bouncing cards come out of the burst queue: give them their bounces */
    static void shot(Battle b, Battle.Fighter f, Battle.Shot sh) {
        if (sh.skill != null && sh.skill.kind == Battle.Kind.BOUNCE) {
            sh.wallBounces = 6;
            sh.push = 0.7f;
            sh.proj = "CardDealerGadget2SkillProjectile";
        }
    }

    // ------------------------------------------------------------------ landing
    static boolean land(Battle b, Battle.Shot s, Battle.Fighter f) {
        if (f == null) return false;
        switch (s.tag) {
            case "frog": {
                hurtAround(b, f, s.tx, s.tz, 1.33f, f.kit.weapon.damage, false);
                b.fx.add(new Object[]{"area", s.tx, s.tz, "FrogWizardWeaponArea", f, 1.33f});
                // the frog stays sitting there
                Battle.Shot p = new Battle.Shot();
                p.id = b.nextId++;
                p.team = f.team;
                p.owner = f.id;
                p.visual = true;
                p.parked = true;
                p.proj = s.proj;
                p.skill = s.skill;
                p.x = s.tx;
                p.z = s.tz;
                p.h = 0.05f;
                p.tag = "sitting";
                b.shots.add(p);
                int sitting = 0;
                for (Battle.Shot x : b.shots) if (x.owner == f.id && "sitting".equals(x.tag) && !x.dead) sitting++;
                if (sitting >= 2) triangle(b, f);
                return true;
            }
            case "knight": {
                for (Battle.Fighter o : b.fighters) {
                    if (!o.alive || !b.enemies(f, o) || o.box) continue;
                    if (Math.hypot(o.x - s.tx, o.z - s.tz) > 3 + o.kit.radius) continue;
                    o.reyMarkStart = b.time - 2.5f;
                    o.reyMarkUntil = b.time + 3;
                    o.slowUntil = Math.max(o.slowUntil, b.time + 2);
                }
                b.fx.add(new Object[]{"area", s.tx, s.tz, "TrackerGadgetMarkArea", f, 3f});
                return true;
            }
            case "zone": {
                Battle.Area a = new Battle.Area();
                a.kind = "cards";
                a.look = "CardDealerSuperArea";
                a.x = s.tx;
                a.z = s.tz;
                a.radius = f.kit.ulti.areaRadius;
                a.team = f.team;
                a.owner = f.id;
                a.left = 4;
                a.next = 0.1f;
                a.tick = 1.05f;
                b.areas.add(a);
                b.fx.add(new Object[]{"area", s.tx, s.tz, "CardDealerUltiBulletExplosionArea", f, a.radius});
                return true;
            }
            default:
                return false;
        }
    }

    static void hurtAround(Battle b, Battle.Fighter f, float x, float z, float r, int dmg, boolean ulti) {
        for (Battle.Fighter o : new ArrayList<>(b.fighters)) {
            if (!o.alive || !b.enemies(f, o)) continue;
            if (Math.hypot(o.x - x, o.z - z) > r + o.kit.radius * 0.5f) continue;
            b.damage(f, o, dmg, ulti);
        }
    }

    /** both frogs sit: the triangle between them and the third frog is struck, then they come back */
    static void triangle(Battle b, Battle.Fighter f) {
        List<Battle.Shot> sit = new ArrayList<>();
        for (Battle.Shot x : b.shots) if (x.owner == f.id && "sitting".equals(x.tag) && !x.dead) sit.add(x);
        if (sit.size() < 2) return;
        float[][] p = {{f.x, f.z}, {sit.get(0).x, sit.get(0).z}, {sit.get(1).x, sit.get(1).z}};
        int edgeDmg = Math.round(1500 * Battle.POWER), innerDmg = Math.round(edgeDmg * 0.7f);
        boolean mire = f.kit.starPower == 2 && !f.kit.starPowerName.isEmpty();
        for (Battle.Fighter o : new ArrayList<>(b.fighters)) {
            if (!o.alive) continue;
            float edge = Float.MAX_VALUE;
            for (int i = 0; i < 3; i++) edge = Math.min(edge, segDist(o.x, o.z, p[i], p[(i + 1) % 3]));
            boolean inside = inTriangle(o.x, o.z, p);
            boolean onEdge = edge <= 200 / Battle.UNIT + o.kit.radius * 0.5f;
            if (!inside && !onEdge) continue;
            if (b.enemies(f, o)) {
                b.damage(f, o, onEdge ? edgeDmg : innerDmg, false);
                if (onEdge && mire) o.slowUntil = Math.max(o.slowUntil, b.time + 2);
            } else if (f.healNext && o.team == f.team && !o.pet) {
                b.healUnit(o, 2000);
            }
        }
        f.healNext = false;
        Battle.Area flash = new Battle.Area();
        flash.kind = "tri";
        flash.tri = p;
        flash.team = f.team;
        flash.owner = f.id;
        flash.left = 0.45f;
        b.areas.add(flash);
        b.events.add("triangle:" + f.id);
        recallFrogs(b, f, true);
    }

    /** the frogs hop back: ammo is full again */
    static void recallFrogs(Battle b, Battle.Fighter f, boolean fly) {
        for (Battle.Shot x : b.shots) {
            if (x.owner != f.id || x.dead) continue;
            if ("sitting".equals(x.tag)) {
                x.dead = true;
                if (fly) {
                    Battle.Shot r = new Battle.Shot();
                    r.id = b.nextId++;
                    r.team = f.team;
                    r.owner = f.id;
                    r.visual = true;
                    r.homing = f.id;
                    r.proj = x.proj;
                    r.speed = 4000 / Battle.UNIT;
                    r.x = x.x;
                    r.z = x.z;
                    r.h = 0.5f;
                    b.later.add(new Object[]{b.time, "add", r});
                }
            }
        }
        f.frogsOut = 0;
        f.form = f.ultiJumps > 0 ? 3 : 0;
        b.later.add(new Object[]{b.time + (fly ? 0.5f : 0), "ammo", f.id});
    }

    static float segDist(float x, float z, float[] a, float[] c) {
        float dx = c[0] - a[0], dz = c[1] - a[1], l = dx * dx + dz * dz;
        float t = l < 1e-6f ? 0 : Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / l));
        return (float) Math.hypot(x - a[0] - dx * t, z - a[1] - dz * t);
    }

    static boolean inTriangle(float x, float z, float[][] p) {
        float d1 = sign(x, z, p[0], p[1]), d2 = sign(x, z, p[1], p[2]), d3 = sign(x, z, p[2], p[0]);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }

    static float sign(float x, float z, float[] a, float[] c) {
        return (x - c[0]) * (a[1] - c[1]) - (a[0] - c[0]) * (z - c[1]);
    }

    // ------------------------------------------------------------------ Rey
    static void reyFire(Battle b, Battle.Fighter f) {
        f.channelUntil = 0;
        f.form = 0;
        Battle.Fighter best = null;
        float bestScore = -1;
        for (Battle.Fighter o : b.fighters) {
            if (!o.alive || !b.enemies(f, o) || o.box || !b.visibleTo(o, f)) continue;
            float d = (float) Math.hypot(o.x - f.x, o.z - f.z);
            if (d > f.kit.ulti.range) continue;
            float score = markFill(b, o) * 10 - d * 0.1f + 1;
            if (score > bestScore) {
                bestScore = score;
                best = o;
            }
        }
        if (best == null) {
            b.message(f, "Нет целей рядом");
            return;
        }
        Battle.Shot sh = new Battle.Shot();
        sh.id = b.nextId++;
        sh.team = f.team;
        sh.owner = f.id;
        sh.ulti = true;
        sh.skill = f.kit.ulti;
        sh.proj = "TrackerUltiMarkedProjectile";
        sh.homing = best.id;
        sh.damage = f.kit.ulti.damage;
        sh.speed = 4000 / Battle.UNIT;
        sh.x = f.x;
        sh.z = f.z;
        sh.h = 0.6f;
        sh.angle = (float) Math.atan2(best.x - f.x, best.z - f.z);
        b.shots.add(sh);
        f.face = sh.angle;
        f.action = "ulti";
        f.actionStart = b.time;
        b.fx.add(new Object[]{"cast", f, f.kit.ulti, sh.angle, 1});
    }

    static float markFill(Battle b, Battle.Fighter o) {
        if (o.reyMarkUntil <= b.time || o.reyMarkStart < 0) return 0;
        return Math.max(0, Math.min(1, (b.time - o.reyMarkStart) / 2.5f));
    }

    // ------------------------------------------------------------------ flight and hits
    /** Ruby's cards weave a figure eight: crossing at the start, the middle and the end */
    static boolean curve(Battle b, Battle.Shot s, float dt) {
        if (s.curve == 0) return false;
        float step = s.speed * dt;
        s.flown += step;
        s.left -= step;
        s.age += dt;
        float range = s.skill != null ? s.skill.range : 9;
        float off = s.curve * (float) Math.sin(Math.PI * 2 * s.flown / range);
        float px = -s.odz, pz = s.odx;
        float nx = s.ox + s.odx * s.flown + px * off, nz = s.oz + s.odz * s.flown + pz * off;
        s.angle = (float) Math.atan2(nx - s.x, nz - s.z);
        s.x = nx;
        s.z = nz;
        if (s.left <= 0) {
            s.dead = true;
            b.fx.add(new Object[]{"reach", s.x, s.z, s, null});
            return true;
        }
        if (b.blocksShot((int) Math.floor(s.x), (int) Math.floor(s.z))) {
            s.dead = true;
            b.fx.add(new Object[]{"hitEnv", s.x, s.z, s, null});
            return true;
        }
        b.hitAt(s);
        return true;
    }

    static void onHit(Battle b, Battle.Shot s, Battle.Fighter from, Battle.Fighter to) {
        if (from == null || to.box) return;
        if (s.push > 0 && !to.boss) {
            float dx = to.x - s.x, dz = to.z - s.z, l = (float) Math.max(0.05, Math.hypot(dx, dz));
            if (l < 0.06f) {
                dx = s.dx;
                dz = s.dz;
                l = 1;
            }
            to.dashVx = dx / l * 10;
            to.dashVz = dz / l * 10;
            to.dashLeft = s.push;
            to.dashDamage = 0;
            to.dashHit.clear();
        }
        if (is(from, REY) && !s.ulti && s.skill == from.kit.weapon) {
            boolean full = markFill(b, to) >= 1;
            if (to.reyMarkUntil <= b.time) to.reyMarkStart = b.time;
            to.reyMarkUntil = b.time + 3;
            if (full && from.kit.starPower == 2 && !from.kit.starPowerName.isEmpty()) passMark(b, from, to);
        }
        if (is(from, REY) && s.ulti && markFill(b, to) >= 1 && from.kit.starPower == 2 && !from.kit.starPowerName.isEmpty()) passMark(b, from, to);
        if (is(from, RUBY) && s.tag.startsWith("card")) {
            int which = s.tag.equals("card0") ? 0 : 1;
            if (b.time - to.cardTime < 0.6f && to.cardWhich != which) {
                int bonus = pct(to, 0.1f, 1200);
                b.damage(from, to, bonus, false);
                b.events.add("double:" + from.id);
                if (from.kit.starPower == 2 && !from.kit.starPowerName.isEmpty()) dot(b, from, to, pct(to, 0.1f, 600), 1);
                to.cardTime = -9;
            } else {
                to.cardTime = b.time;
                to.cardWhich = which;
            }
        }
        if (is(from, RUBY) && "split".equals(s.tag)) split(b, from, s);
    }

    static void passMark(Battle b, Battle.Fighter from, Battle.Fighter to) {
        Battle.Fighter next = null;
        float best = from.kit.weapon.range;
        for (Battle.Fighter o : b.fighters) {
            if (!o.alive || o == to || o.box || !b.enemies(from, o)) continue;
            float d = (float) Math.hypot(o.x - to.x, o.z - to.z);
            if (d < best) {
                best = d;
                next = o;
            }
        }
        if (next == null) return;
        next.reyMarkStart = b.time - 2.5f;
        next.reyMarkUntil = b.time + 3;
    }

    /** «Перетасовка»: five cards fan out from where the first one stopped */
    static void split(Battle b, Battle.Fighter f, Battle.Shot s) {
        if (s.tag.equals("splitDone")) return;
        s.tag = "splitDone";
        s.dead = true;
        if (f == null) return;
        for (int i = 0; i < 5; i++) {
            float a = s.angle + (float) Math.toRadians(-40 + 20 * i);
            Battle.Shot c = new Battle.Shot();
            c.id = b.nextId++;
            c.team = f.team;
            c.owner = f.id;
            c.skill = s.skill;
            c.tag = "piece";
            c.proj = "CardDealerGadget1SkillProjectileSplit";
            c.speed = 2500 / Battle.UNIT;
            c.radius = 0.34f;
            c.left = 22 / 3f;
            c.pierceChars = true;
            c.x = s.x;
            c.z = s.z;
            c.h = s.h;
            c.angle = a;
            c.dx = (float) Math.sin(a);
            c.dz = (float) Math.cos(a);
            c.hit.addAll(s.hit);
            b.later.add(new Object[]{b.time, "add", c});
        }
    }

    /** a split card: hurts enemies by their health, heals allies */
    static boolean pieceTouch(Battle b, Battle.Shot s) {
        if (!"piece".equals(s.tag)) return false;
        Battle.Fighter f = b.byId(s.owner);
        for (Battle.Fighter o : b.fighters) {
            if (!o.alive || o.critter || s.hit.contains(o.id) || o.box) continue;
            if (Math.hypot(o.x - s.x, o.z - s.z) > o.kit.radius + s.radius) continue;
            s.hit.add(o.id);
            if (f != null && b.enemies(f, o)) b.damage(f, o, pct(o, 0.15f, 1200), false);
            else if (f != null && o.team == f.team && !o.pet) b.healUnit(o, 1600);
        }
        return true;
    }

    /** damage by a part of the target's health (bosses take the floor instead) */
    static int pct(Battle.Fighter o, float part, int floor) {
        return o.boss || o.keeper ? floor : Math.max(floor, Math.round(o.maxHp * part));
    }

    static void dot(Battle b, Battle.Fighter from, Battle.Fighter to, int perSecond, float seconds) {
        to.dotUntil = b.time + seconds;
        to.dotDamage = perSecond;
        to.dotFrom = from.id;
        to.dotNext = b.time + 1;
    }

    static float damage(Battle b, Battle.Fighter from, Battle.Fighter to, float d, boolean ulti) {
        if (is(from, REY)) d *= 1 + markFill(b, to);
        if (is(to, REY) && to.channelUntil > b.time) d *= 0.7f;
        return d;
    }

    // ------------------------------------------------------------------ every step
    static void step(Battle b, float dt) {
        for (Battle.Fighter f : new ArrayList<>(b.fighters)) {
            if (!f.alive) continue;
            if (f.dotUntil > b.time && b.time >= f.dotNext) {
                f.dotNext = b.time + 1;
                Battle.Fighter from = b.byId(f.dotFrom);
                if (from != null) b.damage(from, f, f.dotDamage, false);
            }
            if (is(f, FROGS)) {
                if (f.frogsOut > 0 && b.time > f.frogsBack) recallFrogs(b, f, true);
                if (f.ultiJumps > 0 && b.time >= f.ultiJumpsUntil) {
                    f.ultiJumps = 0;
                    f.form = 0;
                }
                if (f.ultiJumps == 0 && f.form == 3 && f.dashLeft <= 0) f.form = 0;
            }
            if (is(f, REY) && f.channelUntil > 0) {
                boolean slows = f.kit.starPower == 1 && !f.kit.starPowerName.isEmpty();
                for (Battle.Fighter o : b.fighters) {
                    if (!o.alive || o.box || !b.enemies(f, o) || !b.visibleTo(o, f)) continue;
                    if (Math.hypot(o.x - f.x, o.z - f.z) > f.kit.ulti.range) continue;
                    if (o.reyMarkUntil <= b.time) o.reyMarkStart = b.time;
                    o.reyMarkUntil = Math.max(o.reyMarkUntil, b.time + 1);
                    if (slows) o.slowUntil = Math.max(o.slowUntil, b.time + 0.5f);
                }
                if (b.time >= f.channelUntil) reyFire(b, f);
            }
        }
        // Ruby's zone: grounded, hurt every second
        for (Battle.Area a : b.areas) {
            if (!"cards".equals(a.kind)) continue;
            Battle.Fighter f = b.byId(a.owner);
            boolean lucky = f != null && f.kit.starPower == 1 && !f.kit.starPowerName.isEmpty();
            for (Battle.Fighter o : b.fighters) {
                if (!o.alive || o.box || f == null || !b.enemies(f, o)) continue;
                if (Math.hypot(o.x - a.x, o.z - a.z) > a.radius) continue;
                o.groundedUntil = b.time + 0.25f;
            }
            a.next -= dt;
            if (a.next > 0 || f == null) continue;
            a.next = a.tick;
            for (Battle.Fighter o : new ArrayList<>(b.fighters)) {
                if (!o.alive || o.box || !b.enemies(f, o)) continue;
                if (Math.hypot(o.x - a.x, o.z - a.z) > a.radius) continue;
                int d = pct(o, 0.15f, 1200);
                b.damage(f, o, Math.round(d * (lucky ? 1.4f : 1f)), true);
            }
        }
    }

    /** things that happen a moment later: a giant frog lands, frogs come back, a split card appears */
    static void later(Battle b, Object[] e) {
        switch ((String) e[1]) {
            case "frogLand": {
                Battle.Fighter f = b.byId((int) e[2]);
                if (f == null || !f.alive) return;
                f.nextAttackBoost = 0;
                float scale = (float) e[3];
                float r = f.kit.ulti.areaRadius * scale;
                int base = f.kit.ulti.damage;
                int dealt = 0;
                for (Battle.Fighter o : new ArrayList<>(b.fighters)) {
                    if (!o.alive || !b.enemies(f, o)) continue;
                    float d = (float) Math.hypot(o.x - f.x, o.z - f.z);
                    if (d > r + o.kit.radius * 0.5f) continue;
                    int dmg = d < r - 250 / Battle.UNIT ? Math.round(base * 1.3f) : base;
                    b.damage(f, o, dmg, true);
                    dealt += dmg;
                }
                b.fx.add(new Object[]{"area", f.x, f.z, "FrogWizardUltiArea", f, r});
                b.events.add("boom:" + f.id);
                if (dealt > 0 && f.kit.starPower == 1 && !f.kit.starPowerName.isEmpty()) b.healUnit(f, Math.round(dealt * 0.25f));
                if (f.ultiJumps == 0) f.form = 0;
                return;
            }
            case "ammo": {
                Battle.Fighter f = b.byId((int) e[2]);
                if (f != null) f.ammo = f.kit.weapon.maxCharge;
                return;
            }
            case "add":
                b.shots.add((Battle.Shot) e[2]);
                return;
            default:
                break;
        }
    }

    static List<String> describe(String code) {
        List<String> l = new ArrayList<>();
        switch (code) {
            case FROGS:
                l.add("Атака: жаба прыгает в точку; после второй — разряд по треугольнику (края бьют сильнее), жабы возвращаются");
                l.add("Супер «Жабзилла»: огромная жаба, три прыжка (третий дальше), в центре урон выше");
                break;
            case REY:
                l.add("Атака ставит метку: чем дольше она висит, тем сильнее следующий выстрел (до ×2)");
                l.add("Супер «Эндшпиль»: до 3 с прицеливания со щитом 30 %, метит всех рядом, потом самонаводящийся выстрел; повторное нажатие — выстрел сразу");
                break;
            case RUBY:
                l.add("Атака: две карты летят восьмёркой; попадание обеими — дополнительный урон");
                l.add("Супер «Роял-флеш»: зона на 4 с, заземляет врагов и бьёт их каждую секунду");
                break;
            default:
                break;
        }
        return l;
    }
}
