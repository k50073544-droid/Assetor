package com.weker.assetexplorer.codec;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The game's .sc files for the effects of a battle. A file that isn't read yet is asked for from a background thread
 * and answered with null until it is there, so the drawing thread never waits for a 40 MB file. While
 * {@link #blocking} is set (the loading screen) the caller reads it right away instead.
 * A file that can't be read (too little memory, missing) is given up on once and the effects in it simply don't show,
 * where a crash would end the whole battle.
 */
public final class ScLoader implements Fx.ScFiles {

    public interface Source {
        Sc2 load(String file) throws Exception;
    }

    private final Source source;
    private final Map<String, Sc2> ready = new ConcurrentHashMap<>();
    private final Set<String> asked = ConcurrentHashMap.newKeySet();
    private final Set<String> failed = ConcurrentHashMap.newKeySet();
    public volatile boolean blocking;
    /** files given up on because there was no memory (for a message to the person) */
    public volatile int outOfMemory;

    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "sc-loader");
        t.setDaemon(true);
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });

    public ScLoader(Source source) {
        this.source = source;
    }

    @Override
    public Sc2 sc(String file) {
        if (file == null || file.isEmpty()) return null;
        Sc2 s = ready.get(file);
        if (s != null) return s;
        if (failed.contains(file)) return null;
        if (blocking) return loadNow(file);
        if (asked.add(file)) {
            try {
                worker.execute(() -> loadNow(file));
            } catch (RuntimeException e) {
                failed.add(file);
            }
        }
        return null;
    }

    private synchronized Sc2 loadNow(String file) {
        Sc2 s = ready.get(file);
        if (s != null || failed.contains(file)) return s;
        try {
            s = source.load(file);
        } catch (OutOfMemoryError e) {
            outOfMemory++;
            s = null;
            System.gc();
        } catch (Throwable e) {
            s = null;
        }
        if (s == null) failed.add(file);
        else ready.put(file, s);
        return s;
    }

    /** every file is read again when it is next needed */
    public void forget() {
        ready.clear();
        asked.clear();
        failed.clear();
    }

    public int loaded() {
        return ready.size();
    }

    public void shutdown() {
        worker.shutdownNow();
    }
}
