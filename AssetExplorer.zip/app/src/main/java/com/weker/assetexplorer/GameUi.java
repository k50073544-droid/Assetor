package com.weker.assetexplorer;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/** The game's own look: its font (LilitaOne) and interface pictures from ui.sc. */
public final class GameUi {

    private GameUi() {}

    private static Typeface font;
    private static long fontVid = -1;
    private static final Map<String, Bitmap> pics = new HashMap<>();

    /** the font Brawl Stars writes with (Pusia for Cyrillic, as the Russian game; LilitaOne otherwise), or bold sans */
    public static synchronized Typeface font(GameData gd) {
        if (font != null && fontVid == gd.vid) return font;
        Typeface t = null;
        for (String n : new String[]{"Pusia-Bold.otf", "LilitaOne-Regular.ttf", "LilitaOne.ttf"}) {
            File f = gd.file(n);
            if (f == null || !f.exists()) continue;
            try {
                t = Typeface.createFromFile(f);
                break;
            } catch (Throwable ignored) {
                // next
            }
        }
        font = t != null ? t : Typeface.DEFAULT_BOLD;
        fontVid = gd.vid;
        return font;
    }

    /** a picture from ui.sc (joysticks, buttons…), cached; null when not in the archive */
    public static Bitmap pic(GameData gd, String export, int size) {
        String key = gd.vid + "/" + export + "/" + size;
        synchronized (pics) {
            if (pics.containsKey(key)) return pics.get(key);
        }
        Bitmap b = gd.export("ui.sc", export, size);
        synchronized (pics) {
            pics.put(key, b);
        }
        return b;
    }

    /** text with the game's dark outline */
    public static void outlined(Canvas c, String s, float x, float y, Paint p, int color, float outline) {
        Paint.Style st = p.getStyle();
        int old = p.getColor();
        int a = p.getAlpha();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(outline);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(0xFF000000);
        p.setAlpha(a);
        c.drawText(s, x, y + outline * 0.35f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setAlpha(a);
        c.drawText(s, x, y, p);
        p.setStyle(st);
        p.setColor(old);
    }
}
