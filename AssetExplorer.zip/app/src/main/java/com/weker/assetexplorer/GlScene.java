package com.weker.assetexplorer;

import android.opengl.GLES20;

import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Model3d;
import com.weker.assetexplorer.codec.Sc2;
import com.weker.assetexplorer.codec.Scene3d;
import com.weker.assetexplorer.codec.SupercellFiles;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Draws a {@link Scene3d} with OpenGL ES 2.0 the way the game does (call from a GLSurfaceView renderer):
 * <ul>
 * <li>materials follow the game's "uber" shader: texture × diffuse lightmap, plus the specular lightmap times the
 * material's specular colour or texture; things without a lightmap are not shaded at all;</li>
 * <li>characters are skinned by the GPU: their model is uploaded once and each frame only sends bone matrices;</li>
 * <li>2D effects are drawn as triangles straight from the atlases of their .sc files, with each shape's own colour
 * transform and blend mode (glows add light), batched into a few draw calls;</li>
 * <li>textures stay ASTC-compressed with the mip levels stored in the game's files when the chip reads ASTC.</li>
 * </ul>
 */
public final class GlScene {

    // ------------------------------------------------------------------ shaders
    static final String VS_MODEL = "attribute vec3 aPos;\n"
            + "attribute vec3 aNrm;\n"
            + "attribute vec2 aUv;\n"
            + "attribute vec4 aCol;\n"
            + "#ifdef SKIN\n"
            + "attribute vec4 aJoint;\n"
            + "attribute vec4 aWeight;\n"
            + "uniform vec4 uBones[BONES * 3];\n"
            + "#endif\n"
            + "uniform mat4 uMvp;\n"
            + "uniform mat3 uRot;\n"
            + "uniform vec4 uSway;\n" // x: how far a bush top moves (0 = not a bush), y: time, z: 1 = z is up in the model
            + "varying vec2 vUv;\n"
            + "varying vec3 vN;\n"
            + "varying vec4 vCol;\n"
            + "void main() {\n"
            + "  vec4 p = vec4(aPos, 1.0);\n"
            + "  vec3 n = aNrm;\n"
            + "#ifdef SKIN\n"
            + "  vec4 w = aWeight / max(0.0001, aWeight.x + aWeight.y + aWeight.z + aWeight.w);\n"
            + "  vec4 n4 = vec4(n, 0.0);\n"
            + "  vec3 sp = vec3(0.0);\n"
            + "  vec3 sn = vec3(0.0);\n"
            + "  int j = int(aJoint.x + 0.5) * 3;\n"
            + "  sp += w.x * vec3(dot(uBones[j], p), dot(uBones[j + 1], p), dot(uBones[j + 2], p));\n"
            + "  sn += w.x * vec3(dot(uBones[j], n4), dot(uBones[j + 1], n4), dot(uBones[j + 2], n4));\n"
            + "  j = int(aJoint.y + 0.5) * 3;\n"
            + "  sp += w.y * vec3(dot(uBones[j], p), dot(uBones[j + 1], p), dot(uBones[j + 2], p));\n"
            + "  sn += w.y * vec3(dot(uBones[j], n4), dot(uBones[j + 1], n4), dot(uBones[j + 2], n4));\n"
            + "  j = int(aJoint.z + 0.5) * 3;\n"
            + "  sp += w.z * vec3(dot(uBones[j], p), dot(uBones[j + 1], p), dot(uBones[j + 2], p));\n"
            + "  sn += w.z * vec3(dot(uBones[j], n4), dot(uBones[j + 1], n4), dot(uBones[j + 2], n4));\n"
            + "  j = int(aJoint.w + 0.5) * 3;\n"
            + "  sp += w.w * vec3(dot(uBones[j], p), dot(uBones[j + 1], p), dot(uBones[j + 2], p));\n"
            + "  sn += w.w * vec3(dot(uBones[j], n4), dot(uBones[j + 1], n4), dot(uBones[j + 2], n4));\n"
            + "  p = vec4(sp, 1.0);\n"
            + "  n = sn;\n"
            + "#else\n"
            + "  if (uSway.x > 0.0) {\n" // the game's plants shader: tops lean to and fro, roots stay
            + "    float h = uSway.z > 0.5 ? p.z : p.y;\n"
            + "    float seed = p.x * 1.7 + (uSway.z > 0.5 ? p.y : p.z) * 0.9;\n"
            + "    float k = clamp(h, 0.0, 1.5) * uSway.x;\n"
            + "    p.x += cos(uSway.y * 1.9 + seed) * k;\n"
            + "    if (uSway.z > 0.5) p.y += sin(uSway.y * 1.3 + seed) * k * 0.6; else p.z += sin(uSway.y * 1.3 + seed) * k * 0.6;\n"
            + "  }\n"
            + "#endif\n"
            + "  gl_Position = uMvp * p;\n"
            + "  vN = uRot * n;\n"
            + "  vUv = aUv;\n"
            + "  vCol = aCol;\n"
            + "}\n";

    /**
     * The game's uber shader, the parts the models use:
     * colour = diffuse × diffuse lightmap × colorize + emission + specular lightmap × specular, × opacity, then the
     * colour transform (multiply, add). Lightmaps are looked up with the view-space normal.
     */
    static final String FS_MODEL = "#ifdef GL_FRAGMENT_PRECISION_HIGH\n"
            + "precision highp float;\n"
            + "#else\n"
            + "precision mediump float;\n"
            + "#endif\n"
            + "uniform sampler2D uTex;\n"
            + "uniform sampler2D uLmD;\n"
            + "uniform sampler2D uLmS;\n"
            + "uniform sampler2D uSpecTex;\n"
            + "uniform vec4 uMode;\n"  // x: 0 plain colour, 1 texture, 2 corner colours; y: 1 = diffuse lightmap; z: specular 0 none, 1 colour, 2 the texture itself, 3 uSpecTex; w: alpha under which a pixel is dropped
            + "uniform vec4 uBase;\n"  // colour of parts without a texture
            + "uniform vec3 uTint;\n"
            + "uniform vec3 uEmit;\n"
            + "uniform vec3 uSpec;\n"
            + "uniform vec4 uColor;\n" // multiply; a = opacity
            + "uniform vec3 uAdd;\n"
            + "uniform vec2 uOut;\n"   // x: 1 = see-through by the picture's alpha; y: 1 = adds light
            + "varying vec2 vUv;\n"
            + "varying vec3 vN;\n"
            + "varying vec4 vCol;\n"
            + "void main() {\n"
            + "  vec4 c = uBase;\n"
            + "  if (uMode.x > 1.5) c = vCol;\n"
            + "  else if (uMode.x > 0.5) c = texture2D(uTex, vUv);\n"
            + "  if (c.a < uMode.w) discard;\n"
            + "  vec3 col = c.rgb;\n"
            + "  vec3 n = normalize(vN);\n"
            + "  if (n.z < 0.0) n = -n;\n"
            + "  vec2 m = n.xy * vec2(0.5, -0.5) + vec2(0.5, 0.5);\n"
            + "  if (uMode.y > 0.5) col *= texture2D(uLmD, m).rgb;\n"
            + "  col = col * uTint + uEmit;\n"
            + "  if (uMode.z > 2.5) col += texture2D(uLmS, m).rgb * texture2D(uSpecTex, vUv).rgb;\n"
            + "  else if (uMode.z > 1.5) col += texture2D(uLmS, m).rgb * c.rgb;\n"
            + "  else if (uMode.z > 0.5) col += texture2D(uLmS, m).rgb * uSpec;\n"
            + "  col = col * uColor.rgb + uAdd;\n"
            + "  float a = mix(1.0, c.a, uOut.x) * uColor.a;\n"
            + "  gl_FragColor = vec4(min(col, vec3(1.0)) * a, a * (1.0 - uOut.y));\n"
            + "}\n";

    static final String VS_SPRITE = "attribute vec3 aPos;\n"
            + "attribute vec2 aUv;\n"
            + "attribute vec4 aCol;\n"
            + "attribute vec4 aAdd;\n"
            + "uniform mat4 uMvp;\n"
            + "varying vec2 vUv;\n"
            + "varying vec4 vMul;\n"
            + "varying vec4 vAdd;\n"
            + "void main() {\n"
            + "  gl_Position = uMvp * vec4(aPos, 1.0);\n"
            + "  vUv = aUv;\n"
            + "  vMul = aCol;\n"
            + "  vAdd = aAdd;\n"
            + "}\n";

    /** a clip's shape: picture × colour + added colour; alpha 0 in the output makes it add light (blend ONE, 1 − alpha) */
    static final String FS_SPRITE = "#ifdef GL_FRAGMENT_PRECISION_HIGH\n"
            + "precision highp float;\n"
            + "#else\n"
            + "precision mediump float;\n"
            + "#endif\n"
            + "uniform sampler2D uTex;\n"
            + "varying vec2 vUv;\n"
            + "varying vec4 vMul;\n"
            + "varying vec4 vAdd;\n"
            + "void main() {\n"
            + "  vec4 t = texture2D(uTex, vUv);\n"
            + "  float a = t.a * vMul.a;\n"
            + "  vec3 c = min(t.rgb * vMul.rgb + vAdd.rgb, vec3(1.0));\n"
            + "  gl_FragColor = vec4(c * a, a * (1.0 - vAdd.a));\n"
            + "}\n";

    static final int A_POS = 0, A_NRM = 1, A_UV = 2, A_COL = 3, A_JOINT = 4, A_WEIGHT = 5, A_ADD = 6;

    static final class Prog {
        int id, uMvp, uRot, uBones, uSway, uMode, uBase, uTint, uEmit, uSpec, uColor, uAdd, uOut;
    }

    /** a part on the GPU */
    static final class Buf {
        int id, stride, count, lastFrame;
        boolean skinned, colors;
        /** skinned parts: runs of corners that fit the bone limit, and the skin joints each run uses (slot 0 = none) */
        int[] chunkStart, chunkCount;
        int[][] chunkJoints;
    }

    private Prog solid, skin, sprite;
    private int whiteTex;
    private boolean ready;
    private int frame;
    public int width = 1, height = 1;
    /** the chip reads ASTC textures itself */
    public boolean astc;
    /** bones a skinned draw can take (from the uniform limit) */
    public int maxBones = 60;
    /** for tests: a smaller bone limit than the chip's */
    public static int boneLimit = 0;
    /** reads atlases that live in their own files; set by the screen */
    public Sc2.Files files;
    /** what the last frame took: draw calls, sprite corners, bytes sent */
    public int draws, corners;
    public long uploaded;
    public String error;

    private final Map<Img, int[]> textures = new IdentityHashMap<>();
    private final Map<Model3d.Part, Buf> buffers = new IdentityHashMap<>();
    private final Map<Sc2, int[]> atlases = new IdentityHashMap<>();

    // scratch (nothing is allocated while drawing)
    private final float[] proj = new float[16], vp = new float[16], mv = new float[16], mvp = new float[16], tmp = new float[16], rot = new float[9];
    private float[] palette = new float[61 * 12];
    private static final int SPRITE_INTS = 7, SPRITE_MAX = 6144;
    private final int[] sv = new int[SPRITE_INTS * SPRITE_MAX];
    private IntBuffer spriteBuf;
    private int spriteVbo, spriteCount, spriteTex;
    private final List<Scene3d.Item> later = new ArrayList<>();
    private final int[] one = new int[1];

    // GL state kept here to skip calls that change nothing
    private int curProg = -1;
    private final int[] bound = {-1, -1, -1, -1};
    private int activeUnit = -1;
    private final boolean[] arrays = new boolean[8];

    // ------------------------------------------------------------------ setup
    /** call from onSurfaceCreated (all GPU objects are new then) */
    public void init() {
        textures.clear();
        buffers.clear();
        atlases.clear();
        curProg = -1;
        activeUnit = -1;
        java.util.Arrays.fill(bound, -1);
        java.util.Arrays.fill(arrays, false);
        ready = false;
        String ext = String.valueOf(GLES20.glGetString(GLES20.GL_EXTENSIONS));
        String ver = String.valueOf(GLES20.glGetString(GLES20.GL_VERSION));
        astc = ext.contains("texture_compression_astc") || ver.contains("OpenGL ES 3.2");
        GLES20.glGetIntegerv(GLES20.GL_MAX_VERTEX_UNIFORM_VECTORS, one, 0);
        int vectors = one[0] <= 0 ? 128 : one[0];
        maxBones = Math.max(16, Math.min(120, (vectors - 24) / 3));
        if (boneLimit > 0) maxBones = Math.min(maxBones, boneLimit);
        palette = new float[(maxBones + 1) * 12];
        solid = model(false);
        skin = model(true);
        sprite = new Prog();
        sprite.id = link(VS_SPRITE, FS_SPRITE, "");
        sprite.uMvp = GLES20.glGetUniformLocation(sprite.id, "uMvp");
        use(sprite);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(sprite.id, "uTex"), 0);
        whiteTex = rgba(1, 1, new int[]{0xFFFFFFFF}, false);
        GLES20.glGenBuffers(1, one, 0);
        spriteVbo = one[0];
        spriteBuf = ByteBuffer.allocateDirect(sv.length * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        ready = true;
    }

    private Prog model(boolean skinned) {
        Prog p = new Prog();
        p.id = link(VS_MODEL, FS_MODEL, skinned ? "#define SKIN\n#define BONES " + (maxBones + 1) + "\n" : "");
        p.uMvp = GLES20.glGetUniformLocation(p.id, "uMvp");
        p.uRot = GLES20.glGetUniformLocation(p.id, "uRot");
        p.uBones = GLES20.glGetUniformLocation(p.id, "uBones");
        p.uSway = GLES20.glGetUniformLocation(p.id, "uSway");
        p.uMode = GLES20.glGetUniformLocation(p.id, "uMode");
        p.uBase = GLES20.glGetUniformLocation(p.id, "uBase");
        p.uTint = GLES20.glGetUniformLocation(p.id, "uTint");
        p.uEmit = GLES20.glGetUniformLocation(p.id, "uEmit");
        p.uSpec = GLES20.glGetUniformLocation(p.id, "uSpec");
        p.uColor = GLES20.glGetUniformLocation(p.id, "uColor");
        p.uAdd = GLES20.glGetUniformLocation(p.id, "uAdd");
        p.uOut = GLES20.glGetUniformLocation(p.id, "uOut");
        use(p);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(p.id, "uTex"), 0);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(p.id, "uLmD"), 1);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(p.id, "uLmS"), 2);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(p.id, "uSpecTex"), 3);
        return p;
    }

    static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s));
        return s;
    }

    static int link(String vs, String fs, String defines) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, defines + vs));
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glBindAttribLocation(p, A_POS, "aPos");
        GLES20.glBindAttribLocation(p, A_NRM, "aNrm");
        GLES20.glBindAttribLocation(p, A_UV, "aUv");
        GLES20.glBindAttribLocation(p, A_COL, "aCol");
        GLES20.glBindAttribLocation(p, A_JOINT, "aJoint");
        GLES20.glBindAttribLocation(p, A_WEIGHT, "aWeight");
        GLES20.glBindAttribLocation(p, A_ADD, "aAdd");
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("program: " + GLES20.glGetProgramInfoLog(p));
        return p;
    }

    public void resize(int w, int h) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        GLES20.glViewport(0, 0, width, height);
    }

    // ------------------------------------------------------------------ a frame
    /** seconds, for swaying bushes */
    public float time;

    public void draw(Scene3d s) {
        frame++;
        draws = 0;
        corners = 0;
        if (frame % 240 == 0) sweep();
        int bg = s.background;
        GLES20.glDepthMask(true);
        GLES20.glClearColor(((bg >> 16) & 255) / 255f, ((bg >> 8) & 255) / 255f, (bg & 255) / 255f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        if (!ready) return;
        projection(s, width / (float) height, proj);
        mul(proj, s.view, vp);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        GLES20.glDepthFunc(GLES20.GL_LEQUAL);
        List<Scene3d.Item> items = s.items;
        int n = items.size();

        // 1. far surroundings and the ground: nothing is behind them, so no depth; solid parts, then their decals
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthMask(false);
        GLES20.glDisable(GLES20.GL_BLEND);
        for (int i = 0; i < n; i++) {
            Scene3d.Item it = items.get(i);
            if (it.background) item(s, it, true, false);
        }
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < n; i++) {
            Scene3d.Item it = items.get(i);
            if (it.background) item(s, it, false, true);
        }

        // 2. solid things, front to back by the depth buffer
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthMask(true);
        later.clear();
        for (int i = 0; i < n; i++) {
            Scene3d.Item it = items.get(i);
            if (it.background) continue;
            boolean see = (it.color >>> 24) < 255 || it.overlay || it.sprite;
            if (see) {
                later.add(it);
                continue;
            }
            if (item(s, it, true, false)) later.add(it);
        }

        // 3. see-through things over them: sprites lying on the ground, markers and shadows, glass, then the effects
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glDepthMask(false);
        sprites(s, true);
        for (int i = 0; i < later.size(); i++) {
            Scene3d.Item it = later.get(i);
            boolean see = (it.color >>> 24) < 255 || it.overlay || it.sprite;
            item(s, it, see, true);
        }
        sprites(s, false);
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    /**
     * Draws an item's parts. {@code solids}: parts of solid materials; {@code blended}: see-through ones (and every
     * part of a see-through item). Returns true when the item has see-through parts that were left for later.
     */
    private boolean item(Scene3d s, Scene3d.Item it, boolean solids, boolean blended) {
        Model3d model = it.model;
        if (model == null) return false;
        boolean itemSee = (it.color >>> 24) < 255 || it.overlay || it.sprite;
        boolean left = false, set = false;
        Prog pr = null;
        Map<String, Img> imgs = it.images;
        List<Model3d.Part> parts = model.parts;
        for (int pi = 0; pi < parts.size(); pi++) {
            Model3d.Part p = parts.get(pi);
            if (!p.visible || p.triangles == 0 || p.pos == null) continue;
            if (it.onlyParts != null && !it.onlyParts.contains(p.name)) continue;
            Model3d.Mat mat = p.mat;
            boolean see = itemSee || (mat != null && !mat.solid());
            if (see ? !blended : !solids) {
                if (see) left = true;
                continue;
            }
            boolean skinned = p.joints != null && p.weights != null && p.skin >= 0 && it.pose != null && it.pose.skins != null
                    && p.skin < it.pose.skins.length;
            Buf b = buffers.get(p);
            if (b == null) {
                b = upload(p, skinned);
                buffers.put(p, b);
            }
            b.lastFrame = frame;
            Prog want = b.skinned ? skin : solid;
            if (want != pr) {
                pr = want;
                use(pr);
                set = false;
            }
            float[] rigid = it.pose != null && it.pose.rigid != null && pi < it.pose.rigid.length ? it.pose.rigid[pi] : null;
            if (!set || rigid != null) {
                mul(s.view, it.matrix, mv);
                if (rigid != null) {
                    mul(mv, rigid, tmp);
                    System.arraycopy(tmp, 0, mv, 0, 16);
                }
                mul(proj, mv, mvp);
                GLES20.glUniformMatrix4fv(pr.uMvp, 1, false, mvp, 0);
                rot[0] = mv[0]; rot[1] = mv[1]; rot[2] = mv[2];
                rot[3] = mv[4]; rot[4] = mv[5]; rot[5] = mv[6];
                rot[6] = mv[8]; rot[7] = mv[9]; rot[8] = mv[10];
                GLES20.glUniformMatrix3fv(pr.uRot, 1, false, rot, 0);
                int c = it.color, f = it.flash;
                GLES20.glUniform4f(pr.uColor, ((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, (c >>> 24) / 255f);
                GLES20.glUniform3f(pr.uAdd, ((f >> 16) & 255) / 255f, ((f >> 8) & 255) / 255f, (f & 255) / 255f);
                if (pr == solid) GLES20.glUniform4f(pr.uSway, it.plant ? 0.045f : 0f, time, 1f, 0f);
                set = rigid == null;
            }
            material(pr, it, p, mat, imgs, see);
            attribs(b);
            if (b.skinned) {
                float[] pal = skinned ? it.pose.skins[p.skin] : null;
                for (int ch = 0; ch < b.chunkStart.length; ch++) {
                    int[] joints = b.chunkJoints[ch];
                    palette[0] = 1; palette[1] = 0; palette[2] = 0; palette[3] = 0;
                    palette[4] = 0; palette[5] = 1; palette[6] = 0; palette[7] = 0;
                    palette[8] = 0; palette[9] = 0; palette[10] = 1; palette[11] = 0;
                    for (int k = 1; k < joints.length; k++) {
                        int g = joints[k] * 12;
                        if (pal != null && g + 12 <= pal.length) System.arraycopy(pal, g, palette, k * 12, 12);
                        else System.arraycopy(palette, 0, palette, k * 12, 12);
                    }
                    GLES20.glUniform4fv(pr.uBones, joints.length * 3, palette, 0);
                    GLES20.glDrawArrays(GLES20.GL_TRIANGLES, b.chunkStart[ch], b.chunkCount[ch]);
                    draws++;
                }
            } else {
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, b.count);
                draws++;
            }
        }
        return left;
    }

    /** the part's material as the uber shader's switches */
    private void material(Prog pr, Scene3d.Item it, Model3d.Part p, Model3d.Mat mat, Map<String, Img> imgs, boolean see) {
        Img tex = null;
        if (p.hasUv) tex = it.override != null ? it.override : imgs != null && p.diffuseTex != null ? imgs.get(p.diffuseTex) : null;
        boolean lit = !it.overlay && !it.sprite;
        Img lmD = lit && imgs != null && p.lightmapDiffuse != null ? imgs.get(p.lightmapDiffuse) : null;
        Img lmS = lit && imgs != null && p.lightmapSpecular != null ? imgs.get(p.lightmapSpecular) : null;
        float spec = 0;
        if (lmS != null && mat != null) {
            if (mat.specularTex != null) {
                Img st = mat.specularTex.equals(p.diffuseTex) || imgs == null ? null : imgs.get(mat.specularTex);
                if (st != null) {
                    spec = 3;
                    bind(3, st, true);
                } else if (tex != null) {
                    spec = 2;
                }
            } else if (mat.specular != null) {
                spec = 1;
                GLES20.glUniform3f(pr.uSpec, mat.specular[0], mat.specular[1], mat.specular[2]);
            }
        } else if (lmS != null) {
            spec = tex != null ? 2 : 0;
        }
        float kind = it.vertexColors && p.colors != null ? 2 : tex != null ? 1 : 0;
        float cut = kind == 1 ? (see ? 0.004f : 0.35f) : 0f;
        GLES20.glUniform4f(pr.uMode, kind, lmD != null ? 1f : 0f, spec, cut);
        float[] d = mat != null && kind == 0 ? mat.diffuse : null;
        if (d != null) GLES20.glUniform4f(pr.uBase, d[0], d[1], d[2], 1f);
        else GLES20.glUniform4f(pr.uBase, 1f, 1f, 1f, 1f);
        float[] t = mat == null ? null : mat.colorize;
        if (t != null) GLES20.glUniform3f(pr.uTint, t[0], t[1], t[2]);
        else GLES20.glUniform3f(pr.uTint, 1f, 1f, 1f);
        float er = 0, eg = 0, eb = 0;
        if (mat != null && lit) {
            if (mat.emission != null) {
                er += mat.emission[0];
                eg += mat.emission[1];
                eb += mat.emission[2];
            }
            if (mat.ambient != null) {
                er += mat.ambient[0];
                eg += mat.ambient[1];
                eb += mat.ambient[2];
            }
        }
        GLES20.glUniform3f(pr.uEmit, er, eg, eb);
        boolean alphaTex = see && tex != null && (it.sprite || mat == null || mat.blend != 4 || it.overlay);
        boolean adds = it.additive || (mat != null && mat.blend == 6 && lit);
        GLES20.glUniform2f(pr.uOut, alphaTex ? 1f : 0f, adds ? 1f : 0f);
        if (mat != null && mat.opacity < 0.999f && see) {
            int c = it.color;
            GLES20.glUniform4f(pr.uColor, ((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, (c >>> 24) / 255f * mat.opacity);
        }
        bind(0, tex, !it.sprite);
        if (lmD != null) bind(1, lmD, false);
        if (lmS != null && spec > 0) bind(2, lmS, false);
    }

    // ------------------------------------------------------------------ 2D clips
    private void sprites(Scene3d s, boolean ground) {
        List<Scene3d.Sprite> list = s.sprites;
        int n = list.size();
        if (n == 0) return;
        boolean any = false;
        for (int i = 0; i < n; i++) {
            Scene3d.Sprite q = list.get(i);
            if (q.ground != ground || q.sc == null) continue;
            Sc2.Mesh m = q.sc.mesh(q.id, q.frame);
            if (m.count == 0) continue;
            if (!any) {
                any = true;
                use(sprite);
                GLES20.glUniformMatrix4fv(sprite.uMvp, 1, false, vp, 0);
                spriteCount = 0;
                spriteTex = -1;
            }
            int[] ids = atlases.get(q.sc);
            if (ids == null) {
                ids = new int[q.sc.textures.size()];
                atlases.put(q.sc, ids);
            }
            boolean white = q.r >= 0.999f && q.g >= 0.999f && q.b >= 0.999f && q.a >= 0.999f;
            int ir = (int) (q.r * 256), ig = (int) (q.g * 256), ib = (int) (q.b * 256), ia = (int) (q.a * 256);
            int forceAdd = q.additive ? 0xFF000000 : 0;
            float[] xy = m.xy, uv = m.uv;
            int[] mulv = m.mul, addv = m.add;
            for (int r = 0; r < m.runTex.length; r++) {
                int ti = m.runTex[r];
                if (ti < 0 || ti >= ids.length) continue;
                if (ids[ti] == 0) ids[ti] = atlas(q.sc, ti);
                if (ids[ti] < 0) continue;
                if (ids[ti] != spriteTex) {
                    flush();
                    spriteTex = ids[ti];
                }
                int from = m.runStart[r], to = r + 1 < m.runStart.length ? m.runStart[r + 1] : m.count;
                for (int v = from; v < to; ) {
                    int room = SPRITE_MAX - spriteCount;
                    if (room < 3) {
                        flush();
                        room = SPRITE_MAX;
                    }
                    int take = Math.min(to - v, room - room % 3);
                    int o = spriteCount * SPRITE_INTS;
                    for (int k = 0; k < take; k++, v++, o += SPRITE_INTS) {
                        float x = xy[v * 2], y = xy[v * 2 + 1];
                        sv[o] = Float.floatToRawIntBits(q.ox + q.rx * x - q.ux * y);
                        sv[o + 1] = Float.floatToRawIntBits(q.oy + q.ry * x - q.uy * y);
                        sv[o + 2] = Float.floatToRawIntBits(q.oz + q.rz * x - q.uz * y);
                        sv[o + 3] = Float.floatToRawIntBits(uv[v * 2]);
                        sv[o + 4] = Float.floatToRawIntBits(uv[v * 2 + 1]);
                        int c = mulv[v];
                        if (!white) {
                            c = (((c & 255) * ir) >> 8) | ((((c >> 8) & 255) * ig) >> 8 << 8) | ((((c >> 16) & 255) * ib) >> 8 << 16)
                                    | ((((c >>> 24) * ia) >> 8) << 24);
                        }
                        sv[o + 5] = c;
                        sv[o + 6] = addv[v] | forceAdd;
                    }
                    spriteCount += take;
                }
            }
        }
        if (any) flush();
    }

    private void flush() {
        if (spriteCount == 0 || spriteTex <= 0) {
            spriteCount = 0;
            return;
        }
        bindId(0, spriteTex);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, spriteVbo);
        spriteBuf.clear();
        spriteBuf.put(sv, 0, spriteCount * SPRITE_INTS);
        spriteBuf.position(0);
        int bytes = spriteCount * SPRITE_INTS * 4;
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, bytes, spriteBuf, GLES20.GL_STREAM_DRAW);
        array(A_POS, true);
        array(A_UV, true);
        array(A_COL, true);
        array(A_ADD, true);
        array(A_NRM, false);
        array(A_JOINT, false);
        array(A_WEIGHT, false);
        GLES20.glVertexAttribPointer(A_POS, 3, GLES20.GL_FLOAT, false, 28, 0);
        GLES20.glVertexAttribPointer(A_UV, 2, GLES20.GL_FLOAT, false, 28, 12);
        GLES20.glVertexAttribPointer(A_COL, 4, GLES20.GL_UNSIGNED_BYTE, true, 28, 20);
        GLES20.glVertexAttribPointer(A_ADD, 4, GLES20.GL_UNSIGNED_BYTE, true, 28, 24);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, spriteCount);
        draws++;
        corners += spriteCount;
        uploaded += bytes;
        spriteCount = 0;
    }

    /** uploads atlas i of a 2D file: its ASTC blocks as they are when the chip reads them, decoded otherwise */
    private int atlas(Sc2 sc, int i) {
        try {
            Img.Gpu g = sc.gpuTexture(i, files);
            if (g != null) {
                int id = astc ? compressed(g, false) : rgbaOf(SupercellFiles.decode(g), false, false);
                sc.uploaded(i);
                return id;
            }
            Img im = sc.texture(i, new ArrayList<String>());
            return im == null ? -1 : rgbaOf(im, false, false);
        } catch (Throwable e) {
            error = "atlas: " + e;
            return -1;
        }
    }

    // ------------------------------------------------------------------ buffers
    private void attribs(Buf b) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, b.id);
        array(A_POS, true);
        array(A_NRM, true);
        array(A_UV, true);
        array(A_ADD, false);
        GLES20.glVertexAttribPointer(A_POS, 3, GLES20.GL_FLOAT, false, b.stride, 0);
        GLES20.glVertexAttribPointer(A_NRM, 3, GLES20.GL_FLOAT, false, b.stride, 12);
        GLES20.glVertexAttribPointer(A_UV, 2, GLES20.GL_FLOAT, false, b.stride, 24);
        if (b.colors) {
            array(A_COL, true);
            GLES20.glVertexAttribPointer(A_COL, 4, GLES20.GL_UNSIGNED_BYTE, true, b.stride, 32);
        } else {
            array(A_COL, false);
            GLES20.glVertexAttrib4f(A_COL, 1f, 1f, 1f, 1f);
        }
        if (b.skinned) {
            array(A_JOINT, true);
            array(A_WEIGHT, true);
            GLES20.glVertexAttribPointer(A_JOINT, 4, GLES20.GL_UNSIGNED_BYTE, false, b.stride, 32);
            GLES20.glVertexAttribPointer(A_WEIGHT, 4, GLES20.GL_UNSIGNED_BYTE, true, b.stride, 36);
        } else {
            array(A_JOINT, false);
            array(A_WEIGHT, false);
        }
    }

    private void array(int index, boolean on) {
        if (arrays[index] == on) return;
        arrays[index] = on;
        if (on) GLES20.glEnableVertexAttribArray(index);
        else GLES20.glDisableVertexAttribArray(index);
    }

    static float[] normals(Model3d.Part p) {
        if (p.hasNormals && p.nrm != null) return p.nrm;
        float[] out = new float[p.triangles * 9];
        for (int t = 0; t < p.triangles; t++) {
            int i = t * 9;
            float ax = p.pos[i + 3] - p.pos[i], ay = p.pos[i + 4] - p.pos[i + 1], az = p.pos[i + 5] - p.pos[i + 2];
            float bx = p.pos[i + 6] - p.pos[i], by = p.pos[i + 7] - p.pos[i + 1], bz = p.pos[i + 8] - p.pos[i + 2];
            float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            for (int k = 0; k < 3; k++) {
                out[i + k * 3] = nx;
                out[i + k * 3 + 1] = ny;
                out[i + k * 3 + 2] = nz;
            }
        }
        if (p.nrm == null || !p.hasNormals) p.nrm = out;
        p.hasNormals = true;
        return out;
    }

    /** a part into one interleaved GPU buffer: position, normal, texture coordinates, then colours or bones */
    private Buf upload(Model3d.Part p, boolean skinned) {
        int n = p.triangles * 3;
        Buf b = new Buf();
        b.count = n;
        b.skinned = skinned;
        b.colors = !skinned && p.colors != null;
        int ints = 8 + (skinned ? 2 : b.colors ? 1 : 0);
        b.stride = ints * 4;
        int[] d = new int[n * ints];
        float[] nrm = normals(p);
        float[] uv = p.uv;
        for (int i = 0, o = 0; i < n; i++, o += ints) {
            d[o] = Float.floatToRawIntBits(p.pos[i * 3]);
            d[o + 1] = Float.floatToRawIntBits(p.pos[i * 3 + 1]);
            d[o + 2] = Float.floatToRawIntBits(p.pos[i * 3 + 2]);
            if (i * 3 + 2 < nrm.length) {
                d[o + 3] = Float.floatToRawIntBits(nrm[i * 3]);
                d[o + 4] = Float.floatToRawIntBits(nrm[i * 3 + 1]);
                d[o + 5] = Float.floatToRawIntBits(nrm[i * 3 + 2]);
            }
            if (uv != null && i * 2 + 1 < uv.length) {
                d[o + 6] = Float.floatToRawIntBits(uv[i * 2]);
                d[o + 7] = Float.floatToRawIntBits(uv[i * 2 + 1]);
            }
            if (b.colors) {
                int c = p.colors[i];
                d[o + 8] = (c & 0xFF00FF00) | ((c & 255) << 16) | ((c >> 16) & 255); // ARGB → bytes r g b a
            }
        }
        if (skinned) bones(p, b, d, ints);
        ByteBuffer bb = ByteBuffer.allocateDirect(d.length * 4).order(ByteOrder.nativeOrder());
        bb.asIntBuffer().put(d);
        bb.position(0);
        GLES20.glGenBuffers(1, one, 0);
        b.id = one[0];
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, b.id);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, d.length * 4, bb, GLES20.GL_STATIC_DRAW);
        uploaded += d.length * 4L;
        return b;
    }

    /**
     * Bone numbers and weights of every corner, in runs of triangles that together use at most {@link #maxBones}
     * joints (a brawler with more joints than the chip takes at once is drawn in a few runs). Slot 0 of each run means
     * "not moved".
     */
    private void bones(Model3d.Part p, Buf b, int[] d, int ints) {
        int n = p.triangles * 3;
        List<int[]> starts = new ArrayList<>();
        List<int[]> lists = new ArrayList<>();
        java.util.HashMap<Integer, Integer> local = new java.util.HashMap<>();
        List<Integer> globals = new ArrayList<>();
        globals.add(-1);
        int start = 0;
        int[] tj = new int[12];
        for (int t = 0; t < p.triangles; t++) {
            int fresh = 0;
            for (int i = t * 3; i < t * 3 + 3; i++) {
                for (int k = 0; k < 4; k++) {
                    if (p.weights[i * 4 + k] <= 0) continue;
                    int j = p.joints[i * 4 + k];
                    if (j < 0 || local.containsKey(j)) continue;
                    boolean seen = false;
                    for (int q = 0; q < fresh; q++) if (tj[q] == j) seen = true;
                    if (!seen) tj[fresh++] = j;
                }
            }
            if (globals.size() - 1 + fresh > maxBones && t * 3 > start) {
                starts.add(new int[]{start, t * 3 - start});
                lists.add(toArray(globals));
                local.clear();
                globals.clear();
                globals.add(-1);
                start = t * 3;
                t--; // this triangle again, in the new run
                continue;
            }
            for (int q = 0; q < fresh; q++) {
                local.put(tj[q], globals.size());
                globals.add(tj[q]);
            }
            for (int i = t * 3; i < t * 3 + 3; i++) {
                float sum = 0;
                for (int k = 0; k < 4; k++) if (p.weights[i * 4 + k] > 0 && p.joints[i * 4 + k] >= 0) sum += p.weights[i * 4 + k];
                int js = 0, ws = 0;
                if (sum <= 0) {
                    ws = 255; // slot 0, full weight: stays where it is
                } else {
                    for (int k = 0; k < 4; k++) {
                        float w = p.weights[i * 4 + k];
                        int j = p.joints[i * 4 + k];
                        if (w <= 0 || j < 0) continue;
                        Integer l = local.get(j);
                        int wb = Math.max(1, Math.min(255, Math.round(w / sum * 255)));
                        js |= (l == null ? 0 : l) << (8 * k);
                        ws |= wb << (8 * k);
                    }
                }
                d[i * ints + 8] = js;
                d[i * ints + 9] = ws;
            }
        }
        starts.add(new int[]{start, n - start});
        lists.add(toArray(globals));
        b.chunkStart = new int[starts.size()];
        b.chunkCount = new int[starts.size()];
        b.chunkJoints = new int[starts.size()][];
        for (int i = 0; i < starts.size(); i++) {
            b.chunkStart[i] = starts.get(i)[0];
            b.chunkCount[i] = starts.get(i)[1];
            b.chunkJoints[i] = lists.get(i);
        }
    }

    private static int[] toArray(List<Integer> l) {
        int[] a = new int[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    // ------------------------------------------------------------------ textures
    private void bind(int unit, Img im, boolean repeat) {
        int id = whiteTex;
        if (im != null) {
            int[] t = textures.get(im);
            if (t == null) {
                t = new int[]{texture(im, repeat), frame};
                textures.put(im, t);
            }
            t[1] = frame;
            id = t[0];
        }
        bindId(unit, id);
    }

    private void bindId(int unit, int id) {
        if (bound[unit] == id) return;
        bound[unit] = id;
        if (activeUnit != unit) {
            activeUnit = unit;
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit);
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
    }

    private int texture(Img im, boolean repeat) {
        try {
            if (im.gpu != null && astc) return compressed(im.gpu, repeat);
            if (im.argb == null && im.gpu != null) return rgbaOf(SupercellFiles.decode(im.gpu), true, repeat);
            return rgbaOf(im, true, repeat);
        } catch (Throwable e) {
            error = "texture: " + e;
            return whiteTex;
        }
    }

    private int newTexture() {
        GLES20.glGenTextures(1, one, 0);
        activeUnit = 0;
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, one[0]);
        bound[0] = one[0];
        return one[0];
    }

    private static boolean pot(int v) {
        return (v & (v - 1)) == 0;
    }

    private void params(boolean mips, boolean repeat, int w, int h) {
        boolean wrap = repeat && pot(w) && pot(h);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, mips ? GLES20.GL_LINEAR_MIPMAP_LINEAR : GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrap ? GLES20.GL_REPEAT : GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrap ? GLES20.GL_REPEAT : GLES20.GL_CLAMP_TO_EDGE);
    }

    /** ASTC blocks straight to the chip, with the mip levels the file has */
    private int compressed(Img.Gpu g, boolean repeat) {
        int id = newTexture();
        int levels = g.levels();
        // a full chain is needed for mip filtering; files have one down to 1×1
        boolean chain = levels > 1 && g.width[levels - 1] == 1 && g.height[levels - 1] == 1;
        if (!chain) levels = 1;
        for (int l = 0; l < levels; l++) {
            ByteBuffer bb = ByteBuffer.allocateDirect(g.size[l]).order(ByteOrder.nativeOrder());
            bb.put(g.data, g.offset[l], g.size[l]);
            bb.position(0);
            GLES20.glCompressedTexImage2D(GLES20.GL_TEXTURE_2D, l, g.format, g.width[l], g.height[l], 0, g.size[l], bb);
            uploaded += g.size[l];
        }
        params(chain, repeat, g.width[0], g.height[0]);
        return id;
    }

    private int rgbaOf(Img im, boolean mips, boolean repeat) {
        if (im == null || im.argb == null) return whiteTex;
        int id = rgba(im.width, im.height, im.argb, mips && pot(im.width) && pot(im.height));
        params(mips && pot(im.width) && pot(im.height), repeat, im.width, im.height);
        return id;
    }

    private int rgba(int w, int h, int[] argb, boolean mips) {
        int id = newTexture();
        ByteBuffer bb = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder());
        IntBuffer ib = bb.asIntBuffer();
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = argb[y * w + x];
                row[x] = (c & 0xFF00FF00) | ((c & 255) << 16) | ((c >> 16) & 255); // ARGB → bytes r g b a
            }
            ib.put(row);
        }
        bb.position(0);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, bb);
        uploaded += w * h * 4L;
        if (mips) GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, mips ? GLES20.GL_LINEAR_MIPMAP_LINEAR : GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        return id;
    }

    private void use(Prog p) {
        if (curProg == p.id) return;
        curProg = p.id;
        GLES20.glUseProgram(p.id);
    }

    /** frees GPU buffers and textures not used for a while (rebuilt map chunks, pictures of effects that ended) */
    private void sweep() {
        Iterator<Map.Entry<Model3d.Part, Buf>> it = buffers.entrySet().iterator();
        while (it.hasNext()) {
            Buf b = it.next().getValue();
            if (frame - b.lastFrame < 900) continue;
            one[0] = b.id;
            GLES20.glDeleteBuffers(1, one, 0);
            it.remove();
        }
        if (textures.size() > 160) {
            Iterator<Map.Entry<Img, int[]>> ti = textures.entrySet().iterator();
            while (ti.hasNext()) {
                int[] t = ti.next().getValue();
                if (frame - t[1] < 900 || t[0] == whiteTex) continue;
                GLES20.glDeleteTextures(1, t, 0);
                ti.remove();
            }
            java.util.Arrays.fill(bound, -1);
        }
    }

    // ------------------------------------------------------------------ matrices (column-major, into given arrays)
    static void mul(float[] a, float[] b, float[] o) {
        for (int c = 0; c < 4; c++) {
            float b0 = b[c * 4], b1 = b[c * 4 + 1], b2 = b[c * 4 + 2], b3 = b[c * 4 + 3];
            o[c * 4] = a[0] * b0 + a[4] * b1 + a[8] * b2 + a[12] * b3;
            o[c * 4 + 1] = a[1] * b0 + a[5] * b1 + a[9] * b2 + a[13] * b3;
            o[c * 4 + 2] = a[2] * b0 + a[6] * b1 + a[10] * b2 + a[14] * b3;
            o[c * 4 + 3] = a[3] * b0 + a[7] * b1 + a[11] * b2 + a[15] * b3;
        }
    }

    static void projection(Scene3d s, float aspect, float[] m) {
        float f = (float) (1 / Math.tan(Math.toRadians(s.fovY) / 2));
        java.util.Arrays.fill(m, 0f);
        m[0] = f / aspect;
        m[5] = f;
        m[10] = (s.far + s.near) / (s.near - s.far);
        m[11] = -1;
        m[14] = 2 * s.far * s.near / (s.near - s.far);
    }
}
