package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The game's music (music.csv: menu themes, battle tracks, jingles, with the locations that play them) and
 * sounds (sounds.csv), sorted into groups: each brawler's voice lines, each brawler's other sounds, interface,
 * battle and effects.
 */
public final class SoundLib {

    public static final class Track {
        public String name, title, file, group;
        public boolean background, loop;
        /** locations / themes that play it */
        public final List<String> usedBy = new ArrayList<>();
    }

    public static final class Sound {
        public String name, title, group, brawler;
        public final List<String> files = new ArrayList<>();
    }

    public static final String[] MUSIC_GROUPS = {"Меню", "В бою", "Победа, поражение и голы", "Другое"};

    /** every track of music.csv (one per file), and loose music files the table does not name */
    public static List<Track> music(GameDb db, Set<String> filesInArchive) {
        List<Track> out = new ArrayList<>();
        GameDb.Table t = db.table("music.csv");
        Map<String, List<String>> used = new HashMap<>();
        GameDb.Table th = db.table("location_themes.csv");
        for (String[] r : th.rows) {
            String m = th.get(r, "Music");
            if (!m.isEmpty() && r.length > 0 && !r[0].isEmpty()) used.computeIfAbsent(m, k -> new ArrayList<>()).add(GameDb.nice(r[0]));
        }
        String name = "";
        boolean loop = false;
        Set<String> seen = new HashSet<>();
        for (String[] r : t.rows) {
            if (r.length == 0) continue;
            if (!t.get(r, "Name").isEmpty()) {
                name = t.get(r, "Name");
                loop = "true".equalsIgnoreCase(t.get(r, "Loop"));
            }
            String f = t.get(r, "FileName");
            if (f.isEmpty() || !seen.add(f)) continue;
            Track k = new Track();
            k.name = name;
            k.file = GameDb.fileName(f);
            k.title = musicTitle(name);
            k.background = t.flag(r, "BackgroundFile");
            k.loop = loop || "true".equalsIgnoreCase(t.get(r, "Loop"));
            k.group = musicGroup(name);
            List<String> u = used.get(name);
            if (u != null) k.usedBy.addAll(u);
            out.add(k);
        }
        if (filesInArchive != null) {
            Set<String> known = new HashSet<>();
            for (Track k : out) known.add(k.file.toLowerCase(Locale.ROOT));
            for (String f : filesInArchive) {
                if (known.contains(f.toLowerCase(Locale.ROOT))) continue;
                Track k = new Track();
                k.name = f;
                k.file = f;
                k.title = musicTitle(f.replaceAll("\\.[a-z0-9]+$", ""));
                k.group = "Другое";
                out.add(k);
            }
        }
        return out;
    }

    static String musicGroup(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.contains("win") || n.contains("lose") || n.contains("draw") || n.contains("jingle") || n.contains("goal") || n.contains("panic")) return MUSIC_GROUPS[2];
        if (n.contains("menu") || n.contains("lobby") || n.contains("shop")) return MUSIC_GROUPS[0];
        if (n.contains("ingame") || n.contains("battle") || n.contains("boss") || n.contains("level") || n.contains("brawl")) return MUSIC_GROUPS[1];
        return MUSIC_GROUPS[3];
    }

    /** "Footbrawl_ingame_muzak" → "Footbrawl · в бою" */
    public static String musicTitle(String name) {
        if (name == null || name.isEmpty()) return "Без названия";
        String n = name.replace('-', '_');
        List<String> words = new ArrayList<>();
        String tag = "";
        for (String w : n.split("_+")) {
            String l = w.toLowerCase(Locale.ROOT);
            if (l.isEmpty() || l.equals("muzak") || l.equals("music") || l.equals("nusic") || l.matches("0\\d")) continue;
            if (l.equals("ingame") || l.equals("battle")) tag = "в бою";
            else if (l.equals("menu")) tag = "меню";
            else if (l.equals("jingle")) tag = "джингл";
            else if (l.equals("loop")) tag = tag.isEmpty() ? "петля" : tag;
            else words.add(Character.toUpperCase(w.charAt(0)) + w.substring(1));
        }
        String base = words.isEmpty() ? name : String.join(" ", words);
        if (base.equals("BattleMusic") || base.equals("Battle")) base = "Бой";
        if (base.equals("MenuMusic")) base = "Главное меню";
        return tag.isEmpty() ? base : base + " · " + tag;
    }

    // ------------------------------------------------------------------ sounds
    public static final String VOICE = "Реплики · ", BRAWLER = "Звуки · ", UI = "Интерфейс", BATTLE = "Бой и эффекты";

    static final String[] UI_WORDS = {"menu", "button", "click", "popup", "shop", "reward", "box", "unlock", "achiev", "ui_", "tab", "scroll",
            "purchase", "claim", "trophy", "rank", "pass", "quest", "chest", "mega", "starr", "notification", "coin", "gem_", "token", "level_up", "upgrade"};

    /** every sounds.csv entry with its files and group */
    public static List<Sound> sounds(GameDb db) {
        // voice lines: characters.csv and skin_confs.csv VO columns
        Map<String, String> voiceOf = new HashMap<>(), voiceTitle = new HashMap<>();
        GameDb.Table ch = db.table("characters.csv"), confs = db.table("skin_confs.csv");
        Map<String, String> brawlerName = new HashMap<>();
        Map<String, String> prefixes = new LinkedHashMap<>();
        List<GameDb.Brawler> order = new ArrayList<>(db.brawlers());
        order.sort((x, y) -> Boolean.compare(x.hidden, y.hidden)); // real brawlers claim their lines before hidden copies
        for (GameDb.Brawler b : order) {
            brawlerName.put(b.code, b.name.replace(" (скрыт)", ""));
            for (Map.Entry<String, String> v : b.voice.entrySet()) {
                voiceOf.putIfAbsent(v.getValue(), b.code);
                voiceTitle.putIfAbsent(v.getValue(), v.getKey());
            }
            for (GameDb.Skin s : b.skins) {
                for (Map.Entry<String, String> v : s.voice.entrySet()) {
                    voiceOf.putIfAbsent(v.getValue(), b.code);
                    voiceTitle.putIfAbsent(v.getValue(), v.getKey() + (s.name.equals(b.defaultSkin) ? "" : " · " + s.title));
                }
            }
            if (b.item != null && b.item.length() >= 2 && !b.hidden) prefixes.putIfAbsent(b.item.toLowerCase(Locale.ROOT), b.code);
            prefixes.putIfAbsent(b.code.toLowerCase(Locale.ROOT), b.code);
        }
        List<Sound> out = new ArrayList<>();
        for (String n : db.soundNames()) {
            Sound s = new Sound();
            s.name = n;
            s.files.addAll(db.soundFiles(n));
            if (s.files.isEmpty()) continue;
            String l = n.toLowerCase(Locale.ROOT);
            String who = voiceOf.get(n);
            if (who != null) {
                s.brawler = who;
                s.group = VOICE + brawlerName.get(who);
                s.title = voiceTitle.get(n) + "  ·  " + n;
            } else {
                for (Map.Entry<String, String> p : prefixes.entrySet()) {
                    String k = p.getKey();
                    boolean byName = k.length() >= 3 ? l.startsWith(k) : l.startsWith(k + "_");
                    if (byName || s.files.get(0).toLowerCase(Locale.ROOT).startsWith(k + "_")) {
                        s.brawler = p.getValue();
                        break;
                    }
                }
                s.title = n;
                if (s.brawler != null) s.group = BRAWLER + brawlerName.get(s.brawler);
                else {
                    s.group = BATTLE;
                    for (String w : UI_WORDS) if (l.contains(w)) s.group = UI;
                }
            }
            out.add(s);
        }
        return out;
    }
}
