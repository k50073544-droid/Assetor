package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.weker.assetexplorer.codec.GameDb;
import com.weker.assetexplorer.codec.MapPlan;
import com.weker.assetexplorer.codec.MapScene;
import com.weker.assetexplorer.codec.Scene3d;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * One map: the plan from above (pinch to zoom) and the map in 3D in its location's theme —
 * drag to turn around it, pinch to come closer, two fingers to move, double tap to see it whole.
 */
public final class MapViewActivity extends Activity implements GLSurfaceView.Renderer {

    private final Handler main = new Handler(Looper.getMainLooper());
    private GameData gd;
    private MapPlan.Entry entry;
    private GameDb.MapData map;
    private ZoomImageView plan;
    private GLSurfaceView gl;
    private final GlScene glScene = new GlScene();
    private volatile MapScene scene;
    private TextView status, toggle;
    private boolean show3d;
    private long vid;
    /** another location theme put on this map (null = its own) */
    private String theme;
    private TextView titleSub;
    private final Object lock = new Object();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        String loc = getIntent().getStringExtra("location");
        gd = GameData.get(this, vid);
        for (java.util.List<MapPlan.Entry> l : MapPlan.byMode(gd.db).values()) for (MapPlan.Entry e : l) if (e.location.equals(loc)) entry = e;
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(p, p, p, Ui.dp(this, 6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(Ui.bold(this, entry == null ? loc : entry.title, 18, Ui.TEXT));
        titleSub = Ui.text(this, "", 12, Ui.MUTED);
        titles.addView(titleSub);
        subtitle();
        top.addView(titles, Ui.lp(0, -2, 1));
        TextView env = Ui.button(this, "Окружение", false);
        env.setOnClickListener(v -> pickTheme());
        LinearLayout.LayoutParams el = Ui.lp(-2, -2, 0);
        el.rightMargin = Ui.dp(this, 6);
        top.addView(env, el);
        TextView legend = Ui.button(this, "?", false);
        legend.setOnClickListener(v -> legend());
        top.addView(legend);
        toggle = Ui.button(this, "3D", true);
        toggle.setOnClickListener(v -> setMode(!show3d));
        LinearLayout.LayoutParams tl = Ui.lp(-2, -2, 0);
        tl.leftMargin = Ui.dp(this, 8);
        top.addView(toggle, tl);
        root.addView(top);
        FrameLayout box = new FrameLayout(this);
        plan = new ZoomImageView(this);
        box.addView(plan, new FrameLayout.LayoutParams(-1, -1));
        gl = new Orbit();
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(new GlModelView.Chooser());
        gl.setRenderer(this);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        gl.setVisibility(View.GONE);
        box.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        status = Ui.text(this, "", 14, Ui.TEXT);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0x99000000);
        status.setPadding(p, p, p, p);
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        box.addView(status, sl);
        status.setVisibility(View.GONE);
        root.addView(box, Ui.lp(-1, 0, 1));
        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(p, Ui.dp(this, 4), p, Ui.dp(this, 8));
        TextView hint = Ui.text(this, "2D: щипок — увеличить. 3D: тяни — вращать, щипок — ближе, два пальца — двигать, двойной тап — вся карта.", 11, Ui.MUTED);
        bottom.addView(hint, Ui.lp(0, -2, 1));
        TextView play = Ui.button(this, "🎮 Играть", true);
        play.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(this, PlayActivity.class);
            i.putExtra("vid", vid);
            if (entry != null) i.putExtra("location", entry.location);
            if (theme != null) i.putExtra("theme", theme);
            startActivity(i);
        });
        bottom.addView(play);
        root.addView(bottom);
        setContentView(root);
        if (entry == null) {
            status.setVisibility(View.VISIBLE);
            status.setText("Карта не найдена");
            return;
        }
        new Thread(() -> {
            GameDb.MapData m = gd.db.map(entry.map);
            if (m != null) m.theme = entry.theme;
            Bitmap bm = m == null ? null : MapsActivity.plan(gd, entry, 1400);
            main.post(() -> {
                map = m;
                if (bm != null) plan.setBitmap(bm);
            });
        }).start();
    }

    private void setMode(boolean three) {
        show3d = three;
        toggle.setText(three ? "2D" : "3D");
        plan.setVisibility(three ? View.GONE : View.VISIBLE);
        gl.setVisibility(three ? View.VISIBLE : View.GONE);
        if (three && scene == null) load3d();
        else if (three) gl.requestRender();
        if (!three) status.setVisibility(View.GONE);
    }

    private void load3d() {
        status.setVisibility(View.VISIBLE);
        status.setText("Загружаю модели темы «" + GameDb.nice(entry.theme) + "»…");
        new Thread(() -> {
            String err = null;
            MapScene s = null;
            try {
                GameDb.MapData m = map != null ? map : gd.db.map(entry.map);
                if (m != null) m.theme = theme != null ? theme : entry.theme;
                s = new MapScene(m, gd.assets, entry.mode);
            } catch (Throwable e) {
                err = e.toString();
            }
            MapScene fs = s;
            String fe = err;
            main.post(() -> {
                if (fs == null) {
                    status.setText("Не получилось: " + fe);
                    return;
                }
                scene = fs;
                status.setVisibility(View.GONE);
                gl.requestRender();
            });
        }, "map3d").start();
    }

    private void subtitle() {
        if (entry == null) return;
        titleSub.setText(entry.modeTitle + " · окружение: " + GameDb.nice(theme != null ? theme : entry.theme) + (entry.disabled ? " · скрыта" : ""));
    }

    /** put another location's look on this map */
    private void pickTheme() {
        java.util.List<String[]> th = MapScene.themes(gd.db);
        String[] n = new String[th.size() + 1];
        n[0] = "Как в игре";
        for (int i = 0; i < th.size(); i++) n[i + 1] = th.get(i)[1];
        new AlertDialog.Builder(this).setTitle("Окружение").setItems(n, (d, w) -> {
            theme = w == 0 ? null : th.get(w - 1)[0];
            subtitle();
            scene = null;
            if (show3d) load3d();
            else setMode(true);
        }).show();
    }

    private void legend() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        l.setPadding(p, p / 2, p, p / 2);
        for (String[] it : MapPlan.LEGEND) {
            char c = it[0].charAt(0);
            int col = MapPlan.markColor(c) != 0 ? MapPlan.markColor(c) : MapPlan.tileColor(c);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            View sw = new View(this);
            sw.setBackground(Ui.round(col, MapPlan.markColor(c) != 0 ? Ui.dp(this, 9) : Ui.dp(this, 3)));
            row.addView(sw, Ui.lp(Ui.dp(this, 18), Ui.dp(this, 18), 0));
            TextView t = Ui.text(this, "   " + it[1], 15, 0xFF222222);
            row.addView(t);
            l.addView(row);
        }
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("Обозначения").setView(sv).setPositiveButton("Ок", null).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
    }

    // ------------------------------------------------------------------ GL thread
    @Override
    public void onSurfaceCreated(GL10 g, EGLConfig config) {
        try {
            glScene.init();
        } catch (RuntimeException e) {
            main.post(() -> {
                status.setVisibility(View.VISIBLE);
                status.setText("OpenGL ES 2.0 недоступен: " + e.getMessage());
            });
        }
    }

    @Override
    public void onSurfaceChanged(GL10 g, int w, int h) {
        glScene.resize(w, h);
    }

    @Override
    public void onDrawFrame(GL10 g) {
        MapScene s = scene;
        Scene3d sc;
        synchronized (lock) {
            sc = s == null ? new Scene3d() : s.build(glScene.width / (float) Math.max(1, glScene.height));
        }
        if (s == null) sc.background = Ui.BG;
        glScene.draw(sc);
    }

    // ------------------------------------------------------------------ touch: orbit, zoom, move
    final class Orbit extends GLSurfaceView {
        float lastX, lastY;
        long lastTap;
        boolean moved;
        final ScaleGestureDetector pinch;

        Orbit() {
            super(MapViewActivity.this);
            pinch = new ScaleGestureDetector(MapViewActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    MapScene s = scene;
                    if (s == null) return true;
                    synchronized (lock) {
                        s.dist = Math.max(4f, Math.min(s.dist / d.getScaleFactor(), 200f));
                    }
                    requestRender();
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            pinch.onTouchEvent(e);
            MapScene s = scene;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX();
                    lastY = e.getY();
                    moved = false;
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                case MotionEvent.ACTION_POINTER_UP:
                    lastX = SoftModelView.avgX(e);
                    lastY = SoftModelView.avgY(e);
                    moved = true;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float x = SoftModelView.avgX(e), y = SoftModelView.avgY(e);
                    float dx = x - lastX, dy = y - lastY;
                    lastX = x;
                    lastY = y;
                    if (Math.abs(dx) + Math.abs(dy) > 2) moved = true;
                    if (s == null) break;
                    synchronized (lock) {
                        if (e.getPointerCount() >= 2) {
                            float k = s.dist / Math.max(1, getHeight()) * 1.2f;
                            float c = (float) Math.cos(s.yaw), sn = (float) Math.sin(s.yaw);
                            s.cx -= (dx * c - dy * sn) * k;
                            s.cz -= (dx * sn + dy * c) * k;
                            s.cx = Math.max(-4, Math.min(s.map.width + 4, s.cx));
                            s.cz = Math.max(-4, Math.min(s.map.height + 4, s.cz));
                        } else if (!pinch.isInProgress()) {
                            float r = (float) (Math.PI / Math.max(1, getWidth()));
                            s.yaw -= dx * r;
                            s.pitch = Math.max(0.25f, Math.min(1.55f, s.pitch + dy * r));
                        }
                    }
                    requestRender();
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    long now = System.currentTimeMillis();
                    if (!moved) {
                        if (now - lastTap < 300 && s != null) {
                            synchronized (lock) {
                                s.yaw = 0;
                                s.pitch = 0.95f;
                                s.dist = -1;
                                s.cx = s.map.width / 2f;
                                s.cz = s.map.height / 2f;
                            }
                            requestRender();
                        }
                        lastTap = now;
                    }
                    break;
                }
                default:
                    break;
            }
            return true;
        }
    }
}
