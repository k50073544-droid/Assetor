package com.weker.assetexplorer.codec;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Puts all pieces of one ability on one stage and plays them as the game would:
 * the shot starts at the brawler (left), the projectile and its trails fly to the right,
 * hits / explosions / zones appear where it lands. Abilities without a projectile
 * (Ziggy's storm, teleports…) play all pieces at one point, aim warnings first.
 * All pieces use one common scale, so their sizes compare like in the game.
 */
public final class Scene {

    public static final class Item {
        public final Sc2 sc;
        public final String export, label;
        public final int phase;
        float[] ub;
        int frames, fps;
        // layout
        double startX, startY, endX, endY; // world position of the export's origin (start -> end when flying)
        double t0, t1;                      // seconds; t1 = when it disappears
        boolean moving, loop;
        /** -1 = in every shot, otherwise the index of the outcome round it belongs to */
        int round = -1;
        public boolean defaultOn = true;

        public Item(Sc2 sc, String export, int phase, String label) {
            this.sc = sc;
            this.export = export;
            this.phase = phase;
            this.label = label;
        }
    }

    public static final double FLY_TIME = 0.7, MAX_LEN = 6.0, TAIL = 0.25;

    /** One shot with one outcome: hit a brawler, hit a wall, reach max range. */
    public static final class Round {
        public final String name;
        public final int kind;
        double start, len;

        Round(String name, int kind) {
            this.name = name;
            this.kind = kind;
        }
    }

    public static final int R_ALL = 0, R_HIT = 1, R_WALL = 2, R_RANGE = 3;

    public final List<Item> items = new ArrayList<>();
    public final List<Round> rounds = new ArrayList<>();
    public boolean hasFly;
    public double length;
    /** stage in world units: minX, minY, maxX, maxY */
    public double[] stage;
    public double launchX, targetX;
    private final Map<Item, Map<Integer, Img>> cache = new HashMap<>();
    private double cachedScale = -1;

    public Scene(List<Item> parts) throws IOException {
        for (Item it : parts) {
            it.ub = it.sc.unionBounds(it.export);
            if (it.ub == null) continue; // draws nothing
            it.frames = Math.max(1, it.sc.frameCount(it.export));
            it.fps = it.sc.fps(it.export);
            items.add(it);
        }
        layout();
    }

    double dur(Item it) {
        return it.frames / (double) it.fps;
    }

    private void layout() {
        double flyW = 0;
        double hitW = 0;
        for (Item it : items) {
            double w = it.ub[2] - it.ub[0];
            if (it.phase == BrawlerIndex.P_FLY) {
                hasFly = true;
                flyW = Math.max(flyW, w);
            } else {
                hitW = Math.max(hitW, w);
            }
        }
        launchX = 0;
        // far enough that the flight is visible, but the hit still fits next to the brawler
        targetX = hasFly ? Math.max(160, Math.max(flyW * 2.5, hitW)) : 0;
        double warnLen = 0;
        for (Item it : items) if (it.phase == BrawlerIndex.P_WARN) warnLen = Math.max(warnLen, Math.min(1.0, dur(it)));

        // outcomes of a shot are alternatives in the game, so each gets its own shot
        if (hasFly) {
            boolean hit = false, wall = false, range = false;
            for (Item it : items) {
                if (it.phase == BrawlerIndex.P_FLY || it.phase == BrawlerIndex.P_START || it.phase == BrawlerIndex.P_WARN) continue;
                int k = outcome(it);
                hit |= k == R_HIT;
                wall |= k == R_WALL;
                range |= k == R_RANGE;
            }
            if (hit) rounds.add(new Round("попадание по бойцу", R_HIT));
            if (wall) rounds.add(new Round("попадание в стену", R_WALL));
            if (range) rounds.add(new Round("предел дальности (никого не задел)", R_RANGE));
        }
        if (rounds.isEmpty()) rounds.add(new Round(hasFly ? "выстрел" : "", R_ALL));

        for (Item it : items) {
            double d = Math.min(dur(it), MAX_LEN);
            it.startY = it.endY = 0;
            if (hasFly) {
                switch (it.phase) {
                    case BrawlerIndex.P_WARN:
                        place(it, targetX, 0, d);
                        break;
                    case BrawlerIndex.P_START:
                        place(it, launchX, 0, d);
                        break;
                    case BrawlerIndex.P_FLY:
                        it.startX = launchX;
                        it.endX = targetX;
                        it.t0 = 0;
                        it.t1 = FLY_TIME;
                        it.moving = true;
                        it.loop = true;
                        break;
                    default:
                        place(it, targetX, FLY_TIME, d);
                        int k = outcome(it);
                        for (int r = 0; r < rounds.size(); r++) if (rounds.get(r).kind == k) it.round = r;
                        if (it.round < 0) it.round = 0;
                        break;
                }
            } else {
                place(it, 0, it.phase == BrawlerIndex.P_WARN ? 0 : warnLen, d);
            }
        }
        // numbered alternatives of the same outcome (reached_01 / reached_02): only the first is on by default
        Map<String, Boolean> seen = new HashMap<>();
        for (Item it : items) {
            if (!hasFly || it.round < 0) continue; // several bolts / bones of one super play together
            String base = it.export.replaceAll("_(\\d+)(?=(_red|_flip)*$)", "#");
            if (base.equals(it.export)) continue;
            if (seen.containsKey(base)) it.defaultOn = false;
            else seen.put(base, true);
        }
        double t = 0;
        for (int r = 0; r < rounds.size(); r++) {
            Round rd = rounds.get(r);
            double len = 0;
            for (Item it : items) if (it.round == -1 || it.round == r) len = Math.max(len, Math.min(it.t1, MAX_LEN));
            rd.start = t;
            rd.len = len + TAIL;
            t += rd.len;
        }
        length = t;

        double[] s = {Double.MAX_VALUE, Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE};
        for (Item it : items) {
            grow(s, it.startX, it.startY, it.ub);
            grow(s, it.endX, it.endY, it.ub);
        }
        if (hasFly) { // room for the brawler and target markers
            grow(s, launchX, 0, new float[]{-MARK, -MARK, MARK, MARK});
            grow(s, targetX, 0, new float[]{-MARK, -MARK, MARK, MARK});
        }
        stage = s;
    }

    static final float MARK = 24;

    /** which outcome a hit-phase piece shows */
    static int outcome(Item it) {
        String e = it.export.toLowerCase(java.util.Locale.ROOT);
        if (e.contains("_env") || e.contains("wall")) return R_WALL;
        if (e.contains("reached") || e.contains("maxrange") || e.contains("_range")) return R_RANGE;
        return R_HIT;
    }

    public boolean[] defaults() {
        boolean[] b = new boolean[items.size()];
        for (int i = 0; i < b.length; i++) b[i] = items.get(i).defaultOn && !items.get(i).export.toLowerCase(java.util.Locale.ROOT).contains("flip");
        return b;
    }

    public Round roundAt(double t) {
        for (Round r : rounds) if (t >= r.start && t < r.start + r.len) return r;
        return rounds.get(rounds.size() - 1);
    }

    private static void place(Item it, double x, double t0, double d) {
        it.startX = it.endX = x;
        it.t0 = t0;
        it.t1 = t0 + d;
    }

    private static void grow(double[] s, double x, double y, float[] ub) {
        s[0] = Math.min(s[0], x + ub[0]);
        s[1] = Math.min(s[1], y + ub[1]);
        s[2] = Math.max(s[2], x + ub[2]);
        s[3] = Math.max(s[3], y + ub[3]);
    }

    /** pixels per world unit so the longest side of the stage is maxSide */
    public double scaleFor(int maxSide) {
        double w = stage[2] - stage[0], h = stage[3] - stage[1];
        return maxSide / Math.max(1e-3, Math.max(w, h));
    }

    public int width(double scale) { return Math.max(1, (int) Math.ceil((stage[2] - stage[0]) * scale)); }

    public int height(double scale) { return Math.max(1, (int) Math.ceil((stage[3] - stage[1]) * scale)); }

    public int frameCount(int fps) { return Math.max(1, (int) Math.round(length * fps)); }

    /**
     * Renders the stage at time t.
     *
     * @param background ARGB colour, 0 = transparent
     * @param markers    draw the brawler (left) and the target (right) when the ability flies
     * @param enabled    which items to draw (null = all)
     */
    public synchronized Img render(double t, double scale, int ss, int background, boolean markers, boolean[] enabled) throws IOException {
        if (scale != cachedScale) {
            cache.clear();
            cachedScale = scale;
        }
        int w = width(scale), h = height(scale);
        int[] px = new int[w * h];
        if (background != 0) java.util.Arrays.fill(px, background);
        Round rd = roundAt(t);
        int ri = rounds.indexOf(rd);
        double lt = t - rd.start;
        if (markers && hasFly) {
            int y = (int) Math.round((0 - stage[1]) * scale);
            int r = Math.max(5, (int) Math.round(MARK * 0.75 * scale));
            int tx = (int) Math.round((targetX - stage[0]) * scale);
            disc(px, w, h, (int) Math.round((launchX - stage[0]) * scale), y, r, 0x664FC3F7);
            if (rd.kind == R_WALL) box(px, w, h, tx + r / 2, y, r, 0x99A1887F);
            else if (rd.kind != R_RANGE) ring(px, w, h, tx, y, r, Math.max(2, r / 5), 0x99FF6B6B);
        }
        for (int i = 0; i < items.size(); i++) {
            if (enabled != null && i < enabled.length && !enabled[i]) continue;
            Item it = items.get(i);
            if (it.round != -1 && it.round != ri) continue;
            if (lt < it.t0 || lt >= it.t1) continue;
            double local = lt - it.t0;
            int f = (int) Math.floor(local * it.fps);
            f = it.loop ? Math.floorMod(f, it.frames) : Math.min(it.frames - 1, f);
            Img im = frame(it, f, scale, ss);
            if (im == null) continue;
            double k = it.moving ? Math.min(1, local / Math.max(1e-3, it.t1 - it.t0)) : 0;
            double ox = it.startX + (it.endX - it.startX) * k, oy = it.startY + (it.endY - it.startY) * k;
            int dx = (int) Math.round((ox + it.ub[0] - stage[0]) * scale);
            int dy = (int) Math.round((oy + it.ub[1] - stage[1]) * scale);
            over(px, w, h, im, dx, dy);
        }
        return new Img(w, h, px);
    }

    private Img frame(Item it, int f, double scale, int ss) throws IOException {
        // only looping pieces (projectiles, trails) repeat frames; caching the rest would just fill memory
        Map<Integer, Img> m = it.loop ? cache.get(it) : null;
        if (it.loop && m == null) cache.put(it, m = new HashMap<>());
        if (m != null) {
            Img im = m.get(f);
            if (im != null || m.containsKey(f)) return im;
        }
        double side = Math.max(it.ub[2] - it.ub[0], it.ub[3] - it.ub[1]) * scale;
        Img im = side < 1 ? null : it.sc.renderFrame(it.export, f, it.ub, (int) Math.ceil(side), ss);
        if (m != null) m.put(f, im);
        return im;
    }

    public synchronized void clearCache() {
        cache.clear();
    }

    /** source-over of non-premultiplied ARGB */
    static void over(int[] dst, int w, int h, Img src, int dx, int dy) {
        for (int y = 0; y < src.height; y++) {
            int ty = y + dy;
            if (ty < 0 || ty >= h) continue;
            for (int x = 0; x < src.width; x++) {
                int tx = x + dx;
                if (tx < 0 || tx >= w) continue;
                int s = src.argb[y * src.width + x];
                int sa = s >>> 24;
                if (sa == 0) continue;
                int o = ty * w + tx;
                if (sa == 255) {
                    dst[o] = s;
                    continue;
                }
                dst[o] = blend(dst[o], s);
            }
        }
    }

    static int blend(int d, int s) {
        float sa = (s >>> 24) / 255f, da = (d >>> 24) / 255f;
        float oa = sa + da * (1 - sa);
        if (oa <= 0) return 0;
        float r = (((s >> 16) & 255) * sa + ((d >> 16) & 255) * da * (1 - sa)) / oa;
        float g = (((s >> 8) & 255) * sa + ((d >> 8) & 255) * da * (1 - sa)) / oa;
        float b = ((s & 255) * sa + (d & 255) * da * (1 - sa)) / oa;
        return (Math.round(oa * 255) << 24) | (Math.round(r) << 16) | (Math.round(g) << 8) | Math.round(b);
    }

    static void disc(int[] px, int w, int h, int cx, int cy, int r, int color) {
        for (int y = cy - r; y <= cy + r; y++) {
            for (int x = cx - r; x <= cx + r; x++) {
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                int dx = x - cx, dy = y - cy;
                if (dx * dx + dy * dy <= r * r) px[y * w + x] = blend(px[y * w + x], color);
            }
        }
    }

    static void box(int[] px, int w, int h, int cx, int cy, int r, int color) {
        for (int y = cy - r; y <= cy + r; y++) {
            for (int x = cx - r / 2; x <= cx + r / 2; x++) {
                if (x >= 0 && y >= 0 && x < w && y < h) px[y * w + x] = blend(px[y * w + x], color);
            }
        }
    }

    static void ring(int[] px, int w, int h, int cx, int cy, int r, int t, int color) {
        int in = (r - t) * (r - t);
        for (int y = cy - r; y <= cy + r; y++) {
            for (int x = cx - r; x <= cx + r; x++) {
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                int dx = x - cx, dy = y - cy, d = dx * dx + dy * dy;
                if (d <= r * r && d >= in) px[y * w + x] = blend(px[y * w + x], color);
            }
        }
    }

    /** When each piece shows up, for the legend under the scene. */
    public String timing(Item it) {
        String r = it.round >= 0 && rounds.size() > 1 ? " · " + rounds.get(it.round).name : "";
        return String.format(java.util.Locale.ROOT, "%.2f–%.2f c", it.t0, Math.min(it.t1, MAX_LEN)) + r;
    }
}
