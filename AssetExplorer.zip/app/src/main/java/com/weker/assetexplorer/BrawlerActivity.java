package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.weker.assetexplorer.codec.BrawlerIndex;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Sc2;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One brawler: skins, team colour and every ability with its 2D pieces. */
public final class BrawlerActivity extends Activity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private ExecutorService thumbs = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(16 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) { return b.getByteCount() / 1024; }
    };
    private long vid;
    private String key;
    private BrawlerData data;
    private BrawlerIndex.Brawler brawler;
    private String skin;
    private boolean red;
    private LinearLayout skinRow, list;
    private TextView blueChip, redChip, status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        key = getIntent().getStringExtra("key");
        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        TextView title = Ui.bold(this, BrawlerIndex.displayName(key == null ? "" : key), 20, Ui.TEXT);
        root.addView(title);
        status = Ui.text(this, "Загружаю…", 12, Ui.MUTED);
        status.setPadding(0, Ui.dp(this, 4), 0, 0);
        root.addView(status);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        skinRow = new LinearLayout(this);
        hs.addView(skinRow);
        hs.setPadding(0, Ui.dp(this, 8), 0, 0);
        root.addView(hs);

        LinearLayout team = new LinearLayout(this);
        team.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        blueChip = Ui.chip(this, "Синие (свои)");
        redChip = Ui.chip(this, "Красные (враги)");
        blueChip.setOnClickListener(v -> setTeam(false));
        redChip.setOnClickListener(v -> setTeam(true));
        team.addView(blueChip);
        team.addView(redChip);
        root.addView(team);

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 0, 0, Ui.dp(this, 16));
        sv.addView(list);
        root.addView(sv, Ui.lp(-1, 0, 1));
        setContentView(root);

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                BrawlerData d = BrawlerData.load(this, vid, t -> main.post(() -> status.setText(t)));
                main.post(() -> {
                    data = d;
                    brawler = d.index.brawlers.get(key);
                    if (brawler == null) {
                        status.setText("Боец не найден");
                        return;
                    }
                    title.setText(brawler.name);
                    skin = brawler.defaultSkin();
                    fillSkins();
                    setTeam(false);
                });
            } catch (Throwable e) {
                main.post(() -> status.setText("Не получилось: " + e.getMessage()));
            }
        });
    }

    private void fillSkins() {
        skinRow.removeAllViews();
        for (String s : brawler.skinList()) {
            TextView c = Ui.chip(this, BrawlerIndex.skinName(s));
            c.setTag(s);
            c.setOnClickListener(v -> {
                skin = s;
                updateSkinChips();
                rebuild();
            });
            skinRow.addView(c);
        }
        updateSkinChips();
    }

    private void updateSkinChips() {
        for (int i = 0; i < skinRow.getChildCount(); i++) {
            TextView t = (TextView) skinRow.getChildAt(i);
            Ui.setChip(this, t, t.getTag().equals(skin));
        }
    }

    private void setTeam(boolean r) {
        red = r;
        Ui.setChip(this, blueChip, !r);
        Ui.setChip(this, redChip, r);
        rebuild();
    }

    private void rebuild() {
        if (brawler == null) return;
        // drop queued thumbnails of the previous view
        thumbs.shutdownNow();
        thumbs = Executors.newSingleThreadExecutor();
        list.removeAllViews();
        List<BrawlerIndex.Group> groups = brawler.groupsFor(skin);
        int parts = 0;
        for (BrawlerIndex.Group g : groups) parts += g.team(red).size();
        status.setText(BrawlerIndex.skinName(skin) + " · способностей: " + groups.size() + " · частей: " + parts
                + "\nТап по картинке — кадры по одному. «Собрать вместе» — все части одной сценой.");
        for (BrawlerIndex.Group g : groups) list.addView(card(g));
        if (groups.isEmpty()) list.addView(Ui.text(this, "У этого вида нет 2D-частей.", 14, Ui.MUTED));
    }

    private LinearLayout card(BrawlerIndex.Group g) {
        int p = Ui.dp(this, 10);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 12)));
        card.setPadding(p, p, p, p);
        LinearLayout.LayoutParams clp = Ui.lp(-1, -2, 0);
        clp.topMargin = Ui.dp(this, 8);
        card.setLayoutParams(clp);

        List<BrawlerIndex.Part> parts = g.team(red);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(Ui.bold(this, g.title(brawler), 16, Ui.ACCENT));
        String sub = parts.size() + " частей";
        if (!g.skin.equals(skin)) sub += " · из стандартного вида";
        int fromTables = 0;
        for (BrawlerIndex.Part x : parts) if (x.fromTables) fromTables++;
        if (fromTables > 0) sub += " · " + fromTables + " по таблицам игры";
        texts.addView(Ui.text(this, sub, 11, Ui.MUTED));
        head.addView(texts, Ui.lp(0, -2, 1));
        TextView play = Ui.button(this, "▶ Собрать вместе", true);
        play.setOnClickListener(v -> {
            Intent i = new Intent(this, SceneActivity.class);
            i.putExtra("vid", vid);
            i.putExtra("key", key);
            i.putExtra("skin", skin);
            i.putExtra("ability", g.ability);
            i.putExtra("buffy", g.buffy);
            i.putExtra("red", red);
            startActivity(i);
        });
        head.addView(play);
        card.addView(head);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, Ui.dp(this, 8), 0, 0);
        hs.addView(row);
        for (BrawlerIndex.Part part : parts) row.addView(thumb(part));
        card.addView(hs);
        return card;
    }

    private LinearLayout thumb(BrawlerIndex.Part part) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        int w = Ui.dp(this, 92);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, -2);
        lp.rightMargin = Ui.dp(this, 6);
        cell.setLayoutParams(lp);
        FrameLayout box = new FrameLayout(this);
        box.setBackground(Ui.round(0xFF2E3344, Ui.dp(this, 8)));
        ImageView img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = Ui.dp(this, 4);
        img.setPadding(pad, pad, pad, pad);
        box.addView(img, new FrameLayout.LayoutParams(-1, -1));
        cell.addView(box, new LinearLayout.LayoutParams(-1, Ui.dp(this, 80)));
        TextView ph = Ui.bold(this, BrawlerIndex.PHASE_NAMES[part.phase], 10, Ui.ACCENT);
        ph.setPadding(0, pad, 0, 0);
        cell.addView(ph);
        TextView name = Ui.text(this, part.label, 10, Ui.TEXT);
        name.setMaxLines(2);
        cell.addView(name);
        cell.setOnClickListener(v -> openFrames(part));

        String ck = part.fileId + "/" + part.export;
        Bitmap c = cache.get(ck);
        if (c != null) {
            img.setImageBitmap(c);
        } else {
            thumbs.execute(() -> {
                try {
                    Sc2 s = BrawlerData.sc(this, data.rows.get(part.fileId));
                    Img im = s.renderExport(part.export, 200);
                    if (im == null) return;
                    Bitmap bm = Decoders.toBitmap(im);
                    cache.put(ck, bm);
                    main.post(() -> img.setImageBitmap(bm));
                } catch (Throwable ignored) {
                    // leave empty
                }
            });
        }
        return cell;
    }

    private void openFrames(BrawlerIndex.Part part) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                Sc2 s = BrawlerData.sc(this, data.rows.get(part.fileId));
                main.post(() -> {
                    FramesActivity.holder = s;
                    Intent i = new Intent(this, FramesActivity.class);
                    i.putExtra("export", part.export);
                    startActivity(i);
                });
            } catch (Throwable e) {
                main.post(() -> android.widget.Toast.makeText(this, "Ошибка: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        thumbs.shutdownNow();
    }
}
