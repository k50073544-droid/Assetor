package com.weker.assetexplorer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.Cave;
import com.weker.assetexplorer.codec.GameDb;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** One brawler: portrait, numbers, skins, every animation, voice lines, gadgets / star powers, and the training cave. */
public final class BrawlerActivity extends Activity {

    private final Handler main = new Handler(Looper.getMainLooper());
    private long vid;
    private GameData gd;
    private GameDb.Brawler br;
    private GameDb.Skin skin;
    private Sfx sfx;
    private LinearLayout skinsRow, animBox, voiceBox;
    private final List<TextView> skinCards = new ArrayList<>();
    private TextView voiceInfo;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        vid = getIntent().getLongExtra("vid", -1);
        gd = GameData.get(this, vid);
        sfx = new Sfx(gd);
        br = gd.db.brawler(getIntent().getStringExtra("brawler"));
        if (br == null) {
            finish();
            return;
        }
        skin = br.skins.isEmpty() ? null : br.skins.get(0);
        int p = Ui.dp(this, 14);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);
        sv.addView(root);

        // header
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView portrait = new ImageView(this);
        portrait.setBackground(Ui.round(HubActivity.dim(GameDb.rarityColor(br.rarity)), Ui.dp(this, 14)));
        int ps = Ui.dp(this, 96);
        head.addView(portrait, new LinearLayout.LayoutParams(ps, ps));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(Ui.dp(this, 12), 0, 0, 0);
        ht.addView(Ui.bold(this, br.name, 24, Ui.TEXT));
        TextView rar = Ui.bold(this, br.rarityName.isEmpty() ? br.code : br.rarityName, 14, GameDb.rarityColor(br.rarity));
        ht.addView(rar);
        TextView stats = Ui.text(this, "", 12, Ui.MUTED);
        ht.addView(stats);
        head.addView(ht, Ui.lp(0, -2, 1));
        root.addView(head);

        TextView cave = Ui.button(this, "⚔  Тренировочная пещера", true);
        cave.setOnClickListener(v -> {
            Intent i = new Intent(this, CaveActivity.class);
            i.putExtra("vid", vid);
            i.putExtra("brawler", br.code);
            if (skin != null) i.putExtra("skin", skin.name);
            startActivity(i);
        });
        LinearLayout.LayoutParams cl = Ui.lp(-1, Ui.dp(this, 50), 0);
        cl.topMargin = Ui.dp(this, 14);
        root.addView(cave, cl);
        TextView view3d = Ui.button(this, "Открыть в 3D (все анимации, текстура скина)", false);
        view3d.setOnClickListener(v -> {
            if (skin != null) HubActivity.openSkin(this, gd, br, skin);
        });
        LinearLayout.LayoutParams vl = Ui.lp(-1, -2, 0);
        vl.topMargin = Ui.dp(this, 8);
        root.addView(view3d, vl);

        section(root, "Скины (" + br.skins.size() + ")");
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        skinsRow = new LinearLayout(this);
        hs.addView(skinsRow);
        root.addView(hs);
        for (GameDb.Skin s : br.skins) skinsRow.addView(skinCard(s));

        section(root, "Анимации — нажми, чтобы посмотреть в 3D");
        animBox = new LinearLayout(this);
        animBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(animBox);

        section(root, "Реплики");
        voiceInfo = Ui.text(this, "", 11, Ui.MUTED);
        root.addView(voiceInfo);
        voiceBox = new LinearLayout(this);
        voiceBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(voiceBox);

        section(root, "Способности");
        StringBuilder ab = new StringBuilder();
        if (!br.gadgets.isEmpty()) ab.append("Гаджеты: ").append(android.text.TextUtils.join(", ", br.gadgets)).append('\n');
        if (!br.starPowers.isEmpty()) ab.append("Звёздные силы: ").append(android.text.TextUtils.join(", ", br.starPowers)).append('\n');
        if (br.hypercharge != null) ab.append("Гиперзаряд: ").append(br.hypercharge).append('\n');
        if (ab.length() == 0) ab.append("Нет данных в cards.csv");
        root.addView(Ui.text(this, ab.toString().trim(), 13, Ui.TEXT));
        setContentView(sv);

        new Thread(() -> {
            Bitmap bm = gd.export(br.portraitFile, br.portraitExport, 320);
            String st;
            try {
                Cave.Weapon w = Cave.weapon(gd.db, br.weapon), u = Cave.weapon(gd.db, br.ulti);
                st = String.format(Locale.ROOT, "Здоровье %d · скорость %.2f кл/с\nАтака: %d урона%s, дальность %.1f кл., патронов %d, перезарядка %.1f с\nСупер: %d урона%s, дальность %.1f кл.",
                        br.hp, br.speed / 300f, w.damage, w.bullets > 1 ? " × " + w.bullets : "", w.range, w.maxCharge, w.reload,
                        u.damage, u.bullets > 1 ? " × " + u.bullets : "", u.range);
            } catch (Throwable e) {
                st = "Здоровье " + br.hp;
            }
            String fst = st;
            main.post(() -> {
                if (bm != null) portrait.setImageBitmap(bm);
                stats.setText(fst);
            });
        }).start();
        selectSkin(skin);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sfx.stopAll();
    }

    private void section(LinearLayout root, String title) {
        TextView t = Ui.bold(this, title, 15, Ui.ACCENT);
        t.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 6));
        root.addView(t);
    }

    private TextView skinCard(GameDb.Skin s) {
        TextView t = Ui.text(this, s.title + (s.priceGems > 0 ? "\n" + s.priceGems + " 💎" : ""), 12, Ui.TEXT);
        t.setGravity(Gravity.CENTER);
        int p = Ui.dp(this, 10);
        t.setPadding(p, p, p, p);
        t.setMaxWidth(Ui.dp(this, 150));
        t.setTag(s);
        t.setOnClickListener(v -> selectSkin(s));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, Ui.dp(this, 64));
        lp.rightMargin = Ui.dp(this, 6);
        t.setLayoutParams(lp);
        skinCards.add(t);
        return t;
    }

    private void selectSkin(GameDb.Skin s) {
        skin = s;
        for (TextView t : skinCards) {
            GameDb.Skin x = (GameDb.Skin) t.getTag();
            int col = HubActivity.dim(GameDb.rarityColor(x.rarity.isEmpty() ? "common" : x.rarity));
            t.setBackground(Ui.round(x == s ? Ui.ACCENT : col, Ui.dp(this, 10)));
            t.setTextColor(x == s ? 0xFF16130A : Ui.TEXT);
        }
        if (s == null) return;
        animBox.removeAllViews();
        animBox.addView(Ui.text(this, "Читаю анимации…", 12, Ui.MUTED));
        new Thread(() -> {
            List<SkinTables.Anim> anims = new ArrayList<>();
            try {
                SkinTables t = SkinTables.get(this, vid);
                Map<String, String> conf = t.conf(s.model, s.texture);
                anims = t.animations(conf);
            } catch (Throwable ignored) {
                // none
            }
            List<SkinTables.Anim> fa = anims;
            main.post(() -> showAnims(s, fa));
        }).start();
        showVoice(s);
    }

    private void showAnims(GameDb.Skin s, List<SkinTables.Anim> anims) {
        if (skin != s) return;
        animBox.removeAllViews();
        if (anims.isEmpty()) {
            animBox.addView(Ui.text(this, "Анимации не найдены в таблицах (skin_confs.csv / animations.csv)", 12, Ui.MUTED));
            return;
        }
        LinearLayout row = null;
        for (int i = 0; i < anims.size(); i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                LinearLayout.LayoutParams rl = Ui.lp(-1, -2, 0);
                rl.bottomMargin = Ui.dp(this, 6);
                animBox.addView(row, rl);
            }
            SkinTables.Anim a = anims.get(i);
            TextView b = Ui.button(this, "▶ " + a.label, false);
            b.setOnClickListener(v -> {
                Db.Row r = gd.row(s.model);
                if (r == null) {
                    Toast.makeText(this, "В архиве нет модели " + s.model, Toast.LENGTH_LONG).show();
                    return;
                }
                Intent in = new Intent(this, Model3dActivity.class);
                in.putExtra("id", r.id);
                in.putExtra("texture", s.texture);
                in.putExtra("title", s.title + " · " + br.name);
                in.putExtra("anim", a.label);
                startActivity(in);
            });
            LinearLayout.LayoutParams bl = Ui.lp(0, -2, 1);
            if (i % 2 == 1) bl.leftMargin = Ui.dp(this, 6);
            row.addView(b, bl);
        }
        if (anims.size() % 2 == 1 && row != null) row.addView(new TextView(this), Ui.lp(0, -2, 1));
    }

    private void showVoice(GameDb.Skin s) {
        voiceBox.removeAllViews();
        Map<String, String> voice = s.voice.isEmpty() ? br.voice : s.voice;
        voiceInfo.setText(s.voice.isEmpty() || s.voice.equals(br.voice) ? "Голос бойца" : "Свой голос скина «" + s.title + "»");
        if (voice.isEmpty()) {
            voiceBox.addView(Ui.text(this, "Реплик нет в characters.csv", 12, Ui.MUTED));
            return;
        }
        for (Map.Entry<String, String> e : voice.entrySet()) {
            List<String> files = gd.db.soundFiles(e.getValue());
            TextView b = Ui.button(this, "🔊 " + e.getKey() + (files.size() > 1 ? "  (" + files.size() + " вар.)" : ""), false);
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            b.setOnClickListener(v -> {
                String f = sfx.play(e.getValue());
                if (f == null) Toast.makeText(this, "Нет звука " + e.getValue() + " в архиве", Toast.LENGTH_SHORT).show();
                else voiceInfo.setText("Играет: " + f);
            });
            LinearLayout.LayoutParams bl = Ui.lp(-1, -2, 0);
            bl.bottomMargin = Ui.dp(this, 6);
            voiceBox.addView(b, bl);
        }
    }
}
