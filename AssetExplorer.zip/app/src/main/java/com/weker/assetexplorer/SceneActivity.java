package com.weker.assetexplorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.weker.assetexplorer.codec.BrawlerIndex;
import com.weker.assetexplorer.codec.GifEncoder;
import com.weker.assetexplorer.codec.Img;
import com.weker.assetexplorer.codec.Scene;
import com.weker.assetexplorer.codec.Sc2;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * All pieces of one ability played together on one stage: start at the brawler (blue dot),
 * flight to the right, then each outcome (hit a brawler / a wall / max range) as its own shot.
 */
public final class SceneActivity extends Activity {

    static final int REQ_GIF = 1, REQ_PNG = 2;
    static final int FPS = 15, PREVIEW_SIDE = 440;
    static final int BG = 0xFF1A1D27;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService render = Executors.newSingleThreadExecutor();
    private final ExecutorService save = Executors.newSingleThreadExecutor();
    private Scene scene;
    private String title = "";
    private boolean[] enabled;
    private boolean markers = true;
    private float speed = 1f;
    private final List<Bitmap> frames = new ArrayList<>();
    private int total;
    private volatile int gen;
    private boolean playing = true;
    private long playStart;
    private double pausedAt;

    private ZoomImageView view;
    private TextView caption, info, playBtn, speedChip, markChip;
    private LinearLayout partsBox;
    private int saveBg = 0xFF1A1D27;
    private boolean saveMarkers = true;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        long vid = getIntent().getLongExtra("vid", -1);
        String key = getIntent().getStringExtra("key");
        String skin = getIntent().getStringExtra("skin");
        int ability = getIntent().getIntExtra("ability", 0);
        boolean buffy = getIntent().getBooleanExtra("buffy", false);
        boolean red = getIntent().getBooleanExtra("red", false);

        int p = Ui.dp(this, 12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(p, p, p, 0);
        TextView head = Ui.bold(this, "Сцена", 18, Ui.TEXT);
        root.addView(head);
        info = Ui.text(this, "Собираю сцену…", 12, Ui.MUTED);
        info.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 6));
        root.addView(info);

        view = new ZoomImageView(this);
        view.setBackground(Ui.round(BG, Ui.dp(this, 12)));
        root.addView(view, new LinearLayout.LayoutParams(-1, Ui.dp(this, 280)));
        caption = Ui.bold(this, "", 13, Ui.ACCENT);
        caption.setGravity(Gravity.CENTER);
        caption.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2));
        root.addView(caption);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        playBtn = Ui.button(this, "❚❚", false);
        playBtn.setOnClickListener(v -> togglePlay());
        LinearLayout.LayoutParams blp = Ui.lp(-2, -2, 0);
        blp.rightMargin = Ui.dp(this, 6);
        controls.addView(playBtn, blp);
        speedChip = Ui.chip(this, "1×");
        speedChip.setOnClickListener(v -> cycleSpeed());
        controls.addView(speedChip);
        markChip = Ui.chip(this, "Метки");
        Ui.setChip(this, markChip, true);
        markChip.setOnClickListener(v -> {
            markers = !markers;
            Ui.setChip(this, markChip, markers);
            rerender();
        });
        controls.addView(markChip);
        TextView spacer = new TextView(this);
        controls.addView(spacer, Ui.lp(0, 1, 1));
        TextView saveBtn = Ui.button(this, "Сохранить", true);
        saveBtn.setOnClickListener(v -> saveMenu());
        controls.addView(saveBtn);
        root.addView(controls);

        TextView legend = Ui.text(this, "Синий круг — боец, красное кольцо — враг, коричневый блок — стена. "
                + "Галочки ниже — какие части показывать (одинаковые варианты выключены, их можно включить).", 11, Ui.MUTED);
        legend.setPadding(0, 0, 0, Ui.dp(this, 4));
        root.addView(legend);

        ScrollView sv = new ScrollView(this);
        partsBox = new LinearLayout(this);
        partsBox.setOrientation(LinearLayout.VERTICAL);
        partsBox.setPadding(0, 0, 0, Ui.dp(this, 16));
        sv.addView(partsBox);
        root.addView(sv, Ui.lp(-1, 0, 1));
        setContentView(root);

        render.execute(() -> {
            try {
                BrawlerData d = BrawlerData.load(this, vid, t -> main.post(() -> info.setText(t)));
                BrawlerIndex.Brawler br = d.index.brawlers.get(key);
                if (br == null) throw new java.io.IOException("боец не найден");
                BrawlerIndex.Group g = null;
                for (BrawlerIndex.Group x : br.groupsFor(skin)) if (x.ability == ability && x.buffy == buffy) g = x;
                if (g == null) throw new java.io.IOException("способность не найдена");
                List<Scene.Item> items = new ArrayList<>();
                for (BrawlerIndex.Part part : g.team(red)) {
                    Sc2 s = BrawlerData.sc(this, d.rows.get(part.fileId));
                    items.add(new Scene.Item(s, part.export, part.phase, part.label));
                }
                Scene sc = new Scene(items);
                if (sc.items.isEmpty()) throw new java.io.IOException("в этих частях нечего рисовать");
                String t = br.name + " · " + g.title(br);
                String sub = BrawlerIndex.skinName(g.skin) + (red ? " · красные" : " · синие") + " · частей: " + sc.items.size()
                        + (sc.rounds.size() > 1 ? " · исходов: " + sc.rounds.size() : "");
                main.post(() -> {
                    scene = sc;
                    title = t;
                    head.setText(t);
                    info.setText(sub);
                    enabled = sc.defaults();
                    fillParts();
                    rerender();
                    playStart = SystemClock.uptimeMillis();
                    main.post(tick);
                });
            } catch (Throwable e) {
                main.post(() -> info.setText("Не получилось собрать: " + e.getMessage()));
            }
        });
    }

    // ------------------------------------------------------------------ parts list
    private void fillParts() {
        partsBox.removeAllViews();
        for (int i = 0; i < scene.items.size(); i++) {
            Scene.Item it = scene.items.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 10)));
            int pad = Ui.dp(this, 6);
            row.setPadding(pad, pad / 2, pad, pad / 2);
            LinearLayout.LayoutParams lp = Ui.lp(-1, -2, 0);
            lp.topMargin = Ui.dp(this, 4);
            CheckBox cb = new CheckBox(this);
            cb.setChecked(enabled[i]);
            int idx = i;
            cb.setOnCheckedChangeListener((v, on) -> {
                enabled[idx] = on;
                rerender();
            });
            row.addView(cb);
            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.addView(Ui.text(this, BrawlerIndex.PHASE_NAMES[it.phase] + " · " + it.label, 13, Ui.TEXT));
            texts.addView(Ui.text(this, scene.timing(it) + "\n" + it.export, 10, Ui.MUTED));
            row.addView(texts, Ui.lp(0, -2, 1));
            row.setOnClickListener(v -> cb.toggle());
            partsBox.addView(row, lp);
        }
    }

    // ------------------------------------------------------------------ rendering & playback
    private void rerender() {
        if (scene == null) return;
        final int g = ++gen;
        final boolean[] en = enabled.clone();
        final boolean mk = markers;
        synchronized (frames) {
            frames.clear();
        }
        total = scene.frameCount(FPS);
        render.execute(() -> {
            try {
                double scale = scene.scaleFor(PREVIEW_SIDE);
                for (int i = 0; i < total; i++) {
                    if (g != gen) return;
                    Img im = scene.render(i / (double) FPS, scale, 1, BG, mk, en);
                    Bitmap bm = Decoders.toBitmap(im);
                    synchronized (frames) {
                        if (g != gen) return;
                        frames.add(bm);
                    }
                }
                scene.clearCache();
            } catch (Throwable e) {
                main.post(() -> info.setText("Ошибка отрисовки: " + e.getMessage()));
            }
        });
    }

    private double now() {
        if (!playing) return pausedAt;
        return (SystemClock.uptimeMillis() - playStart) / 1000.0 * speed;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (scene == null || isFinishing()) return;
            int ready;
            Bitmap bm = null;
            double len = scene.length;
            double t = now() % len;
            int f = Math.min(total - 1, (int) (t * FPS));
            synchronized (frames) {
                ready = frames.size();
                if (ready > 0) bm = frames.get(Math.min(f, ready - 1));
            }
            if (bm != null) view.setFrame(bm);
            Scene.Round r = scene.roundAt(Math.min(t, (ready - 1) / (double) FPS));
            StringBuilder cap = new StringBuilder();
            if (scene.rounds.size() > 1) {
                cap.append("Выстрел ").append(scene.rounds.indexOf(r) + 1).append(" из ").append(scene.rounds.size()).append(": ").append(r.name);
            } else if (!r.name.isEmpty()) {
                cap.append(r.name);
            }
            if (ready < total) cap.append(cap.length() > 0 ? "  ·  " : "").append("готовлю кадры ").append(ready).append("/").append(total);
            else cap.append(cap.length() > 0 ? "  ·  " : "").append(String.format(Locale.ROOT, "%.1f / %.1f c", t, len));
            caption.setText(cap);
            main.postDelayed(this, 1000 / FPS);
        }
    };

    private void togglePlay() {
        if (playing) {
            pausedAt = now();
            playing = false;
            playBtn.setText("▶");
        } else {
            playStart = SystemClock.uptimeMillis() - (long) (pausedAt / speed * 1000);
            playing = true;
            playBtn.setText("❚❚");
        }
    }

    private void cycleSpeed() {
        double t = now();
        speed = speed == 1f ? 0.5f : speed == 0.5f ? 0.25f : 1f;
        speedChip.setText(speed == 1f ? "1×" : speed == 0.5f ? "½×" : "¼×");
        if (playing) playStart = SystemClock.uptimeMillis() - (long) (t / speed * 1000);
        else pausedAt = t;
    }

    // ------------------------------------------------------------------ saving
    private void saveMenu() {
        if (scene == null) return;
        String[] items = {"GIF — тёмный фон, с метками", "GIF — прозрачный фон, без меток", "PNG — текущий кадр, 1024 px"};
        new AlertDialog.Builder(this).setTitle("Сохранить сцену").setItems(items, (d, w) -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            String base = title.replaceAll("[^\\p{L}\\p{N}._ -]", "").trim().replace(' ', '_');
            if (w == 2) {
                pausedAt = now();
                if (playing) togglePlay();
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_TITLE, base + ".png");
                startActivityForResult(i, REQ_PNG);
            } else {
                saveBg = w == 0 ? BG : 0;
                saveMarkers = w == 0;
                i.setType("image/gif");
                i.putExtra(Intent.EXTRA_TITLE, base + ".gif");
                startActivityForResult(i, REQ_GIF);
            }
        }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null || scene == null) return;
        Uri uri = data.getData();
        boolean[] en = enabled.clone();
        int bg = saveBg;
        boolean mk = req == REQ_PNG ? markers : saveMarkers;
        double at = pausedAt % scene.length;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        TextView status = Ui.text(this, "Готовлю…", 13, 0xFF888888);
        int p = Ui.dp(this, 20);
        status.setPadding(p, p, p, p);
        AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Сохраняю").setView(status).setCancelable(false).show();
        save.execute(() -> {
            String msg;
            try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                if (o == null) throw new java.io.IOException("нет доступа");
                if (req == REQ_PNG) {
                    Img im = scene.render(at, scene.scaleFor(1024), 2, mk ? BG : 0, mk, en);
                    Decoders.toBitmap(im).compress(Bitmap.CompressFormat.PNG, 100, o);
                } else {
                    double scale = scene.scaleFor(512);
                    int n = scene.frameCount(FPS);
                    List<int[]> samples = new ArrayList<>();
                    int w = 0, h = 0;
                    for (int i = 0; i < n; i += Math.max(1, n / 12)) {
                        Img im = scene.render(i / (double) FPS, scale, 1, bg, mk, en);
                        samples.add(im.argb);
                        w = im.width;
                        h = im.height;
                    }
                    GifEncoder gif = new GifEncoder(new BufferedOutputStream(o, 1 << 16), w, h, samples, bg == 0 ? -1 : bg & 0xFFFFFF);
                    samples.clear();
                    for (int i = 0; i < n; i++) {
                        Img im = scene.render(i / (double) FPS, scale, 2, bg, mk, en);
                        gif.addFrame(im.argb, Math.round(100f / FPS));
                        int fi = i + 1;
                        main.post(() -> status.setText("Кадр " + fi + " / " + n));
                    }
                    gif.finish();
                }
                msg = "Сохранено";
            } catch (Throwable e) {
                msg = "Ошибка: " + e.getMessage();
            }
            scene.clearCache();
            String m = msg;
            main.post(() -> {
                dlg.dismiss();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        gen++;
        main.removeCallbacks(tick);
        render.shutdownNow();
        save.shutdownNow();
    }
}
