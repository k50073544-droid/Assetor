package com.weker.assetexplorer.codec;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Groups 2D effect exports (effects_brawler*.sc) by brawler, skin and ability, using the game's naming:
 * {@code <brawler>_<skin>_<ability>_<part>[_NN][_flip][_red]}, e.g. shelly_010_atk_trail_01_red,
 * ziggy_def_gadget1_teleport, colt_def_oc_atk_hit (oc = hypercharge).
 */
public final class BrawlerIndex {

    // ------------------------------------------------------------------ abilities
    public static final int A_ATTACK = 0, A_SUPER = 1, A_GADGET1 = 2, A_GADGET2 = 3, A_GADGET = 4,
            A_STAR1 = 5, A_STAR2 = 6, A_STAR = 7, A_HYPER = 8, A_SPAWN = 9, A_KILL = 10, A_LOBBY = 11, A_OTHER = 12;

    public static final String[] ABILITY_NAMES = {
            "Атака", "Супер", "Гаджет 1", "Гаджет 2", "Гаджет", "Звёздная сила 1", "Звёздная сила 2", "Звёздная сила",
            "Гиперзаряд", "Появление", "Убийство / смерть", "Лобби и победа", "Прочее"};

    // ------------------------------------------------------------------ phases (order inside an ability)
    public static final int P_WARN = 0, P_START = 1, P_FLY = 2, P_HIT = 3, P_AREA = 4, P_OTHER = 5;
    public static final String[] PHASE_NAMES = {"прицел", "старт", "полёт", "попадание", "зона", "эффект"};

    /** One export = one animated piece. */
    public static final class Part {
        public long fileId;
        public String file;
        public String export;
        public String brawler, skin;
        public int ability, phase;
        public boolean red, flip, buffy;
        /** linked through the game tables (projectiles_skin.csv etc.), not by name */
        public boolean fromTables;
        /** export name without brawler, skin, ability tokens and team suffix — what is shown under the picture */
        public String label;

        @Override
        public String toString() { return export; }
    }

    /** All parts of one ability for one skin. */
    public static final class Group {
        public int ability;
        public boolean buffy;
        public String skin;
        public final List<Part> parts = new ArrayList<>();

        public String title() {
            return ABILITY_NAMES[ability] + (buffy ? " · баффи" : "");
        }

        /** "Гаджет 1 · Перемотка" when the tables give the name */
        public String title(Brawler b) {
            String n = b == null ? null : b.abilityNames.get(ability);
            return n == null ? title() : title() + " · " + n;
        }

        /** parts for one team (red = enemy colours), ordered by phase then name */
        public List<Part> team(boolean red) {
            List<Part> out = new ArrayList<>();
            for (Part p : parts) if (p.red == red) out.add(p);
            if (out.isEmpty()) for (Part p : parts) if (p.red != red) out.add(p);
            Collections.sort(out, (a, b) -> a.phase != b.phase ? Integer.compare(a.phase, b.phase) : a.export.compareTo(b.export));
            return out;
        }
    }

    public static final class Brawler {
        public String key, name;
        public boolean known;
        public final Set<String> files = new HashSet<>();
        /** skin -> ability groups */
        public final Map<String, List<Group>> skins = new TreeMap<>(BrawlerIndex::compareSkins);
        public final Map<Integer, String> abilityNames = new HashMap<>();
        /** portrait export from characters.csv, may be null */
        public String portrait;
        public int count;

        public List<String> skinList() { return new ArrayList<>(skins.keySet()); }

        /** The skin that has an attack or super (Shelly's base look lives in "010", not "def"). */
        public String defaultSkin() {
            List<Group> def = skins.get("def");
            if (def != null) {
                for (Group g : def) if (g.ability == A_ATTACK || g.ability == A_SUPER) return "def";
            }
            String best = null;
            int bestScore = -1;
            for (Map.Entry<String, List<Group>> e : skins.entrySet()) {
                int s = 0;
                for (Group g : e.getValue()) {
                    if (g.ability == A_ATTACK || g.ability == A_SUPER) s += 1000;
                    s += g.parts.size();
                }
                if (s > bestScore) {
                    bestScore = s;
                    best = e.getKey();
                }
            }
            return best;
        }

        /**
         * Groups to show for a skin. Abilities this skin doesn't redraw (gadgets, hypercharge…) are taken
         * from the standard look, as in the game.
         */
        public List<Group> groupsFor(String skin) {
            List<Group> out = new ArrayList<>();
            List<Group> own = skins.get(skin);
            Set<String> have = new HashSet<>();
            if (own != null) {
                for (Group g : own) {
                    out.add(g);
                    have.add(g.ability + ":" + g.buffy);
                }
            }
            if (!"def".equals(skin) && skins.containsKey("def")) {
                for (Group g : skins.get("def")) {
                    if (!have.contains(g.ability + ":" + g.buffy)) out.add(g);
                }
            }
            Collections.sort(out, (a, b) -> a.ability != b.ability ? Integer.compare(a.ability, b.ability) : Boolean.compare(a.buffy, b.buffy));
            return out;
        }
    }

    public final Map<String, Brawler> brawlers = new TreeMap<>();

    // ------------------------------------------------------------------ names
    /** export prefixes that differ from the effects_brawler_<name>.sc file name */
    static final Map<String, String> ALIAS = new HashMap<>();
    static final Map<String, String> DISPLAY = new HashMap<>();

    static {
        ALIAS.put("primo", "elprimo");
        ALIAS.put("el", "elprimo");
        ALIAS.put("lolla", "lola");
        ALIAS.put("twin", "larrylawrie");
        ALIAS.put("twins", "larrylawrie");
        ALIAS.put("larry", "larrylawrie");
        ALIAS.put("melody", "melodie");
        ALIAS.put("jae", "jaeyong");
        ALIAS.put("mr", "mrp");
        ALIAS.put("samurai", "kenji");
        ALIAS.put("arcade", "8bit");
        ALIAS.put("digger", "moe");

        DISPLAY.put("elprimo", "El Primo");
        DISPLAY.put("mrp", "Mr. P");
        DISPLAY.put("8bit", "8-Bit");
        DISPLAY.put("rt", "R-T");
        DISPLAY.put("larrylawrie", "Larry & Lawrie");
        DISPLAY.put("jaeyong", "Jae-Yong");
    }

    public static String normalizeKey(String s) {
        String k = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        String a = ALIAS.get(k);
        return a != null ? a : k;
    }

    public static String displayName(String key) {
        String d = DISPLAY.get(key);
        if (d != null) return d;
        if (key.isEmpty()) return key;
        return Character.toUpperCase(key.charAt(0)) + key.substring(1);
    }

    /** "def" first, then numbered skins in order, then the rest */
    public static int compareSkins(String a, String b) {
        if (a.equals(b)) return 0;
        if (a.equals("def")) return -1;
        if (b.equals("def")) return 1;
        boolean na = a.matches("\\d+"), nb = b.matches("\\d+");
        if (na && nb) return Integer.compare(Integer.parseInt(a), Integer.parseInt(b));
        if (na) return -1;
        if (nb) return 1;
        return a.compareTo(b);
    }

    public static String skinName(String s) {
        if (s.equals("def")) return "Стандарт";
        if (s.matches("\\d+")) return "Скин " + s;
        return s;
    }

    // ------------------------------------------------------------------ building
    private final Set<String> knownKeys = new HashSet<>();
    /** brawlers that have their own effects_brawler_<key>.sc */
    private final Set<String> fileKeys = new HashSet<>();

    /** Brawler keys that are certainly playable brawlers (file names, characters.csv ItemName). */
    public void addKnown(Collection<String> keys) {
        for (String k : keys) knownKeys.add(normalizeKey(k));
    }

    /** "effects_brawler_shelly.sc" -> "shelly", "effects_brawler.sc" -> null */
    public static String fileBrawler(String fileName) {
        String n = fileName.toLowerCase(Locale.ROOT);
        if (!n.startsWith("effects_brawler_") || !n.endsWith(".sc")) return null;
        String k = n.substring("effects_brawler_".length(), n.length() - 3);
        if (k.matches("\\d*")) return null; // effects_brawler2.sc
        return normalizeKey(k);
    }

    public void add(long fileId, String file, Collection<String> exports) {
        String fb = fileBrawler(file);
        if (fb != null) {
            knownKeys.add(fb);
            fileKeys.add(fb);
        }
        for (String e : exports) {
            Part p = classify(e);
            if (p == null) continue;
            if (fb != null && !p.brawler.equals(fb)) {
                // a few exports in a brawler's own file use another prefix: keep them with the file's brawler
                if (!knownKeys.contains(p.brawler)) p.brawler = fb;
            }
            p.fileId = fileId;
            p.file = file;
            put(p);
        }
    }

    private void put(Part p) {
        Brawler b = brawlers.get(p.brawler);
        if (b == null) {
            b = new Brawler();
            b.key = p.brawler;
            b.name = displayName(p.brawler);
            brawlers.put(p.brawler, b);
        }
        b.files.add(p.file);
        b.count++;
        List<Group> gs = b.skins.get(p.skin);
        if (gs == null) {
            gs = new ArrayList<>();
            b.skins.put(p.skin, gs);
        }
        Group g = null;
        for (Group x : gs) if (x.ability == p.ability && x.buffy == p.buffy) g = x;
        if (g == null) {
            g = new Group();
            g.ability = p.ability;
            g.buffy = p.buffy;
            g.skin = p.skin;
            gs.add(g);
        }
        // the same export in two files (old shared file and new per-brawler file): keep the per-brawler one
        for (int i = 0; i < g.parts.size(); i++) {
            Part o = g.parts.get(i);
            if (o.export.equals(p.export)) {
                if (fileBrawler(p.file) != null && fileBrawler(o.file) == null) g.parts.set(i, p);
                return;
            }
        }
        g.parts.add(p);
    }

    /**
     * Adds what the game tables link to each ability (default-look projectiles such as
     * bullet_shotgun_def_blue_long, area effects) and the Russian names of brawlers and abilities.
     *
     * @param files .sc file name -> (file id, its export names)
     */
    public void apply(GameData gd, Map<String, Long> fileIds, Map<String, Set<String>> exportsByFile) {
        Set<String> heroKeys = new HashSet<>();
        for (GameData.Hero h : gd.heroes.values()) if (fileKeys.contains(h.key)) heroKeys.add(h.key);
        for (GameData.Hero h : gd.heroes.values()) {
            String key = resolve(h, exportsByFile, heroKeys);
            knownKeys.add(key);
            for (GameData.Ref r : h.refs) {
                Set<String> ex = exportsByFile.get(r.file);
                Long id = fileIds.get(r.file);
                if (ex == null || id == null || !ex.contains(r.export)) continue;
                Part p = new Part();
                p.export = r.export;
                p.brawler = key;
                p.skin = "def";
                p.ability = r.ability;
                p.phase = r.phase;
                p.red = r.red;
                p.fromTables = true;
                p.fileId = id;
                p.file = r.file;
                p.label = r.export.replaceAll("(?i)_(blue|red)(?=_|$)", "");
                put(p);
            }
            Brawler b = brawlers.get(key);
            if (b != null) {
                if (h.name != null) b.name = h.name;
                b.abilityNames.putAll(h.abilityNames);
                if (h.portrait != null && !h.portrait.isEmpty()) b.portrait = h.portrait;
            }
        }
    }

    /**
     * The tables call some brawlers by a codename (Cosmo = attractor, Mina = dancer) while the effect files use
     * another, and old default effects use yet another prefix (Janet = jetgirl). Pick the brawler's real key
     * (the one with its own effects file) and fold the codename's pieces into it.
     */
    private String resolve(GameData.Hero h, Map<String, Set<String>> exportsByFile, Set<String> heroKeys) {
        Map<String, Integer> votes = new HashMap<>();
        for (GameData.Ref r : h.refs) {
            Set<String> ex = exportsByFile.get(r.file);
            if (ex == null || !ex.contains(r.export)) continue;
            Part p = classify(r.export);
            if (p != null && brawlers.containsKey(p.brawler)) votes.merge(p.brawler, 1, Integer::sum);
        }
        String key = null;
        if (fileKeys.contains(h.key)) key = h.key;
        for (String n : h.names) if (key == null && fileKeys.contains(n)) key = n;
        String voted = null;
        for (Map.Entry<String, Integer> e : votes.entrySet()) if (voted == null || e.getValue() > votes.get(voted)) voted = e.getKey();
        if (key == null) key = voted;
        if (key == null && brawlers.containsKey(h.key)) key = h.key;
        for (String n : h.names) if (key == null && brawlers.containsKey(n)) key = n;
        if (key == null) key = h.key;
        // pieces filed under the codename belong to this brawler
        List<String> merge = new ArrayList<>();
        if (!h.key.equals(key)) merge.add(h.key);
        for (String n : h.names) if (!n.equals(key)) merge.add(n);
        if (voted != null && !voted.equals(key)) merge.add(voted);
        for (String m : merge) {
            if (fileKeys.contains(m) || heroKeys.contains(m) || !brawlers.containsKey(m)) continue;
            mergeInto(brawlers.remove(m), key);
        }
        return key;
    }

    private void mergeInto(Brawler from, String key) {
        for (List<Group> gs : from.skins.values()) {
            for (Group g : gs) {
                for (Part p : g.parts) {
                    p.brawler = key;
                    put(p);
                }
            }
        }
    }

    /** Drops prefixes that aren't brawlers (particles, shared bits) and marks bosses/event characters. */
    public void finish() {
        List<String> drop = new ArrayList<>();
        for (Brawler b : brawlers.values()) {
            b.known = knownKeys.contains(b.key);
            boolean hasAbility = false;
            for (List<Group> gs : b.skins.values()) {
                for (Group g : gs) if (g.ability <= A_HYPER) hasAbility = true;
            }
            if (!b.known && (!hasAbility || b.count < 6)) drop.add(b.key);
        }
        for (String k : drop) brawlers.remove(k);
    }

    public List<Brawler> sorted() {
        List<Brawler> out = new ArrayList<>(brawlers.values());
        Collections.sort(out, (a, b) -> a.known != b.known ? (a.known ? -1 : 1) : a.name.compareToIgnoreCase(b.name));
        return out;
    }

    // ------------------------------------------------------------------ classification
    static final Set<String> NOT_BRAWLER = new HashSet<>();

    static {
        for (String s : new String[]{"particle", "shadow", "gen", "ground", "warning", "atlas", "test", "fx", "effect",
                "effects", "shared", "common", "debug", "water", "bullet", "spawn", "hit", "ui", "gadget", "area", "glow",
                "dropping", "fireball", "burning", "cannonball", "tex", "projectile", "smoke", "explosion", "prt", "sound",
                "splat", "cactus", "bb", "shotgun", "dynamite", "robot", "boss"}) NOT_BRAWLER.add(s);
    }

    public static Part classify(String export) {
        String[] raw = export.split("_");
        if (raw.length < 2) return null;
        String first = raw[0].toLowerCase(Locale.ROOT);
        if (NOT_BRAWLER.contains(first) || !first.matches("[a-z0-9.]+") || first.matches("\\d+")) return null;
        Part p = new Part();
        p.export = export;
        p.brawler = normalizeKey(first);
        int i = 1;
        // "mr_p_..." / "el_primo_..." style two-word prefixes
        if ((first.equals("mr") || first.equals("el")) && raw.length > 2) i = 2;
        String second = raw[i].toLowerCase(Locale.ROOT);
        if (second.equals("def") || second.matches("\\d{2,4}")) {
            p.skin = second;
            i++;
        } else {
            p.skin = "def";
        }

        List<String> rest = new ArrayList<>();
        for (int k = i; k < raw.length; k++) rest.add(raw[k]);

        int ability = -1;
        int gadgetNo = 0, starNo = 0;
        boolean gadget = false, star = false, hyper = false, ulti = false, atk = false;
        boolean spawn = false, kill = false, lobby = false;
        List<String> labelParts = new ArrayList<>();
        for (String t0 : rest) {
            String t = t0.toLowerCase(Locale.ROOT);
            if (t.equals("red")) { p.red = true; continue; }
            if (t.equals("blue")) continue;
            if (t.equals("flip")) { p.flip = true; labelParts.add("flip"); continue; }
            if (t.equals("buddy") || t.equals("buffy") || t.equals("buffie") || t.equals("buffies")) { p.buffy = true; continue; }
            if (t.equals("oc") || t.equals("hc") || t.startsWith("hyper") || t.startsWith("overcharge")) { hyper = true; continue; }
            if (t.startsWith("gadget")) {
                gadget = true;
                String n = t.substring(6).replace("s", "");
                if (n.equals("1") || n.equals("2")) gadgetNo = Integer.parseInt(n);
                continue;
            }
            if (t.equals("sp") || t.equals("sp1") || t.equals("sp2") || t.startsWith("starpower")) {
                star = true;
                if (t.endsWith("1")) starNo = 1;
                else if (t.endsWith("2")) starNo = 2;
                continue;
            }
            if (t.startsWith("ulti") || t.equals("super")) {
                ulti = true;
                if (!t.equals("ulti") && !t.equals("super")) labelParts.add(t);
                continue;
            }
            if (t.startsWith("atk") || t.equals("attack") || t.equals("weapon")) {
                atk = true;
                if (!t.equals("atk") && !t.equals("attack") && !t.equals("weapon")) labelParts.add(t);
                continue;
            }
            if (t.equals("spawn") || t.equals("respawn") || t.equals("intro")) spawn = true;
            if (t.equals("kill") || t.equals("death") || t.equals("die") || t.equals("dead")) kill = true;
            if (t.equals("lobby") || t.equals("win") || t.equals("lose") || t.equals("mvp") || t.equals("pose")) lobby = true;
            labelParts.add(t0);
        }
        if (hyper) ability = A_HYPER;
        else if (gadget) ability = gadgetNo == 1 ? A_GADGET1 : gadgetNo == 2 ? A_GADGET2 : A_GADGET;
        else if (star) ability = starNo == 1 ? A_STAR1 : starNo == 2 ? A_STAR2 : A_STAR;
        else if (ulti) ability = A_SUPER;
        else if (atk) ability = A_ATTACK;
        else if (spawn) ability = A_SPAWN;
        else if (kill) ability = A_KILL;
        else if (lobby) ability = A_LOBBY;
        else ability = A_OTHER;
        p.ability = ability;
        p.phase = phase(labelParts);
        StringBuilder lb = new StringBuilder();
        for (String s : labelParts) {
            if (lb.length() > 0) lb.append('_');
            lb.append(s);
        }
        if (hyper && (atk || ulti)) lb.insert(0, (atk ? "атака" : "супер") + (lb.length() > 0 ? " · " : ""));
        p.label = lb.length() == 0 ? (ulti ? "супер" : atk ? "атака" : export) : lb.toString();
        return p;
    }

    static int phase(List<String> tokens) {
        int best = P_OTHER;
        for (String t0 : tokens) {
            String t = t0.toLowerCase(Locale.ROOT);
            int ph = -1;
            if (t.startsWith("projectile") || t.startsWith("trail") || t.equals("bullet") || t.equals("missile")
                    || t.equals("proj") || t.equals("keychain") || t.equals("plasmaball") || t.equals("speedline")) ph = P_FLY;
            else if (t.equals("warning") || t.equals("aim") || t.equals("indicator") || t.equals("crit")) ph = P_WARN;
            else if (t.equals("muzzle") || t.equals("start") || t.equals("cast") || t.equals("casting") || t.equals("charge")
                    || t.equals("shoot") || t.equals("launch") || t.equals("use") || t.equals("activate") || t.equals("dash")
                    || t.equals("jump")) ph = P_START;
            else if (t.equals("hit") || t.equals("reached") || t.equals("impact") || t.startsWith("explo") || t.equals("exp")
                    || t.equals("end") || t.equals("splash") || t.equals("burst") || t.equals("land") || t.equals("landing")) ph = P_HIT;
            else if (t.equals("ground") || t.equals("area") || t.equals("zone") || t.equals("cloud") || t.equals("pool")
                    || t.equals("puddle") || t.equals("storm") || t.equals("crack") || t.equals("field")) ph = P_AREA;
            if (ph < 0) continue;
            // the most "concrete" token wins: projectile beats hit (projectile_hit), warning beats ground
            if (best == P_OTHER || rank(ph) > rank(best)) best = ph;
        }
        return best;
    }

    static int rank(int phase) {
        switch (phase) {
            case P_FLY: return 5;
            case P_WARN: return 4;
            case P_HIT: return 3;
            case P_START: return 2;
            case P_AREA: return 1;
            default: return 0;
        }
    }

    /** Cheap test used when listing files: is this .sc an effects file with brawler pieces? */
    public static boolean isEffectsFile(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.startsWith("effects_brawler") && n.endsWith(".sc") && !n.endsWith("_tex.sc");
    }

    /** For debugging/tests: abilities with part counts. */
    public static String describe(Brawler b) {
        StringBuilder sb = new StringBuilder(b.name).append(" [").append(b.key).append("] ");
        Map<String, Integer> m = new LinkedHashMap<>();
        for (Map.Entry<String, List<Group>> e : b.skins.entrySet()) {
            for (Group g : e.getValue()) m.put(e.getKey() + "/" + g.title(b), g.parts.size());
        }
        return sb.append(m).toString();
    }
}
